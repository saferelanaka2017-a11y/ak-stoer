/**
 * @file contexts/AuthContext.tsx
 * سياق المصادقة وإدارة المستخدمين والصلاحيات المخصصة (Admin / Custom Non-Admin Permissions)
 * Authentication and Granular Role-Based Access Control Context
 */

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { User, UserRole, UserPermissions } from '../types';
import { db, getEffectivePermissions } from '../db/database';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  isAdmin: boolean;
  isCashier: boolean;
  users: User[];
  permissions: UserPermissions;
  hasPermission: (key: keyof UserPermissions) => boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  refreshUsers: () => void;
  addUser: (userData: {
    username: string;
    name: string;
    password: string;
    role: UserRole;
    jobTitle?: string;
    phone?: string;
    isActive?: boolean;
    permissions?: UserPermissions;
  }) => { success: boolean; message: string; user?: User };
  updateUser: (
    id: string,
    updates: {
      username?: string;
      name?: string;
      newPassword?: string;
      role?: UserRole;
      jobTitle?: string;
      phone?: string;
      isActive?: boolean;
      permissions?: UserPermissions;
    }
  ) => { success: boolean; message: string; user?: User };
  deleteUser: (id: string) => { success: boolean; message: string };
  canDelete: boolean;
  canViewReports: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Always start with login page showing at start as requested by the user
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(() => db.getUsers());

  const refreshUsers = useCallback(() => {
    const latestUsers = db.getUsers();
    setUsers([...latestUsers]);
    setUser(prev => {
      if (!prev) return null;
      const updatedSelf = latestUsers.find(u => u.id === prev.id);
      if (!updatedSelf || updatedSelf.isActive === false) return null;
      return updatedSelf;
    });
  }, []);

  useEffect(() => {
    const unsubscribe = db.onRemoteUpdate(() => {
      refreshUsers();
    });
    return unsubscribe;
  }, [refreshUsers]);

  const login = (username: string, password: string): boolean => {
    // Password is strictly required — never allow passwordless or empty password login
    if (!username || !username.trim() || !password || !password.trim()) {
      return false;
    }

    const authenticatedUser = db.authenticate(username.trim(), password.trim());
    if (authenticatedUser) {
      setUser(authenticatedUser);
      setUsers([...db.getUsers()]);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const addUser = useCallback(
    (userData: {
      username: string;
      name: string;
      password: string;
      role: UserRole;
      jobTitle?: string;
      phone?: string;
      isActive?: boolean;
      permissions?: UserPermissions;
    }) => {
      const res = db.addUser(userData);
      if (res.success) {
        refreshUsers();
      }
      return res;
    },
    [refreshUsers]
  );

  const updateUser = useCallback(
    (
      id: string,
      updates: {
        username?: string;
        name?: string;
        newPassword?: string;
        role?: UserRole;
        jobTitle?: string;
        phone?: string;
        isActive?: boolean;
        permissions?: UserPermissions;
      }
    ) => {
      const res = db.updateUser(id, updates);
      if (res.success) {
        refreshUsers();
      }
      return res;
    },
    [refreshUsers]
  );

  const deleteUser = useCallback(
    (id: string) => {
      const res = db.deleteUser(id);
      if (res.success) {
        refreshUsers();
      }
      return res;
    },
    [refreshUsers]
  );

  const role = user?.role || null;
  const isAdmin = user?.username?.toLowerCase() === 'admin';
  const isCashier = role === 'cashier';

  const permissions = getEffectivePermissions(user);

  const hasPermission = useCallback(
    (key: keyof UserPermissions): boolean => {
      if (!user) return false;
      if (user.role === 'admin') return true;
      const eff = getEffectivePermissions(user);
      return !!eff[key];
    },
    [user]
  );

  const canDelete = isAdmin || hasPermission('canDelete');
  const canViewReports = isAdmin || hasPermission('viewReports');

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAdmin,
        isCashier,
        users,
        permissions,
        hasPermission,
        login,
        logout,
        refreshUsers,
        addUser,
        updateUser,
        deleteUser,
        canDelete,
        canViewReports
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

