/**
 * @file utils/googleDriveBackup.ts
 * نظام النسخ الاحتياطي السحابي لقاعدة البيانات عبر Google Drive API (خاص بالأدمن)
 * Cloud Database Backup & Restore Integration with Google Drive API (drive.file scope)
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App safely (reuse if already initialized)
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

// Google Workspace OAuth Scopes (Least privilege: drive.file only)
export const SCOPES = [
  'https://www.googleapis.com/auth/drive.file'
];

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => provider.addScope(scope));
provider.setCustomParameters({
  prompt: 'select_account'
});

// In-memory cache for OAuth access token (NEVER stored in localStorage or sessionStorage)
let isSigningIn = false;
let cachedAccessToken: string | null = null;

export interface DriveBackupFile {
  id: string;
  name: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
  description?: string;
}

/**
 * Initialize Firebase Auth state listener and manage in-memory access token
 */
export const initGoogleDriveAuth = (
  onAuthSuccess?: (user: FirebaseUser, token: string) => void,
  onAuthFailure?: (user: FirebaseUser | null) => void
) => {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure(user);
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure(null);
    }
  });
};

/**
 * Sign in with Google via Popup and obtain Google Drive OAuth access token in memory
 */
export const googleSignInForDrive = async (): Promise<{
  user: FirebaseUser;
  accessToken: string;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to obtain Google Drive access token');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error('Google Drive Sign-In Error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Get the in-memory OAuth access token
 */
export const getDriveAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

/**
 * Get current signed-in Firebase user (if any)
 */
export const getCurrentDriveUser = (): FirebaseUser | null => {
  return auth.currentUser;
};

/**
 * Sign out from Google and clear the in-memory access token
 */
export const googleSignOutFromDrive = async (): Promise<void> => {
  await auth.signOut();
  cachedAccessToken = null;
};

/**
 * Find or create the dedicated "AK Store Backups" folder in the user's Google Drive
 */
async function getOrCreateBackupFolder(accessToken: string): Promise<string | null> {
  try {
    const query = encodeURIComponent(
      "mimeType = 'application/vnd.google-apps.folder' and name = 'AK Store Backups' and trashed = false"
    );
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)&spaces=drive`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    if (searchRes.ok) {
      const data = await searchRes.json();
      if (data.files && data.files.length > 0) {
        return data.files[0].id;
      }
    }

    // Create folder if not found
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: 'AK Store Backups',
        mimeType: 'application/vnd.google-apps.folder',
        description: 'مجلد النسخ الاحتياطية لنظام AK Store لإدارة المبيعات ونقاط البيع'
      })
    });

    if (createRes.ok) {
      const folder = await createRes.json();
      return folder.id || null;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * List all AK Store database backup files stored in Google Drive
 */
export const listGoogleDriveBackups = async (): Promise<DriveBackupFile[]> => {
  const accessToken = await getDriveAccessToken();
  if (!accessToken) {
    throw new Error('UNAUTHENTICATED');
  }

  const query = encodeURIComponent(
    "mimeType != 'application/vnd.google-apps.folder' and trashed = false"
  );
  const fields = encodeURIComponent(
    'files(id,name,size,createdTime,modifiedTime,webViewLink,description)'
  );

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=${fields}&orderBy=modifiedTime desc&pageSize=25`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    }
  );

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('UNAUTHENTICATED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to list Google Drive backups: ${errText}`);
  }

  const data = await res.json();
  return (data.files || []) as DriveBackupFile[];
};

/**
 * Upload a new database backup file to Google Drive
 */
export const uploadDatabaseToGoogleDrive = async (
  databaseContent: string,
  storeName: string,
  customFileName?: string
): Promise<DriveBackupFile> => {
  const accessToken = await getDriveAccessToken();
  if (!accessToken) {
    throw new Error('UNAUTHENTICATED');
  }

  const folderId = await getOrCreateBackupFolder(accessToken);
  const now = new Date();
  const dateStamp = now.toISOString().slice(0, 10);
  const timeStamp = now.toTimeString().slice(0, 5).replace(':', '-');
  const safeStore = (storeName || 'AK_Store').replace(/[^\w\u0600-\u06FF\s-]/g, '').trim().replace(/\s+/g, '_');

  const fileName = customFileName || `${safeStore}_Backup_${dateStamp}_${timeStamp}.db`;

  const metadata: Record<string, any> = {
    name: fileName,
    mimeType: 'application/json',
    description: `نسخة احتياطية لقاعدة بيانات ${storeName || 'AK Store'} بتاريخ ${now.toLocaleString('ar-SA')}`
  };

  if (folderId) {
    metadata.parents = [folderId];
  }

  const boundary = '-------AKStoreDriveBackupBoundary' + Date.now();
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    databaseContent +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime,webViewLink,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`
      },
      body: multipartRequestBody
    }
  );

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('UNAUTHENTICATED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Upload failed: ${errText}`);
  }

  return (await res.json()) as DriveBackupFile;
};

/**
 * Overwrite/Update an existing backup file on Google Drive (Requires prior user confirmation in UI)
 */
export const overwriteGoogleDriveBackupFile = async (
  fileId: string,
  databaseContent: string
): Promise<DriveBackupFile> => {
  const accessToken = await getDriveAccessToken();
  if (!accessToken) {
    throw new Error('UNAUTHENTICATED');
  }

  const res = await fetch(
    `https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(fileId)}?uploadType=media&fields=id,name,size,createdTime,modifiedTime,webViewLink,description`,
    {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json; charset=UTF-8'
      },
      body: databaseContent
    }
  );

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('UNAUTHENTICATED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Overwrite failed: ${errText}`);
  }

  return (await res.json()) as DriveBackupFile;
};

/**
 * Download the content of a backup file from Google Drive to restore into local SQLite database
 */
export const downloadGoogleDriveBackupFile = async (fileId: string): Promise<string> => {
  const accessToken = await getDriveAccessToken();
  if (!accessToken) {
    throw new Error('UNAUTHENTICATED');
  }

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    }
  );

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('UNAUTHENTICATED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Download failed: ${errText}`);
  }

  return await res.text();
};

/**
 * Delete a backup file from Google Drive (Requires prior user confirmation in UI)
 */
export const deleteGoogleDriveBackupFile = async (fileId: string): Promise<void> => {
  const accessToken = await getDriveAccessToken();
  if (!accessToken) {
    throw new Error('UNAUTHENTICATED');
  }

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`,
    {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    }
  );

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('UNAUTHENTICATED');
  }

  if (!res.ok && res.status !== 204) {
    const errText = await res.text();
    throw new Error(`Delete failed: ${errText}`);
  }
};
