/**
 * @file components/AKStoreLogo.tsx
 * الشعار الاحترافي الرسمي لـ AK Store (الكريم متجر)
 * يولّد الشعار بصيغة PNG Base64 عالية الدقة (256x256) متوافقة 100% مع جميع الطابعات الحرارية (80mm/58mm) وطابعات A4 وملفات PDF و Word
 */

import React from 'react';

interface LogoPalette {
  bgStart: string;
  bgMid: string;
  bgEnd: string;
  border: string;
  accentStart: string;
  accentEnd: string;
  letterA: string;
  letterK: string;
  pillBg: string;
  pillText: string;
}

const PALETTES: Record<string, LogoPalette> = {
  'royal-blue-gold': {
    bgStart: '#0f172a',
    bgMid: '#1e3a8a',
    bgEnd: '#2563eb',
    border: '#f59e0b',
    accentStart: '#fde68a',
    accentEnd: '#d97706',
    letterA: '#ffffff',
    letterK: '#f59e0b',
    pillBg: '#0f172a',
    pillText: '#ffffff'
  },
  'luxury-black-gold': {
    bgStart: '#090d16',
    bgMid: '#111827',
    bgEnd: '#1e293b',
    border: '#f59e0b',
    accentStart: '#fef08a',
    accentEnd: '#b45309',
    letterA: '#f59e0b',
    letterK: '#ffffff',
    pillBg: '#000000',
    pillText: '#fde68a'
  },
  'emerald-retail': {
    bgStart: '#064e3b',
    bgMid: '#047857',
    bgEnd: '#0d9488',
    border: '#34d399',
    accentStart: '#6ee7b7',
    accentEnd: '#10b981',
    letterA: '#ffffff',
    letterK: '#6ee7b7',
    pillBg: '#022c22',
    pillText: '#ecfdf5'
  },
  'royal-violet': {
    bgStart: '#311068',
    bgMid: '#5b21b6',
    bgEnd: '#db2777',
    border: '#67e8f9',
    accentStart: '#67e8f9',
    accentEnd: '#38bdf8',
    letterA: '#ffffff',
    letterK: '#67e8f9',
    pillBg: '#1e1b4b',
    pillText: '#ffffff'
  }
};

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * توليد صورة شعار PNG Base64 حقيقية ومباشرة عبر HTML5 Canvas لضمان ظهورها 100% في جميع الطابعات الحرارية والورقية
 */
function renderPresetToPngDataUrl(presetId: string): string {
  const pal = PALETTES[presetId] || PALETTES['royal-blue-gold'];
  try {
    if (typeof document !== 'undefined') {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // 1. Background rounded square
        const bgGrad = ctx.createLinearGradient(0, 0, 256, 256);
        bgGrad.addColorStop(0, pal.bgStart);
        bgGrad.addColorStop(0.5, pal.bgMid);
        bgGrad.addColorStop(1, pal.bgEnd);
        drawRoundedRect(ctx, 4, 4, 248, 248, 54);
        ctx.fillStyle = bgGrad;
        ctx.fill();

        // 2. Inner golden/accent border
        drawRoundedRect(ctx, 14, 14, 228, 228, 46);
        ctx.strokeStyle = pal.border;
        ctx.lineWidth = 3.5;
        ctx.stroke();

        // 3. Shopping bag handle arc at top
        ctx.beginPath();
        ctx.arc(128, 72, 30, Math.PI, 0, false);
        ctx.strokeStyle = pal.accentStart;
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.stroke();

        // Handle rivets
        ctx.fillStyle = pal.accentStart;
        ctx.beginPath();
        ctx.arc(98, 74, 5.5, 0, Math.PI * 2);
        ctx.arc(158, 74, 5.5, 0, Math.PI * 2);
        ctx.fill();

        // Top star / diamond
        ctx.beginPath();
        ctx.moveTo(128, 24);
        ctx.lineTo(134, 34);
        ctx.lineTo(128, 44);
        ctx.lineTo(122, 34);
        ctx.closePath();
        ctx.fillStyle = pal.accentStart;
        ctx.fill();

        // 4. Bold "AK" Monogram
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '900 104px "Segoe UI", Arial, sans-serif';

        // Draw "A"
        ctx.fillStyle = pal.letterA;
        ctx.fillText('A', 88, 134);

        // Draw "K"
        ctx.fillStyle = pal.letterK;
        ctx.fillText('K', 168, 134);

        // 5. Bottom "STORE" pill badge
        drawRoundedRect(ctx, 48, 188, 160, 36, 18);
        ctx.fillStyle = pal.pillBg;
        ctx.fill();
        ctx.strokeStyle = pal.border;
        ctx.lineWidth = 2.5;
        ctx.stroke();

        ctx.font = '900 17px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = pal.pillText;
        ctx.fillText('AK STORE', 128, 207);

        return canvas.toDataURL('image/png');
      }
    }
  } catch {
    // Fallback below if SSR
  }

  // Fallback SVG without any url(#gradient) references so even raw SVG prints 100% cleanly
  const cleanSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" width="256" height="256">
    <rect x="4" y="4" width="248" height="248" rx="54" fill="${pal.bgMid}" stroke="${pal.border}" stroke-width="6" />
    <path d="M98 72 A30 30 0 0 1 158 72" fill="none" stroke="${pal.accentStart}" stroke-width="8" stroke-linecap="round" />
    <text x="128" y="152" text-anchor="middle" fill="${pal.letterA}" font-family="Arial, sans-serif" font-size="96" font-weight="900">AK</text>
    <rect x="48" y="188" width="160" height="36" rx="18" fill="${pal.pillBg}" stroke="${pal.border}" stroke-width="2.5" />
    <text x="128" y="212" text-anchor="middle" fill="${pal.pillText}" font-family="Arial, sans-serif" font-size="16" font-weight="900">AK STORE</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(cleanSvg.trim())}`;
}

export const AK_STORE_DEFAULT_LOGO_DATA_URL = renderPresetToPngDataUrl('royal-blue-gold');

export interface AKLogoPreset {
  id: string;
  nameAr: string;
  nameEn: string;
  dataUrl: string;
}

export const AK_STORE_LOGO_PRESETS: AKLogoPreset[] = [
  {
    id: 'royal-blue-gold',
    nameAr: 'الملكي الأزرق والذهبي (الرسمي)',
    nameEn: 'Royal Blue & Gold (Official)',
    dataUrl: AK_STORE_DEFAULT_LOGO_DATA_URL
  },
  {
    id: 'luxury-black-gold',
    nameAr: 'الفخامة السوداء والذهبية',
    nameEn: 'Luxury Obsidian & Gold',
    dataUrl: renderPresetToPngDataUrl('luxury-black-gold')
  },
  {
    id: 'emerald-retail',
    nameAr: 'الزمردي التجاري الحديث',
    nameEn: 'Modern Emerald Retail',
    dataUrl: renderPresetToPngDataUrl('emerald-retail')
  },
  {
    id: 'royal-violet',
    nameAr: 'البنفسجي العصري المتألق',
    nameEn: 'Cyber Violet & Cyan',
    dataUrl: renderPresetToPngDataUrl('royal-violet')
  }
];

/**
 * تحويل أي شعار (سواء كان SVG قديم أو صورة مرفوعة) إلى PNG Base64 متوافق 100% مع الطابعات
 */
export function normalizeLogoForPrint(rawLogoUrl?: string): string {
  if (!rawLogoUrl || !rawLogoUrl.trim()) {
    return AK_STORE_DEFAULT_LOGO_DATA_URL;
  }
  const trimmed = rawLogoUrl.trim();
  // إذا كان الشعار المحفوظ قديماً بصيغة SVG يحتوي على تدرجات لونية قد تختفي في الطابعة، نستبدله بنسخة الـ PNG المعتمدة
  if (trimmed.startsWith('data:image/svg+xml')) {
    if (trimmed.includes('lxBg')) return AK_STORE_LOGO_PRESETS[1].dataUrl;
    if (trimmed.includes('emBg')) return AK_STORE_LOGO_PRESETS[2].dataUrl;
    if (trimmed.includes('vlBg')) return AK_STORE_LOGO_PRESETS[3].dataUrl;
    return AK_STORE_DEFAULT_LOGO_DATA_URL;
  }
  return trimmed;
}

/**
 * تحويل أي ملف صورة يرفعه المستخدم إلى PNG Base64 واضح ومضغوط بمقاس 256x256 لضمان سرعة الحفظ والطباعة
 */
export function convertUploadedImageFileToPngDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const rawDataUrl = reader.result as string;
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const maxDim = 256;
          let w = img.naturalWidth || 256;
          let h = img.naturalHeight || 256;
          if (w > maxDim || h > maxDim) {
            const ratio = Math.min(maxDim / w, maxDim / h);
            w = Math.max(1, Math.round(w * ratio));
            h = Math.max(1, Math.round(h * ratio));
          }
          const canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, w, h);
            resolve(canvas.toDataURL('image/png'));
            return;
          }
        } catch {
          // fallback to rawDataUrl
        }
        resolve(rawDataUrl);
      };
      img.onerror = () => resolve(rawDataUrl);
      img.src = rawDataUrl;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

interface AKStoreLogoProps {
  logoUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const AKStoreLogo: React.FC<AKStoreLogoProps> = ({
  logoUrl,
  size = 'md',
  className = ''
}) => {
  const sizeClasses = {
    xs: 'w-6 h-6 rounded-lg',
    sm: 'w-9 h-9 rounded-xl',
    md: 'w-11 h-11 rounded-2xl',
    lg: 'w-16 h-16 rounded-2xl',
    xl: 'w-20 h-20 rounded-3xl'
  }[size];

  const resolvedSrc = normalizeLogoForPrint(logoUrl);

  return (
    <div
      className={`relative inline-flex items-center justify-center overflow-hidden select-none shrink-0 shadow-md ${sizeClasses} ${className}`}
    >
      <img
        src={resolvedSrc}
        alt="AK Store Logo"
        className="w-full h-full object-contain"
        referrerPolicy="no-referrer"
      />
    </div>
  );
};

