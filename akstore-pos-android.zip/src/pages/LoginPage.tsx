/**
 * @file pages/LoginPage.tsx
 * شاشة تسجيل الدخول العصرية والمبسطة (Modern & Simple Login)
 * تعتمد على كومبو بوكس (Combobox) لاختيار اسم المستخدم مع إخفاء حقل كلمة المرور لتسجيل الدخول السريع والسلس
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Store,
  Users,
  ChevronDown,
  Check,
  ArrowRight,
  ShieldCheck,
  ShoppingCart,
  Lock,
  Key,
  Clock,
  Search,
  Sparkles,
  Eye,
  EyeOff,
  Download,
  Smartphone,
  Monitor,
  Mail,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import { db, normalizeSyncEmailClient } from '../db/database';
import { User } from '../types';
import { getLicenseState, LicenseState } from '../utils/licenseManager';
import { ActivationModal } from '../components/ActivationModal';
import { AKStoreLogo } from '../components/AKStoreLogo';
import {
  normalizeEnglishPasswordInput,
  handleEnglishPasswordKeyDown
} from '../utils/keyboardNormalizer';

interface LoginPageProps {
  onOpenWindowsModal?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onOpenWindowsModal }) => {
  const { login, users: authUsers } = useAuth();
  const { t, tr, language, setLanguage, dir, settings, showToast, syncEmail, emailSyncLocked, setSyncEmail } = useApp();
  const [emailInput, setEmailInput] = useState<string>(() => syncEmail || db.getSyncEmail() || '');
  const [isSyncingEmail, setIsSyncingEmail] = useState<boolean>(false);

  // Load available users with Manager first and Admin as the very last user
  const availableUsers: User[] = useMemo(() => {
    const raw = authUsers && authUsers.length > 0 ? authUsers : db.getUsers();
    const managers: User[] = [];
    const others: User[] = [];
    const admins: User[] = [];
    for (const u of raw) {
      const uname = (u.username || '').toLowerCase();
      if (uname === 'admin' || u.id === 'user-admin') {
        admins.push(u);
      } else if (u.id === 'user-manager' || uname === 'manager') {
        managers.push(u);
      } else {
        others.push(u);
      }
    }
    return [...managers, ...others, ...admins];
  }, [authUsers]);

  const [selectedUsername, setSelectedUsername] = useState<string>(
    availableUsers[0]?.username || 'manager'
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [showPasswordText, setShowPasswordText] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [licenseState, setLicenseState] = useState<LicenseState>(getLicenseState());
  const [isActivationOpen, setIsActivationOpen] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const passwordInputRef = useRef<HTMLInputElement>(null);

  const isTrialLocked = licenseState.isTrialExpired && !licenseState.isActivated;

  // Selected user details
  const currentUser = useMemo(() => {
    return (
      availableUsers.find(
        (u) =>
          u.username.toLowerCase() === selectedUsername.toLowerCase() ||
          u.id.toLowerCase() === selectedUsername.toLowerCase()
      ) || availableUsers[0]
    );
  }, [availableUsers, selectedUsername]);

  // Keep selectedUsername synced if the first user (General Manager) had his username customized
  useEffect(() => {
    if (currentUser && currentUser.username !== selectedUsername) {
      setSelectedUsername(currentUser.username);
    }
  }, [currentUser, selectedUsername]);

  // Filtered users for combobox search
  const filteredUsers = useMemo(() => {
    if (!searchTerm.trim()) return availableUsers;
    const term = searchTerm.toLowerCase().trim();
    return availableUsers.filter(
      (u) =>
        u.name.toLowerCase().includes(term) ||
        u.username.toLowerCase().includes(term) ||
        (u.role === 'admin' ? 'مدير admin' : 'كاشير cashier').includes(term)
    );
  }, [availableUsers, searchTerm]);

  // Close combobox when clicking outside & sync license state
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    function handleLicenseChange() {
      setLicenseState(getLicenseState());
    }
    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('akstore-license-updated', handleLicenseChange);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('akstore-license-updated', handleLicenseChange);
    };
  }, []);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (isDropdownOpen) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    } else {
      setSearchTerm('');
    }
  }, [isDropdownOpen]);

  const handleSelectUser = (user: User) => {
    setSelectedUsername(user.username);
    setPassword('');
    setIsDropdownOpen(false);
    setError('');
    setTimeout(() => {
      passwordInputRef.current?.focus();
    }, 50);
  };

  const performLogin = (usernameToUse: string, passwordToUse: string) => {
    setError('');
    setIsLoading(true);

    try {
      const userObj =
        availableUsers.find(
          (u) =>
            u.username.toLowerCase() === usernameToUse.toLowerCase() ||
            u.id.toLowerCase() === usernameToUse.toLowerCase()
        ) || currentUser;

      if (userObj && userObj.isActive === false) {
        const suspendedMsg = tr(
          'هذا الحساب موقوف مؤقتاً من قِبل مدير النظام، يرجى مراجعة الإدارة',
          'This user account is currently suspended by the administrator'
        );
        setError(suspendedMsg);
        showToast(suspendedMsg, 'error');
        setIsLoading(false);
        return;
      }

      const targetUsername = userObj?.username || usernameToUse;
      const success = login(targetUsername, passwordToUse);

      if (!success) {
        const errMsg = tr(
          'كلمة المرور غير صحيحة، يرجى التحقق وإعادة المحاولة',
          'Incorrect password, please verify and try again'
        );
        setError(errMsg);
        showToast(errMsg, 'error');
        setIsLoading(false);
        setTimeout(() => {
          passwordInputRef.current?.focus();
          passwordInputRef.current?.select();
        }, 50);
      } else {
        showToast(
          tr(`أهلاً بك، ${userObj?.name || targetUsername}`, `Welcome, ${userObj?.name || targetUsername}`),
          'success'
        );
      }
    } catch {
      setError(tr('حدث خطأ أثناء تسجيل الدخول', 'An error occurred during login'));
      setIsLoading(false);
    }
  };

  const handleLinkEmail = async () => {
    const clean = normalizeSyncEmailClient(emailInput);
    if (!clean) {
      showToast(
        tr(
          'يرجى إدخال بريد إلكتروني صحيح (مثال: name@gmail.com) للمزامنة بين الكمبيوتر والموبايل',
          'Please enter a valid email address (e.g. name@gmail.com) to sync between PC and mobile'
        ),
        'error'
      );
      return;
    }
    setIsSyncingEmail(true);
    await setSyncEmail(clean);
    setEmailInput(clean);
    setIsSyncingEmail(false);
    showToast(
      tr(
        `تم ربط ومزامنة بياناتك الخاصة بالبريد (${clean}) بنجاح!`,
        `Successfully linked and synced private data for (${clean})!`
      ),
      'success'
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetUsername = currentUser?.username || selectedUsername;
    if (!targetUsername.trim()) {
      const msg = tr('يرجى اختيار اسم المستخدم من القائمة', 'Please select a user from the list');
      setError(msg);
      showToast(msg, 'error');
      return;
    }
    if (!password.trim()) {
      const msg = tr('يرجى كتابة كلمة المرور للدخول إلى النظام', 'Please enter your password to sign in to the system');
      setError(msg);
      showToast(msg, 'error');
      passwordInputRef.current?.focus();
      return;
    }

    // If user typed a valid sync email in the box, link & pull latest data for that email before checking login
    const typedCleanEmail = normalizeSyncEmailClient(emailInput);
    if (typedCleanEmail && typedCleanEmail !== syncEmail) {
      setIsLoading(true);
      await setSyncEmail(typedCleanEmail);
    }

    performLogin(targetUsername, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-[#edf2f7] via-[#e5ecf4] to-[#edf3f8] relative overflow-hidden select-none">
      {/* Modern Ambient Glow Elements */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-400/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-[32rem] h-[32rem] bg-indigo-400/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-sky-200/20 rounded-full blur-[120px] pointer-events-none" />

      {/* Main Modern Minimalist Card */}
      <div className="neu-card rounded-3xl w-full max-w-md p-6 sm:p-8 relative z-10 border border-white/80 shadow-[0_20px_50px_rgba(0,0,0,0.07)] backdrop-blur-xl">
        {/* Language Toggle on Login Card */}
        <div className={`flex ${dir === 'rtl' ? 'justify-end' : 'justify-start'} mb-2`}>
          <button
            type="button"
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="neu-button px-2.5 py-1 rounded-xl text-[11px] font-bold text-slate-600 hover:text-blue-600 cursor-pointer flex items-center gap-1.5"
          >
            <span>🌐</span>
            <span>{language === 'ar' ? 'English (LTR)' : 'العربية (RTL)'}</span>
          </button>
        </div>

        {/* Header with AK Store Identity & Professional Logo */}
        <div className="text-center mb-7">
          <div className="relative inline-block mb-3.5 group">
            <div className="absolute -inset-1.5 bg-gradient-to-tr from-blue-600 via-indigo-500 to-amber-500 rounded-3xl opacity-35 blur-md group-hover:opacity-60 transition-opacity duration-300" />
            <AKStoreLogo
              logoUrl={settings.logoUrl}
              size="xl"
              className="relative ring-4 ring-white shadow-xl transform group-hover:scale-105 transition-all duration-300"
            />
          </div>
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {settings.storeName || 'AK Store'}
            </h1>
            <span className="px-2 py-0.5 rounded-lg text-[10px] font-black tracking-widest uppercase bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs">
              PRO
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1.5 font-semibold flex items-center justify-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>
              {tr(
                'الكريم متجر — نظام نقاط البيع وإدارة المبيعات والمخزون',
                'Al-Kareem Store — Point of Sale & Retail Management System'
              )}
            </span>
          </p>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="mb-5 p-3 rounded-2xl bg-red-500/10 border border-red-300/60 text-red-600 text-xs text-center font-bold animate-shake">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Private Per-Email Sync Box (Shown Once Until Synced, or When Admin Unlocks It) */}
          {!emailSyncLocked && (
            <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-200/80 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-extrabold text-blue-900 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  <span>
                    {tr(
                      'البريد الإلكتروني للمزامنة الخاصة (كمبيوتر ⇄ تليفون):',
                      'Personal Sync Email (PC ⇄ Mobile):'
                    )}
                  </span>
                </label>
                {syncEmail ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {tr('مرتبط ومعزول', 'Linked & Private')}
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                    {tr('محلي فقط', 'Local Only')}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <input
                  type="email"
                  dir="ltr"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="example@gmail.com"
                  className="flex-1 px-3 py-2 rounded-xl bg-white border border-blue-200 text-xs font-mono font-bold text-slate-800 outline-none focus:border-blue-500 text-left"
                />
                <button
                  type="button"
                  disabled={isSyncingEmail}
                  onClick={handleLinkEmail}
                  className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer shrink-0 shadow-xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncingEmail ? 'animate-spin' : ''}`} />
                  <span>{tr('ربط ومزامنة', 'Link & Sync')}</span>
                </button>
              </div>

              <p className="text-[10px] text-slate-500 leading-relaxed">
                {tr(
                  '🔒 يظهر هذا الحقل مرة واحدة فقط عند الربط، وبمجرد المزامنة بين الكمبيوتر والتليفون يختفي تلقائياً.',
                  '🔒 Appears once for initial pairing and automatically hides after syncing.'
                )}
              </p>
            </div>
          )}

          {/* Modern Combobox (حقل اختيار المستخدم المنسدل فقط) */}
          <div className="relative" ref={dropdownRef}>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-blue-600" />
                <span>{tr('اسم المستخدم', 'Username')}</span>
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                {availableUsers.length} {tr('مستخدمين متاحين', 'Available Users')}
              </span>
            </div>

            {/* Combobox Trigger Card */}
            <button
              type="button"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full p-3 rounded-2xl bg-white/90 hover:bg-white border border-slate-200 hover:border-blue-400 shadow-sm transition-all duration-200 flex items-center justify-between cursor-pointer group text-right outline-none focus:ring-2 focus:ring-blue-500/30"
            >
              <div className="flex items-center gap-3 overflow-hidden">
                {/* User Avatar */}
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold shadow-sm shrink-0 transition-transform group-hover:scale-105 ${
                    currentUser?.role === 'admin'
                      ? 'bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-blue-500/20'
                      : 'bg-gradient-to-tr from-emerald-600 to-teal-600 shadow-emerald-500/20'
                  }`}
                >
                  {currentUser?.name ? currentUser.name.charAt(0) : 'U'}
                </div>

                {/* User Information */}
                <div className="truncate text-right">
                  <div className="text-sm font-bold text-slate-800 truncate">
                    {currentUser?.name || selectedUsername}
                  </div>
                  <div className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                    <span className="font-mono text-slate-400">@{currentUser?.username || selectedUsername}</span>
                    <span>•</span>
                    <span
                      className={`font-semibold ${
                        currentUser?.role === 'admin' ? 'text-blue-600' : 'text-emerald-600'
                      }`}
                    >
                      {currentUser?.role === 'admin' ? tr('مدير النظام', 'System Admin') : tr('كاشير مبيعات', 'Sales Cashier')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Dropdown Indicator */}
              <div className="w-8 h-8 rounded-xl bg-slate-100/80 group-hover:bg-blue-50 flex items-center justify-center text-slate-400 group-hover:text-blue-600 transition-colors shrink-0 mr-1">
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-300 ${
                    isDropdownOpen ? 'rotate-180 text-blue-600' : ''
                  }`}
                />
              </div>
            </button>

            {/* Combobox Dropdown Menu */}
            {isDropdownOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 z-50 rounded-2xl p-2 shadow-2xl border border-white/95 bg-white/95 backdrop-blur-xl max-h-72 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
                {/* Search Bar inside Combobox */}
                <div className="relative mb-2">
                  <input
                    ref={searchInputRef}
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={tr('ابحث عن اسم المستخدم...', 'Search username...')}
                    className="w-full pl-3 pr-8 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700 outline-none focus:border-blue-500 focus:bg-white transition-colors"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute top-2.5 right-2.5" />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="text-[10px] text-slate-400 hover:text-slate-600 absolute top-2 left-2.5 bg-slate-200/60 hover:bg-slate-200 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      {tr('مسح', 'Clear')}
                    </button>
                  )}
                </div>

                {/* List of Users */}
                <div className="overflow-y-auto space-y-1.5 pr-0.5 max-h-56">
                  {filteredUsers.length === 0 ? (
                    <div className="text-center py-5 text-xs text-slate-400">
                      {tr('لا يوجد مستخدم يطابق البحث', 'No matching user found')}
                    </div>
                  ) : (
                    filteredUsers.map((u) => {
                      const isSelected = u.username.toLowerCase() === selectedUsername.toLowerCase();
                      return (
                        <div
                          key={u.id || u.username}
                          onClick={() => handleSelectUser(u)}
                          className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition-all duration-150 ${
                            isSelected
                              ? 'bg-blue-50 text-blue-800 border border-blue-200/80 font-bold'
                              : 'hover:bg-slate-100/80 text-slate-700 border border-transparent'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            <div
                              className={`w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0 ${
                                u.role === 'admin'
                                  ? 'bg-gradient-to-tr from-blue-600 to-indigo-600'
                                  : 'bg-gradient-to-tr from-emerald-600 to-teal-600'
                              }`}
                            >
                              {u.name.charAt(0)}
                            </div>
                            <div className="truncate text-right">
                              <div className="text-xs font-bold leading-tight truncate">{u.name}</div>
                              <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                                <span className="font-mono">@{u.username}</span>
                                <span>•</span>
                                <span
                                  className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                                    u.role === 'admin'
                                      ? 'bg-blue-100/70 text-blue-700'
                                      : 'bg-emerald-100/70 text-emerald-700'
                                  }`}
                                >
                                  {u.role === 'admin' ? tr('مدير', 'Admin') : tr('كاشير', 'Cashier')}
                                </span>
                              </div>
                            </div>
                          </div>

                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Mandatory Password Input (Always Visible & Never Defaulted) */}
          <div className="pt-1">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-blue-600" />
                <span>{tr('كلمة المرور', 'Password')}</span>
                <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                {tr('مطلوب للدخول', 'Required to sign in')}
              </span>
            </div>
            <div className="relative">
              <input
                ref={passwordInputRef}
                type={showPasswordText ? 'text' : 'password'}
                dir="ltr"
                lang="en"
                inputMode="text"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={password}
                onKeyDown={(e) =>
                  handleEnglishPasswordKeyDown(e, password, (nextVal) => {
                    setPassword(nextVal);
                    if (error) setError('');
                  })
                }
                onChange={(e) => {
                  setPassword(normalizeEnglishPasswordInput(e.target.value));
                  if (error) setError('');
                }}
                autoComplete="new-password"
                className="w-full pl-10 pr-10 py-3 rounded-2xl border border-slate-200 hover:border-blue-400 bg-white/90 focus:bg-white text-sm font-mono font-bold text-slate-800 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-sm transition-all text-left"
                placeholder={tr('اكتب كلمة المرور هنا...', 'Enter your password here...')}
              />
              <Lock
                className={`w-4 h-4 text-slate-400 absolute top-3.5 ${
                  dir === 'rtl' ? 'right-3.5' : 'left-3.5'
                } pointer-events-none`}
              />
              <button
                type="button"
                onClick={() => setShowPasswordText(!showPasswordText)}
                title={showPasswordText ? tr('إخفاء كلمة المرور', 'Hide password') : tr('إظهار كلمة المرور', 'Show password')}
                className={`absolute top-3 ${
                  dir === 'rtl' ? 'left-3' : 'right-3'
                } text-slate-400 hover:text-blue-600 transition-colors p-0.5 rounded cursor-pointer`}
              >
                {showPasswordText ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Modern Login Action Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="neu-button-primary w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 text-sm font-bold shadow-lg shadow-blue-500/20 cursor-pointer transform active:scale-98 hover:-translate-y-0.5 transition-all disabled:opacity-50"
          >
            <span>{isLoading ? tr('جاري التحميل...', 'Signing in...') : tr('دخول إلى النظام', 'Sign In to System')}</span>
            <ArrowRight className={`w-4 h-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
          </button>
        </form>

        {/* License & Trial Footer */}
        <div className="mt-6 pt-4 border-t border-slate-200/70 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5">
            {licenseState.isActivated ? (
              <span className="text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200/60">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>{tr('مرخص مدى الحياة', 'Lifetime Licensed')}</span>
              </span>
            ) : (
              <span className="text-amber-800 font-bold flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200/60">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>
                  {tr(`تجريبي (متبقي: ${licenseState.remainingHours}س و ${licenseState.remainingMinutes}د)`, `Trial (${licenseState.remainingHours}h ${licenseState.remainingMinutes}m left)`)}
                </span>
              </span>
            )}
          </div>

          {currentUser?.username?.toLowerCase() === 'admin' && (
            <button
              type="button"
              onClick={() => setIsActivationOpen(true)}
              className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Key className="w-3.5 h-3.5" />
              <span>{licenseState.isActivated ? tr('بيانات التفعيل', 'License Info') : tr('إدخال السيريل', 'Enter Serial')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Activation / Lock Modal */}
      <ActivationModal
        isOpen={isTrialLocked || isActivationOpen}
        isMandatory={isTrialLocked}
        onClose={() => setIsActivationOpen(false)}
        licenseState={licenseState}
        onRefreshLicense={() => setLicenseState(getLicenseState())}
      />
    </div>
  );
};
