/**
 * @file pages/DashboardPage.tsx
 * لوحة البيانات والتحليلات المالية الرئيسية (Dashboard)
 * تعرض إجمالي المبيعات اليومية والشهرية ومخطط أداء المبيعات الأسبوعي التفاعلي باستخدام مكتبة Recharts
 */

import React, { useMemo, useState, useEffect } from 'react';
import {
  TrendingUp,
  CreditCard,
  CalendarClock,
  Package,
  ShoppingCart,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle,
  MessageCircle,
  BellRing,
  BarChart3,
  Activity,
  Layers,
  Receipt,
  Calendar,
  Eye,
  Award,
  Wallet,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { InstallmentPlan } from '../types';
import { db } from '../db/database';
import { WeeklyInstallmentsAlertModal } from '../components/WeeklyInstallmentsAlertModal';
import { InstallmentReminderModal } from '../components/InstallmentReminderModal';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import {
  getApproachingInstallments,
  formatWhatsAppPhone,
  generateReminderMessage,
  openSmartWhatsAppModal,
  ApproachingInstallment
} from '../utils/installmentAlerts';

interface DashboardPageProps {
  onNavigate: (tab: string) => void;
}

type ChartViewType = 'area' | 'bar' | 'composed';
type InvoiceFilterType = 'all' | 'today' | 'week';

const WEEKLY_ALERT_SNOOZE_KEY = 'pos_dashboard_weekly_installments_snoozed';
const LOW_STOCK_ALERT_SNOOZE_KEY = 'pos_dashboard_low_stock_alert_snoozed';

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const {
    sales,
    products,
    expenses,
    installmentPlans,
    formatCurrency,
    settings,
    tr,
    language,
    showToast,
    openInvoiceModal,
    refreshData
  } = useApp();

  const [chartType, setChartType] = useState<ChartViewType>('area');
  const [invoiceFilter, setInvoiceFilter] = useState<InvoiceFilterType>('all');
  const [isWeeklyAlertOpen, setIsWeeklyAlertOpen] = useState<boolean>(false);
  const [isLowStockBannerExpanded, setIsLowStockBannerExpanded] = useState<boolean>(true);
  const [isLowStockBannerDismissed, setIsLowStockBannerDismissed] = useState<boolean>(false);
  const [lowStockFilterType, setLowStockFilterType] = useState<'all' | 'out' | 'low'>('all');
  const [selectedReminderPlan, setSelectedReminderPlan] = useState<{
    plan: InstallmentPlan;
    installmentId: string;
  } | null>(null);

  // Helper to get local YYYY-MM-DD date string accurately
  const toDateKey = (dateInput: Date | string): string => {
    const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    if (isNaN(d.getTime())) {
      return typeof dateInput === 'string' ? dateInput.split('T')[0] : '';
    }
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayDate = new Date();
  const todayStr = toDateKey(todayDate);

  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterdayStr = toDateKey(yesterdayDate);

  const currentYearMonth = todayStr.substring(0, 7);

  // Automated Approaching Installments for This Week (next 7 days + overdue)
  const urgentInstallments = useMemo(() => {
    return getApproachingInstallments(installmentPlans, 7);
  }, [installmentPlans]);

  // Automated Low Stock Products (stock <= minStockAlert) sorted by lowest stock first
  const lowStockProducts = useMemo(() => {
    return products
      .filter((p) => p.stock <= p.minStockAlert)
      .sort((a, b) => a.stock - b.stock);
  }, [products]);

  const outOfStockProductsCount = useMemo(
    () => lowStockProducts.filter((p) => p.stock <= 0).length,
    [lowStockProducts]
  );

  const filteredLowStockProducts = useMemo(() => {
    if (lowStockFilterType === 'out') {
      return lowStockProducts.filter((p) => p.stock <= 0);
    }
    if (lowStockFilterType === 'low') {
      return lowStockProducts.filter((p) => p.stock > 0 && p.stock <= p.minStockAlert);
    }
    return lowStockProducts;
  }, [lowStockProducts, lowStockFilterType]);

  // Automatically trigger the Weekly Installments Alert System when opening the Dashboard
  useEffect(() => {
    if (urgentInstallments.length === 0) return;
    const isSnoozed = sessionStorage.getItem(WEEKLY_ALERT_SNOOZE_KEY) === 'true';
    if (!isSnoozed) {
      setIsWeeklyAlertOpen(true);
    }
  }, [urgentInstallments.length]);

  // Automatically notify user when products reach minimum stock threshold on Dashboard load
  useEffect(() => {
    if (lowStockProducts.length === 0) return;
    const isSnoozed = sessionStorage.getItem(LOW_STOCK_ALERT_SNOOZE_KEY) === 'true';
    if (!isSnoozed) {
      sessionStorage.setItem(LOW_STOCK_ALERT_SNOOZE_KEY, 'true');
      showToast(
        tr(
          `تنبيه المخزون: يوجد ${lowStockProducts.length} منتج وصل للحد الأدنى للمخزون (${outOfStockProductsCount} نفد بالكامل)`,
          `Low Stock Alert: ${lowStockProducts.length} product(s) reached minimum stock (${outOfStockProductsCount} out of stock)`
        ),
        'error'
      );
    }
  }, [lowStockProducts.length, outOfStockProductsCount]);

  const handleCloseWeeklyAlert = (snoozeForSession?: boolean) => {
    if (snoozeForSession) {
      sessionStorage.setItem(WEEKLY_ALERT_SNOOZE_KEY, 'true');
    }
    setIsWeeklyAlertOpen(false);
  };

  const handleQuickPayFromWidget = (item: ApproachingInstallment) => {
    const ok = db.payInstallmentItem(
      item.planId,
      item.installment.id,
      item.amount,
      tr('تم التحصيل من لوحة التحكم', 'Collected from Dashboard')
    );
    if (ok) {
      refreshData();
      showToast(
        tr(
          `تم سداد القسط #${item.installment.installmentNumber} للعميل "${item.customerName}" بقيمة ${formatCurrency(item.amount)} بنجاح!`,
          `Installment #${item.installment.installmentNumber} for "${item.customerName}" marked as paid!`
        ),
        'success'
      );
    }
  };

  // Weekly 7-Day Sales Performance Data for Recharts
  const weeklyChartData = useMemo(() => {
    const dayBuckets: {
      dateKey: string;
      dayName: string;
      shortDate: string;
      fullLabel: string;
      sales: number;
      profit: number;
      ordersCount: number;
      itemsSold: number;
      isToday: boolean;
    }[] = [];

    const bucketMap: Record<string, (typeof dayBuckets)[0]> = {};

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = toDateKey(d);
      const dayName = d.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
        weekday: 'short'
      });
      const shortDate = d.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
        day: 'numeric',
        month: 'short'
      });
      const entry = {
        dateKey: key,
        dayName,
        shortDate,
        fullLabel: `${dayName} (${shortDate})`,
        sales: 0,
        profit: 0,
        ordersCount: 0,
        itemsSold: 0,
        isToday: key === todayStr
      };
      dayBuckets.push(entry);
      bucketMap[key] = entry;
    }

    sales.forEach((invoice) => {
      const sKey = toDateKey(invoice.date);
      const bucket = bucketMap[sKey];
      if (bucket) {
        bucket.sales += invoice.grandTotal;
        bucket.ordersCount += 1;

        let invoiceCost = 0;
        let invoiceItemsQty = 0;
        invoice.items.forEach((item) => {
          invoiceCost += (item.product?.costPrice || 0) * item.quantity;
          invoiceItemsQty += item.quantity;
        });

        const invProfit = Math.max(0, invoice.grandTotal - invoice.taxTotal - invoiceCost);
        bucket.profit += invProfit;
        bucket.itemsSold += invoiceItemsQty;
      }
    });

    return dayBuckets.map((b) => ({
      ...b,
      sales: Math.round(b.sales * 100) / 100,
      profit: Math.round(b.profit * 100) / 100
    }));
  }, [sales, language, todayStr]);

  // Aggregated Daily, Weekly, and Monthly KPI Stats
  const stats = useMemo(() => {
    let todayRev = 0;
    let todayOrders = 0;
    let todayCashRev = 0;
    let todayCardRev = 0;
    let yesterdayRev = 0;

    let monthRev = 0;
    let monthOrders = 0;
    let monthCost = 0;

    sales.forEach((sale) => {
      const saleDateKey = toDateKey(sale.date);
      if (saleDateKey === todayStr) {
        todayRev += sale.grandTotal;
        todayOrders += 1;
        if (sale.paymentMethod === 'cash') {
          todayCashRev += sale.grandTotal;
        } else {
          todayCardRev += sale.grandTotal;
        }
      }
      if (saleDateKey === yesterdayStr) {
        yesterdayRev += sale.grandTotal;
      }
      if (saleDateKey.startsWith(currentYearMonth)) {
        monthRev += sale.grandTotal;
        monthOrders += 1;
        sale.items.forEach((item) => {
          monthCost += (item.product?.costPrice || 0) * item.quantity;
        });
      }
    });

    // Expenses for current month
    let monthExpenses = 0;
    expenses.forEach((exp) => {
      if (exp.date.startsWith(currentYearMonth)) {
        monthExpenses += exp.amount;
      }
    });

    const monthProfit = Math.max(0, monthRev - monthCost - monthExpenses);
    const todayAvgOrder = todayOrders > 0 ? todayRev / todayOrders : 0;
    const dailyGrowthPct =
      yesterdayRev > 0
        ? Math.round(((todayRev - yesterdayRev) / yesterdayRev) * 100)
        : todayRev > 0
        ? 100
        : 0;

    // Weekly totals from weeklyChartData
    const weekTotalRev = weeklyChartData.reduce((acc, d) => acc + d.sales, 0);
    const weekTotalProfit = weeklyChartData.reduce((acc, d) => acc + d.profit, 0);
    const weekTotalOrders = weeklyChartData.reduce((acc, d) => acc + d.ordersCount, 0);
    const weekTotalItems = weeklyChartData.reduce((acc, d) => acc + d.itemsSold, 0);
    const weekDailyAverage = Math.round(weekTotalRev / 7);

    const bestDay = weeklyChartData.reduce(
      (max, d) => (d.sales > max.sales ? d : max),
      weeklyChartData[0] || { dayName: '-', shortDate: '-', sales: 0 }
    );

    // Installments status
    let pendingInstallmentsTotal = 0;
    let overdueCount = 0;
    installmentPlans.forEach((plan) => {
      plan.installments.forEach((inst) => {
        if (inst.status === 'pending' || inst.status === 'overdue') {
          pendingInstallmentsTotal += inst.amount;
          if (new Date(inst.dueDate) < new Date(todayStr)) {
            overdueCount += 1;
          }
        }
      });
    });

    // Low stock
    const lowStockCount = products.filter((p) => p.stock <= p.minStockAlert).length;

    return {
      todayRev,
      todayOrders,
      todayCashRev,
      todayCardRev,
      todayAvgOrder,
      yesterdayRev,
      dailyGrowthPct,
      monthRev,
      monthOrders,
      monthProfit,
      monthExpenses,
      weekTotalRev,
      weekTotalProfit,
      weekTotalOrders,
      weekTotalItems,
      weekDailyAverage,
      bestDay,
      pendingInstallmentsTotal,
      overdueCount,
      lowStockCount
    };
  }, [sales, products, expenses, installmentPlans, todayStr, yesterdayStr, currentYearMonth, weeklyChartData]);

  // Filtered Recent Sales Invoices for the Dashboard Table
  const filteredRecentSales = useMemo(() => {
    const weekKeys = new Set(weeklyChartData.map((d) => d.dateKey));
    return [...sales]
      .filter((s) => {
        const key = toDateKey(s.date);
        if (invoiceFilter === 'today') return key === todayStr;
        if (invoiceFilter === 'week') return weekKeys.has(key);
        return true;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 6);
  }, [sales, invoiceFilter, todayStr, weeklyChartData]);

  const handleQuickWhatsApp = (item: (typeof urgentInstallments)[0]) => {
    const formatted = formatWhatsAppPhone(item.customerPhone);
    if (!formatted) {
      showToast(tr('رقم هاتف العميل غير صحيح', 'Invalid customer phone number'), 'error');
      return;
    }

    const msg = generateReminderMessage({
      customerName: item.customerName,
      installmentNumber: item.installment.installmentNumber,
      amount: item.amount,
      dueDate: item.dueDate,
      currencySymbol: settings.currencySymbol || 'ج.م',
      storeName: settings.storeName || tr('المتجر', 'Store'),
      storePhone: settings.storePhone,
      daysDiff: item.daysDiff,
      templateType:
        item.urgency === 'overdue' ? 'overdue' : item.urgency === 'today' ? 'due_today' : 'gentle'
    });

    openSmartWhatsAppModal({
      customerName: item.customerName,
      phone: item.customerPhone,
      message: msg,
      title: tr('تذكير واتساب بموعد القسط', 'WhatsApp Installment Reminder')
    });
  };

  // Custom Recharts Tooltip
  const renderCustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload || !payload.length) return null;
    const dataPoint = payload[0]?.payload;
    if (!dataPoint) return null;

    return (
      <div className="bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-2xl p-3.5 shadow-xl text-xs space-y-2 min-w-[200px]">
        <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
          <span className="font-black text-slate-800">
            {dataPoint.dayName} · {dataPoint.shortDate}
          </span>
          {dataPoint.isToday && (
            <span className="text-[10px] font-bold text-blue-600">
              {tr('اليوم', 'Today')}
            </span>
          )}
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500 font-medium">
              {tr('إجمالي المبيعات:', 'Total Sales:')}
            </span>
            <span className="font-black text-blue-600 tabular-nums">
              {formatCurrency(dataPoint.sales)}
            </span>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500 font-medium">
              {tr('صافي الربح التقديري:', 'Net Profit:')}
            </span>
            <span className="font-bold text-emerald-600 tabular-nums">
              {formatCurrency(dataPoint.profit)}
            </span>
          </div>

          <div className="flex items-center justify-between gap-4 pt-1 border-t border-slate-100 text-[11px]">
            <span className="text-slate-500">
              {tr('عدد الفواتير:', 'Invoices:')}
            </span>
            <span className="font-bold text-slate-700 tabular-nums">
              {dataPoint.ordersCount} {tr('فاتورة', 'inv')} ({dataPoint.itemsSold} {tr('قطعة', 'items')})
            </span>
          </div>
        </div>
      </div>
    );
  };

  const currentMonthName = todayDate.toLocaleDateString(
    language === 'ar' ? 'ar-EG' : 'en-US',
    { month: 'long', year: 'numeric' }
  );

  return (
    <div className="space-y-6">
      {/* Top Header & Quick Actions Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-black text-slate-800 tracking-tight">
              {tr('لوحة بيانات ومؤشرات المبيعات (Dashboard)', 'Sales Analytics & Performance Dashboard')}
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {tr(
              `ملخص فوري لإجمالي المبيعات اليومية والشهرية (${currentMonthName}) ومخطط أداء المبيعات على مدار الأسبوع`,
              `Live summary of daily & monthly sales (${currentMonthName}) with weekly Recharts performance analytics`
            )}
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {lowStockProducts.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setIsLowStockBannerDismissed(false);
                setIsLowStockBannerExpanded(true);
              }}
              className="px-3.5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white flex items-center gap-2 text-xs font-bold shadow-sm transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <AlertTriangle className="w-4 h-4 animate-pulse" />
              <span>
                {tr('تنبيه الحد الأدنى للمخزون', 'Low Stock Alert')} ({lowStockProducts.length})
              </span>
            </button>
          )}
          {urgentInstallments.length > 0 && (
            <button
              type="button"
              onClick={() => setIsWeeklyAlertOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-2 text-xs font-bold shadow-sm transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <BellRing className="w-4 h-4 animate-bounce" />
              <span>
                {tr('تنبيهات أقساط الأسبوع', 'Weekly Due Installments')} ({urgentInstallments.length})
              </span>
            </button>
          )}
          <button
            onClick={() => onNavigate('pos')}
            className="neu-button-primary px-4 py-2.5 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer whitespace-nowrap shrink-0"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{tr('فتح شاشة البيع (POS)', 'Open POS Terminal')}</span>
          </button>
          <button
            onClick={() => onNavigate('sales-invoices')}
            className="neu-button px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Receipt className="w-3.5 h-3.5 text-blue-600" />
            <span>{tr('فواتير المبيعات', 'Sales Invoices')}</span>
          </button>
          <button
            onClick={() => onNavigate('reports')}
            className="neu-button px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer whitespace-nowrap shrink-0"
          >
            <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{tr('التقارير التفصيلية', 'Detailed Reports')}</span>
          </button>
        </div>
      </div>

      {/* Automatic Low Stock Alert Banner & Interactive Restock Widget */}
      {lowStockProducts.length > 0 && !isLowStockBannerDismissed && (
        <div className="neu-card p-5 rounded-3xl border-2 border-red-400/80 bg-red-50/40 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start sm:items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-md shrink-0">
                <AlertTriangle className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-black text-red-900 text-sm sm:text-base">
                    {tr(
                      'تنبيه تلقائي: منتجات وصلت للحد الأدنى للمخزون (Low Stock Alert)',
                      'Automatic Low Stock Alert: Products Reached Minimum Threshold'
                    )}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-lg bg-red-600 text-white text-[11px] font-extrabold tabular-nums">
                    {lowStockProducts.length} {tr('صنف يحتاج توريد', 'items need restock')}
                  </span>
                  {outOfStockProductsCount > 0 && (
                    <span className="px-2.5 py-0.5 rounded-lg bg-red-900 text-white text-[11px] font-extrabold tabular-nums">
                      {outOfStockProductsCount} {tr('نفد بالكامل (0)', 'Out of Stock (0)')}
                    </span>
                  )}
                </div>
                <p className="text-xs text-red-700/90 mt-1 font-medium">
                  {tr(
                    'وصلت هذه الأصناف إلى الحد الأدنى المسموح به في المخزون أو نفدت تماماً. يُنصح بإصدار فاتورة مشتريات أو تعديل الأرصدة.',
                    'These items have reached their minimum stock alert threshold or ran out completely.'
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap shrink-0">
              <button
                type="button"
                onClick={() => onNavigate('products')}
                className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <Package className="w-3.5 h-3.5" />
                <span>{tr('عرض في جدول المنتجات', 'View in Products Table')}</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('purchases')}
                className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 hover:text-blue-600 flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-blue-600" />
                <span>{tr('توريد مشتريات', 'Restock / Purchase')}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsLowStockBannerExpanded(!isLowStockBannerExpanded)}
                className="neu-button px-3 py-2 rounded-xl text-xs font-bold text-slate-600 cursor-pointer"
              >
                {isLowStockBannerExpanded ? tr('طي القائمة', 'Collapse') : tr('عرض الأصناف', 'Expand')}
              </button>
              <button
                type="button"
                onClick={() => setIsLowStockBannerDismissed(true)}
                className="px-2.5 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-red-600 cursor-pointer"
                title={tr('إخفاء مؤقتاً', 'Dismiss temporarily')}
              >
                ✕
              </button>
            </div>
          </div>

          {isLowStockBannerExpanded && (
            <div className="space-y-3 pt-2 border-t border-red-200/70">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setLowStockFilterType('all')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                      lowStockFilterType === 'all'
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-white/80 text-slate-600 hover:bg-white'
                    }`}
                  >
                    {tr('الكل', 'All')} ({lowStockProducts.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLowStockFilterType('out')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                      lowStockFilterType === 'out'
                        ? 'bg-red-800 text-white shadow-xs'
                        : 'bg-white/80 text-slate-600 hover:bg-white'
                    }`}
                  >
                    {tr('نفد بالكامل (0)', 'Out of Stock (0)')} ({outOfStockProductsCount})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLowStockFilterType('low')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                      lowStockFilterType === 'low'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-white/80 text-slate-600 hover:bg-white'
                    }`}
                  >
                    {tr('وصل للحد الأدنى', 'Reached Minimum')} (
                    {lowStockProducts.length - outOfStockProductsCount})
                  </button>
                </div>

                <span className="text-[11px] font-semibold text-red-700">
                  {tr(
                    'اضغط على أي منتج للانتقال إلى جدول المنتجات وتحديث رصيده',
                    'Click any product to open the Products table and update stock'
                  )}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-h-64 overflow-y-auto pr-1">
                {filteredLowStockProducts.map((product) => {
                  const isOut = product.stock <= 0;
                  return (
                    <div
                      key={product.id}
                      onClick={() => onNavigate('products')}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                        isOut
                          ? 'bg-red-100/90 border-red-400 hover:bg-red-100'
                          : 'bg-white/90 border-red-300/80 hover:border-red-500'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="font-extrabold text-red-950 text-xs truncate" title={product.name}>
                            {product.name}
                          </p>
                          <span className="text-[10px] text-slate-500 font-mono block">
                            {product.barcode} · {product.category}
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold shrink-0 ${
                            isOut
                              ? 'bg-red-700 text-white animate-pulse'
                              : 'bg-red-100 text-red-700 border border-red-300'
                          }`}
                        >
                          {isOut ? tr('نفد تماماً', 'Out of Stock') : tr('حد أدنى', 'Low Stock')}
                        </span>
                      </div>

                      <div className="mt-3 pt-2 border-t border-red-200/60 flex items-center justify-between text-[11px]">
                        <div>
                          <span className="text-slate-500">{tr('المتوفر:', 'Stock:')} </span>
                          <strong className="font-black text-red-600 tabular-nums">
                            {product.stock} {product.unit}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500">{tr('الحد الأدنى:', 'Min:')} </span>
                          <strong className="font-bold text-slate-700 tabular-nums">
                            {product.minStockAlert} {product.unit}
                          </strong>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Primary KPI Grid: Daily Sales, Monthly Sales, Weekly Sales, Due Installments */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Daily Sales Total Card (إجمالي المبيعات اليومية) */}
        <div className="neu-card p-5 rounded-3xl flex flex-col justify-between border border-blue-200/60">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs text-slate-500 font-bold block mb-1">
                {tr('إجمالي المبيعات اليومية', 'Daily Sales Total')}
              </span>
              <span className="text-2xl font-black text-slate-900 tabular-nums tracking-tight block">
                {formatCurrency(stats.todayRev)}
              </span>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-sm shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-slate-600">
              <span>
                {tr('فواتير اليوم:', "Today's Invoices:")}{' '}
                <strong className="font-bold text-slate-800 tabular-nums">{stats.todayOrders}</strong>
              </span>
              <span
                className={`inline-flex items-center gap-0.5 font-bold tabular-nums ${
                  stats.dailyGrowthPct >= 0 ? 'text-emerald-600' : 'text-amber-600'
                }`}
              >
                {stats.dailyGrowthPct >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                {stats.dailyGrowthPct >= 0 ? `+${stats.dailyGrowthPct}%` : `${stats.dailyGrowthPct}%`}{' '}
                {tr('عن الأمس', 'vs yesterday')}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>
                {tr('نقدي:', 'Cash:')}{' '}
                <span className="text-slate-600 font-semibold tabular-nums">
                  {formatCurrency(stats.todayCashRev)}
                </span>
              </span>
              <span>·</span>
              <span>
                {tr('شبكة/آجل:', 'Card/Credit:')}{' '}
                <span className="text-slate-600 font-semibold tabular-nums">
                  {formatCurrency(stats.todayCardRev)}
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* 2. Monthly Sales Total Card (إجمالي المبيعات الشهرية) */}
        <div className="neu-card p-5 rounded-3xl flex flex-col justify-between border border-emerald-200/60">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs text-slate-500 font-bold block mb-1">
                {tr('إجمالي المبيعات الشهرية', 'Monthly Sales Total')}
              </span>
              <span className="text-2xl font-black text-blue-600 tabular-nums tracking-tight block">
                {formatCurrency(stats.monthRev)}
              </span>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">{tr('صافي ربح الشهر:', 'Monthly Net Profit:')}</span>
              <span className="font-bold text-emerald-600 tabular-nums">
                {formatCurrency(stats.monthProfit)}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>
                {tr('إجمالي الفواتير:', 'Total Invoices:')}{' '}
                <strong className="text-slate-700 tabular-nums">{stats.monthOrders}</strong>
              </span>
              <span>·</span>
              <span>{currentMonthName}</span>
            </div>
          </div>
        </div>

        {/* 3. Weekly Sales Performance Summary Card (إجمالي مبيعات الأسبوع) */}
        <div className="neu-card p-5 rounded-3xl flex flex-col justify-between">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs text-slate-500 font-bold block mb-1">
                {tr('أداء المبيعات خلال الأسبوع', '7-Day Weekly Sales')}
              </span>
              <span className="text-2xl font-black text-slate-800 tabular-nums tracking-tight block">
                {formatCurrency(stats.weekTotalRev)}
              </span>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-indigo-500/15 text-indigo-600 flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">{tr('المتوسط اليومي:', 'Daily Average:')}</span>
              <span className="font-bold text-indigo-600 tabular-nums">
                {formatCurrency(stats.weekDailyAverage)}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>
                {tr('أعلى يوم:', 'Peak Day:')}{' '}
                <strong className="text-slate-700">{stats.bestDay.dayName}</strong>
              </span>
              <span>·</span>
              <span className="tabular-nums">
                {stats.weekTotalItems} {tr('قطعة مباعة', 'items sold')}
              </span>
            </div>
          </div>
        </div>

        {/* 4. Installments & Inventory Status Card */}
        <div
          onClick={() => {
            if (urgentInstallments.length > 0) {
              setIsWeeklyAlertOpen(true);
            } else {
              onNavigate('installments');
            }
          }}
          className="neu-card p-5 rounded-3xl flex flex-col justify-between cursor-pointer hover:shadow-md transition-shadow border border-amber-200/70"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs text-slate-500 font-bold block mb-1">
                {tr('الأقساط المستحقة والمخزون', 'Installments & Stock')}
              </span>
              <span className="text-2xl font-black text-amber-600 tabular-nums tracking-tight block">
                {formatCurrency(stats.pendingInstallmentsTotal)}
              </span>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-amber-500/15 text-amber-600 flex items-center justify-center shrink-0">
              <CalendarClock className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">{tr('أقساط هذا الأسبوع:', 'Due This Week:')}</span>
              <span
                className={`font-bold tabular-nums ${
                  urgentInstallments.length > 0 ? 'text-amber-700' : 'text-emerald-600'
                }`}
              >
                {urgentInstallments.length > 0
                  ? tr(`${urgentInstallments.length} أقساط مستحقة`, `${urgentInstallments.length} due`)
                  : tr('منتظم بالكامل', 'All on time')}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>{tr('نواقص المخزون:', 'Low Stock:')}</span>
              <span
                className={`font-bold tabular-nums ${
                  stats.lowStockCount > 0 ? 'text-red-500' : 'text-slate-600'
                }`}
              >
                {stats.lowStockCount} {tr('أصناف', 'items')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Weekly Sales Performance Recharts Section */}
      <div className="neu-card p-5 sm:p-6 rounded-3xl space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200/70">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              <h3 className="font-black text-slate-800 text-base">
                {tr(
                  'مخطط أداء المبيعات والأرباح على مدار الأسبوع (Recharts)',
                  'Weekly Sales & Profit Performance Chart (Last 7 Days)'
                )}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {tr(
                `تحليل بياني يومي لإجمالي المبيعات وصافي الأرباح وعدد الفواتير خلال آخر 7 أيام بالـ ${settings.currencySymbol}`,
                `Day-by-day graphical breakdown of total sales, net profit, and invoice volume in ${settings.currencySymbol}`
              )}
            </p>
          </div>

          {/* Interactive Chart Type Segmented Switcher */}
          <div className="flex items-center gap-1 p-1 rounded-2xl neu-pressed self-start md:self-auto">
            <button
              type="button"
              onClick={() => setChartType('area')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                chartType === 'area'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tr('مخطط مساحي (Area)', 'Area Chart')}
            </button>
            <button
              type="button"
              onClick={() => setChartType('bar')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                chartType === 'bar'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tr('مخطط أعمدة (Bar)', 'Bar Chart')}
            </button>
            <button
              type="button"
              onClick={() => setChartType('composed')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                chartType === 'composed'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tr('مبيعات وفواتير (مركب)', 'Sales & Orders')}
            </button>
          </div>
        </div>

        {/* Summary KPI Strip Inside Chart Panel */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="neu-pressed px-3.5 py-2.5 rounded-2xl">
            <span className="text-[11px] text-slate-500 block">
              {tr('إجمالي مبيعات 7 أيام', '7-Day Total Sales')}
            </span>
            <span className="text-sm sm:text-base font-black text-blue-600 tabular-nums">
              {formatCurrency(stats.weekTotalRev)}
            </span>
          </div>
          <div className="neu-pressed px-3.5 py-2.5 rounded-2xl">
            <span className="text-[11px] text-slate-500 block">
              {tr('صافي ربح الأسبوع', '7-Day Net Profit')}
            </span>
            <span className="text-sm sm:text-base font-black text-emerald-600 tabular-nums">
              {formatCurrency(stats.weekTotalProfit)}
            </span>
          </div>
          <div className="neu-pressed px-3.5 py-2.5 rounded-2xl">
            <span className="text-[11px] text-slate-500 block">
              {tr('متوسط المبيعات اليومي', 'Daily Sales Average')}
            </span>
            <span className="text-sm sm:text-base font-black text-slate-800 tabular-nums">
              {formatCurrency(stats.weekDailyAverage)}
            </span>
          </div>
          <div className="neu-pressed px-3.5 py-2.5 rounded-2xl">
            <span className="text-[11px] text-slate-500 block">
              {tr('أعلى يوم مبيعات', 'Peak Sales Day')}
            </span>
            <span className="text-sm sm:text-base font-black text-indigo-600 tabular-nums">
              {stats.bestDay.dayName} ({formatCurrency(stats.bestDay.sales)})
            </span>
          </div>
        </div>

        {/* Recharts Canvas */}
        <div className="h-80 w-full pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'area' ? (
              <AreaChart data={weeklyChartData} margin={{ top: 15, right: 20, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="weeklySalesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.38} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="weeklyProfitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.32} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#cbd5e1" strokeOpacity={0.6} />
                <XAxis
                  dataKey="fullLabel"
                  tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={renderCustomTooltip} />
                <Legend
                  verticalAlign="top"
                  height={32}
                  formatter={(value) => (
                    <span className="text-xs font-bold text-slate-700">{value}</span>
                  )}
                />
                {stats.weekDailyAverage > 0 && (
                  <ReferenceLine
                    y={stats.weekDailyAverage}
                    stroke="#6366f1"
                    strokeDasharray="4 4"
                    label={{
                      value: tr('المتوسط اليومي', 'Daily Avg'),
                      position: 'insideTopRight',
                      fill: '#4f46e5',
                      fontSize: 10,
                      fontWeight: 700
                    }}
                  />
                )}
                <Area
                  type="monotone"
                  dataKey="sales"
                  name={tr('إجمالي المبيعات اليومية', 'Daily Sales')}
                  stroke="#2563eb"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#weeklySalesGrad)"
                  activeDot={{ r: 6, strokeWidth: 2, stroke: '#ffffff' }}
                />
                <Area
                  type="monotone"
                  dataKey="profit"
                  name={tr('صافي الربح اليومي', 'Daily Net Profit')}
                  stroke="#10b981"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#weeklyProfitGrad)"
                  activeDot={{ r: 5, strokeWidth: 2, stroke: '#ffffff' }}
                />
              </AreaChart>
            ) : chartType === 'bar' ? (
              <BarChart data={weeklyChartData} margin={{ top: 15, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#cbd5e1" strokeOpacity={0.6} />
                <XAxis
                  dataKey="fullLabel"
                  tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={renderCustomTooltip} />
                <Legend
                  verticalAlign="top"
                  height={32}
                  formatter={(value) => (
                    <span className="text-xs font-bold text-slate-700">{value}</span>
                  )}
                />
                <Bar
                  dataKey="sales"
                  name={tr('إجمالي المبيعات اليومية', 'Daily Sales')}
                  fill="#2563eb"
                  radius={[8, 8, 0, 0]}
                  maxBarSize={38}
                />
                <Bar
                  dataKey="profit"
                  name={tr('صافي الربح اليومي', 'Daily Net Profit')}
                  fill="#10b981"
                  radius={[8, 8, 0, 0]}
                  maxBarSize={38}
                />
              </BarChart>
            ) : (
              <ComposedChart data={weeklyChartData} margin={{ top: 15, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#cbd5e1" strokeOpacity={0.6} />
                <XAxis
                  dataKey="fullLabel"
                  tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="left"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: '#d97706' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={renderCustomTooltip} />
                <Legend
                  verticalAlign="top"
                  height={32}
                  formatter={(value) => (
                    <span className="text-xs font-bold text-slate-700">{value}</span>
                  )}
                />
                <Bar
                  yAxisId="left"
                  dataKey="sales"
                  name={tr('إجمالي المبيعات', 'Total Sales')}
                  fill="#2563eb"
                  radius={[8, 8, 0, 0]}
                  maxBarSize={40}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="ordersCount"
                  name={tr('عدد الفواتير اليومية', 'Invoices Count')}
                  stroke="#d97706"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#d97706' }}
                />
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* 7-Day Daily Breakdown Cards Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 pt-2 border-t border-slate-200/60">
          {weeklyChartData.map((day) => {
            const isPeak = stats.bestDay.dateKey === day.dateKey && day.sales > 0;
            return (
              <div
                key={day.dateKey}
                className={`p-3 rounded-2xl border text-xs transition-all ${
                  day.isToday
                    ? 'bg-blue-50/70 border-blue-300 shadow-xs'
                    : isPeak
                    ? 'bg-emerald-50/60 border-emerald-200'
                    : 'bg-white/60 border-slate-200/70'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-800">{day.dayName}</span>
                  <span className="text-[10px] text-slate-400 tabular-nums">{day.shortDate}</span>
                </div>
                <div className="font-black text-slate-900 text-sm tabular-nums">
                  {formatCurrency(day.sales)}
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span className="tabular-nums">
                    {day.ordersCount} {tr('فاتورة', 'inv')}
                  </span>
                  {day.isToday ? (
                    <span className="font-bold text-blue-600">{tr('اليوم', 'Today')}</span>
                  ) : isPeak ? (
                    <span className="font-bold text-emerald-600">{tr('الأعلى', 'Peak')}</span>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Urgent Approaching Installments This Week Alert Widget */}
      {urgentInstallments.length > 0 && (
        <div className="neu-card p-5 rounded-3xl border border-amber-300/80 bg-gradient-to-r from-amber-50/40 via-white/80 to-white">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/60">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
                <BellRing className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2 flex-wrap">
                  <span>
                    {tr(
                      'تنبيهات العملاء الذين اقترب موعد استحقاق أقساطهم هذا الأسبوع',
                      'Customers with Installments Due This Week'
                    )}
                  </span>
                  <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md tabular-nums">
                    {urgentInstallments.length} {tr('أقساط مستحقة', 'Due')}
                  </span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  {tr(
                    'متابعة فورية لأقساط هذا الأسبوع (خلال 7 أيام) والأقساط المتأخرة مع إمكانية السداد المباشر أو التذكير عبر واتساب',
                    'Track installments due within 7 days or overdue with 1-click collection or WhatsApp reminder'
                  )}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap shrink-0">
              <button
                type="button"
                onClick={() => setIsWeeklyAlertOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <BellRing className="w-3.5 h-3.5" />
                <span>{tr('عرض نافذة تنبيهات الأسبوع كاملة', 'Open Weekly Alerts Popup')}</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('installments')}
                className="text-xs text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <span>{tr('إدارة الأقساط', 'Installments Hub')}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
            {urgentInstallments.slice(0, 6).map((item) => {
              const isOverdue = item.urgency === 'overdue';
              const isToday = item.urgency === 'today';

              return (
                <div
                  key={`${item.planId}-${item.installment.id}`}
                  className={`p-3.5 rounded-2xl border flex flex-col justify-between text-xs transition-all ${
                    isOverdue
                      ? 'bg-red-50/60 border-red-200'
                      : isToday
                      ? 'bg-amber-50/60 border-amber-300'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-800 text-xs truncate max-w-[160px]">
                        {item.customerName}
                      </span>
                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md tabular-nums ${
                          isOverdue
                            ? 'bg-red-100 text-red-700'
                            : isToday
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {isOverdue
                          ? tr(`متأخر ${Math.abs(item.daysDiff)} يوم`, `Overdue ${Math.abs(item.daysDiff)}d`)
                          : isToday
                          ? tr('مستحق اليوم', 'Due Today')
                          : item.daysDiff === 1
                          ? tr('مستحق غداً', 'Due Tomorrow')
                          : item.daysDiff === 2
                          ? tr('خلال يومين', 'In 2 days')
                          : tr(`خلال ${item.daysDiff} أيام`, `In ${item.daysDiff} days`)}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 font-mono tabular-nums flex items-center justify-between">
                      <span>
                        {tr(
                          `قسط #${item.installment.installmentNumber} · استحقاق: ${item.dueDate}`,
                          `Inst #${item.installment.installmentNumber} · Due: ${item.dueDate}`
                        )}
                      </span>
                      <span dir="ltr">{item.customerPhone}</span>
                    </div>

                    <div className="font-extrabold text-slate-900 text-sm mt-1.5 tabular-nums">
                      {formatCurrency(item.amount)}
                    </div>
                  </div>

                  <div className="pt-2.5 mt-2 border-t border-slate-200/50 flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleQuickPayFromWidget(item)}
                      className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer flex-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{tr('تحصيل القسط', 'Collect')}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickWhatsApp(item)}
                      className="neu-button-emerald flex-1 py-1.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{tr('واتساب', 'WhatsApp')}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const targetPlan = installmentPlans.find((p) => p.id === item.planId);
                        if (targetPlan) {
                          setSelectedReminderPlan({
                            plan: targetPlan,
                            installmentId: item.installment.id
                          });
                        }
                      }}
                      className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-semibold text-slate-600 cursor-pointer"
                    >
                      <span>{tr('تفاصيل', 'Details')}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Grid: Recent Sales Invoices Table & Low Stock Fast Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Daily & Weekly Invoices Table */}
        <div className="lg:col-span-2 neu-card p-5 rounded-3xl flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                  <Receipt className="w-4 h-4 text-blue-600" />
                  <span>{tr('سجل فواتير المبيعات الأخيرة', 'Recent Sales Invoices')}</span>
                </h3>
                <span className="text-xs text-slate-500">
                  {tr(
                    'اضغط على أي فاتورة لمعاينتها أو إعادة طباعتها فوراً',
                    'Click any invoice to preview or reprint immediately'
                  )}
                </span>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 p-1 rounded-xl neu-pressed self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setInvoiceFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    invoiceFilter === 'all'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tr('الكل', 'All')}
                </button>
                <button
                  type="button"
                  onClick={() => setInvoiceFilter('today')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    invoiceFilter === 'today'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tr('مبيعات اليوم', 'Today')}
                </button>
                <button
                  type="button"
                  onClick={() => setInvoiceFilter('week')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    invoiceFilter === 'week'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tr('هذا الأسبوع', 'This Week')}
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200/80 text-slate-500">
                    <th className="py-2.5 px-2 text-right font-bold">{tr('رقم الفاتورة', 'Invoice #')}</th>
                    <th className="py-2.5 px-2 text-right font-bold">{tr('التاريخ', 'Date')}</th>
                    <th className="py-2.5 px-2 text-right font-bold">{tr('العميل', 'Customer')}</th>
                    <th className="py-2.5 px-2 text-right font-bold">{tr('طريقة الدفع', 'Payment')}</th>
                    <th className="py-2.5 px-2 text-right font-bold">{tr('الإجمالي', 'Total')}</th>
                    <th className="py-2.5 px-2 text-center font-bold">{tr('عرض', 'View')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/50">
                  {filteredRecentSales.map((inv) => {
                    const invDate = new Date(inv.date);
                    const formattedDate = isNaN(invDate.getTime())
                      ? inv.date.split('T')[0]
                      : invDate.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        });

                    return (
                      <tr
                        key={inv.id}
                        onClick={() => openInvoiceModal(inv)}
                        className="hover:bg-white/60 transition-colors cursor-pointer"
                      >
                        <td className="py-2.5 px-2 font-mono font-bold text-blue-700 tabular-nums">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-2.5 px-2 text-slate-500 tabular-nums">{formattedDate}</td>
                        <td className="py-2.5 px-2 font-semibold text-slate-800 truncate max-w-[140px]">
                          {inv.customerName || tr('عميل نقدي', 'Walk-in Customer')}
                        </td>
                        <td className="py-2.5 px-2 text-slate-600">
                          {inv.paymentMethod === 'cash'
                            ? tr('نقدي', 'Cash')
                            : inv.paymentMethod === 'card'
                            ? tr('بطاقة / شبكة', 'Card')
                            : tr('آجل / تقسيط', 'Credit')}
                        </td>
                        <td className="py-2.5 px-2 font-black text-slate-900 tabular-nums">
                          {formatCurrency(inv.grandTotal)}
                        </td>
                        <td className="py-2.5 px-2 text-center">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openInvoiceModal(inv);
                            }}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                            title={tr('معاينة وطباعة الفاتورة', 'Preview & Print Invoice')}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}

                  {filteredRecentSales.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        {tr('لا توجد فواتير مبيعات مطابقة لهذا الفلتر', 'No sales invoices match this filter')}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-4 mt-3 border-t border-slate-200/60 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 tabular-nums">
              {tr(`إجمالي الفواتير المسجلة: ${sales.length}`, `Total Recorded Invoices: ${sales.length}`)}
            </span>
            <button
              onClick={() => onNavigate('sales-invoices')}
              className="text-xs text-blue-600 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>{tr('فتح سجل الفواتير الكامل', 'View All Sales Invoices')}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Low Stock Fast Table */}
        <div className="neu-card p-5 rounded-3xl flex flex-col justify-between border border-red-200/70">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span>{tr('أصناف وصلت للحد الأدنى', 'Low Stock Alert Items')}</span>
                {lowStockProducts.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-black tabular-nums">
                    {lowStockProducts.length}
                  </span>
                )}
              </h3>
              <button
                onClick={() => onNavigate('products')}
                className="text-xs text-red-600 hover:underline font-bold cursor-pointer"
              >
                {tr('عرض الكل', 'View All')}
              </button>
            </div>

            <div className="space-y-2 overflow-y-auto max-h-64 pr-1">
              {lowStockProducts.slice(0, 8).map((product) => {
                const isOut = product.stock <= 0;
                return (
                  <div
                    key={product.id}
                    onClick={() => onNavigate('products')}
                    className={`p-2.5 rounded-2xl flex items-center justify-between text-xs border transition-colors cursor-pointer ${
                      isOut
                        ? 'bg-red-100/90 border-red-300 hover:bg-red-100'
                        : 'bg-red-50/70 border-red-200/80 hover:bg-red-100/60'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-red-600 shrink-0 animate-pulse" />
                        <p className="font-extrabold text-red-950 truncate max-w-[145px]">
                          {product.name}
                        </p>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono tabular-nums block mt-0.5">
                        {product.barcode} · {tr('الحد الأدنى:', 'Min:')} {product.minStockAlert}
                      </span>
                    </div>
                    <div className="text-left shrink-0">
                      <span
                        className={`px-2 py-0.5 rounded-lg text-[11px] font-extrabold tabular-nums inline-block ${
                          isOut
                            ? 'bg-red-700 text-white'
                            : 'bg-red-600 text-white'
                        }`}
                      >
                        {product.stock} {product.unit}
                      </span>
                    </div>
                  </div>
                );
              })}

              {lowStockProducts.length === 0 && (
                <div className="py-8 text-center text-xs text-slate-400">
                  {tr('المخزون بوضع ممتاز، لا توجد أصناف منخفضة', 'Inventory is healthy, no low stock items')}
                </div>
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('purchases')}
            className="neu-button w-full py-2.5 rounded-xl text-xs font-bold text-slate-700 mt-4 cursor-pointer"
          >
            {tr('إنشاء طلب شراء جديد للموردين', 'Create New Purchase Order')}
          </button>
        </div>
      </div>

      {/* Automatic Weekly Due Installments Notification Modal */}
      <WeeklyInstallmentsAlertModal
        isOpen={isWeeklyAlertOpen}
        onClose={handleCloseWeeklyAlert}
        installments={urgentInstallments}
        onNavigateToInstallments={() => onNavigate('installments')}
        onOpenDetailedReminder={(item) => {
          const targetPlan = installmentPlans.find((p) => p.id === item.planId);
          if (targetPlan) {
            setIsWeeklyAlertOpen(false);
            setSelectedReminderPlan({
              plan: targetPlan,
              installmentId: item.installment.id
            });
          }
        }}
      />

      {/* Advanced Reminder & Partial Payment Modal */}
      {selectedReminderPlan && (
        <InstallmentReminderModal
          plan={selectedReminderPlan.plan}
          selectedInstallmentId={selectedReminderPlan.installmentId}
          onClose={() => setSelectedReminderPlan(null)}
          onSuccess={() => {
            refreshData();
            setSelectedReminderPlan(null);
          }}
        />
      )}
    </div>
  );
};
