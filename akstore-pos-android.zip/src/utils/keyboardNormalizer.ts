/**
 * @file utils/keyboardNormalizer.ts
 * تحويل الحروف والأرقام المكتوبة بلوحة المفاتيح العربية تلقائياً إلى الإنجليزية (QWERTY)
 * Automatic Arabic-to-English QWERTY Keyboard & Digits Normalizer for Password Fields
 */

import React from 'react';

const ARABIC_TO_ENGLISH_QWERTY_MAP: Record<string, string> = {
  // Top letter row
  'ض': 'q',
  'ص': 'w',
  'ث': 'e',
  'ق': 'r',
  'ف': 't',
  'غ': 'y',
  'ع': 'u',
  'ه': 'i',
  'خ': 'o',
  'ح': 'p',
  'ج': '[',
  'د': ']',

  // Home letter row
  'ش': 'a',
  'س': 's',
  'ي': 'd',
  'ب': 'f',
  'ل': 'g',
  'ا': 'h',
  'أ': 'h',
  'ت': 'j',
  'ن': 'k',
  'م': 'l',
  'ك': ';',
  'ط': "'",

  // Bottom letter row
  'ئ': 'z',
  'ء': 'x',
  'ؤ': 'c',
  'ر': 'v',
  'ى': 'n',
  'آ': 'n',
  'ة': 'm',
  'و': ',',
  'ز': '.',
  'ظ': '/',
  'ذ': '`',
  'إ': 'y',

  // Arabic-Indic Digits (٠-٩)
  '٠': '0',
  '١': '1',
  '٢': '2',
  '٣': '3',
  '٤': '4',
  '٥': '5',
  '٦': '6',
  '٧': '7',
  '٨': '8',
  '٩': '9',

  // Eastern Arabic Digits (۰-۹)
  '۰': '0',
  '۱': '1',
  '۲': '2',
  '۳': '3',
  '۴': '4',
  '۵': '5',
  '۶': '6',
  '۷': '7',
  '۸': '8',
  '۹': '9'
};

const ARABIC_CHAR_REGEX = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;

/**
 * يحول أي نص كُتب بالكيبورد العربي (مثل "شيةهى" أو "١٢٣") إلى مقابله الإنجليزي فوراً ("admin" أو "123")
 */
export function normalizeEnglishPasswordInput(input: string): string {
  if (!input) return '';

  // Handle 'لا' (B key on Arabic Windows keyboard) before single character mapping
  let processed = input
    .replace(/\uFEFB|\uFEF7|\uFEF9|\uFEF5/g, 'b')
    .replace(/لا|لأ|لإ|لآ/g, 'b');

  let result = '';
  for (const ch of processed) {
    if (ARABIC_TO_ENGLISH_QWERTY_MAP[ch] !== undefined) {
      result += ARABIC_TO_ENGLISH_QWERTY_MAP[ch];
    } else if (ARABIC_CHAR_REGEX.test(ch)) {
      // Strip any stray Arabic diacritics/tatweel
      continue;
    } else {
      result += ch;
    }
  }
  return result;
}

/**
 * يعترض ضغطات الأزرار على الكيبورد الفعلي عندما تكون اللغة عربي ويكتب الحرف الإنجليزي المقابل للزر الفعلي فوراً
 */
export function handleEnglishPasswordKeyDown(
  e: React.KeyboardEvent<HTMLInputElement>,
  currentValue: string,
  onValueChange: (nextValue: string) => void
) {
  if (e.ctrlKey || e.altKey || e.metaKey) return;

  const key = e.key || '';
  if (!ARABIC_CHAR_REGEX.test(key)) return;

  const code = e.code || '';
  let mappedChar: string | null = null;

  if (/^Key([A-Z])$/.test(code)) {
    const letter = code.slice(3);
    const capsLock = e.getModifierState ? e.getModifierState('CapsLock') : false;
    const isUpper = Boolean(e.shiftKey) !== Boolean(capsLock);
    mappedChar = isUpper ? letter.toUpperCase() : letter.toLowerCase();
  } else if (/^Digit([0-9])$/.test(code) && !e.shiftKey) {
    mappedChar = code.slice(5);
  } else if (/^Numpad([0-9])$/.test(code)) {
    mappedChar = code.slice(6);
  } else {
    const normalized = normalizeEnglishPasswordInput(key);
    if (normalized) {
      mappedChar = normalized;
    }
  }

  if (mappedChar !== null) {
    e.preventDefault();
    const inputEl = e.currentTarget;
    const start = inputEl.selectionStart ?? currentValue.length;
    const end = inputEl.selectionEnd ?? currentValue.length;
    const nextValue = currentValue.slice(0, start) + mappedChar + currentValue.slice(end);
    onValueChange(nextValue);

    const nextCursor = start + mappedChar.length;
    requestAnimationFrame(() => {
      try {
        inputEl.setSelectionRange(nextCursor, nextCursor);
      } catch {
        // ignore if input type does not support selection range
      }
    });
  }
}
