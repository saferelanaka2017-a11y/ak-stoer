/**
 * @file pages/SettingsPage.tsx
 * شاشة إعدادات المتجر والطابعات وقواعد البيانات واللغة
 * Store, Printers, and SQLite Database Configuration Page
 */

import React, { useState, useRef } from 'react';
import {
  Settings as SettingsIcon,
  Store,
  Printer,
  Database,
  Globe,
  Upload,
  Download,
  RotateCcw,
  CheckCircle2,
  Image as ImageIcon,
  FileText,
  Sliders,
  Zap,
  Key,
  MessageSquare,
  Copy,
  ExternalLink,
  ShieldCheck,
  Building2,
  Boxes,
  ArrowLeftRight,
  PackagePlus,
  MapPin,
  Phone,
  User,
  Plus,
  Edit2,
  Trash2,
  Search,
  X,
  Check,
  Coins,
  TrendingUp,
  RefreshCw,
  History,
  Monitor,
  Cpu
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { generateTestPrintPDF, exportInvoiceToWord, printInvoiceDirect } from '../utils/exportUtils';
import { PrinterType, SaleInvoice, Warehouse, WarehouseTransfer, Product, CurrencyRate } from '../types';
import { PrinterSelectionModal } from '../components/PrinterSelectionModal';
import { NumberStepperInput } from '../components/NumberStepperInput';
import { 
  getLicenseState, 
  activateLicense, 
  getWhatsAppActivationUrl, 
  getWhatsAppActivationMessage,
  OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
  downloadStandaloneKeygenHtml,
  LicenseState 
} from '../utils/licenseManager';
import { openSmartWhatsAppModal } from '../utils/installmentAlerts';
import {
  AKStoreLogo,
  AK_STORE_LOGO_PRESETS,
  AK_STORE_DEFAULT_LOGO_DATA_URL,
  normalizeLogoForPrint,
  convertUploadedImageFileToPngDataUrl
} from '../components/AKStoreLogo';
import {
  downloadWindows7InstallerBat,
  downloadWindowsSilentLauncherVbs,
  downloadPortableHtmlLauncher,
  downloadElectronWin7ExeBuilder,
  downloadExeAutoUpdaterScriptBat
} from '../utils/windowsDesktopBuilder';
import {
  APP_VERSION,
  APP_BUILD_NUMBER,
  checkForSystemUpdate,
  applySafeOnlineUpdateAndReload,
  exportOfflineUpdatePackage,
  installOfflineUpdatePackage,
  syncDatabaseAndLicenseToSafeVault
} from '../utils/updateManager';
import { detectSystemCompatibility, copyTextFallback } from '../utils/win7Polyfills';
import { GoogleDriveBackupPanel } from '../components/GoogleDriveBackupPanel';

export const SettingsPage: React.FC = () => {
  const {
    settings,
    updateSettings,
    language,
    setLanguage,
    showToast,
    refreshData,
    t,
    tr,
    dir,
    requestConfirm,
    warehouses,
    warehouseTransfers,
    addWarehouse,
    updateWarehouse,
    deleteWarehouse,
    setDefaultWarehouse,
    distributeProductStock,
    transferStock,
    products,
    formatCurrency,
    currencies,
    activeCurrency,
    baseCurrency,
    switchActiveCurrency,
    updateCurrencyExchangeRate,
    addCurrency,
    deleteCurrency,
    setBaseCurrency,
    lowSpecMode,
    setLowSpecMode
  } = useApp();
  const { isAdmin } = useAuth();

  const sysInfo = React.useMemo(() => detectSystemCompatibility(), []);

  const [storeName, setStoreName] = useState(settings.storeName);
  const [storePhone, setStorePhone] = useState(settings.storePhone);
  const [storeAddress, setStoreAddress] = useState(settings.storeAddress);
  const [taxNumber, setTaxNumber] = useState(settings.taxNumber);
  const [crNumber, setCrNumber] = useState(settings.crNumber || '');
  const [vatPercentage, setVatPercentage] = useState(settings.vatPercentage);
  const [installmentInterestPercentage, setInstallmentInterestPercentage] = useState<number>(settings.installmentInterestPercentage ?? 10);
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol);
  const [printLayout, setPrintLayout] = useState<'thermal' | 'a4'>(settings.printLayout);
  const [footerNotes, setFooterNotes] = useState(settings.footerNotes);
  const [enableZatcaQR, setEnableZatcaQR] = useState(settings.enableZatcaQR);
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || '');

  // Multi-Currency & Manual Exchange Rate States
  const [activeCurrencyTab, setActiveCurrencyTab] = useState<'rates' | 'preview' | 'history'>('rates');
  const [editingRates, setEditingRates] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {};
    (settings.currencies || []).forEach(c => {
      map[c.code] = String(c.exchangeRate);
    });
    return map;
  });
  const [autoUpdatePricesOnRateChange, setAutoUpdatePricesOnRateChange] = useState<boolean>(
    settings.autoUpdatePricesOnRateChange ?? true
  );
  const [priceImpactMode, setPriceImpactMode] = useState<'auto' | 'scale_all' | 'convert_active'>('auto');
  const [previewCurrencyCode, setPreviewCurrencyCode] = useState<string>(activeCurrency?.code || 'EGP');
  const [isAddCurrencyModalOpen, setIsAddCurrencyModalOpen] = useState(false);
  const [newCurrCode, setNewCurrCode] = useState('');
  const [newCurrName, setNewCurrName] = useState('');
  const [newCurrSymbol, setNewCurrSymbol] = useState('');
  const [newCurrRate, setNewCurrRate] = useState('1');

  // Keep currencySymbol, vatPercentage and editingRates synced when settings/currencies update
  React.useEffect(() => {
    setCurrencySymbol(settings.currencySymbol);
  }, [settings.currencySymbol]);

  React.useEffect(() => {
    setVatPercentage(Number(settings.vatPercentage) > 0 ? Number(settings.vatPercentage) : 0);
  }, [settings.vatPercentage]);

  React.useEffect(() => {
    const map: Record<string, string> = {};
    currencies.forEach(c => {
      map[c.code] = String(c.exchangeRate);
    });
    setEditingRates(map);
  }, [currencies]);

  // Printer configuration state
  const [selectedPrinter, setSelectedPrinter] = useState<PrinterType>(settings.selectedPrinter || 'thermal-80');
  const [printerCustomName, setPrinterCustomName] = useState(settings.printerCustomName || '');
  const [autoPrintOnSale, setAutoPrintOnSale] = useState(Boolean(settings.autoPrintOnSale));
  const [showPrinterDialogBeforePrint, setShowPrinterDialogBeforePrint] = useState(Boolean(settings.showPrinterDialogBeforePrint));
  const [isPrinterModalOpen, setIsPrinterModalOpen] = useState(false);

  // License & Activation state
  const [licenseState, setLicenseState] = useState<LicenseState>(getLicenseState());
  const [activationKeyInput, setActivationKeyInput] = useState('');
  const [copiedDeviceCode, setCopiedDeviceCode] = useState(false);

  // Multi-Warehouse UI States
  const [enableMultiWarehouse, setEnableMultiWarehouse] = useState<boolean>(settings.enableMultiWarehouse ?? true);
  const [activeWhTab, setActiveWhTab] = useState<'list' | 'distribution' | 'transfers'>('list');
  const [searchDistProduct, setSearchDistProduct] = useState('');
  const [filterDistWarehouse, setFilterDistWarehouse] = useState<string>('all');
  const [filterDistStockStatus, setFilterDistStockStatus] = useState<'all' | 'in_stock' | 'out_of_stock'>('all');
  const [activeSettingsSection, setActiveSettingsSection] = useState<'all' | 'windows' | 'language' | 'warehouses' | 'store' | 'currencies' | 'printers' | 'database' | 'license'>('all');

  // Add/Edit Warehouse Modal State
  const [isWhModalOpen, setIsWhModalOpen] = useState(false);
  const [editingWh, setEditingWh] = useState<Warehouse | null>(null);
  const [whName, setWhName] = useState('');
  const [whCode, setWhCode] = useState('');
  const [whLocation, setWhLocation] = useState('');
  const [whManager, setWhManager] = useState('');
  const [whPhone, setWhPhone] = useState('');
  const [whIsDefault, setWhIsDefault] = useState(false);
  const [whNotes, setWhNotes] = useState('');

  // Inter-Warehouse Transfer Modal State
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferFromWhId, setTransferFromWhId] = useState('');
  const [transferToWhId, setTransferToWhId] = useState('');
  const [transferProductId, setTransferProductId] = useState('');
  const [transferQty, setTransferQty] = useState(1);
  const [transferNotes, setTransferNotes] = useState('');

  // Stock Distribution Modal State
  const [isDistributeModalOpen, setIsDistributeModalOpen] = useState(false);
  const [distributeProduct, setDistributeProduct] = useState<Product | null>(null);
  const [distributionMap, setDistributionMap] = useState<Record<string, number>>({});

  const logoInputRef = useRef<HTMLInputElement>(null);
  const dbImportRef = useRef<HTMLInputElement>(null);
  const updatePackageInputRef = useRef<HTMLInputElement>(null);
  const [isCheckingExeUpdate, setIsCheckingExeUpdate] = useState(false);
  const [exeUpdateStatusMsg, setExeUpdateStatusMsg] = useState<string>('');

  // Open Add Warehouse
  const handleOpenAddWh = () => {
    setEditingWh(null);
    setWhName('');
    const nextCode = `WH-${(warehouses.length + 1).toString().padStart(2, '0')}`;
    setWhCode(nextCode);
    setWhLocation('');
    setWhManager('');
    setWhPhone('');
    setWhIsDefault(warehouses.length === 0);
    setWhNotes('');
    setIsWhModalOpen(true);
  };

  // Open Edit Warehouse
  const handleOpenEditWh = (wh: Warehouse) => {
    setEditingWh(wh);
    setWhName(wh.name);
    setWhCode(wh.code);
    setWhLocation(wh.location);
    setWhManager(wh.managerName || '');
    setWhPhone(wh.phone || '');
    setWhIsDefault(wh.isDefault);
    setWhNotes(wh.notes || '');
    setIsWhModalOpen(true);
  };

  // Save Warehouse (Create / Update)
  const handleSaveWarehouse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whName.trim() || !whCode.trim() || !whLocation.trim()) {
      showToast('يرجى ملء اسم المستودع، الرمز، والموقع', 'error');
      return;
    }

    if (editingWh) {
      updateWarehouse(editingWh.id, {
        name: whName.trim(),
        code: whCode.trim(),
        location: whLocation.trim(),
        managerName: whManager.trim(),
        phone: whPhone.trim(),
        isDefault: whIsDefault,
        notes: whNotes.trim()
      });
      showToast(`تم تحديث بيانات المستودع "${whName.trim()}" بنجاح!`, 'success');
    } else {
      addWarehouse({
        name: whName.trim(),
        code: whCode.trim(),
        location: whLocation.trim(),
        managerName: whManager.trim(),
        phone: whPhone.trim(),
        isDefault: whIsDefault,
        notes: whNotes.trim()
      });
      showToast(`تمت إضافة المستودع "${whName.trim()}" بنجاح!`, 'success');
    }

    setIsWhModalOpen(false);
  };

  // Delete Warehouse with safety guard
  const handleDeleteWarehouse = (wh: Warehouse) => {
    requestConfirm({
      title: 'حذف المستودع',
      message: `هل أنت متأكد من حذف المستودع "${wh.name}" (${wh.code})؟ لن تتم العملية إذا كان يحتوي على بضاعة مسجلة.`,
      confirmText: 'نعم، حذف المستودع',
      isDestructive: true,
      onConfirm: () => {
        const res = deleteWarehouse(wh.id);
        if (res.success) {
          showToast(`تم حذف المستودع "${wh.name}" بنجاح`, 'success');
        } else {
          showToast(res.message || 'تعذر حذف المستودع', 'error');
        }
      }
    });
  };

  // Set Default Warehouse
  const handleSetDefaultWarehouse = (wh: Warehouse) => {
    setDefaultWarehouse(wh.id);
    showToast(`تم تعيين "${wh.name}" كمستودع افتراضي للبيع والصرف الفوري!`, 'success');
  };

  // Open Transfer Modal
  const handleOpenTransferModal = () => {
    if (warehouses.length < 2) {
      showToast('يجب توفر مستودعين على الأقل لتنفيذ أمر تحويل بضاعة!', 'error');
      return;
    }
    const fromId = warehouses[0]?.id || '';
    const toId = warehouses[1]?.id || '';
    setTransferFromWhId(fromId);
    setTransferToWhId(toId);
    setTransferProductId(products[0]?.id || '');
    setTransferQty(1);
    setTransferNotes('');
    setIsTransferModalOpen(true);
  };

  // Submit Stock Transfer
  const handleSubmitTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferFromWhId || !transferToWhId || !transferProductId || transferQty <= 0) {
      showToast('يرجى تحديد المستودعات، المنتج، وكمية صحيحة أكبر من صفر', 'error');
      return;
    }

    const res = transferStock({
      fromWarehouseId: transferFromWhId,
      toWarehouseId: transferToWhId,
      productId: transferProductId,
      quantity: Number(transferQty),
      notes: transferNotes.trim()
    });

    if (res.success) {
      showToast(res.message, 'success');
      setIsTransferModalOpen(false);
    } else {
      showToast(res.message, 'error');
    }
  };

  // Open Stock Distribution Modal
  const handleOpenDistributeModal = (product: Product) => {
    setDistributeProduct(product);
    // Pre-populate distribution map
    const map: Record<string, number> = {};
    warehouses.forEach(wh => {
      map[wh.id] = product.warehouseStock?.[wh.id] || 0;
    });
    setDistributionMap(map);
    setIsDistributeModalOpen(true);
  };

  // Save Stock Distribution
  const handleSaveDistribution = () => {
    if (!distributeProduct) return;
    distributeProductStock(distributeProduct.id, distributionMap);
    showToast(`تم تحديث توزيع مخزون "${distributeProduct.name}" بنجاح!`, 'success');
    setIsDistributeModalOpen(false);
  };

  // Export Warehouse Inventory to CSV / Excel
  const handleExportWarehouseInventory = (targetWhId?: string) => {
    const targetWh = warehouses.find(w => w.id === targetWhId);
    const headers = ['كود الصنف (الباركود)', 'اسم المنتج', 'التصنيف', 'المستودع', 'كود المستودع', 'الكمية المتوفرة', 'سعر التكلفة', 'سعر البيع', 'إجمالي قيمة التكلفة', 'إجمالي القيمة البيعية'];
    const rows: string[][] = [headers];

    products.forEach(p => {
      if (targetWhId && targetWhId !== 'all') {
        const qty = p.warehouseStock?.[targetWhId] || 0;
        if (filterDistStockStatus === 'in_stock' && qty <= 0) return;
        if (filterDistStockStatus === 'out_of_stock' && qty > 0) return;
        rows.push([
          p.barcode,
          p.name,
          p.category || 'عام',
          targetWh?.name || '',
          targetWh?.code || '',
          qty.toString(),
          p.costPrice.toFixed(2),
          p.salePrice.toFixed(2),
          (qty * p.costPrice).toFixed(2),
          (qty * p.salePrice).toFixed(2)
        ]);
      } else {
        warehouses.forEach(wh => {
          const qty = p.warehouseStock?.[wh.id] || 0;
          if (filterDistStockStatus === 'in_stock' && qty <= 0) return;
          if (filterDistStockStatus === 'out_of_stock' && qty > 0) return;
          rows.push([
            p.barcode,
            p.name,
            p.category || 'عام',
            wh.name,
            wh.code,
            qty.toString(),
            p.costPrice.toFixed(2),
            p.salePrice.toFixed(2),
            (qty * p.costPrice).toFixed(2),
            (qty * p.salePrice).toFixed(2)
          ]);
        });
      }
    });

    const csvContent = '\uFEFF' + rows.map(r => r.map(c => `"${(c || '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `جرد_مستودع_${targetWh ? targetWh.code : 'كافة_المستودعات'}_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`تم تصدير ملف جرد المستودع (${targetWh ? targetWh.name : 'كافة المستودعات'}) بنجاح!`, 'success');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      storeName,
      storePhone,
      storeAddress,
      taxNumber,
      crNumber,
      vatPercentage,
      installmentInterestPercentage,
      currencySymbol,
      printLayout,
      footerNotes,
      enableZatcaQR,
      logoUrl,
      selectedPrinter,
      printerCustomName,
      autoPrintOnSale,
      showPrinterDialogBeforePrint,
      enableMultiWarehouse
    });
    showToast('تم حفظ كافة الإعدادات وخيارات المستودعات والطابعات بنجاح!', 'success');
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const pngDataUrl = await convertUploadedImageFileToPngDataUrl(file);
        setLogoUrl(pngDataUrl);
        updateSettings({ logoUrl: pngDataUrl });
        showToast(
          tr(
            'تم رفع وحفظ شعار المتجر بصيغة PNG للطباعة الفورية بنجاح!',
            'Custom logo uploaded and saved as print-ready PNG!'
          ),
          'success'
        );
      } catch {
        const reader = new FileReader();
        reader.onloadend = () => {
          const resUrl = normalizeLogoForPrint(reader.result as string);
          setLogoUrl(resUrl);
          updateSettings({ logoUrl: resUrl });
          showToast(tr('تم رفع وحفظ الشعار بنجاح!', 'Logo uploaded and saved!'), 'success');
        };
        reader.readAsDataURL(file);
      }
    }
    e.target.value = '';
  };

  // Export SQLite database.db file
  const handleExportDB = () => {
    const blob = db.exportDatabaseFile();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'database.db';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('تم تصدير ملف قاعدة البيانات (database.db) بنجاح!', 'success');
  };

  // Import SQLite database.db file
  const handleImportDB = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        const success = db.importDatabaseFile(content);
        if (success) {
          showToast('تم استيراد قاعدة البيانات بنجاح!', 'success');
          refreshData();
        } else {
          showToast('فشل استيراد قاعدة البيانات، الملف غير صالح', 'error');
        }
      };
      reader.readAsText(file);
    }
    e.target.value = '';
  };

  // Reset to default seed
  const handleReset = () => {
    requestConfirm({
      title: 'إعادة ضبط قاعدة البيانات',
      message: 'هل أنت متأكد من رغبتك في إعادة ضبط قاعدة البيانات إلى البيانات الأولية التجريبية؟ سيتم استبدال البيانات الحالية.',
      confirmText: 'نعم، إعادة الضبط',
      isDestructive: true,
      onConfirm: () => {
        db.resetToDefault();
        refreshData();
        showToast('تمت إعادة ضبط النظام إلى الإعدادات الافتراضية بنجاح!', 'success');
      }
    });
  };

  // Generate a mock invoice for testing purposes
  const getMockTestInvoice = (): SaleInvoice => ({
    id: 'test-inv-001',
    invoiceNumber: 'TEST-INV-100',
    date: new Date().toISOString(),
    cashierId: 'admin',
    cashierName: 'مسؤول النظام',
    customerName: 'عميل تجريبي للاختبار',
    items: [
      {
        product: {
          id: 'p-test-1',
          barcode: '628100123001',
          name: 'قهوة اسبريسو فاخرة 500 جرام',
          category: 'مشروبات',
          costPrice: 28,
          salePrice: 42,
          stock: 50,
          minStockAlert: 5,
          unit: 'حبة',
          createdAt: new Date().toISOString()
        },
        quantity: 2,
        price: 42,
        discount: 4,
        tax: 12,
        total: 92
      }
    ],
    subtotal: 80,
    taxTotal: 12,
    discountTotal: 4,
    grandTotal: 92,
    paidAmount: 100,
    changeAmount: 8,
    paymentMethod: 'cash',
    notes: 'إيصال تجريبي لاختبار إعدادات الطابعة'
  });

  // 1. Direct Instant Test Print
  const handleTestDirectPrint = () => {
    try {
      showToast('جاري إرسال أمر الطباعة التجريبية الفورية...', 'info');
      printInvoiceDirect(getMockTestInvoice(), {
        ...settings,
        storeName,
        storePhone,
        storeAddress,
        taxNumber,
        logoUrl: normalizeLogoForPrint(logoUrl),
        selectedPrinter,
        printLayout
      });
      showToast('تم إرسال أمر الطباعة الفورية بنجاح!', 'success');
    } catch (e) {
      console.error(e);
      showToast('تعذر إرسال أمر الطباعة المباشر', 'error');
    }
  };

  // 2. Test Word Export
  const handleTestWord = () => {
    try {
      showToast('جاري تصدير نموذج فاتورة Word (.doc)...', 'info');
      exportInvoiceToWord(
        getMockTestInvoice(),
        {
          ...settings,
          storeName,
          storePhone,
          storeAddress,
          taxNumber,
          logoUrl: normalizeLogoForPrint(logoUrl)
        },
        `نموذج_فاتورة_تجريبية_${new Date().toISOString().slice(0, 10)}.doc`
      );
      showToast('تم تحميل نموذج الفاتورة بصيغة Word (.doc) بنجاح!', 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء ملف Word', 'error');
    }
  };

  // 3. Test PDF with Arabic support
  const handleTestPrintPDF = async () => {
    try {
      showToast('جاري تصدير صفحة اختبار الطباعة باللغة العربية...', 'info');
      await generateTestPrintPDF(
        {
          ...settings,
          storeName,
          storePhone,
          storeAddress,
          taxNumber,
          logoUrl: normalizeLogoForPrint(logoUrl)
        },
        printLayout
      );
      showToast('تم تحميل صفحة اختبار الطباعة PDF بنجاح بحروف عربية واضحة!', 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء صفحة اختبار الطباعة', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="neu-card p-5 rounded-3xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
              <SettingsIcon className="w-5 h-5 text-blue-600" />
              <span>{tr('إعدادات النظام والمتجر', 'System & Store Settings')}</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {tr(
                'تخصيص لغة النظام واتجاه الواجهة (RTL / LTR)، بيانات المنشأة، العملات، الطابعات، والنسخ الاحتياطي',
                'Configure system language & UI direction (RTL / LTR), store profile, currencies, printers, and backups'
              )}
            </p>
          </div>

          {/* Quick Language & Direction Status Pill in Settings Header */}
          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-2xl text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>
                {language === 'ar'
                  ? 'اللغة الحالية: العربية (RTL — من اليمين لليسار)'
                  : 'Active Language: English (LTR — Left to Right)'}
              </span>
            </span>
          </div>
        </div>

        {/* Quick Module Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-4 mt-3 border-t border-slate-200/60 no-scrollbar select-none">
          <button
            type="button"
            onClick={() => setActiveSettingsSection('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeSettingsSection === 'all'
                ? 'neu-pressed text-blue-700 bg-white font-black shadow-2xs'
                : 'neu-button text-slate-600 hover:text-blue-600'
            }`}
          >
            {tr('📋 عرض كافة الإعدادات', '📋 All Settings')}
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSettingsSection('language');
              const el = document.getElementById('section-language');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeSettingsSection === 'language'
                ? 'neu-pressed text-blue-700 bg-white font-black shadow-2xs ring-2 ring-blue-400'
                : 'neu-button text-blue-700 hover:text-blue-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{tr('اللغة واتجاه الواجهة (AR / EN)', 'Language & Direction (AR / EN)')}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSettingsSection('warehouses');
              const el = document.getElementById('section-warehouses');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeSettingsSection === 'warehouses'
                ? 'neu-pressed text-indigo-700 bg-white font-black shadow-2xs ring-2 ring-indigo-400'
                : 'neu-button text-indigo-700 hover:text-indigo-800'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{tr(`إدارة تعدد المخازن (${warehouses.length})`, `Multi-Warehouse (${warehouses.length})`)}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSettingsSection('store');
              const el = document.getElementById('section-store');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeSettingsSection === 'store'
                ? 'neu-pressed text-blue-700 bg-white font-black shadow-2xs'
                : 'neu-button text-slate-600 hover:text-blue-600'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>{tr('بيانات المنشأة', 'Store Profile')}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSettingsSection('currencies');
              const el = document.getElementById('section-currencies');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeSettingsSection === 'currencies'
                ? 'neu-pressed text-emerald-700 bg-white font-black shadow-2xs'
                : 'neu-button text-slate-600 hover:text-emerald-600'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>{tr('العملات وأسعار الصرف', 'Currencies & Exchange Rates')}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSettingsSection('printers');
              const el = document.getElementById('section-printers');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeSettingsSection === 'printers'
                ? 'neu-pressed text-purple-700 bg-white font-black shadow-2xs'
                : 'neu-button text-slate-600 hover:text-purple-600'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{tr('الطابعات والطباعة', 'Printers & Receipt')}</span>
          </button>
          {isAdmin && (
            <>
              <button
                type="button"
                onClick={() => {
                  setActiveSettingsSection('database');
                  const el = document.getElementById('section-database');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  activeSettingsSection === 'database'
                    ? 'neu-pressed text-amber-700 bg-white font-black shadow-2xs'
                    : 'neu-button text-slate-600 hover:text-amber-600'
                }`}
              >
                <Database className="w-3.5 h-3.5" />
                <span>{tr('النسخ الاحتياطي', 'Database Backup')}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveSettingsSection('license');
                  const el = document.getElementById('section-license');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  activeSettingsSection === 'license'
                    ? 'neu-pressed text-rose-700 bg-white font-black shadow-2xs'
                    : 'neu-button text-slate-600 hover:text-rose-600'
                }`}
              >
                <Key className="w-3.5 h-3.5" />
                <span>{tr('الترخيص والتفعيل', 'License & Activation')}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* LIVE OTA & .EXE UPDATE TOOL CARD (تحديث النسخة المحملة على الموبايل واللابتوب .EXE فور تعديل النظام) */}
      <div className="neu-card p-5 rounded-3xl space-y-4 text-xs border border-emerald-200/80 bg-gradient-to-r from-emerald-50/50 via-white to-blue-50/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-sm shrink-0">
              <RefreshCw className={`w-5 h-5 ${isCheckingExeUpdate ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-black text-slate-800 text-sm">
                  {tr(
                    'أداة التحديث المباشر للنسخة المحملة على الموبايل واللابتوب (.EXE)',
                    'Live OTA & .EXE Update Tool (Mobile PWA & Laptop .EXE)'
                  )}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 font-mono">
                  v{APP_VERSION} · Live OTA
                </span>
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">
                {tr(
                  'يسحب أي تعديل جديد تم عمله على النظام هنا ويطبّقه فوراً على تطبيق الموبايل ونسخة اللابتوب (.EXE) مع الحفاظ الكامل 100% على قاعدة البيانات والتفعيل.',
                  'Automatically pulls any new system modifications and applies them to your installed Mobile App and Laptop (.EXE) while preserving 100% of your database and license.'
                )}
              </p>
            </div>
          </div>
        </div>

        <input
          ref={updatePackageInputRef}
          type="file"
          accept=".akupdate,.json"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            setIsCheckingExeUpdate(true);
            setExeUpdateStatusMsg(
              tr('جاري قراءة وتثبيت ملف التحديث مع تأمين قاعدة البيانات...', 'Reading and installing update file while securing database...')
            );
            try {
              const text = await file.text();
              const res = await installOfflineUpdatePackage(text);
              setExeUpdateStatusMsg(res.messageAr);
              showToast(res.messageAr, res.success ? 'success' : 'error');
              if (res.success) {
                refreshData();
              }
            } catch {
              showToast(tr('حدث خطأ أثناء قراءة ملف التحديث', 'Error reading update file'), 'error');
            } finally {
              setIsCheckingExeUpdate(false);
              e.target.value = '';
            }
          }}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {/* 1. زر أخذ ملف التحديث (.akupdate) */}
          <button
            type="button"
            disabled={isCheckingExeUpdate}
            onClick={async () => {
              setIsCheckingExeUpdate(true);
              setExeUpdateStatusMsg(
                tr('جاري تجميع وتجهيز ملف التحديث الشامل (.akupdate)...', 'Packaging full update file (.akupdate)...')
              );
              await exportOfflineUpdatePackage();
              setIsCheckingExeUpdate(false);
              const msg = tr(
                'تم أخذ وتحميل ملف التحديث الشامل (AK_Store_Update_v' + APP_VERSION + '.akupdate) بنجاح!',
                'Downloaded full update file (AK_Store_Update_v' + APP_VERSION + '.akupdate)!'
              );
              setExeUpdateStatusMsg(msg);
              showToast(msg, 'success');
            }}
            className="neu-button-emerald py-3 px-4 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-60"
          >
            <Download className="w-4 h-4" />
            <span>
              {tr('أخذ ملف التحديث (.akupdate)', 'Get Update File (.akupdate)')}
            </span>
          </button>

          {/* 2. زر تثبيت / رفع ملف التحديث (.akupdate) */}
          <button
            type="button"
            disabled={isCheckingExeUpdate}
            onClick={() => updatePackageInputRef.current?.click()}
            className="neu-button py-3 px-4 rounded-2xl font-extrabold text-blue-800 bg-white border-2 border-blue-300 text-xs flex items-center justify-center gap-2 cursor-pointer hover:bg-blue-50 disabled:opacity-60"
          >
            <Upload className="w-4 h-4 text-blue-600" />
            <span>
              {tr('تثبيت ملف التحديث (.akupdate)', 'Install Update File (.akupdate)')}
            </span>
          </button>

          {/* 3. زر التحديث المباشر أونلاين */}
          <button
            type="button"
            disabled={isCheckingExeUpdate}
            onClick={async () => {
              setIsCheckingExeUpdate(true);
              setExeUpdateStatusMsg(
                tr('جاري تأمين قاعدة البيانات وسحب أحدث تعديلات النظام...', 'Securing database and pulling latest system modifications...')
              );
              await syncDatabaseAndLicenseToSafeVault();
              const res = await applySafeOnlineUpdateAndReload();
              setIsCheckingExeUpdate(false);
              setExeUpdateStatusMsg(res.messageAr);
              showToast(res.messageAr, res.success ? 'success' : 'error');
            }}
            className="neu-button-primary py-3 px-4 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-60"
          >
            <RefreshCw className={`w-4 h-4 ${isCheckingExeUpdate ? 'animate-spin' : ''}`} />
            <span>
              {tr('تحديث الموبايل واللاب (.EXE) الآن', 'Update Mobile & Laptop (.EXE) Now')}
            </span>
          </button>

          {/* 4. زر تحميل أداة تحديث اللاب (.BAT) */}
          <button
            type="button"
            onClick={() => {
              downloadExeAutoUpdaterScriptBat();
              showToast(
                tr(
                  'تم تحميل أداة تحديث اللابتوب والـ EXE (AK_Store_EXE_Updater_Tool.bat)! شغّلها على اللابتوب لسحب أحدث تعديلات النظام.',
                  'Downloaded Laptop .EXE Updater Tool (AK_Store_EXE_Updater_Tool.bat)!'
                ),
                'success'
              );
            }}
            className="neu-button py-3 px-4 rounded-2xl font-extrabold text-emerald-800 bg-white border border-emerald-300 text-xs flex items-center justify-center gap-2 cursor-pointer hover:bg-emerald-50"
          >
            <Monitor className="w-4 h-4 text-emerald-600" />
            <span>
              {tr('أداة تحديث اللاب (.BAT)', 'Laptop .EXE Updater (.BAT)')}
            </span>
          </button>
        </div>

        {exeUpdateStatusMsg && (
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 font-bold text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{exeUpdateStatusMsg}</span>
          </div>
        )}
      </div>

      {/* DEDICATED LANGUAGE & INTERFACE DIRECTION CARD (التبديل بين اللغتين العربية والإنجليزية ودعم RTL / LTR) */}
      <div id="section-language" className="neu-card p-5 rounded-3xl space-y-4 text-xs border border-blue-200/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-blue-100/80 flex items-center justify-center text-blue-700 shadow-inner">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-black text-slate-800 text-sm">
                  {tr(
                    'إعدادات اللغة واتجاه واجهة المستخدم (العربية RTL / الإنجليزية LTR)',
                    'System Language & User Interface Direction (Arabic RTL / English LTR)'
                  )}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300 font-mono uppercase">
                  {dir.toUpperCase()} · {language.toUpperCase()}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {tr(
                  'اختر لغة النظام المفضلة؛ عند اختيار الإنجليزية يتم تحديث اتجاه الواجهة بالكامل من اليسار إلى اليمين (LTR) مع عكس القوائم والجداول تلقائياً',
                  'Select your preferred system language; selecting English automatically switches the entire UI layout to Left-to-Right (LTR)'
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Arabic (RTL) Option Card */}
          <div
            onClick={() => {
              if (language !== 'ar') {
                setLanguage('ar');
                showToast('تم التبديل إلى اللغة العربية وتطبيق اتجاه الواجهة من اليمين إلى اليسار (RTL)', 'success');
              }
            }}
            className={`p-4 rounded-2xl transition-all cursor-pointer flex flex-col justify-between gap-3 select-none ${
              language === 'ar'
                ? 'neu-pressed bg-blue-50/70 border-2 border-blue-500 shadow-sm'
                : 'neu-button hover:border-blue-300'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm shadow-xs ${
                    language === 'ar' ? 'bg-blue-600 text-white' : 'bg-slate-200/80 text-slate-700'
                  }`}
                >
                  عربي
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-black text-slate-800 text-sm">العربية (Arabic)</h4>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-indigo-100 text-indigo-800">
                      RTL (Right-to-Left)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    اتجاه الواجهة من اليمين إلى اليسار — القائمة الجانبية يميناً ومحاذاة عربية كاملة
                  </p>
                </div>
              </div>

              {language === 'ar' ? (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1 shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{tr('مفعّلة حالياً', 'Active')}</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 shrink-0">
                  {tr('انقر للتفعيل', 'Click to activate')}
                </span>
              )}
            </div>

            {/* Visual Layout Preview Diagram for RTL */}
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 flex items-center justify-between gap-2 text-[10px]" dir="rtl">
              <div className="w-16 h-10 rounded-lg bg-blue-600/15 border border-blue-300 flex items-center justify-center font-bold text-blue-800 shrink-0">
                القائمة (يمين)
              </div>
              <div className="flex-1 h-10 rounded-lg bg-slate-100 border border-slate-200 px-2.5 flex items-center justify-between text-slate-600">
                <span className="font-bold">محتوى الشاشة والجداول →</span>
                <span className="font-mono text-[9px] text-slate-400">dir="rtl"</span>
              </div>
            </div>
          </div>

          {/* English (LTR) Option Card */}
          <div
            onClick={() => {
              if (language !== 'en') {
                setLanguage('en');
                showToast('Switched to English — Left-to-Right (LTR) interface direction applied!', 'success');
              }
            }}
            className={`p-4 rounded-2xl transition-all cursor-pointer flex flex-col justify-between gap-3 select-none ${
              language === 'en'
                ? 'neu-pressed bg-blue-50/70 border-2 border-blue-500 shadow-sm'
                : 'neu-button hover:border-blue-300'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center font-mono font-black text-sm shadow-xs ${
                    language === 'en' ? 'bg-blue-600 text-white' : 'bg-slate-200/80 text-slate-700'
                  }`}
                >
                  EN
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-black text-slate-800 text-sm">English (الإنجليزية)</h4>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800">
                      LTR (Left-to-Right)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Left-to-Right interface direction — Sidebar on the left, English menus & tables
                  </p>
                </div>
              </div>

              {language === 'en' ? (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1 shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{tr('مفعّلة حالياً', 'Active')}</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 shrink-0">
                  {tr('انقر للتفعيل', 'Click to activate')}
                </span>
              )}
            </div>

            {/* Visual Layout Preview Diagram for LTR */}
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 flex items-center justify-between gap-2 text-[10px]" dir="ltr">
              <div className="w-16 h-10 rounded-lg bg-blue-600/15 border border-blue-300 flex items-center justify-center font-bold text-blue-800 shrink-0">
                Sidebar (Left)
              </div>
              <div className="flex-1 h-10 rounded-lg bg-slate-100 border border-slate-200 px-2.5 flex items-center justify-between text-slate-600">
                <span className="font-bold">← Main Viewport & Tables</span>
                <span className="font-mono text-[9px] text-slate-400">dir="ltr"</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Store Profile Card */}
        <div id="section-store" className="neu-card p-5 rounded-3xl space-y-4 text-xs">
          <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
            <Store className="w-4 h-4 text-blue-600" />
            <span>{tr('بيانات المنشأة والمتجر', 'Store & Company Profile')}</span>
          </h3>

          {/* Logo Upload & Official AK Store Logo Presets */}
          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <AKStoreLogo
                  logoUrl={logoUrl || AK_STORE_DEFAULT_LOGO_DATA_URL}
                  size="xl"
                  className="ring-4 ring-white shadow-lg"
                />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-black text-slate-800 text-sm">
                      {tr('شعار المتجر الرسمي (AK Store)', 'Official Store Logo (AK Store)')}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700">
                      Vector HD
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {tr(
                      'يظهر في شريط النظام، شاشة الدخول، ورأس الفواتير الحرارية 80mm وفواتير A4',
                      'Displayed in the navbar, login screen, and Thermal 80mm & A4 invoice headers'
                    )}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-2.5">
                    <input
                      ref={logoInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => logoInputRef.current?.click()}
                      className="neu-button px-3.5 py-1.5 rounded-xl font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer text-xs"
                    >
                      <Upload className="w-3.5 h-3.5 text-blue-600" />
                      <span>{tr('رفع شعار خاص من جهازك', 'Upload Custom Image')}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 4 Built-in Professional AK Store Vector Logos */}
            <div className="pt-2 border-t border-slate-200/70">
              <label className="text-[11px] font-bold text-slate-600 block mb-2">
                {tr(
                  'أو اختر من تصميمات شعار AK Store الاحترافية الجاهزة (بضغطة واحدة):',
                  'Or choose from ready-made professional AK Store vector logos (1-click):'
                )}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {AK_STORE_LOGO_PRESETS.map((preset) => {
                  const isCurrent = normalizeLogoForPrint(logoUrl || AK_STORE_DEFAULT_LOGO_DATA_URL) === preset.dataUrl;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setLogoUrl(preset.dataUrl);
                        updateSettings({ logoUrl: preset.dataUrl });
                        showToast(
                          tr(
                            `تم تفعيل شعار: ${preset.nameAr}`,
                            `Activated logo: ${preset.nameEn}`
                          ),
                          'success'
                        );
                      }}
                      className={`p-2.5 rounded-2xl border transition-all flex items-center gap-2.5 cursor-pointer text-right ${
                        isCurrent
                          ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-500/20 shadow-xs'
                          : 'bg-white/90 hover:bg-white border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      <img
                        src={preset.dataUrl}
                        alt={preset.nameEn}
                        className="w-10 h-10 rounded-xl object-contain shrink-0 shadow-xs"
                      />
                      <div className="overflow-hidden flex-1">
                        <div className="font-bold text-slate-800 text-[11px] truncate">
                          {language === 'ar' ? preset.nameAr : preset.nameEn}
                        </div>
                        <div className="text-[10px] text-blue-600 font-semibold flex items-center gap-1 mt-0.5">
                          {isCurrent ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>{tr('مفعّل حالياً', 'Active')}</span>
                            </>
                          ) : (
                            <span className="text-slate-400">{tr('اضغط للاختيار', 'Select')}</span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="font-semibold block mb-1">
                {tr('اسم المتجر / الشركة:', 'Store / Company Name:')}
              </label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('رقم الهاتف والتواصل:', 'Phone & Contact Number:')}
              </label>
              <input
                type="text"
                required
                value={storePhone}
                onChange={(e) => setStorePhone(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('العنوان والموقع:', 'Store Address & Location:')}
              </label>
              <input
                type="text"
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('الرقم الضريبي (VAT):', 'Tax Registration Number (VAT):')}
              </label>
              <input
                type="text"
                value={taxNumber}
                onChange={(e) => setTaxNumber(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('رقم السجل التجاري (CR):', 'Commercial Registration (CR):')}
              </label>
              <input
                type="text"
                value={crNumber}
                onChange={(e) => setCrNumber(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('رمز العملة:', 'Currency Symbol:')}
              </label>
              <input
                type="text"
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                placeholder="ج.م، EGP، $..."
              />
            </div>

            <div>
              <label className="font-semibold block mb-1 flex items-center justify-between">
                <span>{tr('نسبة ضريبة القيمة المضافة (%):', 'Value Added Tax (VAT %):')}</span>
                <span className="text-[10px] text-emerald-700 font-bold">
                  {tr('(طالما هي 0 لا تُحسب في أي فاتورة)', '(0 = Not calculated on any invoice)')}
                </span>
              </label>
              <NumberStepperInput
                min={0}
                max={100}
                step={1}
                value={vatPercentage}
                onChange={(val) => setVatPercentage(Math.max(0, Number(val) || 0))}
                placeholder="0"
                className="w-full"
                inputClassName="font-bold tabular-nums"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                {tr(
                  'تظل الضريبة صفر (0) ولا تُحسب في أي فاتورة إطلاقاً إلا عند كتابة رقم أكبر من صفر في الخانة.',
                  'VAT stays 0 and is never calculated on any invoice unless a number > 0 is entered in the field.'
                )}
              </span>
            </div>

            <div>
              <label className="font-semibold block mb-1 flex items-center justify-between">
                <span>{tr('نسبة فائدة التقسيط الافتراضية (%):', 'Default Installment Interest (%):')}</span>
                <span className="text-[10px] text-amber-600 font-bold">
                  {tr('(تحتسب من المبلغ الباقي فقط)', '(Calculated on remaining balance)')}
                </span>
              </label>
              <NumberStepperInput
                min={0}
                max={100}
                step={1}
                value={installmentInterestPercentage}
                onChange={(val) => setInstallmentInterestPercentage(val)}
                className="w-full"
                inputClassName="font-bold tabular-nums text-amber-800"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                {tr(
                  'تطبق بالنسبة المئوية على المبلغ المتبقي بعد خصم الدفعة المقدمة عند اختيار التقسيط، ولا تظهر في الفاتورة.',
                  'Applied as a percentage on the remaining amount after down payment; hidden on customer receipt.'
                )}
              </span>
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('لغة واجهة النظام واتجاه العرض:', 'System Interface Language & Direction:')}
              </label>
              <select
                value={language}
                onChange={(e) => {
                  const nextLang = e.target.value as 'ar' | 'en';
                  setLanguage(nextLang);
                  showToast(
                    nextLang === 'en'
                      ? 'Switched to English (Left-to-Right LTR Layout)'
                      : 'تم التبديل إلى اللغة العربية (اتجاه من اليمين لليسار RTL)',
                    'success'
                  );
                }}
                className="neu-input w-full px-3 py-2 rounded-xl font-bold text-blue-700"
              >
                <option value="ar">العربية (Arabic — RTL من اليمين لليسار)</option>
                <option value="en">English (LTR — Left to Right)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Print & Printer Configuration */}
        <div id="section-printers" className="neu-card p-5 rounded-3xl space-y-4 text-xs">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Printer className="w-4 h-4 text-blue-600" />
              <span>{tr('إعدادات الطابعة والطباعة الفورية', 'Printer & Instant Receipt Configuration')}</span>
            </h3>
            <button
              type="button"
              onClick={() => setIsPrinterModalOpen(true)}
              className="neu-button px-3 py-1.5 rounded-xl font-bold text-blue-600 flex items-center gap-1.5 cursor-pointer text-xs"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{tr('معالج اختيار وتعريف الطابعة الشامل', 'Comprehensive Printer Setup Wizard')}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold block mb-1">
                {tr('نوع الطابعة المستهدفة للطباعة الفورية:', 'Target Printer Type for Instant Print:')}
              </label>
              <select
                value={selectedPrinter}
                onChange={(e) => {
                  const val = e.target.value as PrinterType;
                  setSelectedPrinter(val);
                  if (val === 'a4-standard') setPrintLayout('a4');
                  else if (val === 'thermal-80' || val === 'thermal-58') setPrintLayout('thermal');
                }}
                className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
              >
                <option value="thermal-80">{tr('طابعة فواتير حرارية (80mm Thermal Receipt) — الموصى به', '80mm Thermal Receipt Printer — Recommended')}</option>
                <option value="thermal-58">{tr('طابعة فواتير حرارية مدمجة (58mm Thermal Mini)', '58mm Compact Thermal Receipt Printer')}</option>
                <option value="a4-standard">{tr('طابعة مكتبية قياسية (Standard A4 / Laser)', 'Standard Office A4 / Laser Printer')}</option>
                <option value="system-dialog">{tr('قائمة طابعات النظام يدوياً (System Print Dialog)', 'System Print Dialog')}</option>
                <option value="pdf-export">{tr('طابعة PDF الرقمية (حفظ كملف)', 'Digital PDF Export (Save as File)')}</option>
              </select>
            </div>

            <div>
              <label className="font-semibold block mb-1">
                {tr('اسم أو موديل الطابعة المتصلة (اختياري):', 'Connected Printer Name / Model (Optional):')}
              </label>
              <input
                type="text"
                value={printerCustomName}
                onChange={(e) => setPrinterCustomName(e.target.value)}
                placeholder={tr('مثال: Epson TM-T20III أو Xprinter XP-420B أو HP LaserJet', 'e.g. Epson TM-T20III, Xprinter XP-420B, HP LaserJet')}
                className="neu-input w-full px-3 py-2 rounded-xl font-medium"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoPrintOnSale}
                  onChange={(e) => setAutoPrintOnSale(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>{tr('طباعة فورية تلقائية بمجرد إتمام وحفظ الفاتورة (Auto-Print)', 'Automatic Instant Print upon completing a sale (Auto-Print)')}</span>
                </span>
              </label>

              <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showPrinterDialogBeforePrint}
                  onChange={(e) => setShowPrinterDialogBeforePrint(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <span>{tr('إظهار قائمة اختيار الطابعة قبل كل عملية طباعة', 'Show printer selection dialog before every print')}</span>
              </label>
            </div>

            <div>
              <label className="font-semibold block mb-1">{tr('كود التحقق الإلكتروني (ZATCA QR):', 'Electronic Tax QR Code (ZATCA / Tax QR):')}</label>
              <label className="flex items-center gap-2 mt-1 font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableZatcaQR}
                  onChange={(e) => setEnableZatcaQR(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <span>{tr('تضمين رمز QR المعتمد للضريبة والفوترة الإلكترونية', 'Include compliant e-Invoice QR code on printed receipts')}</span>
              </label>
            </div>
          </div>

          {/* Test Prints Row */}
          <div className="pt-3 border-t border-slate-200/60 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="font-semibold block text-slate-700">
                {tr('اختبار الفاتورة والطباعة الفورية:', 'Test Receipt & Instant Print:')}
              </span>
              <span className="text-[11px] text-slate-500">
                {tr('يمكنك تجربة إرسال أمر فوري للطابعة أو تحميل النموذج كملف Word أو PDF', 'Send a test print to your printer or download a sample Word / PDF invoice')}
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Test Word */}
              <button
                type="button"
                onClick={handleTestWord}
                className="neu-button px-3 py-1.5 rounded-xl text-xs font-bold text-blue-700 bg-blue-50/50 hover:bg-blue-100/50 flex items-center gap-1.5 cursor-pointer border border-blue-200"
                title={tr('تحميل نموذج الفاتورة في برنامج Word', 'Download sample invoice in Word format')}
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>{tr('نموذج Word (.doc)', 'Word Sample (.doc)')}</span>
              </button>

              {/* Test PDF */}
              <button
                type="button"
                onClick={handleTestPrintPDF}
                className="neu-button px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                title={tr('تحميل نموذج الفاتورة بصيغة PDF', 'Download sample invoice as PDF')}
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>{tr('نموذج PDF', 'PDF Sample')}</span>
              </button>

              {/* Direct Print */}
              <button
                type="button"
                onClick={handleTestDirectPrint}
                className="neu-button-primary px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                title={tr('إرسال أمر طباعة فوري للطابعة المحددة', 'Send instant test print to selected printer')}
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{tr('طباعة فورية تجريبية', 'Instant Test Print')}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Save Changes Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="neu-button-primary px-8 py-3 rounded-2xl text-xs font-bold shadow-lg cursor-pointer"
          >
            {tr('حفظ كافة التغييرات', 'Save All Changes')}
          </button>
        </div>
      </form>

      {/* MULTI-CURRENCY & MANUAL EXCHANGE RATE MANAGEMENT (إدارة العملات وتحديث سعر الصرف يدوياً وتأثيره على البيع والشراء) */}
      <div id="section-currencies" className="neu-card p-5 rounded-3xl space-y-4 text-xs border border-emerald-200/60">
        {/* Card Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-100/80 flex items-center justify-center text-emerald-700 shadow-inner">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-black text-slate-800 text-sm">
                  {tr('إدارة العملات وتحديث أسعار الصرف يدوياً', 'Multi-Currency & Manual Exchange Rate Management')}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                  {tr('العملة النشطة:', 'Active Currency:')} {activeCurrency?.name} ({activeCurrency?.symbol})
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                  {tr('سعر الصرف الحالي:', 'Current Rate:')} {activeCurrency?.exchangeRate}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {tr(
                  'التبديل الفوري بين العملات وتحديث سعر الصرف يدوياً مع تحديث تلقائي لأسعار البيع والشراء في المخزون ونقطة البيع والمشتريات',
                  'Switch currencies and manually update exchange rates with automatic recalculation of sale and purchase prices across POS and inventory'
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <label className="flex items-center gap-1.5 cursor-pointer neu-button px-3 py-1.5 rounded-xl font-bold text-xs text-emerald-800 bg-emerald-50/60 border border-emerald-200">
              <input
                type="checkbox"
                checked={autoUpdatePricesOnRateChange}
                onChange={(e) => {
                  const checked = e.target.checked;
                  setAutoUpdatePricesOnRateChange(checked);
                  updateSettings({ autoUpdatePricesOnRateChange: checked });
                  showToast(
                    checked
                      ? tr('تم تفعيل التحديث التلقائي لأسعار البيع والشراء عند تعديل سعر الصرف!', 'Auto-update of sale & purchase prices enabled!')
                      : tr('تم إيقاف التحديث التلقائي للأسعار عند تعديل الصرف', 'Auto-update of prices disabled'),
                    'info'
                  );
                }}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>{tr('تأثير تلقائي على أسعار البيع والشراء', 'Auto-update Sale & Purchase Prices')}</span>
            </label>

            <button
              type="button"
              onClick={() => {
                setNewCurrCode('');
                setNewCurrName('');
                setNewCurrSymbol('');
                setNewCurrRate('1');
                setIsAddCurrencyModalOpen(true);
              }}
              className="neu-button-primary px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{tr('إضافة عملة جديدة', 'Add Currency')}</span>
            </button>
          </div>
        </div>

        {/* Quick Currency Switcher Cards */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-700 text-xs flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-emerald-600" />
              <span>{tr('التبديل السريع لعملة النظام النشطة (يُحدث أسعار البيع والشراء فوراً):', 'Quick Active Currency Switcher (Instantly updates sale & purchase prices):')}</span>
            </span>
            <span className="text-[10px] text-slate-400">
              {tr('العملة الأساسية المرجعية:', 'Base Reference Currency:')}{' '}
              <strong className="text-slate-700">{baseCurrency?.name} ({baseCurrency?.code}) = 1.00</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {currencies.map((curr) => {
              const isActive = curr.code === activeCurrency?.code;
              const isBase = curr.isBase || curr.code === baseCurrency?.code;
              return (
                <div
                  key={curr.id || curr.code}
                  onClick={() => {
                    if (!isActive) {
                      const res = switchActiveCurrency(curr.code);
                      if (res.success) {
                        setPreviewCurrencyCode(curr.code);
                        showToast(res.message, 'success');
                      } else {
                        showToast(res.message, 'error');
                      }
                    }
                  }}
                  className={`p-3 rounded-2xl transition-all cursor-pointer flex flex-col justify-between gap-2 relative select-none ${
                    isActive
                      ? 'neu-pressed bg-emerald-50/90 border-2 border-emerald-500 shadow-sm'
                      : 'neu-flat hover:border-emerald-300 border border-transparent hover:-translate-y-0.5'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <div>
                      <span className="font-mono font-black text-xs text-slate-800 block">
                        {curr.code} <span className="text-emerald-700">({curr.symbol})</span>
                      </span>
                      <span className="text-[11px] font-bold text-slate-600 block mt-0.5">{curr.name}</span>
                    </div>
                    {isActive && (
                      <span className="px-1.5 py-0.5 rounded-full bg-emerald-600 text-white text-[9px] font-black">
                        نشطة
                      </span>
                    )}
                    {!isActive && isBase && (
                      <span className="px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[9px] font-bold">
                        أساسية
                      </span>
                    )}
                  </div>

                  <div className="pt-1.5 border-t border-slate-200/60 flex items-center justify-between text-[10px]">
                    <span className="text-slate-400">سعر الصرف:</span>
                    <span className="font-mono font-black text-slate-700 tabular-nums">
                      {curr.exchangeRate} {baseCurrency?.symbol}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sub-Tabs for Manual Exchange Rate Editor, Live Price Impact Preview, and Logs */}
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-200/60 pb-2 pt-1">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveCurrencyTab('rates')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeCurrencyTab === 'rates'
                  ? 'neu-pressed text-emerald-700 bg-white font-extrabold shadow-2xs'
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث أسعار الصرف يدوياً ({currencies.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveCurrencyTab('preview')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeCurrencyTab === 'preview'
                  ? 'neu-pressed text-emerald-700 bg-white font-extrabold shadow-2xs'
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>معاينة تأثير الصرف على أسعار البيع والشراء ({products.length} صنف)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveCurrencyTab('history')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeCurrencyTab === 'history'
                  ? 'neu-pressed text-emerald-700 bg-white font-extrabold shadow-2xs'
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>سجل تحديثات الصرف ({settings.exchangeRateLogs?.length || 0})</span>
            </button>
          </div>

          {/* Price Impact Mode Selector */}
          <div className="flex items-center gap-2 text-[11px]">
            <span className="text-slate-500 font-semibold">آلية تأثير تحديث الصرف على الأسعار:</span>
            <select
              value={priceImpactMode}
              onChange={(e) => setPriceImpactMode(e.target.value as 'auto' | 'scale_all' | 'convert_active')}
              className="neu-input px-2.5 py-1 rounded-xl font-bold text-emerald-800 text-[11px]"
            >
              <option value="auto">تلقائي ذكي (تحويل العملة النشطة + تعديل نسبي للأسعار)</option>
              <option value="scale_all">تعديل نسبي مباشر لكافة أسعار البيع والشراء بنسبة تغير الصرف</option>
              <option value="convert_active">تحويل من السعر الأساسي المرجعي فقط</option>
            </select>
          </div>
        </div>

        {/* TAB 1: Manual Exchange Rates Table */}
        {activeCurrencyTab === 'rates' && (
          <div className="space-y-4 pt-1">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="border-b border-slate-200 text-slate-500">
                  <tr>
                    <th className="pb-2.5">العملة والرمز</th>
                    <th className="pb-2.5 text-center">الحالة</th>
                    <th className="pb-2.5">سعر الصرف اليدوي (مقابل {baseCurrency?.name})</th>
                    <th className="pb-2.5 text-center">تعديل سريع للنسبة</th>
                    <th className="pb-2.5 text-center">معادلة التحويل</th>
                    <th className="pb-2.5 text-left">تطبيق التحديث والإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {currencies.map((curr) => {
                    const isActive = curr.code === activeCurrency?.code;
                    const isBase = curr.isBase || curr.code === baseCurrency?.code;
                    const inputVal = editingRates[curr.code] ?? String(curr.exchangeRate);
                    const numericInput = parseFloat(inputVal);
                    const isChanged = !isNaN(numericInput) && numericInput > 0 && Number(numericInput.toFixed(6)) !== Number(curr.exchangeRate.toFixed(6));
                    const pctDiff = (!isNaN(numericInput) && curr.exchangeRate > 0)
                      ? (((numericInput - curr.exchangeRate) / curr.exchangeRate) * 100)
                      : 0;

                    return (
                      <tr
                        key={curr.id || curr.code}
                        className={`transition-colors ${
                          isActive ? 'bg-emerald-50/50' : 'hover:bg-slate-50/70'
                        }`}
                      >
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <span className="w-9 h-9 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-mono font-black text-emerald-700 text-xs">
                              {curr.symbol}
                            </span>
                            <div>
                              <span className="font-bold text-slate-800 block">
                                {curr.name} <span className="font-mono text-[11px] text-slate-500">({curr.code})</span>
                              </span>
                              {curr.updatedAt && (
                                <span className="text-[10px] text-slate-400 block">
                                  آخر تحديث: {new Date(curr.updatedAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>

                        <td className="py-3 text-center">
                          <div className="flex flex-col items-center gap-1">
                            {isActive && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                العملة النشطة حالياً
                              </span>
                            )}
                            {isBase && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                                العملة الأساسية
                              </span>
                            )}
                            {!isActive && !isBase && (
                              <span className="text-[10px] text-slate-400">عملة مساندة</span>
                            )}
                          </div>
                        </td>

                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-semibold text-slate-500 whitespace-nowrap">
                              1 {curr.code} =
                            </span>
                            <div className="relative w-32">
                              <input
                                type="number"
                                step="0.0001"
                                min="0.0001"
                                value={inputVal}
                                onChange={(e) => {
                                  setEditingRates(prev => ({
                                    ...prev,
                                    [curr.code]: e.target.value
                                  }));
                                }}
                                className={`neu-input w-full px-3 py-1.5 rounded-xl font-mono font-black text-center tabular-nums text-xs ${
                                  isChanged
                                    ? 'ring-2 ring-amber-400 text-amber-800 bg-amber-50/40'
                                    : 'text-slate-800'
                                }`}
                              />
                            </div>
                            <span className="text-[11px] font-bold text-slate-600">
                              {baseCurrency?.symbol}
                            </span>
                            {isChanged && (
                              <span
                                className={`px-1.5 py-0.5 rounded-lg font-mono text-[10px] font-black ${
                                  pctDiff > 0 ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {pctDiff > 0 ? `+${pctDiff.toFixed(1)}%` : `${pctDiff.toFixed(1)}%`}
                              </span>
                            )}
                          </div>
                        </td>

                        <td className="py-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            {[
                              { label: '-5%', factor: 0.95 },
                              { label: '-1%', factor: 0.99 },
                              { label: '+1%', factor: 1.01 },
                              { label: '+5%', factor: 1.05 }
                            ].map((btn) => (
                              <button
                                key={btn.label}
                                type="button"
                                onClick={() => {
                                  const currentVal = parseFloat(editingRates[curr.code] || String(curr.exchangeRate)) || curr.exchangeRate;
                                  const nextVal = Number((currentVal * btn.factor).toFixed(4));
                                  setEditingRates(prev => ({
                                    ...prev,
                                    [curr.code]: String(nextVal)
                                  }));
                                }}
                                className="neu-button px-2 py-1 rounded-lg font-mono text-[10px] font-bold text-slate-600 hover:text-emerald-700 cursor-pointer"
                                title={`تعديل سعر الصرف بنسبة ${btn.label}`}
                              >
                                {btn.label}
                              </button>
                            ))}
                          </div>
                        </td>

                        <td className="py-3 text-center font-mono text-[11px] text-slate-500">
                          {numericInput > 0 ? (
                            <div>
                              <span className="block text-slate-700 font-bold">
                                1 {curr.symbol} = {numericInput.toFixed(3)} {baseCurrency?.symbol}
                              </span>
                              <span className="block text-[10px] text-slate-400">
                                1 {baseCurrency?.symbol} = {(1 / numericInput).toFixed(4)} {curr.symbol}
                              </span>
                            </div>
                          ) : (
                            <span>—</span>
                          )}
                        </td>

                        <td className="py-3 text-left">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Manual Update Rate & Apply to Sale/Purchase Prices Button */}
                            <button
                              type="button"
                              onClick={() => {
                                const parsed = parseFloat(editingRates[curr.code] || String(curr.exchangeRate));
                                if (isNaN(parsed) || parsed <= 0) {
                                  showToast('يرجى إدخال سعر صرف صحيح أكبر من الصفر', 'error');
                                  return;
                                }
                                const res = updateCurrencyExchangeRate(curr.code, parsed, {
                                  applyToProductPrices: autoUpdatePricesOnRateChange,
                                  priceImpactMode
                                });
                                if (res.success) {
                                  showToast(res.message, 'success');
                                } else {
                                  showToast(res.message, 'error');
                                }
                              }}
                              className={`px-3 py-1.5 rounded-xl font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-all whitespace-nowrap ${
                                isChanged
                                  ? 'neu-button-primary shadow-md animate-pulse'
                                  : 'neu-button text-emerald-700 hover:text-emerald-800'
                              }`}
                              title="حفظ سعر الصرف الجديد وتحديث أسعار البيع والشراء"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>{isChanged ? 'تأكيد الصرف وتحديث الأسعار' : 'تحديث الصرف'}</span>
                            </button>

                            {!isActive && (
                              <button
                                type="button"
                                onClick={() => {
                                  // First apply any pending rate edit on this currency before switching
                                  const parsed = parseFloat(editingRates[curr.code] || String(curr.exchangeRate));
                                  if (!isNaN(parsed) && parsed > 0 && parsed !== curr.exchangeRate) {
                                    updateCurrencyExchangeRate(curr.code, parsed, {
                                      applyToProductPrices: autoUpdatePricesOnRateChange,
                                      priceImpactMode
                                    });
                                  }
                                  const res = switchActiveCurrency(curr.code);
                                  if (res.success) {
                                    setPreviewCurrencyCode(curr.code);
                                    showToast(res.message, 'success');
                                  } else {
                                    showToast(res.message, 'error');
                                  }
                                }}
                                className="neu-button px-2.5 py-1.5 rounded-xl font-bold text-[11px] text-blue-600 hover:text-blue-800 cursor-pointer whitespace-nowrap"
                                title="تفعيل هذه العملة كعملة نشطة للنظام وتحويل أسعار البيع والشراء إليها"
                              >
                                تفعيل للنظام
                              </button>
                            )}

                            {!isBase && (
                              <button
                                type="button"
                                onClick={() => {
                                  requestConfirm({
                                    title: 'تغيير العملة الأساسية للنظام',
                                    message: `هل تريد تعيين "${curr.name} (${curr.code})" كعملة أساسية مرجعية للنظام (سعر صرفها = 1.0) وإعادة احتساب نسب العملات الأخرى؟`,
                                    confirmText: 'نعم، تعيين كعملة أساسية',
                                    isDestructive: false,
                                    onConfirm: () => {
                                      const res = setBaseCurrency(curr.code);
                                      if (res.success) {
                                        showToast(res.message, 'success');
                                      } else {
                                        showToast(res.message, 'error');
                                      }
                                    }
                                  });
                                }}
                                className="neu-button px-2 py-1.5 rounded-xl font-semibold text-[10px] text-slate-500 hover:text-indigo-700 cursor-pointer whitespace-nowrap"
                                title="جعل هذه العملة هي العملة الأساسية المرجعية (1.0)"
                              >
                                كمرجع أساسي
                              </button>
                            )}

                            {!isBase && !isActive && (
                              <button
                                type="button"
                                onClick={() => {
                                  const res = deleteCurrency(curr.code);
                                  if (res.success) {
                                    showToast(res.message, 'success');
                                  } else {
                                    showToast(res.message, 'error');
                                  }
                                }}
                                className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                                title="حذف العملة"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Instant Live Impact Summary Box */}
            <div className="neu-flat p-4 rounded-2xl bg-emerald-50/40 border border-emerald-200/70 space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span>أمثلة حية لتأثير العملة وسعر الصرف الحالي على أسعار الشراء والبيع في المتجر:</span>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveCurrencyTab('preview')}
                  className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                >
                  عرض جدول جميع الأصناف ({products.length}) ←
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {products.slice(0, 4).map((p) => {
                  const activeInputRate = parseFloat(editingRates[activeCurrency?.code || 'EGP'] || String(activeCurrency?.exchangeRate || 1)) || 1;
                  const savedActiveRate = activeCurrency?.exchangeRate || 1;
                  const isPendingRateChange = Math.abs(activeInputRate - savedActiveRate) > 0.0001;

                  const previewCost = isPendingRateChange
                    ? Number(((p.baseCostPrice ?? p.costPrice * savedActiveRate) / activeInputRate).toFixed(2))
                    : p.costPrice;
                  const previewSale = isPendingRateChange
                    ? Number(((p.baseSalePrice ?? p.salePrice * savedActiveRate) / activeInputRate).toFixed(2))
                    : p.salePrice;

                  return (
                    <div key={p.id} className="bg-white p-2.5 rounded-xl border border-slate-200/80 shadow-2xs space-y-1.5">
                      <span className="font-bold text-slate-800 text-[11px] block truncate">{p.name}</span>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500">سعر الشراء (التكلفة):</span>
                        <span className="font-mono font-bold text-amber-700 tabular-nums">
                          {previewCost.toFixed(2)} {activeCurrency?.symbol}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500">سعر البيع للكاشير:</span>
                        <span className="font-mono font-black text-emerald-700 tabular-nums">
                          {previewSale.toFixed(2)} {activeCurrency?.symbol}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Full Product Sale & Purchase Price Impact Preview */}
        {activeCurrencyTab === 'preview' && (
          <div className="space-y-3 pt-1">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 neu-flat p-3 rounded-2xl">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-slate-700">معاينة الأسعار بعملة:</span>
                <select
                  value={previewCurrencyCode}
                  onChange={(e) => setPreviewCurrencyCode(e.target.value)}
                  className="neu-input px-3 py-1.5 rounded-xl font-bold text-emerald-800 text-xs"
                >
                  {currencies.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.name} ({c.symbol}) — سعر الصرف: {editingRates[c.code] || c.exchangeRate}
                    </option>
                  ))}
                </select>
              </div>

              {previewCurrencyCode !== activeCurrency?.code && (
                <button
                  type="button"
                  onClick={() => {
                    const res = switchActiveCurrency(previewCurrencyCode);
                    if (res.success) {
                      showToast(res.message, 'success');
                    }
                  }}
                  className="neu-button-primary px-4 py-1.5 rounded-xl font-bold text-xs cursor-pointer"
                >
                  اعتماد هذه العملة كعملة نشطة للنظام الآن
                </button>
              )}
            </div>

            <div className="overflow-x-auto max-h-80">
              <table className="w-full text-right text-xs">
                <thead className="sticky top-0 bg-white/95 backdrop-blur-xs border-b border-slate-200 text-slate-500">
                  <tr>
                    <th className="pb-2">الصنف</th>
                    <th className="pb-2 text-center">سعر الشراء الأساسي ({baseCurrency?.symbol})</th>
                    <th className="pb-2 text-center">سعر الشراء بالعملة المختارة</th>
                    <th className="pb-2 text-center">سعر البيع الأساسي ({baseCurrency?.symbol})</th>
                    <th className="pb-2 text-center">سعر البيع بالعملة المختارة</th>
                    <th className="pb-2 text-center">صافي الربح للوحدة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {products.map((p) => {
                    const targetCurr = currencies.find(c => c.code === previewCurrencyCode) || activeCurrency;
                    const rate = parseFloat(editingRates[targetCurr.code] || String(targetCurr.exchangeRate)) || targetCurr.exchangeRate || 1;
                    const baseCost = p.baseCostPrice ?? p.costPrice * (activeCurrency?.exchangeRate || 1);
                    const baseSale = p.baseSalePrice ?? p.salePrice * (activeCurrency?.exchangeRate || 1);
                    const convertedCost = Number((baseCost / rate).toFixed(2));
                    const convertedSale = Number((baseSale / rate).toFixed(2));
                    const unitProfit = Number((convertedSale - convertedCost).toFixed(2));

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/60">
                        <td className="py-2.5">
                          <span className="font-bold text-slate-800 block">{p.name}</span>
                          <span className="font-mono text-[10px] text-slate-400">{p.barcode}</span>
                        </td>
                        <td className="py-2.5 text-center font-mono text-slate-500 tabular-nums">
                          {baseCost.toFixed(2)} {baseCurrency?.symbol}
                        </td>
                        <td className="py-2.5 text-center font-mono font-bold text-amber-700 tabular-nums bg-amber-50/40">
                          {convertedCost.toFixed(2)} {targetCurr.symbol}
                        </td>
                        <td className="py-2.5 text-center font-mono text-slate-500 tabular-nums">
                          {baseSale.toFixed(2)} {baseCurrency?.symbol}
                        </td>
                        <td className="py-2.5 text-center font-mono font-black text-emerald-700 tabular-nums bg-emerald-50/40">
                          {convertedSale.toFixed(2)} {targetCurr.symbol}
                        </td>
                        <td className="py-2.5 text-center font-mono font-bold text-blue-600 tabular-nums">
                          +{unitProfit.toFixed(2)} {targetCurr.symbol}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: Exchange Rate Update History Log */}
        {activeCurrencyTab === 'history' && (
          <div className="space-y-3 pt-1">
            {(!settings.exchangeRateLogs || settings.exchangeRateLogs.length === 0) ? (
              <div className="neu-flat p-8 rounded-2xl text-center text-slate-400 space-y-1">
                <History className="w-8 h-8 mx-auto opacity-40 text-emerald-600" />
                <p className="font-bold text-xs">لا توجد عمليات مسجلة لتغيير سعر الصرف بعد</p>
                <p className="text-[11px]">أي تحديث يدوي لسعر الصرف أو تبديل للعملة سيظهر هنا مع عدد الأصناف المتأثرة</p>
              </div>
            ) : (
              <div className="overflow-x-auto max-h-72">
                <table className="w-full text-right text-xs">
                  <thead className="border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="pb-2">التاريخ والوقت</th>
                      <th className="pb-2">العملة</th>
                      <th className="pb-2 text-center">نوع العملية</th>
                      <th className="pb-2 text-center">سعر الصرف السابق</th>
                      <th className="pb-2 text-center">سعر الصرف الجديد</th>
                      <th className="pb-2 text-center">الأصناف المحدثة</th>
                      <th className="pb-2">التفاصيل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {settings.exchangeRateLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/60">
                        <td className="py-2 font-mono text-[11px] text-slate-500">
                          {new Date(log.date).toLocaleDateString('ar-SA')}{' '}
                          {new Date(log.date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="py-2 font-bold text-slate-800">
                          {log.currencyName} ({log.currencyCode})
                        </td>
                        <td className="py-2 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              log.actionType === 'rate_update'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {log.actionType === 'rate_update' ? 'تحديث سعر الصرف' : 'تبديل عملة النظام'}
                          </span>
                        </td>
                        <td className="py-2 text-center font-mono text-slate-500 tabular-nums">{log.oldRate}</td>
                        <td className="py-2 text-center font-mono font-black text-emerald-700 tabular-nums">{log.newRate}</td>
                        <td className="py-2 text-center font-bold text-blue-600 tabular-nums">
                          {log.affectedProductsCount} صنف
                        </td>
                        <td className="py-2 text-slate-500 text-[11px]">{log.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add New Currency Modal */}
      {isAddCurrencyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="neu-card bg-white w-full max-w-md p-6 rounded-3xl shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Coins className="w-4 h-4 text-emerald-600" />
                <span>إضافة عملة جديدة للنظام</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddCurrencyModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Presets */}
            <div className="space-y-1.5 text-xs">
              <span className="font-semibold text-slate-500 text-[11px] block">اختيار سريع لعملات عربية وعالمية:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {[
                  { code: 'IQD', name: 'دينار عراقي', symbol: 'د.ع', rate: '0.0375' },
                  { code: 'JOD', name: 'دينار أردني', symbol: 'د.أ', rate: '69.50' },
                  { code: 'OMR', name: 'ريال عماني', symbol: 'ر.ع', rate: '128.05' },
                  { code: 'QAR', name: 'ريال قطري', symbol: 'ر.ق', rate: '13.54' },
                  { code: 'BHD', name: 'دينار بحريني', symbol: 'د.ب', rate: '130.80' },
                  { code: 'SYP', name: 'ليرة سورية', symbol: 'ل.س', rate: '0.0038' },
                  { code: 'YER', name: 'ريال يمني', symbol: 'ر.ي', rate: '0.197' },
                  { code: 'LYD', name: 'دينار ليبي', symbol: 'د.ل', rate: '10.15' },
                  { code: 'MAD', name: 'درهم مغربي', symbol: 'د.م', rate: '5.02' },
                  { code: 'TRY', name: 'ليرة تركية', symbol: '₺', rate: '1.44' },
                  { code: 'GBP', name: 'جنيه إسترليني', symbol: '£', rate: '63.80' }
                ].map((preset) => (
                  <button
                    key={preset.code}
                    type="button"
                    onClick={() => {
                      setNewCurrCode(preset.code);
                      setNewCurrName(preset.name);
                      setNewCurrSymbol(preset.symbol);
                      setNewCurrRate(preset.rate);
                    }}
                    className="neu-button px-2 py-1 rounded-lg text-[10px] font-bold text-slate-700 hover:text-emerald-700 cursor-pointer"
                  >
                    {preset.name} ({preset.symbol})
                  </button>
                ))}
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const parsedRate = parseFloat(newCurrRate);
                const res = addCurrency({
                  code: newCurrCode,
                  name: newCurrName,
                  symbol: newCurrSymbol,
                  exchangeRate: parsedRate
                });
                if (res.success) {
                  showToast(res.message, 'success');
                  setIsAddCurrencyModalOpen(false);
                } else {
                  showToast(res.message, 'error');
                }
              }}
              className="space-y-3 text-xs"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1">كود العملة (ISO):</label>
                  <input
                    type="text"
                    required
                    maxLength={5}
                    placeholder="IQD, JOD, GBP..."
                    value={newCurrCode}
                    onChange={(e) => setNewCurrCode(e.target.value.toUpperCase())}
                    className="neu-input w-full px-3 py-2 rounded-xl font-mono font-bold uppercase"
                  />
                </div>
                <div>
                  <label className="font-semibold block mb-1">رمز العرض (Symbol):</label>
                  <input
                    type="text"
                    required
                    placeholder="د.ع، د.أ، £..."
                    value={newCurrSymbol}
                    onChange={(e) => setNewCurrSymbol(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1">اسم العملة بالعربية:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: دينار عراقي، دينار أردني..."
                  value={newCurrName}
                  onChange={(e) => setNewCurrName(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">
                  سعر الصرف مقابل {baseCurrency?.name} (1 {newCurrCode || 'وحدة'} = كم {baseCurrency?.symbol}؟):
                </label>
                <input
                  type="number"
                  step="0.0001"
                  min="0.0001"
                  required
                  value={newCurrRate}
                  onChange={(e) => setNewCurrRate(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono font-black text-emerald-700 tabular-nums"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddCurrencyModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إضافة العملة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MULTI-WAREHOUSE MANAGEMENT & STOCK DISTRIBUTION (إدارة تعدد المخازن وتوزيع المخزون) */}
      <div id="section-warehouses" className="neu-card p-5 rounded-3xl space-y-4 text-xs">
        {/* Card Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-100/80 flex items-center justify-center text-indigo-700 shadow-inner">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-800 text-sm">
                  {tr('نظام إدارة تعدد المخازن والمستودعات', 'Multi-Warehouse & Inventory Distribution System')}
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  enableMultiWarehouse ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                }`}>
                  {enableMultiWarehouse ? tr(`${warehouses.length} مستودعات نشطة`, `${warehouses.length} Active Warehouses`) : tr('النظام معطل', 'Disabled')}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {tr('توزيع الأصناف والكميات على فروع ومخازن مختلفة وتتبع المخزون لكل مستودع مع إمكانية التحويل المباشر', 'Distribute stock across multiple branches/warehouses and track per-warehouse inventory with direct transfers')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <label className="flex items-center gap-1.5 cursor-pointer neu-button px-3 py-1.5 rounded-xl font-bold text-xs text-slate-700">
              <input
                type="checkbox"
                checked={enableMultiWarehouse}
                onChange={(e) => {
                  setEnableMultiWarehouse(e.target.checked);
                  updateSettings({ enableMultiWarehouse: e.target.checked });
                  showToast(e.target.checked ? tr('تم تفعيل نظام تعدد المستودعات!', 'Multi-warehouse system enabled!') : tr('تم تعطيل نظام تعدد المستودعات', 'Multi-warehouse system disabled'), 'info');
                }}
                className="w-3.5 h-3.5 text-indigo-600 rounded"
              />
              <span>{tr('تفعيل تعدد المخازن', 'Enable Multi-Warehouse')}</span>
            </label>

            <button
              type="button"
              onClick={handleOpenTransferModal}
              className="neu-button px-3 py-1.5 rounded-xl font-bold text-indigo-700 flex items-center gap-1.5 cursor-pointer text-xs hover:text-indigo-800"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>{tr('نقل بضاعة بين المستودعات', 'Inter-Warehouse Transfer')}</span>
            </button>
            <button
              type="button"
              onClick={handleOpenAddWh}
              className="neu-button-primary px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{tr('إضافة مستودع جديد', 'Add New Warehouse')}</span>
            </button>
          </div>
        </div>

        {/* Quick KPI Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="neu-flat p-3 rounded-2xl">
            <span className="text-[10px] text-slate-400 block mb-0.5">{tr('عدد المستودعات المسجلة', 'Registered Warehouses')}</span>
            <span className="text-base font-black text-slate-800 tabular-nums">{warehouses.length} {tr('مستودع', 'WH')}</span>
          </div>
          <div className="neu-flat p-3 rounded-2xl">
            <span className="text-[10px] text-slate-400 block mb-0.5">{tr('إجمالي الأصناف بالمخزون', 'Total Products in Stock')}</span>
            <span className="text-base font-black text-blue-600 tabular-nums">{products.length} {tr('صنف', 'items')}</span>
          </div>
          <div className="neu-flat p-3 rounded-2xl">
            <span className="text-[10px] text-slate-400 block mb-0.5">{tr('إجمالي القطع في كافة المخازن', 'Total Units Across Warehouses')}</span>
            <span className="text-base font-black text-emerald-600 tabular-nums">
              {products.reduce((acc, p) => acc + (p.stock || 0), 0)} {tr('قطعة', 'pcs')}
            </span>
          </div>
          <div className="neu-flat p-3 rounded-2xl">
            <span className="text-[10px] text-slate-400 block mb-0.5">{tr('إجمالي قيمة المخزون التقديرية', 'Estimated Inventory Valuation')}</span>
            <span className="text-sm font-black text-purple-700 tabular-nums">
              {formatCurrency(products.reduce((acc, p) => acc + ((p.stock || 0) * (p.costPrice || 0)), 0))}
            </span>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 border-b border-slate-200/60 pb-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveWhTab('list')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeWhTab === 'list'
                ? 'neu-pressed text-indigo-700 bg-white font-extrabold shadow-2xs'
                : 'text-slate-600 hover:text-indigo-600'
            }`}
          >
            {tr('المستودعات وقوائم المخازن', 'Warehouses List')} ({warehouses.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveWhTab('distribution')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeWhTab === 'distribution'
                ? 'neu-pressed text-indigo-700 bg-white font-extrabold shadow-2xs'
                : 'text-slate-600 hover:text-indigo-600'
            }`}
          >
            {tr('توزيع وجرد المخزون حسب المستودع', 'Stock Distribution by Warehouse')}
          </button>
          <button
            type="button"
            onClick={() => setActiveWhTab('transfers')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeWhTab === 'transfers'
                ? 'neu-pressed text-indigo-700 bg-white font-extrabold shadow-2xs'
                : 'text-slate-600 hover:text-indigo-600'
            }`}
          >
            {tr('سجل تحويلات البضائع', 'Stock Transfers Log')} ({warehouseTransfers.length})
          </button>
        </div>

        {/* TAB 1: Warehouses Cards Grid */}
        {activeWhTab === 'list' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
            {warehouses.map(wh => {
              // Calculate stats for this warehouse
              let totalItems = 0;
              let totalPieces = 0;
              let totalCostVal = 0;
              let totalSaleVal = 0;
              products.forEach(p => {
                const qty = p.warehouseStock?.[wh.id] || 0;
                if (qty > 0) {
                  totalItems += 1;
                  totalPieces += qty;
                  totalCostVal += qty * (p.costPrice || 0);
                  totalSaleVal += qty * (p.salePrice || 0);
                }
              });

              return (
                <div
                  key={wh.id}
                  className={`neu-flat p-4 rounded-2xl flex flex-col justify-between transition-all relative ${
                    wh.isDefault ? 'border-2 border-indigo-400/80 shadow-indigo-100/50 shadow-md' : ''
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-black bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-lg">
                          {wh.code}
                        </span>
                        <h4 className="font-bold text-slate-800 text-xs">{wh.name}</h4>
                      </div>
                      {wh.isDefault ? (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          الافتراضي
                        </span>
                      ) : null}
                    </div>

                    <div className="space-y-1 text-[11px] text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{wh.location}</span>
                      </div>
                      {wh.managerName && (
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>المسؤول: {wh.managerName}</span>
                        </div>
                      )}
                      {wh.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="font-mono">{wh.phone}</span>
                        </div>
                      )}
                    </div>

                    {/* Stock & Valuation Metrics */}
                    <div className="pt-2 border-t border-slate-200/50 space-y-2">
                      <div className="grid grid-cols-2 gap-2 text-center">
                        <div className="bg-slate-50 p-1.5 rounded-xl">
                          <span className="text-[10px] text-slate-400 block">الأصناف المتوفرة</span>
                          <span className="font-black text-slate-800 tabular-nums">{totalItems} صنف</span>
                        </div>
                        <div className="bg-slate-50 p-1.5 rounded-xl">
                          <span className="text-[10px] text-slate-400 block">إجمالي القطع</span>
                          <span className="font-black text-indigo-600 tabular-nums">{totalPieces} قطعة</span>
                        </div>
                      </div>

                      <div className="bg-indigo-50/50 border border-indigo-100/70 p-2 rounded-xl flex items-center justify-between text-[11px]">
                        <div>
                          <span className="text-[9px] text-slate-400 block">قيمة المخزون (تكلفة):</span>
                          <span className="font-black text-indigo-800 tabular-nums">
                            {formatCurrency(totalCostVal)}
                          </span>
                        </div>
                        <div className="text-left">
                          <span className="text-[9px] text-slate-400 block">القيمة البيعية:</span>
                          <span className="font-black text-emerald-700 tabular-nums">
                            {formatCurrency(totalSaleVal)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setFilterDistWarehouse(wh.id);
                        setActiveWhTab('distribution');
                      }}
                      className="w-full mt-2 neu-button py-1.5 rounded-xl font-bold text-[11px] text-indigo-700 hover:text-indigo-900 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Boxes className="w-3.5 h-3.5" />
                      <span>عرض وتعديل جرد هذا المستودع</span>
                    </button>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 mt-3 border-t border-slate-200/50 flex items-center justify-between gap-1">
                    {!wh.isDefault ? (
                      <button
                        type="button"
                        onClick={() => handleSetDefaultWarehouse(wh)}
                        className="text-[10px] font-bold text-slate-600 hover:text-indigo-600 cursor-pointer"
                      >
                        تعيين كافتراضي
                      </button>
                    ) : (
                      <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        المستودع الرئيسي
                      </span>
                    )}

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEditWh(wh)}
                        className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                        title="تعديل بيانات المستودع"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteWarehouse(wh)}
                        disabled={wh.isDefault || warehouses.length <= 1}
                        className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 disabled:opacity-30 cursor-pointer"
                        title={wh.isDefault ? 'لا يمكن حذف المستودع الافتراضي' : 'حذف المستودع'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: Per-Product Warehouse Distribution Table */}
        {activeWhTab === 'distribution' && (
          <div className="space-y-3 pt-1">
            {/* Filter Bar */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 flex-1 max-w-md">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={searchDistProduct}
                    onChange={(e) => setSearchDistProduct(e.target.value)}
                    placeholder="ابحث باسم الصنف أو الباركود..."
                    className="neu-input w-full pl-3 pr-8 py-2 rounded-xl text-xs font-semibold"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute top-2.5 right-2.5 pointer-events-none" />
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Filter by warehouse */}
                <select
                  value={filterDistWarehouse}
                  onChange={(e) => setFilterDistWarehouse(e.target.value)}
                  className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-indigo-700"
                >
                  <option value="all">🏢 جميع المستودعات ({warehouses.length})</option>
                  {warehouses.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.code}) {w.isDefault ? '• الافتراضي' : ''}
                    </option>
                  ))}
                </select>

                {/* Filter stock status */}
                <select
                  value={filterDistStockStatus}
                  onChange={(e) => setFilterDistStockStatus(e.target.value as any)}
                  className="neu-input px-3 py-2 rounded-xl text-xs font-semibold text-slate-700"
                >
                  <option value="all">كل الحالات</option>
                  <option value="in_stock">المتوفر فقط</option>
                  <option value="out_of_stock">المنتهي (0)</option>
                </select>

                {/* Export Button */}
                <button
                  type="button"
                  onClick={() => handleExportWarehouseInventory(filterDistWarehouse)}
                  className="neu-button px-3 py-2 rounded-xl font-bold text-slate-700 hover:text-emerald-700 flex items-center gap-1.5 text-xs cursor-pointer whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-600" />
                  <span>تصدير الجرد (CSV)</span>
                </button>
              </div>
            </div>

            {/* If a specific warehouse is filtered, show an informative banner */}
            {filterDistWarehouse !== 'all' && (() => {
              const selectedWh = warehouses.find(w => w.id === filterDistWarehouse);
              if (!selectedWh) return null;
              let itemsCount = 0;
              let piecesCount = 0;
              let costSum = 0;
              let saleSum = 0;
              products.forEach(p => {
                const q = p.warehouseStock?.[selectedWh.id] || 0;
                if (q > 0) {
                  itemsCount++;
                  piecesCount += q;
                  costSum += q * (p.costPrice || 0);
                  saleSum += q * (p.salePrice || 0);
                }
              });

              return (
                <div className="neu-flat p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs bg-indigo-50/40 border border-indigo-100">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black bg-indigo-600 text-white px-2 py-0.5 rounded-lg">
                      {selectedWh.code}
                    </span>
                    <span className="font-bold text-slate-800">{selectedWh.name}</span>
                    <span className="text-[11px] text-slate-400">({selectedWh.location})</span>
                  </div>

                  <div className="flex items-center gap-4 text-[11px]">
                    <div>
                      <span className="text-slate-400 block text-[10px]">الأصناف المتوفرة:</span>
                      <span className="font-black text-slate-800 tabular-nums">{itemsCount} صنف</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">إجمالي القطع:</span>
                      <span className="font-black text-indigo-700 tabular-nums">{piecesCount} قطعة</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">قيمة التكلفة:</span>
                      <span className="font-black text-purple-700 tabular-nums">{formatCurrency(costSum)}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">القيمة البيعية:</span>
                      <span className="font-black text-emerald-700 tabular-nums">{formatCurrency(saleSum)}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFilterDistWarehouse('all')}
                      className="text-xs font-bold text-slate-500 hover:text-red-500 cursor-pointer"
                    >
                      ✕ إلغاء الفلترة
                    </button>
                  </div>
                </div>
              );
            })()}

            <div className="overflow-x-auto max-h-96">
              <table className="w-full text-right text-xs">
                <thead className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-slate-200 text-slate-500">
                  <tr>
                    <th className="pb-2">الصنف والباركود</th>
                    <th className="pb-2 text-center">التصنيف</th>
                    <th className="pb-2 text-center">
                      {filterDistWarehouse === 'all'
                        ? 'إجمالي المخزون'
                        : `مخزون (${warehouses.find(w => w.id === filterDistWarehouse)?.code || 'المستودع'})`}
                    </th>
                    <th className="pb-2">توزيع الكميات في كافة المستودعات</th>
                    <th className="pb-2 text-left">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {products
                    .filter(p => {
                      const q = searchDistProduct.trim().toLowerCase();
                      const matchSearch = !q || (
                        p.name.toLowerCase().includes(q) ||
                        p.barcode.toLowerCase().includes(q) ||
                        (p.category && p.category.toLowerCase().includes(q))
                      );
                      const targetStock = filterDistWarehouse === 'all'
                        ? p.stock
                        : (p.warehouseStock?.[filterDistWarehouse] || 0);

                      let matchStatus = true;
                      if (filterDistStockStatus === 'in_stock') {
                        matchStatus = targetStock > 0;
                      } else if (filterDistStockStatus === 'out_of_stock') {
                        matchStatus = targetStock <= 0;
                      }

                      return matchSearch && matchStatus;
                    })
                    .map(product => {
                      const currentWhQty = filterDistWarehouse === 'all'
                        ? product.stock
                        : (product.warehouseStock?.[filterDistWarehouse] || 0);

                      return (
                        <tr key={product.id} className="hover:bg-slate-50/60">
                          <td className="py-2.5">
                            <span className="font-bold text-slate-800 block">{product.name}</span>
                            <span className="font-mono text-[10px] text-slate-400">{product.barcode}</span>
                          </td>
                          <td className="py-2.5 text-center text-slate-600">
                            <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-[10px] font-semibold">
                              {product.category || 'عام'}
                            </span>
                          </td>
                          <td className="py-2.5 text-center font-black tabular-nums text-slate-800">
                            <span className={`px-2 py-0.5 rounded-lg ${
                              currentWhQty > 0 ? 'bg-indigo-50 text-indigo-700 font-bold' : 'bg-red-50 text-red-600'
                            }`}>
                              {currentWhQty} {product.unit || 'حبة'}
                            </span>
                          </td>
                          <td className="py-2.5">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {warehouses.map(wh => {
                                const qty = product.warehouseStock?.[wh.id] || 0;
                                const isTarget = filterDistWarehouse === wh.id;
                                return (
                                  <span
                                    key={wh.id}
                                    className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 ${
                                      isTarget
                                        ? 'bg-indigo-600 text-white font-black shadow-2xs'
                                        : qty > 0
                                        ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/80 font-bold'
                                        : 'bg-slate-100 text-slate-400'
                                    }`}
                                    title={`${wh.name}: ${qty} قطعة`}
                                  >
                                    <span>{wh.code}:</span>
                                    <span className="tabular-nums font-black">{qty}</span>
                                  </span>
                                );
                              })}
                            </div>
                          </td>
                          <td className="py-2.5 text-left">
                            <button
                              type="button"
                              onClick={() => handleOpenDistributeModal(product)}
                              className="neu-button px-2.5 py-1.5 rounded-xl font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 text-[11px] cursor-pointer whitespace-nowrap"
                            >
                              <Boxes className="w-3.5 h-3.5" />
                              <span>تعديل التوزيع</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: Inter-Warehouse Transfers Log */}
        {activeWhTab === 'transfers' && (
          <div className="space-y-3 pt-1">
            {warehouseTransfers.length === 0 ? (
              <div className="neu-flat p-8 rounded-2xl text-center space-y-2 text-slate-400">
                <ArrowLeftRight className="w-8 h-8 mx-auto opacity-40 text-indigo-600" />
                <p className="font-semibold text-xs">لا توجد عمليات نقل مسجلة بين المستودعات حتى الآن</p>
                <button
                  type="button"
                  onClick={handleOpenTransferModal}
                  className="neu-button-primary px-4 py-2 rounded-xl font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>تنفيذ أول أمر نقل بضاعة</span>
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto max-h-96">
                <table className="w-full text-right text-xs">
                  <thead className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="pb-2">رقم الإذن</th>
                      <th className="pb-2">التاريخ</th>
                      <th className="pb-2">الصنف المنقول</th>
                      <th className="pb-2 text-center">الكمية</th>
                      <th className="pb-2">من مستودع</th>
                      <th className="pb-2">إلى مستودع</th>
                      <th className="pb-2">المسؤول والملاحظات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {warehouseTransfers.map(tr => (
                      <tr key={tr.id} className="hover:bg-slate-50/60">
                        <td className="py-2.5 font-mono font-bold text-indigo-700">{tr.transferNumber}</td>
                        <td className="py-2.5 text-slate-500 tabular-nums">
                          {new Date(tr.date).toLocaleDateString('ar-SA')} {new Date(tr.date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="py-2.5">
                          <span className="font-bold text-slate-800 block">{tr.productName}</span>
                          <span className="font-mono text-[10px] text-slate-400">{tr.barcode}</span>
                        </td>
                        <td className="py-2.5 text-center font-black tabular-nums text-emerald-700">
                          {tr.quantity} قطعة
                        </td>
                        <td className="py-2.5">
                          <span className="px-2 py-0.5 rounded-lg bg-red-50 text-red-700 text-[10px] font-bold">
                            {tr.fromWarehouseName}
                          </span>
                        </td>
                        <td className="py-2.5">
                          <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                            {tr.toWarehouseName}
                          </span>
                        </td>
                        <td className="py-2.5 text-slate-500 text-[11px]">
                          <span>{tr.transferredBy}</span>
                          {tr.notes && <span className="block text-[10px] text-slate-400 truncate">{tr.notes}</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* MODAL 1: Add / Edit Warehouse Modal */}
      {isWhModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="neu-card bg-white w-full max-w-md p-6 rounded-3xl shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-600" />
                <span>{editingWh ? 'تعديل بيانات المستودع' : 'إضافة مستودع / فرع جديد'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsWhModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveWarehouse} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">اسم المستودع / الفرع:</label>
                <input
                  type="text"
                  required
                  value={whName}
                  onChange={(e) => setWhName(e.target.value)}
                  placeholder="مثال: المستودع الشمالي، فرع المعرض 2..."
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1">كود المستودع (رمز تعريفي):</label>
                  <input
                    type="text"
                    required
                    value={whCode}
                    onChange={(e) => setWhCode(e.target.value.toUpperCase())}
                    placeholder="WH-04"
                    className="neu-input w-full px-3 py-2 rounded-xl font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1">مسؤول المستودع (أمين المخزن):</label>
                  <input
                    type="text"
                    value={whManager}
                    onChange={(e) => setWhManager(e.target.value)}
                    placeholder="اسم المسؤول"
                    className="neu-input w-full px-3 py-2 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1">الموقع / العنوان:</label>
                  <input
                    type="text"
                    required
                    value={whLocation}
                    onChange={(e) => setWhLocation(e.target.value)}
                    placeholder="الرياض - حي الياسمين"
                    className="neu-input w-full px-3 py-2 rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1">رقم الهاتف والتواصل:</label>
                  <input
                    type="text"
                    value={whPhone}
                    onChange={(e) => setWhPhone(e.target.value)}
                    placeholder="05xxxxxxxx"
                    className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1">ملاحظات إضافية:</label>
                <textarea
                  value={whNotes}
                  onChange={(e) => setWhNotes(e.target.value)}
                  placeholder="سعة المستودع، مواعيد العمل أو أي تفاصيل..."
                  rows={2}
                  className="neu-input w-full px-3 py-1.5 rounded-xl text-xs resize-none"
                />
              </div>

              <div className="neu-flat p-2.5 rounded-xl flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={whIsDefault}
                    onChange={(e) => setWhIsDefault(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded"
                  />
                  <span>تعيين كمستودع افتراضي للبيع والصرف المباشر</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsWhModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  {editingWh ? 'حفظ التعديلات' : 'إضافة المستودع'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Inter-Warehouse Stock Transfer Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="neu-card bg-white w-full max-w-lg p-6 rounded-3xl shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-indigo-600" />
                <span>إذن نقل بضاعة بين المستودعات</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsTransferModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitTransfer} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1">من مستودع (المصدر):</label>
                  <select
                    value={transferFromWhId}
                    onChange={(e) => setTransferFromWhId(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                  >
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold block mb-1">إلى مستودع (الوجهة):</label>
                  <select
                    value={transferToWhId}
                    onChange={(e) => setTransferToWhId(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                  >
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id} disabled={w.id === transferFromWhId}>
                        {w.name} ({w.code})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1">اختيار الصنف المراد نقله:</label>
                <select
                  value={transferProductId}
                  onChange={(e) => setTransferProductId(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
                >
                  {products.map(p => {
                    const availableInSource = p.warehouseStock?.[transferFromWhId] || 0;
                    return (
                      <option key={p.id} value={p.id}>
                        {p.name} - متوفر بالمصدر: ({availableInSource} {p.unit || 'حبة'})
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Source Available Stock Info Box */}
              {(() => {
                const prod = products.find(p => p.id === transferProductId);
                const sourceStock = prod?.warehouseStock?.[transferFromWhId] || 0;
                return (
                  <div className="p-3 neu-flat rounded-2xl flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-semibold">
                      الرصيد المتاح للتحويل في مستودع المصدر:
                    </span>
                    <span className="font-black text-indigo-700 tabular-nums">
                      {sourceStock} {prod?.unit || 'قطعة'}
                    </span>
                  </div>
                );
              })()}

              <div>
                <label className="font-semibold block mb-1">الكمية المراد نقلها:</label>
                <NumberStepperInput
                  min={1}
                  step={1}
                  fallbackOnBlur={1}
                  value={transferQty}
                  onChange={(val) => setTransferQty(Math.max(1, Math.round(val)))}
                  className="w-full"
                  inputClassName="font-black text-indigo-700 tabular-nums text-sm"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">ملاحظات / سبب النقل:</label>
                <input
                  type="text"
                  value={transferNotes}
                  onChange={(e) => setTransferNotes(e.target.value)}
                  placeholder="مثال: تغذية صالة العرض أو تحويل بناء على طلب الفرع..."
                  className="neu-input w-full px-3 py-2 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  تأكيد نقل البضاعة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Stock Distribution Modal */}
      {isDistributeModalOpen && distributeProduct && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="neu-card bg-white w-full max-w-md p-6 rounded-3xl shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <Boxes className="w-4 h-4 text-indigo-600" />
                  <span>توزيع مخزون الصنف على المستودعات</span>
                </h3>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {distributeProduct.name} ({distributeProduct.barcode})
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsDistributeModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-500 text-[11px]">
                حدد كمية المخزون المتوفرة في كل مستودع. سيتم تحديث إجمالي مخزون الصنف تلقائياً بمجموع هذه الكميات:
              </p>

              <div className="space-y-2">
                {warehouses.map(wh => (
                  <div key={wh.id} className="p-3 neu-flat rounded-2xl flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-bold bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded">
                          {wh.code}
                        </span>
                        <span className="font-bold text-slate-800">{wh.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5 truncate max-w-[200px]">
                        {wh.location}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <NumberStepperInput
                        size="sm"
                        min={0}
                        step={1}
                        value={distributionMap[wh.id] !== undefined ? distributionMap[wh.id] : 0}
                        onChange={(val) => {
                          setDistributionMap(prev => ({ ...prev, [wh.id]: Math.max(0, Math.round(val)) }));
                        }}
                        className="w-24"
                        inputClassName="text-center font-black tabular-nums text-indigo-700 text-sm"
                      />
                      <span className="text-slate-500 font-semibold">{distributeProduct.unit || 'حبة'}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total Calculation Preview */}
              <div className="p-3 neu-pressed rounded-2xl flex items-center justify-between font-bold text-xs">
                <span>إجمالي المخزون الجديد بعد التوزيع:</span>
                <span className="font-black text-indigo-700 tabular-nums text-sm">
                  {Object.values(distributionMap).reduce((sum, v) => sum + (Number(v) || 0), 0)} {distributeProduct.unit || 'حبة'}
                </span>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsDistributeModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleSaveDistribution}
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  حفظ التوزيع المحدث
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Program Licensing & 2-Day Trial Status (Admin Only - Serial Key Only) */}
      {isAdmin && (
        <>
          <div id="section-license" className="neu-card p-5 rounded-3xl space-y-4 text-xs">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Key className="w-4 h-4 text-blue-600" />
                <span>{tr('ترخيص وتفعيل البرنامج (حماية الأجهزة)', 'Software License & Hardware Activation')}</span>
              </h3>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                licenseState.isActivated 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {licenseState.isActivated
                  ? tr('مرخص دائم مدى الحياة', 'Lifetime Activated License')
                  : tr(`نسخة تجريبية (${licenseState.remainingHours} ساعة متبقية)`, `Trial Mode (${licenseState.remainingHours}h remaining)`)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <span className="font-bold text-slate-700 block">{tr('كود هذا الجهاز (Device Hardware ID):', 'Device Hardware ID:')}</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-black text-sm text-blue-800 bg-white px-3 py-2 rounded-xl border border-slate-300 flex-1 text-center select-all shadow-inner">
                    {licenseState.deviceCode}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      copyTextFallback(licenseState.deviceCode);
                      setCopiedDeviceCode(true);
                      showToast(tr('تم نسخ كود الجهاز بنجاح!', 'Device Hardware ID copied!'), 'success');
                      setTimeout(() => setCopiedDeviceCode(false), 2000);
                    }}
                    className="neu-button px-3 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedDeviceCode ? tr('تم النسخ', 'Copied') : tr('نسخ', 'Copy')}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">
                  {tr('كود البصمة الفريد الخاص بهذا الجهاز لاستخراج سيريل التفعيل المخصص له.', 'Unique Hardware ID for generating this device activation serial.')}
                </p>
              </div>

              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="font-bold text-emerald-950 block">{tr('لطلب تفعيل واتساب:', 'Request Activation via WhatsApp:')}</span>
                  <span dir="ltr" className="px-2.5 py-0.5 rounded-lg bg-emerald-600 text-white font-mono font-black text-xs shadow-2xs select-all">
                    {OFFICIAL_ACTIVATION_WHATSAPP_LOCAL}
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <a
                    href={getWhatsAppActivationUrl(licenseState.deviceCode, OFFICIAL_ACTIVATION_WHATSAPP_LOCAL, storeName)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      copyTextFallback(getWhatsAppActivationMessage(licenseState.deviceCode, storeName));
                    }}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer no-underline"
                  >
                    <MessageSquare className="w-4 h-4 fill-white" />
                    <span>{tr(`واتساب مباشر (${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})`, `Direct WhatsApp (${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})`)}</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      const msg = getWhatsAppActivationMessage(licenseState.deviceCode, storeName);
                      openSmartWhatsAppModal({
                        recipientName: tr('خدمة تفعيل AK Store', 'AK Store Activation Support'),
                        phone: OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
                        message: msg,
                        title: tr(`طلب تفعيل واتساب (${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})`, `WhatsApp Activation (${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})`),
                        subtitle: `Device ID: ${licenseState.deviceCode}`
                      });
                    }}
                    className="py-2.5 px-3 rounded-xl bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{tr('باركود موبايل / واتساب ويب', 'Mobile QR / Web')}</span>
                  </button>
                </div>
                <p className="text-[10px] text-emerald-800/80 text-center font-medium">
                  {tr(
                    `تواصل على واتساب رقم ${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL} لإرسال كود جهازك واستلام سيريل التفعيل الرسمي المخصص له فوراً.`,
                    `Contact WhatsApp ${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL} to send your Device ID and receive your official activation serial.`
                  )}
                </p>
              </div>
            </div>

            {/* Enter Activation Serial (Only accepts serial generated from external Keygen) */}
            <div className="p-4 bg-blue-50/50 border border-blue-200/80 rounded-2xl space-y-3">
              <label className="font-bold text-slate-800 block text-xs">
                {tr('إدخال سيريل التفعيل الرسمي (ACT-XXXX-XXXX-XXXX-XXXX):', 'Enter Official Activation Serial Key (ACT-XXXX-XXXX-XXXX-XXXX):')}
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <input
                  type="text"
                  dir="ltr"
                  value={activationKeyInput}
                  onChange={(e) => setActivationKeyInput(e.target.value.toUpperCase())}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const trimmed = activationKeyInput.trim().toUpperCase();
                      if (trimmed === 'AK-KEYGEN' || trimmed === 'KEYGEN-ADMIN') {
                        downloadStandaloneKeygenHtml();
                        setActivationKeyInput('');
                        showToast('تم تحميل برنامج توليد السيريلات المستقل (AK_Store_Keygen_Generator.html)', 'success');
                        return;
                      }
                      const res = activateLicense(activationKeyInput, licenseState.deviceCode);
                      if (res.success) {
                        showToast(res.message, 'success');
                        syncDatabaseAndLicenseToSafeVault();
                        setLicenseState(getLicenseState());
                        setActivationKeyInput('');
                      } else {
                        showToast(res.message, 'error');
                      }
                    }
                  }}
                  placeholder="ACT-XXXX-XXXX-XXXX-XXXX"
                  className="neu-input w-full px-4 py-2.5 rounded-xl font-mono text-center text-xs sm:text-sm font-bold tracking-wider"
                />
                <button
                  type="button"
                  onClick={() => {
                    const trimmed = activationKeyInput.trim().toUpperCase();
                    if (trimmed === 'AK-KEYGEN' || trimmed === 'KEYGEN-ADMIN') {
                      downloadStandaloneKeygenHtml();
                      setActivationKeyInput('');
                      showToast('تم تحميل برنامج توليد السيريلات المستقل (AK_Store_Keygen_Generator.html)', 'success');
                      return;
                    }
                    const res = activateLicense(activationKeyInput, licenseState.deviceCode);
                    if (res.success) {
                      showToast(res.message, 'success');
                      syncDatabaseAndLicenseToSafeVault();
                      setLicenseState(getLicenseState());
                      setActivationKeyInput('');
                    } else {
                      showToast(res.message, 'error');
                    }
                  }}
                  className="neu-button-primary px-6 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap cursor-pointer w-full sm:w-auto flex items-center justify-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{tr('تأكيد تفعيل البرنامج الآن', 'Confirm Activation Now')}</span>
                </button>
              </div>
              {licenseState.isActivated && (
                <div className="p-2.5 rounded-xl bg-emerald-100/80 border border-emerald-300 text-emerald-900 font-bold text-xs flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    {tr(
                      `البرنامج مفعل رسمياً! السيريل المسجل: ${licenseState.licenseKey || 'مفعل دائم'}`,
                      `Activated! Registered Serial: ${licenseState.licenseKey || 'Lifetime'}`
                    )}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Database Management & Backups (Admin Only) */}
          <div id="section-database" className="neu-card p-5 rounded-3xl space-y-4 text-xs">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-600" />
              <span>{tr('إدارة قاعدة البيانات المحلية (SQLite Backup)', 'Local Database Management & Backups (SQLite)')}</span>
            </h3>
            <p className="text-slate-500">
              {tr('يمكنك تصدير قاعدة البيانات كملف database.db لحفظ نسخة احتياطية محلية، أو استيراد قاعدة بيانات سابقة.', 'Export your local database as a database.db backup file or restore from an existing backup.')}
            </p>

            <div className="flex items-center gap-3 flex-wrap pt-2">
              <button
                type="button"
                onClick={handleExportDB}
                className="neu-button px-4 py-2.5 rounded-xl font-bold text-blue-700 flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{tr('تصدير نسخة احتياطية (database.db)', 'Export Backup (database.db)')}</span>
              </button>

              <input
                ref={dbImportRef}
                type="file"
                accept=".db, .json, .sqlite"
                onChange={handleImportDB}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => dbImportRef.current?.click()}
                className="neu-button px-4 py-2.5 rounded-xl font-bold text-emerald-700 flex items-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>{tr('استيراد قاعدة بيانات', 'Import Database')}</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                className={`neu-button px-4 py-2.5 rounded-xl font-bold text-red-600 flex items-center gap-2 cursor-pointer ${
                  dir === 'rtl' ? 'mr-auto' : 'ml-auto'
                }`}
              >
                <RotateCcw className="w-4 h-4" />
                <span>{tr('إعادة ضبط المصنع', 'Factory Reset')}</span>
              </button>
            </div>

            {/* Google Drive Cloud Backup & Restore Panel (Admin Only) */}
            <GoogleDriveBackupPanel />
          </div>
        </>
      )}

      {/* Printer Selection Modal */}
      <PrinterSelectionModal
        isOpen={isPrinterModalOpen}
        onClose={() => setIsPrinterModalOpen(false)}
        onSelectAndPrint={(type) => {
          setSelectedPrinter(type);
          if (type === 'a4-standard') setPrintLayout('a4');
          else if (type === 'thermal-80' || type === 'thermal-58') setPrintLayout('thermal');
        }}
      />
    </div>
  );
};
