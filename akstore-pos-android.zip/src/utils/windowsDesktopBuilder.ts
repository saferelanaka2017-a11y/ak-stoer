/**
 * @file utils/windowsDesktopBuilder.ts
 * أدوات ومعالج تسطيب نظام AK Store كبرنامج سطح مكتب على جميع أنظمة ويندوز (Windows 7 / 8 / 8.1 / 10 / 11)
 * وملف التسطيب السريع على التليفون (Android & iPhone)
 */

import { getUpdateServerUrl } from './updateManager';

/**
 * Helper to resolve active server URL safely even when running inside .exe (file://)
 */
export function resolveActiveServerUrl(): string {
  return getUpdateServerUrl();
}

/**
 * Helper to trigger file download with Windows CRLF line endings
 */
function downloadWindowsFile(filename: string, content: string, mimeType = 'text/plain;charset=utf-8') {
  const crlfContent = content.replace(/\r?\n/g, '\r\n');
  const blob = new Blob([crlfContent], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * 0. برنامج معالج التسطيب الرسومي للويندوز (.HTA Native Windows GUI Installer Wizard)
 * يعمل مباشرة بواجهة رسومية عربية على Windows 7 / 8 / 8.1 / 10 / 11 بدون أي برامج خارجية
 * وينشئ أيقونة سطح المكتب وقائمة ابدأ ويشغّل النظام في نافذة مستقلة
 */
export function downloadWindowsGuiSetupWizardHta(): void {
  const baseUrl = resolveActiveServerUrl();
  const liteUrl = `${baseUrl}/?lite=1`;

  const htaContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <title>معالج تسطيب برنامج AK Store POS - لويندوز 7 / 8 / 10 / 11</title>
  <HTA:APPLICATION
    ID="AKStoreSetupWizard"
    APPLICATIONNAME="AK Store POS Setup"
    BORDER="dialog"
    BORDERSTYLE="normal"
    CAPTION="yes"
    MAXIMIZEBUTTON="no"
    MINIMIZEBUTTON="yes"
    SHOWINTASKBAR="yes"
    SINGLEINSTANCE="yes"
    SYSMENU="yes"
    VERSION="2.6.0"
    WINDOWSTATE="normal"
  />
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Tahoma, 'Segoe UI', Arial, sans-serif;
      background-color: #e9eff5;
      color: #1e293b;
      direction: rtl;
    }
    .header {
      background-color: #1e40af;
      color: #ffffff;
      padding: 18px 22px;
      border-bottom: 3px solid #f59e0b;
    }
    .header h1 {
      margin: 0;
      font-size: 18px;
    }
    .header p {
      margin: 5px 0 0 0;
      font-size: 12px;
      color: #dbeafe;
    }
    .container {
      padding: 20px 22px;
    }
    .box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      padding: 14px 16px;
      margin-bottom: 14px;
    }
    .box h3 {
      margin: 0 0 10px 0;
      font-size: 14px;
      color: #1e3a8a;
    }
    .opt {
      display: block;
      margin-bottom: 8px;
      font-size: 13px;
      font-weight: bold;
      cursor: pointer;
    }
    .status {
      background: #ecfdf5;
      border: 1px solid #10b981;
      color: #065f46;
      padding: 10px 14px;
      font-size: 12px;
      font-weight: bold;
      margin-bottom: 14px;
      display: none;
    }
    .btn-row {
      text-align: left;
      padding-top: 6px;
    }
    .btn-install {
      background-color: #2563eb;
      color: #ffffff;
      border: none;
      padding: 11px 24px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      font-family: Tahoma, Arial, sans-serif;
    }
    .btn-close {
      background-color: #cbd5e1;
      color: #1e293b;
      border: none;
      padding: 11px 16px;
      font-size: 13px;
      font-weight: bold;
      cursor: pointer;
      margin-right: 8px;
      font-family: Tahoma, Arial, sans-serif;
    }
  </style>
  <script language="VBScript">
    Sub Window_OnLoad()
      On Error Resume Next
      window.resizeTo 560, 470
      window.moveTo (screen.availWidth - 560) / 2, (screen.availHeight - 470) / 2
    End Sub

    Function FindBrowserPath()
      Dim objShell, objFSO, arrPaths(8), i, expandedPath, strBrowser
      Set objShell = CreateObject("WScript.Shell")
      Set objFSO = CreateObject("Scripting.FileSystemObject")
      strBrowser = ""

      arrPaths(0) = "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
      arrPaths(1) = "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
      arrPaths(2) = "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"
      arrPaths(3) = "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
      arrPaths(4) = "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
      arrPaths(5) = "%LocalAppData%\\Microsoft\\Edge\\Application\\msedge.exe"
      arrPaths(6) = "%ProgramFiles%\\Supermium\\chrome.exe"
      arrPaths(7) = "%ProgramFiles(x86)%\\Supermium\\chrome.exe"
      arrPaths(8) = "%LocalAppData%\\Supermium\\chrome.exe"

      For i = 0 To 8
        expandedPath = objShell.ExpandEnvironmentStrings(arrPaths(i))
        If objFSO.FileExists(expandedPath) Then
          strBrowser = expandedPath
          Exit For
        End If
      Next

      On Error Resume Next
      If strBrowser = "" Then
        strBrowser = objShell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe\\")
      End If
      If strBrowser = "" Then
        strBrowser = objShell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\msedge.exe\\")
      End If
      On Error GoTo 0

      FindBrowserPath = strBrowser
    End Function

    Sub RunInstall()
      On Error Resume Next
      Dim objShell, objFSO, strBrowser, strUrl, strFlags, strDesktop, strStartMenu, objLink
      Set objShell = CreateObject("WScript.Shell")
      Set objFSO = CreateObject("Scripting.FileSystemObject")

      If document.getElementById("chkLite").checked Then
        strUrl = "${liteUrl}"
        strFlags = " --disable-gpu-compositing --disable-extensions --process-per-site"
      Else
        strUrl = "${baseUrl}"
        strFlags = ""
      End If

      If document.getElementById("chkThermal").checked Then
        strFlags = strFlags & " --kiosk-printing"
      End If

      strBrowser = FindBrowserPath()

      If strBrowser <> "" And objFSO.FileExists(strBrowser) Then
        If document.getElementById("chkDesktop").checked Then
          strDesktop = objShell.SpecialFolders("Desktop")
          Set objLink = objShell.CreateShortcut(strDesktop & "\\AK Store POS.lnk")
          objLink.TargetPath = strBrowser
          objLink.Arguments = "--app=" & strUrl & " --start-maximized --disable-features=Translate" & strFlags
          objLink.Description = "AK Store POS - نظام الكريم للمبيعات ونقاط البيع"
          objLink.WindowStyle = 3
          objLink.Save
        End If

        If document.getElementById("chkStartMenu").checked Then
          strStartMenu = objShell.SpecialFolders("Programs")
          Set objLink = objShell.CreateShortcut(strStartMenu & "\\AK Store POS.lnk")
          objLink.TargetPath = strBrowser
          objLink.Arguments = "--app=" & strUrl & " --start-maximized --disable-features=Translate" & strFlags
          objLink.Description = "AK Store POS - نظام الكريم للمبيعات ونقاط البيع"
          objLink.WindowStyle = 3
          objLink.Save
        End If

        document.getElementById("statusBox").style.display = "block"
        document.getElementById("statusBox").innerText = "تم تسطيب البرنامج وإنشاء الأيقونة على سطح المكتب بنجاح! جاري تشغيل النظام..."
        objShell.Run Chr(34) & strBrowser & Chr(34) & " --app=" & strUrl & " --start-maximized --disable-features=Translate" & strFlags, 3, False
      Else
        If document.getElementById("chkDesktop").checked Then
          strDesktop = objShell.SpecialFolders("Desktop")
          Set objLink = objShell.CreateShortcut(strDesktop & "\\AK Store POS.url")
          objLink.TargetPath = strUrl
          objLink.Save
        End If
        document.getElementById("statusBox").style.display = "block"
        document.getElementById("statusBox").innerText = "تم إنشاء الاختصار على سطح المكتب بنجاح! جاري فتح النظام..."
        objShell.Run strUrl, 3, False
      End If
    End Sub
  </script>
</head>
<body>
  <div class="header">
    <h1>AK Store POS — معالج تسطيب البرنامج على الويندوز</h1>
    <p>متوافق مع جميع أنظمة Windows 7 / 8 / 8.1 / 10 / 11 (32-bit &amp; 64-bit) مع مزامنة التليفون</p>
  </div>
  <div class="container">
    <div class="box">
      <h3>اختر إعدادات التسطيب على جهاز الكمبيوتر:</h3>
      <label class="opt">
        <input type="checkbox" id="chkDesktop" checked="checked" />
        إنشاء أيقونة برنامج "AK Store POS" على سطح المكتب (Desktop)
      </label>
      <label class="opt">
        <input type="checkbox" id="chkStartMenu" checked="checked" />
        إضافة البرنامج إلى قائمة ابدأ (Start Menu Programs)
      </label>
      <label class="opt">
        <input type="checkbox" id="chkLite" checked="checked" />
        تفعيل وضع السرعة القصوى وتوفير الرامات للأجهزة الضعيفة وويندوز 7
      </label>
      <label class="opt">
        <input type="checkbox" id="chkThermal" />
        تفعيل الطباعة الحرارية الفورية الصامتة للكاشير بدون نافذة معاينة
      </label>
    </div>

    <div id="statusBox" class="status"></div>

    <div class="btn-row">
      <button class="btn-install" onclick="RunInstall()">تسطيب وتشغيل البرنامج الآن</button>
      <button class="btn-close" onclick="window.close()">إغلاق</button>
    </div>
  </div>
</body>
</html>`;

  downloadWindowsFile('AK_Store_Windows_Setup_Wizard.hta', htaContent, 'application/hta;charset=utf-8');
}

/**
 * 1. المثبت الذكي الشامل لجميع أنظمة ويندوز من 7 إلى 11 بأقل الإمكانيات (.BAT)
 * يكتشف المتصفح تلقائياً من المسارات أو الريجستري (32-bit و 64-bit)، ويفعّل أعلام توفير الرامات وتعطيل مشاكل كرت الشاشة في ويندوز 7
 */
export function downloadWindows7InstallerBat(enableSilentThermalPrint = false, lowSpecOptimization = true): void {
  const baseUrl = resolveActiveServerUrl();
  const appUrl = lowSpecOptimization ? `${baseUrl}/?lite=1` : baseUrl;
  const printFlag = enableSilentThermalPrint ? ' --kiosk-printing' : '';
  const lowSpecFlags = lowSpecOptimization
    ? ' --disable-gpu-compositing --disable-extensions --disable-background-networking --process-per-site'
    : '';

  const batContent = `@echo off
title AK Store POS - Universal Windows 7 / 8 / 10 / 11 Setup (Low-Spec Ready)
color 1F
echo ============================================================================
echo      AK Store POS - Universal Windows 7 / 8 / 8.1 / 10 / 11 Installer
echo      Optimized for Low-Spec PCs (1GB-2GB RAM, 32-bit x86 ^& 64-bit x64)
echo ============================================================================
echo.
echo [1/3] Detecting compatible engine on Windows (32-bit / 64-bit / Registry)...

set "APP_URL=${appUrl}"
set "BROWSER_PATH="

:: 1. Check Standard 32-bit and 64-bit Paths (Chrome, Edge, Supermium, Brave)
if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_PATH=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_PATH=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_PATH=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_PATH=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_PATH=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
if exist "%LocalAppData%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_PATH=%LocalAppData%\\Microsoft\\Edge\\Application\\msedge.exe"
if exist "%ProgramFiles%\\Supermium\\chrome.exe" set "BROWSER_PATH=%ProgramFiles%\\Supermium\\chrome.exe"
if exist "%ProgramFiles(x86)%\\Supermium\\chrome.exe" set "BROWSER_PATH=%ProgramFiles(x86)%\\Supermium\\chrome.exe"
if exist "%LocalAppData%\\Supermium\\chrome.exe" set "BROWSER_PATH=%LocalAppData%\\Supermium\\chrome.exe"

:: 2. Fallback: Query Windows Registry App Paths (Critical for custom installs on Windows 7)
if "%BROWSER_PATH%"=="" (
    for /f "tokens=2*" %%A in ('reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe" /ve 2^>nul') do set "BROWSER_PATH=%%B"
)
if "%BROWSER_PATH%"=="" (
    for /f "tokens=2*" %%A in ('reg query "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe" /ve 2^>nul') do set "BROWSER_PATH=%%B"
)
if "%BROWSER_PATH%"=="" (
    for /f "tokens=2*" %%A in ('reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\msedge.exe" /ve 2^>nul') do set "BROWSER_PATH=%%B"
)

if "%BROWSER_PATH%"=="" (
    echo [!] Using default system browser handler...
    set "VBS_FALLBACK=%TEMP%\\akstore_url_shortcut.vbs"
    echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS_FALLBACK%"
    echo sDesktop = oWS.SpecialFolders("Desktop") >> "%VBS_FALLBACK%"
    echo Set oLink = oWS.CreateShortcut(sDesktop ^& "\\AK Store POS.url") >> "%VBS_FALLBACK%"
    echo oLink.TargetPath = "%APP_URL%" >> "%VBS_FALLBACK%"
    echo oLink.Save >> "%VBS_FALLBACK%"
    cscript //nologo "%VBS_FALLBACK%"
    del "%VBS_FALLBACK%"
    start "" "%APP_URL%"
    exit /b 0
)

echo [2/3] Creating Desktop ^& Start Menu Shortcuts ("AK Store POS")...

set "VBS_SCRIPT=%TEMP%\\create_akstore_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS_SCRIPT%"
echo sDesktop = oWS.SpecialFolders("Desktop") >> "%VBS_SCRIPT%"
echo Set oLink = oWS.CreateShortcut(sDesktop ^& "\\AK Store POS.lnk") >> "%VBS_SCRIPT%"
echo oLink.TargetPath = "%BROWSER_PATH%" >> "%VBS_SCRIPT%"
echo oLink.Arguments = "--app=%APP_URL% --start-maximized --disable-features=Translate${lowSpecFlags}${printFlag}" >> "%VBS_SCRIPT%"
echo oLink.Description = "AK Store POS - Windows 7/8/10/11 Low-Spec Ready" >> "%VBS_SCRIPT%"
echo oLink.IconLocation = "%BROWSER_PATH%,0" >> "%VBS_SCRIPT%"
echo oLink.WindowStyle = 3 >> "%VBS_SCRIPT%"
echo oLink.Save >> "%VBS_SCRIPT%"

echo sStartMenu = oWS.SpecialFolders("Programs") >> "%VBS_SCRIPT%"
echo Set oLink2 = oWS.CreateShortcut(sStartMenu ^& "\\AK Store POS.lnk") >> "%VBS_SCRIPT%"
echo oLink2.TargetPath = "%BROWSER_PATH%" >> "%VBS_SCRIPT%"
echo oLink2.Arguments = "--app=%APP_URL% --start-maximized --disable-features=Translate${lowSpecFlags}${printFlag}" >> "%VBS_SCRIPT%"
echo oLink2.Description = "AK Store POS - Point of Sale System" >> "%VBS_SCRIPT%"
echo oLink2.IconLocation = "%BROWSER_PATH%,0" >> "%VBS_SCRIPT%"
echo oLink2.WindowStyle = 3 >> "%VBS_SCRIPT%"
echo oLink2.Save >> "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%"
del "%VBS_SCRIPT%"

echo [3/3] Launching AK Store POS in Low-Spec Desktop Mode...
start "" "%BROWSER_PATH%" --app="%APP_URL%" --start-maximized --disable-features=Translate${lowSpecFlags}${printFlag}

echo.
echo ============================================================================
echo   SUCCESS! Shortcut "AK Store POS" has been created on your Desktop!
echo ============================================================================
timeout /t 3 >nul
exit
`;

  const filename = enableSilentThermalPrint
    ? 'AK_Store_Win7_to_11_ThermalPrint_Setup.bat'
    : 'AK_Store_Windows_7_8_10_11_Setup.bat';

  downloadWindowsFile(filename, batContent);
}

/**
 * 2. المشغل الصامت المباشر للأجهزة الضعيفة وويندوز 7 إلى 11 (.VBS)
 * يعمل بدون أي شاشة سوداء وبأقل استهلاك للرامات والـ CPU
 */
export function downloadWindowsSilentLauncherVbs(lowSpecOptimization = true): void {
  const baseUrl = resolveActiveServerUrl();
  const appUrl = lowSpecOptimization ? `${baseUrl}/?lite=1` : baseUrl;
  const extraFlags = lowSpecOptimization
    ? ' --disable-gpu-compositing --disable-extensions --process-per-site'
    : '';

  const vbsContent = `' ============================================================================
' AK Store POS - Silent Native Desktop Launcher for Windows 7 / 8 / 8.1 / 10 / 11
' Works on both 32-bit (x86) and 64-bit (x64) Low-Spec Windows PCs
' ============================================================================
Option Explicit

Dim objShell, objFSO, strAppUrl, strBrowser, strDesktop, strShortcutPath, objShortcut
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

strAppUrl = "${appUrl}"
strBrowser = ""

' Check Chrome, Edge, and Supermium paths across Windows 7 / 8 / 10 / 11 (32-bit and 64-bit)
Dim arrPaths(8), i, expandedPath
arrPaths(0) = "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
arrPaths(1) = "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
arrPaths(2) = "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"
arrPaths(3) = "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
arrPaths(4) = "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
arrPaths(5) = "%LocalAppData%\\Microsoft\\Edge\\Application\\msedge.exe"
arrPaths(6) = "%ProgramFiles%\\Supermium\\chrome.exe"
arrPaths(7) = "%ProgramFiles(x86)%\\Supermium\\chrome.exe"
arrPaths(8) = "%LocalAppData%\\Supermium\\chrome.exe"

For i = 0 To 8
    expandedPath = objShell.ExpandEnvironmentStrings(arrPaths(i))
    If objFSO.FileExists(expandedPath) Then
        strBrowser = expandedPath
        Exit For
    End If
Next

' Fallback: Check Registry App Paths if not in standard folders
On Error Resume Next
If strBrowser = "" Then
    strBrowser = objShell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe\\")
End If
If strBrowser = "" Then
    strBrowser = objShell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\msedge.exe\\")
End If
On Error GoTo 0

If strBrowser <> "" And objFSO.FileExists(strBrowser) Then
    ' Ensure Desktop Shortcut exists
    strDesktop = objShell.SpecialFolders("Desktop")
    strShortcutPath = strDesktop & "\\AK Store POS.lnk"
    If Not objFSO.FileExists(strShortcutPath) Then
        Set objShortcut = objShell.CreateShortcut(strShortcutPath)
        objShortcut.TargetPath = strBrowser
        objShortcut.Arguments = "--app=" & strAppUrl & " --start-maximized --disable-features=Translate${extraFlags}"
        objShortcut.Description = "AK Store POS - Windows 7 to 11 Desktop Application"
        objShortcut.WindowStyle = 3
        objShortcut.Save
    End If

    ' Launch standalone POS window silently
    objShell.Run Chr(34) & strBrowser & Chr(34) & " --app=" & strAppUrl & " --start-maximized --disable-features=Translate${extraFlags}", 3, False
Else
    objShell.Run strAppUrl, 3, False
End If
`;

  downloadWindowsFile('AK_Store_Win7_to_11_Silent_Launcher.vbs', vbsContent);
}

/**
 * 3. ملف التشغيل والتسطيب المباشر للكمبيوتر والتليفون (.HTML)
 * يعمل بمجرد النقر عليه على ويندوز أو الموبايل (أندرويد / آيفون)
 */
export function downloadPortableHtmlLauncher(): void {
  const baseUrl = resolveActiveServerUrl();
  const installUrl = `${baseUrl}/`;
  const liteUrl = `${baseUrl}/?lite=1`;

  const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>AK Store POS - مشغل ومثبت الويندوز والتليفون</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
      background-color: #e9eff5;
      color: #1e293b;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .card {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 20px;
      padding: 28px;
      max-width: 460px;
      width: 90%;
      text-align: center;
      box-shadow: 0 8px 24px rgba(0,0,0,0.08);
    }
    .logo {
      width: 60px;
      height: 60px;
      background: linear-gradient(135deg, #2563eb, #4f46e5);
      color: #ffffff;
      border-radius: 16px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 24px;
      margin-bottom: 12px;
    }
    h1 { font-size: 19px; margin: 0 0 8px 0; }
    p { font-size: 13px; color: #475569; line-height: 1.6; margin: 0 0 20px 0; }
    .btn {
      display: block;
      width: 100%;
      padding: 13px;
      background: #2563eb;
      color: #ffffff;
      text-decoration: none;
      border-radius: 12px;
      font-weight: bold;
      font-size: 14px;
      box-sizing: border-box;
      margin-bottom: 10px;
    }
    .btn-emerald {
      background: #059669;
    }
    .btn-secondary {
      background: #f1f5f9;
      color: #334155;
      border: 1px solid #cbd5e1;
    }
  </style>
  <script>
    window.onload = function() {
      setTimeout(function() {
        window.location.replace("${installUrl}");
      }, 600);
    };
  </script>
</head>
<body>
  <div class="card">
    <div class="logo">AK</div>
    <h1>AK Store — نظام الكريم للمبيعات (ويندوز + موبايل)</h1>
    <p>جاري فتح معالج التسطيب والتشغيل المتوافق مع الكمبيوتر (Windows 7–11) والتليفون (Android &amp; iPhone)...</p>
    <a class="btn btn-emerald" href="${installUrl}">📲💻 فتح وتسطيب التطبيق الآن</a>
    <a class="btn" href="${liteUrl}">⚡ الدخول بوضع الأجهزة الضعيفة (Windows 7)</a>
    <a class="btn btn-secondary" href="${baseUrl}">الدخول المباشر للنظام</a>
  </div>
</body>
</html>`;

  downloadWindowsFile('AK_Store_Universal_Installer.html', htmlContent, 'text/html;charset=utf-8');
}

/**
 * 4. أداة بناء ملف تنفيذي مستقل (.EXE) قابل للتحديث المباشر لنظام Windows 7 / 8 / 10 / 11 (32-bit & 64-bit)
 */
export function downloadElectronWin7ExeBuilder(): void {
  const builderBatContent = `@echo off
title AK Store POS - Updatable Windows 7 / 8 / 10 / 11 (.EXE) Builder
color 0B
echo ================================================================================
echo   AK Store POS - Updatable Native Windows (.EXE) Packager (Win 7 / 8 / 10 / 11)
echo   Supports 32-bit (ia32) ^& 64-bit (x64) + Seamless Future Updates!
echo ================================================================================
echo.
echo [INFO] This builder configures:
echo   1. Fixed Persistent Data Vault in %%APPDATA%%\\AKStorePOS_Data (Database ^& License safe!)
echo   2. Unpacked App Bundle (asar=false) so you can update the .EXE anytime without data loss!
echo   3. Electron 22.3.27 LTS for 100%% compatibility from Windows 7 SP1 to Windows 11.
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed on this build machine.
    echo Please run this builder on a machine with Node.js installed, then copy the generated .EXE to any Windows 7/8/10/11 PC.
    pause
    exit /b 1
)

echo [1/4] Installing Electron 22.3.27 (Windows 7-11 Compatible) and electron-builder...
call npm install --save-dev electron@22.3.27 electron-builder@24.13.3

echo [2/4] Building Production POS Bundle (Vite ES2019 / Chrome 79 Target)...
call npm run build

echo [3/4] Generating Updatable Windows 7 / 8 / 10 / 11 (.EXE) Files (32-bit ^& 64-bit)...
call npx electron-builder --win nsis portable --x64 --ia32 -c.electronVersion=22.3.27 -c.asar=false -c.appId=com.akstore.pos -c.productName="AKStorePOS" -c.nsis.oneClick=false -c.nsis.allowToChangeInstallationDirectory=true -c.nsis.deleteAppDataOnUninstall=false

echo.
echo ================================================================================
echo   DONE! Your Updatable Windows 7/8/10/11 (.EXE) files are inside "dist_electron"!
echo   Any future Setup.exe or Portable.exe will automatically upgrade existing
echo   installations while keeping 100%% of the customer's Database and License!
echo ================================================================================
pause
`;

  downloadWindowsFile('AK_Store_Build_Updatable_Win7_to_11_EXE.bat', builderBatContent);
}

/**
 * 5. أداة التحديث الذكي لنسخة الـ (.EXE) وسطح المكتب المثبتة لدى العميل (AK_Store_EXE_Updater_Tool.bat)
 * تسحب أحدث التعديلات مباشرة من السيرفر إلى مجلد البرنامج والـ EXE على اللابتوب مع حماية قاعدة البيانات 100%
 */
export function downloadExeAutoUpdaterScriptBat(): void {
  const baseUrl = resolveActiveServerUrl();

  const updaterBatContent = `@echo off
title AK Store POS - Smart Live .EXE ^& Desktop Auto-Updater (Preserves Database ^& License)
color 1F
echo ================================================================================
echo      AK Store POS - Smart Live .EXE ^& Desktop Updater (Windows 7 / 8 / 10 / 11)
echo      Downloads Latest System Modifications Directly to Your Laptop (.EXE)
echo      100%% Safe Update: Preserves SQLite Database, Invoices ^& License Serial
echo ================================================================================
echo.

set "DATA_DIR=%APPDATA%\\AKStorePOS_Data"
set "BACKUP_DIR=%APPDATA%\\AKStorePOS_Data\\AutoBackups"
set "LIVE_UPDATE_DIR=%APPDATA%\\AKStorePOS_Data\\live_update"
set "REMOTE_URL=${baseUrl}"

if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
if not exist "%LIVE_UPDATE_DIR%" mkdir "%LIVE_UPDATE_DIR%"
if not exist "%LIVE_UPDATE_DIR%\\assets" mkdir "%LIVE_UPDATE_DIR%\\assets"

echo [1/5] Closing running AKStorePOS.exe instance safely (if open)...
taskkill /F /IM AKStorePOS.exe >nul 2>nul

echo [2/5] Backing up Customer Database ^& Hardware License Vault...
if exist "%DATA_DIR%\\akstore_persistent_vault.json" (
    copy /Y "%DATA_DIR%\\akstore_persistent_vault.json" "%BACKUP_DIR%\\vault_backup_%RANDOM%.json" >nul
    echo       [OK] Database ^& License Vault backed up safely to: %BACKUP_DIR%
) else (
    echo       [OK] Persistent Data Folder verified: %DATA_DIR%
)

echo [3/5] Downloading Latest System Modifications from Server (%REMOTE_URL%)...
echo { "useRemoteUpdateServer": true, "remoteServerUrl": "%REMOTE_URL%", "updatedAt": "%DATE% %TIME%" } > "%DATA_DIR%\\akstore_update_config.json"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " ^
  "$ErrorActionPreference = 'SilentlyContinue'; " ^
  "$base = '%REMOTE_URL%'; " ^
  "$liveDir = '%LIVE_UPDATE_DIR%'; " ^
  "$res = Invoke-RestMethod -Uri ($base + '/api/update/live-bundle?t=' + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -TimeoutSec 15; " ^
  "if ($res -and $res.success -and $res.indexHtml) { " ^
  "  $html = $res.indexHtml.Replace('src=\"/assets/', 'src=\"./assets/').Replace('href=\"/assets/', 'href=\"./assets/'); " ^
  "  [IO.File]::WriteAllText((Join-Path $liveDir 'index.html'), $html, [Text.Encoding]::UTF8); " ^
  "  foreach ($asset in $res.manifest.assets) { " ^
  "    if ($asset -ne '/' -and $asset -ne '/index.html') { " ^
  "      $rel = $asset.TrimStart('/'); " ^
  "      $target = Join-Path $liveDir $rel; " ^
  "      $dir = Split-Path $target -Parent; " ^
  "      if (!(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }; " ^
  "      Invoke-WebRequest -Uri ($base + $asset) -OutFile $target -UseBasicParsing -TimeoutSec 20; " ^
  "    } " ^
  "  } " ^
  "  Write-Host '      [OK] Downloaded all latest system files into .EXE live_update folder!'; " ^
  "}"

if exist "%~dp0dist\\index.html" (
    xcopy /E /I /Y "%~dp0dist\\*" "%LIVE_UPDATE_DIR%\\" >nul
)
if exist "%~dp0resources\\app\\dist" (
    xcopy /E /I /Y "%LIVE_UPDATE_DIR%\\*" "%~dp0resources\\app\\dist\\" >nul
)

echo [4/5] Clearing outdated UI cache (Keeping Database ^& License 100%% intact)...
if exist "%DATA_DIR%\\Cache" rmdir /S /Q "%DATA_DIR%\\Cache" >nul 2>nul
if exist "%DATA_DIR%\\Code Cache" rmdir /S /Q "%DATA_DIR%\\Code Cache" >nul 2>nul
if exist "%DATA_DIR%\\GPUCache" rmdir /S /Q "%DATA_DIR%\\GPUCache" >nul 2>nul
if exist "%DATA_DIR%\\Service Worker\\CacheStorage" rmdir /S /Q "%DATA_DIR%\\Service Worker\\CacheStorage" >nul 2>nul
if exist "%DATA_DIR%\\Service Worker\\ScriptCache" rmdir /S /Q "%DATA_DIR%\\Service Worker\\ScriptCache" >nul 2>nul

echo [5/5] Launching Updated AK Store POS...
if exist "%~dp0AKStorePOS.exe" (
    start "" "%~dp0AKStorePOS.exe"
) else if exist "%LocalAppData%\\Programs\\AKStorePOS\\AKStorePOS.exe" (
    start "" "%LocalAppData%\\Programs\\AKStorePOS\\AKStorePOS.exe"
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
    start "" "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" --app="%REMOTE_URL%/?updated=%RANDOM%" --start-maximized
) else if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
    start "" "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" --app="%REMOTE_URL%/?updated=%RANDOM%" --start-maximized
) else (
    start "" "%REMOTE_URL%/?updated=%RANDOM%"
)

echo.
echo ================================================================================
echo   UPDATE COMPLETE! Your AK Store (.EXE ^& Desktop) is now running the latest build!
echo   All Products, Sales Invoices, Users, and License Activation are preserved.
echo ================================================================================
timeout /t 3 >nul
exit
`;

  downloadWindowsFile('AK_Store_EXE_Updater_Tool.bat', updaterBatContent);
}

