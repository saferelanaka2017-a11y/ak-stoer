/**
 * @file components/NumberStepperInput.tsx
 * حقل إدخال رقمي ذكي يدعم مسح الصفر والواحد وأي رقم بالكامل بحرية تامة مع أسهم زيادة وإنقاص واضحة (▲ / ▼)
 * Smart Numeric Input with full Backspace/Zero/One clearing and High-Contrast Up/Down Stepper Arrows
 */

import React, { useState, useEffect, useRef } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';

export interface NumberStepperInputProps {
  value: number;
  onChange: (newValue: number) => void;
  min?: number;
  max?: number;
  step?: number;
  fallbackOnBlur?: number;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  inputClassName?: string;
  size?: 'xs' | 'sm' | 'md';
  onFocus?: (e: React.FocusEvent<HTMLInputElement>) => void;
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  inputRef?: React.Ref<HTMLInputElement>;
  title?: string;
}

export const NumberStepperInput: React.FC<NumberStepperInputProps> = ({
  value,
  onChange,
  min = 0,
  max,
  step = 1,
  fallbackOnBlur,
  placeholder = '',
  required = false,
  disabled = false,
  className = '',
  inputClassName = '',
  size = 'md',
  onFocus,
  onClick,
  inputRef,
  title
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [draft, setDraft] = useState<string>(() =>
    value === undefined || value === null || isNaN(value) ? '' : String(value)
  );
  const internalRef = useRef<HTMLInputElement | null>(null);
  const lastCommittedRef = useRef<number>(value);

  // Sync draft when external value changes (e.g. Numpad or +/- buttons) without interrupting active typing/clearing
  useEffect(() => {
    if (!isFocused) {
      setDraft(value === undefined || value === null || isNaN(value) ? '' : String(value));
      lastCommittedRef.current = value;
    } else if (value !== lastCommittedRef.current) {
      // External state change while focused (e.g., user clicked Numpad or external +/- button)
      setDraft(String(value));
      lastCommittedRef.current = value;
    }
  }, [value, isFocused]);

  const clampValue = (num: number): number => {
    let res = num;
    if (min !== undefined && res < min) res = min;
    if (max !== undefined && res > max) res = max;
    return Math.round(res * 10000) / 10000;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Convert Arabic/Eastern digits (٠-٩) to standard digits (0-9) and allow decimal point
    const raw = e.target.value
      .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
      .replace(/[٫,]/g, '.')
      .replace(/[^0-9.-]/g, '');

    // Allow user to completely clear the input (including 0, 1, or any digit)
    if (raw === '' || raw === '-' || raw === '.') {
      setDraft(raw === '.' ? '0.' : '');
      if (raw !== '.' && (min === undefined || min <= 0)) {
        lastCommittedRef.current = 0;
        onChange(0);
      }
      return;
    }

    // Strip leading zeros like "05" -> "5" unless it's "0."
    const cleaned =
      raw.length > 1 && raw.startsWith('0') && !raw.startsWith('0.')
        ? raw.replace(/^0+/, '') || '0'
        : raw;

    setDraft(cleaned);

    const parsed = parseFloat(cleaned);
    if (!isNaN(parsed)) {
      let nextVal = parsed;
      if (max !== undefined && nextVal > max) {
        nextVal = max;
        setDraft(String(max));
      }
      // If min >= 1 (e.g., Quantity field) and user typed 0 transiently, don't force clamp to 1 until blur
      if (min !== undefined && min >= 1 && nextVal < min) {
        return;
      }
      lastCommittedRef.current = nextVal;
      onChange(nextVal);
    }
  };

  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsFocused(true);
    if (value === 0) {
      // Immediately clear 0 on focus so user can type directly without fighting a stuck 0
      setDraft('');
    } else {
      setDraft(String(value));
      // Auto-select existing value so typing a new number replaces it or Backspace clears it in 1 keystroke
      const target = e.target;
      setTimeout(() => {
        try {
          target.select();
        } catch {
          // ignore selection errors on unsupported mobile webviews
        }
      }, 0);
    }
    onFocus?.(e);
  };

  const handleBlur = () => {
    setIsFocused(false);
    const parsed = parseFloat(draft);
    if (draft.trim() === '' || isNaN(parsed)) {
      const fb =
        fallbackOnBlur !== undefined
          ? fallbackOnBlur
          : min !== undefined && min > 0
          ? min
          : 0;
      lastCommittedRef.current = fb;
      onChange(fb);
      setDraft(String(fb));
    } else {
      const clamped = clampValue(parsed);
      lastCommittedRef.current = clamped;
      if (clamped !== value) {
        onChange(clamped);
      }
      setDraft(String(clamped));
    }
  };

  const handleStep = (direction: 1 | -1, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (disabled) return;
    const parsedDraft = parseFloat(draft);
    const current = !isNaN(parsedDraft) ? parsedDraft : value || 0;
    const increment = step > 0 ? step : 1;
    const next = clampValue(current + direction * increment);
    lastCommittedRef.current = next;
    onChange(next);
    setDraft(String(next));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const parsedDraft = parseFloat(draft);
      const current = !isNaN(parsedDraft) ? parsedDraft : value || 0;
      const increment = step > 0 ? step : 1;
      const next = clampValue(current + increment);
      lastCommittedRef.current = next;
      onChange(next);
      setDraft(String(next));
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const parsedDraft = parseFloat(draft);
      const current = !isNaN(parsedDraft) ? parsedDraft : value || 0;
      const increment = step > 0 ? step : 1;
      const next = clampValue(current - increment);
      lastCommittedRef.current = next;
      onChange(next);
      setDraft(String(next));
    }
  };

  const setRefs = (el: HTMLInputElement | null) => {
    internalRef.current = el;
    if (typeof inputRef === 'function') {
      inputRef(el);
    } else if (inputRef && typeof inputRef === 'object') {
      (inputRef as React.MutableRefObject<HTMLInputElement | null>).current = el;
    }
  };

  const btnWidth = size === 'xs' ? 'w-5' : size === 'sm' ? 'w-6' : 'w-7';
  const iconSize = size === 'xs' ? 'w-3 h-3' : size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';

  return (
    <div
      onClick={onClick}
      title={title}
      className={`inline-flex items-stretch neu-input rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-blue-500/50 border border-slate-300/80 ${className}`}
    >
      <input
        ref={setRefs}
        type="text"
        inputMode="decimal"
        required={required && value === 0 && draft === ''}
        disabled={disabled}
        value={draft}
        placeholder={isFocused ? '' : placeholder}
        onChange={handleInputChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className={`w-full min-w-0 bg-transparent outline-none tabular-nums ${
          size === 'xs'
            ? 'px-1.5 py-1 text-xs'
            : size === 'sm'
            ? 'px-2 py-1.5 text-xs'
            : 'px-3 py-2 text-xs'
        } ${inputClassName}`}
      />
      {!disabled && (
        <div
          className={`flex flex-col border-s border-slate-300/90 bg-slate-100 shrink-0 select-none ${btnWidth}`}
        >
          <button
            type="button"
            tabIndex={-1}
            onMouseDown={(e) => e.preventDefault()}
            onClick={(e) => handleStep(1, e)}
            className="flex-1 min-h-[14px] flex items-center justify-center bg-blue-50/90 text-blue-700 hover:bg-blue-600 hover:text-white active:bg-blue-700 active:text-white transition-colors cursor-pointer border-b border-slate-300/90"
            title="زيادة الرقم (+ ▲)"
            aria-label="زيادة الرقم"
          >
            <ChevronUp className={iconSize} strokeWidth={3} />
          </button>
          <button
            type="button"
            tabIndex={-1}
            onMouseDown={(e) => e.preventDefault()}
            onClick={(e) => handleStep(-1, e)}
            className="flex-1 min-h-[14px] flex items-center justify-center bg-slate-100 text-slate-700 hover:bg-rose-600 hover:text-white active:bg-rose-700 active:text-white transition-colors cursor-pointer"
            title="إنقاص الرقم (- ▼)"
            aria-label="إنقاص الرقم"
          >
            <ChevronDown className={iconSize} strokeWidth={3} />
          </button>
        </div>
      )}
    </div>
  );
};
