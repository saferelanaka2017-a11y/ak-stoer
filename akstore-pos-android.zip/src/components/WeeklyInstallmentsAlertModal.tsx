/**
 * @file components/WeeklyInstallmentsAlertModal.tsx
 * نظام التنبيهات التلقائي لأقساط العملاء المستحقة هذا الأسبوع عند فتح لوحة التحكم (Dashboard)
 * Automatic Weekly Due Installments Notification System for Dashboard
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  BellRing,
  X,
  CalendarClock,
  CheckCircle2,
  AlertTriangle,
  Clock,
  MessageCircle,
  Copy,
  Check,
  Search,
  DollarSign,
  Phone,
  FileText,
  ArrowUpRight,
  Volume2,
  VolumeX,
  SlidersHorizontal
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import {
  ApproachingInstallment,
  formatWhatsAppPhone,
  generateReminderMessage,
  createWhatsAppUrl,
  openSmartWhatsAppModal
} from '../utils/installmentAlerts';

interface WeeklyInstallmentsAlertModalProps {
  isOpen: boolean;
  onClose: (snoozeForSession?: boolean) => void;
  installments: ApproachingInstallment[];
  onNavigateToInstallments: () => void;
  onOpenDetailedReminder?: (item: ApproachingInstallment) => void;
}

type FilterMode = 'all' | 'this_week_only' | 'today' | 'overdue';

/**
 * تشغيل نغمة تنبيه لطيفة عند ظهور إشعار أقساط الأسبوع تلقائياً
 */
export function playInstallmentAlertChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Two-tone gentle chime (E5 -> A5)
    const freqs = [659.25, 880];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.14);

      gain.gain.setValueAtTime(0.001, now + idx * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.08, now + idx * 0.14 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.14 + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.14);
      osc.stop(now + idx * 0.14 + 0.3);
    });
  } catch {
    // Ignore audio context autoplay restrictions
  }
}

export const WeeklyInstallmentsAlertModal: React.FC<WeeklyInstallmentsAlertModalProps> = ({
  isOpen,
  onClose,
  installments,
  onNavigateToInstallments,
  onOpenDetailedReminder
}) => {
  const { formatCurrency, settings, tr, language, showToast, refreshData } = useApp();

  const [filterMode, setFilterMode] = useState<FilterMode>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [confirmPayId, setConfirmPayId] = useState<string | null>(null);
  const [dontShowAgainSession, setDontShowAgainSession] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  useEffect(() => {
    if (isOpen && soundEnabled && installments.length > 0) {
      playInstallmentAlertChime();
    }
  }, [isOpen, soundEnabled, installments.length]);

  // Summary metrics
  const summary = useMemo(() => {
    let todayCount = 0;
    let upcomingWeekCount = 0;
    let overdueCount = 0;
    let totalWeekAmount = 0;
    let totalAllAmount = 0;

    installments.forEach((item) => {
      totalAllAmount += item.amount;
      if (item.urgency === 'today') {
        todayCount += 1;
        totalWeekAmount += item.amount;
      } else if (item.urgency === 'upcoming') {
        upcomingWeekCount += 1;
        totalWeekAmount += item.amount;
      } else if (item.urgency === 'overdue') {
        overdueCount += 1;
      }
    });

    return {
      todayCount,
      upcomingWeekCount,
      thisWeekTotalCount: todayCount + upcomingWeekCount,
      overdueCount,
      totalWeekAmount,
      totalAllAmount
    };
  }, [installments]);

  // Filtered list
  const filteredList = useMemo(() => {
    return installments.filter((item) => {
      if (filterMode === 'this_week_only' && item.urgency === 'overdue') return false;
      if (filterMode === 'today' && item.urgency !== 'today') return false;
      if (filterMode === 'overdue' && item.urgency !== 'overdue') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        return (
          item.customerName.toLowerCase().includes(q) ||
          item.customerPhone.includes(q) ||
          item.invoiceNumber.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [installments, filterMode, searchQuery]);

  if (!isOpen) return null;

  const getWeekdayName = (dateStr: string) => {
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return '';
    return d.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long' });
  };

  const buildReminderMessageForCustomer = (item: ApproachingInstallment) => {
    return generateReminderMessage({
      customerName: item.customerName,
      installmentNumber: item.installment.installmentNumber,
      amount: item.amount,
      dueDate: item.dueDate,
      currencySymbol: settings.currencySymbol || 'ج.م',
      storeName: settings.storeName || 'AK Store',
      storePhone: settings.storePhone,
      daysDiff: item.daysDiff,
      templateType:
        item.urgency === 'overdue' ? 'overdue' : item.urgency === 'today' ? 'due_today' : 'gentle'
    });
  };

  const handleCopyReminder = (item: ApproachingInstallment) => {
    const msg = buildReminderMessageForCustomer(item);
    navigator.clipboard.writeText(msg);
    const key = `${item.planId}-${item.installment.id}`;
    setCopiedId(key);
    showToast(
      tr(
        `تم نسخ رسالة تذكير القسط للعميل: ${item.customerName}`,
        `Copied installment reminder for: ${item.customerName}`
      ),
      'success'
    );
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleQuickPayInstallment = (item: ApproachingInstallment) => {
    const success = db.payInstallmentItem(
      item.planId,
      item.installment.id,
      item.amount,
      tr('تم تحصيل القسط مباشرة من نافذة تنبيهات لوحة التحكم', 'Paid directly from Dashboard Weekly Alert')
    );

    if (success) {
      refreshData();
      setConfirmPayId(null);
      showToast(
        tr(
          `تم تسجيل سداد القسط #${item.installment.installmentNumber} للعميل "${item.customerName}" بقيمة ${formatCurrency(item.amount)} بنجاح!`,
          `Installment #${item.installment.installmentNumber} for "${item.customerName}" marked as paid!`
        ),
        'success'
      );
    } else {
      showToast(
        tr('تعذر تسجيل سداد القسط، يرجى المحاولة مرة أخرى', 'Failed to record installment payment'),
        'error'
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/50 backdrop-blur-sm overflow-y-auto"
      onClick={() => onClose(dontShowAgainSession)}
    >
      <div
        className="neu-card rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl border border-amber-300/70 my-auto max-h-[92vh] flex flex-col bg-slate-50"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-amber-500/15 via-blue-500/10 to-white border-b border-slate-200/80 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md shrink-0">
              <BellRing className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  {tr(
                    'تنبيه تلقائي: أقساط العملاء المستحقة هذا الأسبوع',
                    'Automatic Alert: Customers with Installments Due This Week'
                  )}
                </h2>
                <span className="text-xs font-extrabold text-amber-800 bg-amber-100/90 border border-amber-300 px-2.5 py-0.5 rounded-lg tabular-nums">
                  {installments.length} {tr('عملاء للمتابعة', 'Due Alerts')}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                {tr(
                  'قائمة العملاء الذين يحل موعد سداد أقساطهم خلال الـ 7 أيام القادمة أو المتأخرين عن السداد — يمكنك التحصيل الفوري أو إرسال تذكير واتساب.',
                  'Customers with installments approaching due date within the next 7 days or overdue.'
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSoundEnabled((prev) => !prev)}
              className="p-2 rounded-xl neu-button text-slate-600 hover:text-slate-900 cursor-pointer"
              title={tr('تفعيل / كتم صوت التنبيه', 'Toggle Alert Sound')}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
            </button>
            <button
              type="button"
              onClick={() => onClose(dontShowAgainSession)}
              className="p-2 rounded-xl neu-button text-slate-600 hover:text-red-600 cursor-pointer"
              title={tr('إغلاق النافذة', 'Close')}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Summary KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-5 py-3.5 bg-white/70 border-b border-slate-200/70 shrink-0">
          <div className="p-3 rounded-2xl border border-blue-200/80 bg-blue-50/50">
            <div className="flex items-center justify-between text-[11px] font-bold text-blue-700 mb-1">
              <span>{tr('أقساط هذا الأسبوع (7 أيام)', 'Due This Week (7d)')}</span>
              <CalendarClock className="w-3.5 h-3.5" />
            </div>
            <div className="text-base font-black text-slate-900 tabular-nums">
              {summary.thisWeekTotalCount} {tr('أقساط', 'installments')}
            </div>
            <div className="text-[11px] font-bold text-blue-600 tabular-nums mt-0.5">
              {formatCurrency(summary.totalWeekAmount)}
            </div>
          </div>

          <div className="p-3 rounded-2xl border border-amber-200/80 bg-amber-50/50">
            <div className="flex items-center justify-between text-[11px] font-bold text-amber-800 mb-1">
              <span>{tr('مستحقة السداد اليوم', 'Due Today')}</span>
              <Clock className="w-3.5 h-3.5" />
            </div>
            <div className="text-base font-black text-amber-900 tabular-nums">
              {summary.todayCount} {tr('قسط اليوم', 'due today')}
            </div>
            <div className="text-[11px] text-amber-700 mt-0.5">
              {tr('أولوية تحصيل فورية', 'Immediate collection priority')}
            </div>
          </div>

          <div className="p-3 rounded-2xl border border-red-200/80 bg-red-50/50">
            <div className="flex items-center justify-between text-[11px] font-bold text-red-700 mb-1">
              <span>{tr('أقساط متأخرة السداد', 'Overdue Installments')}</span>
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
            <div className="text-base font-black text-red-800 tabular-nums">
              {summary.overdueCount} {tr('قسط متأخر', 'overdue')}
            </div>
            <div className="text-[11px] text-red-600 mt-0.5">
              {tr('تجاوزت تاريخ الاستحقاق', 'Past scheduled due date')}
            </div>
          </div>

          <div className="p-3 rounded-2xl border border-emerald-200/80 bg-emerald-50/50">
            <div className="flex items-center justify-between text-[11px] font-bold text-emerald-800 mb-1">
              <span>{tr('إجمالي المبالغ المستحقة', 'Total Due Amount')}</span>
              <DollarSign className="w-3.5 h-3.5" />
            </div>
            <div className="text-base font-black text-emerald-900 tabular-nums">
              {formatCurrency(summary.totalAllAmount)}
            </div>
            <div className="text-[11px] text-emerald-700 mt-0.5">
              {tr('شامل الأسبوع والمتأخرات', 'Including week & overdue')}
            </div>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="px-5 py-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-slate-200/70 bg-slate-100/60 shrink-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer tabular-nums ${
                filterMode === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
              }`}
            >
              {tr('الكل', 'All')} ({installments.length})
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('this_week_only')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer tabular-nums ${
                filterMode === 'this_week_only'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
              }`}
            >
              {tr('خلال هذا الأسبوع فقط', 'This Week Only')} ({summary.thisWeekTotalCount})
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('today')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer tabular-nums ${
                filterMode === 'today'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white text-amber-800 hover:bg-amber-50 border border-amber-200'
              }`}
            >
              {tr('مستحق اليوم', 'Due Today')} ({summary.todayCount})
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('overdue')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer tabular-nums ${
                filterMode === 'overdue'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white text-red-700 hover:bg-red-50 border border-red-200'
              }`}
            >
              {tr('متأخر السداد', 'Overdue')} ({summary.overdueCount})
            </button>
          </div>

          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={tr('بحث باسم العميل أو الهاتف أو الفاتورة...', 'Search customer, phone, invoice...')}
              className="w-full pr-8 pl-3 py-1.5 rounded-xl bg-white border border-slate-200/90 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Customers Installment List */}
        <div className="p-5 overflow-y-auto flex-1 space-y-3">
          {filteredList.map((item) => {
            const rowKey = `${item.planId}-${item.installment.id}`;
            const isOverdue = item.urgency === 'overdue';
            const isToday = item.urgency === 'today';
            const isConfirmingPay = confirmPayId === rowKey;
            const isCopied = copiedId === rowKey;

            const cleanPhone = formatWhatsAppPhone(item.customerPhone);
            const reminderMsg = buildReminderMessageForCustomer(item);
            const whatsappHref = cleanPhone ? createWhatsAppUrl(cleanPhone, reminderMsg) : '#';

            return (
              <div
                key={rowKey}
                className={`p-4 rounded-2xl border transition-all ${
                  isOverdue
                    ? 'bg-red-50/50 border-red-200/90 hover:border-red-300'
                    : isToday
                    ? 'bg-amber-50/50 border-amber-300/90 hover:border-amber-400'
                    : 'bg-white border-slate-200/90 hover:border-blue-300'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left/Right Customer & Due Date Details */}
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="font-black text-slate-900 text-sm sm:text-base">
                        {item.customerName}
                      </span>

                      <span
                        className={`px-2.5 py-0.5 rounded-lg text-[11px] font-extrabold border tabular-nums ${
                          isOverdue
                            ? 'bg-red-100 text-red-800 border-red-300'
                            : isToday
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : item.daysDiff === 1
                            ? 'bg-orange-100 text-orange-800 border-orange-300'
                            : 'bg-blue-100 text-blue-800 border-blue-200'
                        }`}
                      >
                        {isOverdue
                          ? tr(`متأخر منذ ${Math.abs(item.daysDiff)} يوم`, `Overdue by ${Math.abs(item.daysDiff)}d`)
                          : isToday
                          ? tr('مستحق السداد اليوم', 'Due Today')
                          : item.daysDiff === 1
                          ? tr('مستحق غداً', 'Due Tomorrow')
                          : item.daysDiff === 2
                          ? tr('مستحق خلال يومين', 'Due in 2 days')
                          : tr(`مستحق خلال ${item.daysDiff} أيام`, `Due in ${item.daysDiff} days`)}
                      </span>

                      <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md tabular-nums">
                        {tr(`قسط #${item.installment.installmentNumber}`, `Inst #${item.installment.installmentNumber}`)}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 flex-wrap text-xs text-slate-600">
                      <span className="flex items-center gap-1 font-mono tabular-nums">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span dir="ltr">{item.customerPhone}</span>
                      </span>

                      <span className="flex items-center gap-1 font-mono tabular-nums">
                        <FileText className="w-3.5 h-3.5 text-slate-400" />
                        <span>{item.invoiceNumber}</span>
                      </span>

                      <span className="flex items-center gap-1 font-semibold text-slate-700 tabular-nums">
                        <CalendarClock className="w-3.5 h-3.5 text-blue-600" />
                        <span>
                          {tr('تاريخ الاستحقاق:', 'Due Date:')} {item.dueDate}{' '}
                          <span className="text-slate-500 font-normal">({getWeekdayName(item.dueDate)})</span>
                        </span>
                      </span>
                    </div>

                    {item.installment.notes && (
                      <p className="text-[11px] text-slate-500">
                        {tr('ملاحظة:', 'Note:')} {item.installment.notes}
                      </p>
                    )}
                  </div>

                  {/* Amount & Action Controls */}
                  <div className="flex flex-col sm:flex-row lg:items-center justify-between lg:justify-end gap-3 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-200/60">
                    <div className="text-right sm:text-left lg:px-3">
                      <span className="text-[10px] font-bold text-slate-400 block">
                        {tr('قيمة القسط المستحق', 'Installment Amount')}
                      </span>
                      <span className="text-base sm:text-lg font-black text-slate-900 tabular-nums">
                        {formatCurrency(item.amount)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      {isConfirmingPay ? (
                        <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-300 px-2.5 py-1.5 rounded-xl">
                          <span className="text-[11px] font-bold text-emerald-900">
                            {tr('تأكيد التحصيل؟', 'Confirm pay?')}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleQuickPayInstallment(item)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            {tr('نعم، تم السداد', 'Yes, Paid')}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmPayId(null)}
                            className="px-2 py-1 rounded-lg bg-white text-slate-600 hover:text-slate-900 text-[11px] font-semibold border border-slate-200 cursor-pointer"
                          >
                            {tr('إلغاء', 'Cancel')}
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmPayId(rowKey)}
                          className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{tr('تحصيل القسط فوراً', 'Collect Now')}</span>
                        </button>
                      )}

                      {cleanPhone ? (
                        <button
                          type="button"
                          onClick={() => {
                            openSmartWhatsAppModal({
                              recipientName: item.customerName,
                              phone: item.customerPhone,
                              message: reminderMsg,
                              title: tr('إرسال تذكير قسط عبر واتساب', 'Send Installment WhatsApp Reminder'),
                              subtitle: `${tr('فاتورة', 'Invoice')} #${item.invoiceNumber} · ${tr('قسط', 'Installment')} #${item.installment.installmentNumber}`
                            });
                          }}
                          className="neu-button-emerald px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer no-underline"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{tr('إرسال واتساب', 'WhatsApp')}</span>
                        </button>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => handleCopyReminder(item)}
                        className="neu-button px-2.5 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                        title={tr('نسخ رسالة التذكير الجاهزة', 'Copy ready reminder message')}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-700 font-bold">{tr('تم النسخ', 'Copied')}</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-slate-500" />
                            <span>{tr('نسخ التذكير', 'Copy Msg')}</span>
                          </>
                        )}
                      </button>

                      {onOpenDetailedReminder && (
                        <button
                          type="button"
                          onClick={() => onOpenDetailedReminder(item)}
                          className="neu-button px-2.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                          title={tr('خيارات تذكير وسداد متقدمة', 'Advanced reminder & payment options')}
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {filteredList.length === 0 && (
            <div className="py-12 text-center bg-white/80 rounded-2xl border border-slate-200/70 space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <p className="text-sm font-bold text-slate-800">
                {tr(
                  'لا توجد أقساط مطابقة لهذا الفلتر حالياً',
                  'No installments match the selected filter'
                )}
              </p>
              <p className="text-xs text-slate-500">
                {tr(
                  'جميع أقساط هذا التصنيف تم تحصيلها أو لا توجد نتائج مطابقة للبحث.',
                  'All installments in this category have been collected or no search matches.'
                )}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-white border-t border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={dontShowAgainSession}
              onChange={(e) => setDontShowAgainSession(e.target.checked)}
              className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
            />
            <span>
              {tr(
                'عدم إظهار هذه النافذة تلقائياً مرة أخرى خلال جلسة العمل الحالية',
                'Do not auto-popup again during this current session'
              )}
            </span>
          </label>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={() => {
                onClose(dontShowAgainSession);
                onNavigateToInstallments();
              }}
              className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-blue-700 hover:bg-blue-50 flex items-center gap-1.5 cursor-pointer"
            >
              <span>{tr('فتح إدارة الأقساط الكاملة', 'Open Full Installments Manager')}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => onClose(dontShowAgainSession)}
              className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold cursor-pointer"
            >
              {tr('متابعة للوحة التحكم', 'Continue to Dashboard')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
