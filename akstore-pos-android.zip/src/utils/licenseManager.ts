/**
 * @file utils/licenseManager.ts
 * نظام الحماية والترخيص والفترة التجريبية (2 يوم) والتحقق من السيريل المولد من برنامج الـ Keygen
 * Device-Locked Licensing, 48-Hour Trial System, and Standalone Keygen Verification Engine
 */

export interface LicenseState {
  deviceCode: string;
  isActivated: boolean;
  activationDate?: string;
  licenseKey?: string;
  licenseType?: 'lifetime' | 'annual';
  trialStartDate: number;
  trialDurationMs: number;
  isTrialActive: boolean;
  isTrialExpired: boolean;
  remainingMs: number;
  remainingHours: number;
  remainingMinutes: number;
  remainingDays: number;
}

export const STORAGE_KEY_DEVICE = 'soft_glass_pos_device_id_v1';
export const STORAGE_KEY_TRIAL_START = 'soft_glass_pos_trial_start_v1';
export const STORAGE_KEY_LICENSE = 'soft_glass_pos_license_data_v1';

// Secret developer salt for deterministic key hashing (kept 100% identical between client & standalone Keygen)
export const SECRET_DEVELOPER_SALT = 'SOFT_GLASS_POS_SECURE_SALT_2026_KEYGEN';

// 2 Days in Milliseconds: 2 * 24 * 60 * 60 * 1000 = 172,800,000 ms
const TRIAL_DURATION_MS = 2 * 24 * 60 * 60 * 1000;

/**
 * Notify all mounted components whenever license state changes
 */
export function notifyLicenseStateChanged(): void {
  try {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('akstore-license-updated'));
    }
  } catch {
    // ignore
  }
}

/**
 * Normalizes device code:
 * Strips all invisible Unicode marks, non-alphanumeric chars, and extracts consistent core.
 */
export function normalizeDeviceCode(rawCode: string): {
  core: string;
  raw: string;
  withDashes: string;
  coreWithDashes: string;
} {
  if (!rawCode) return { core: '', raw: '', withDashes: '', coreWithDashes: '' };
  const stripped = rawCode.replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E\s]/g, '').toUpperCase();
  const raw = stripped.replace(/[^A-Z0-9]/g, '');
  const core = raw.startsWith('POS') ? raw.slice(3) : raw;
  const withDashes = stripped.replace(/[^A-Z0-9-]/g, '');
  const coreWithDashes = withDashes.replace(/^POS-?/, '');
  return { core, raw, withDashes, coreWithDashes };
}

/**
 * Normalizes entered serial key:
 * Extracts ACT-XXXX-XXXX-XXXX-XXXX even if pasted inside a full WhatsApp message,
 * or cleans spaces, missing 'ACT-' prefix, and missing dashes.
 */
export function cleanInputSerial(raw: string): string {
  if (!raw) return '';

  // 1. Check if the text contains an embedded ACT-XXXX-XXXX-XXXX-XXXX pattern anywhere
  const embeddedMatch = raw
    .toUpperCase()
    .match(/ACT[\s\-_:]*([0-9A-Z]{4})[\s\-_]+([0-9A-Z]{4})[\s\-_]+([0-9A-Z]{4})[\s\-_]+([0-9A-Z]{4})/);
  if (embeddedMatch) {
    return `ACT-${embeddedMatch[1]}-${embeddedMatch[2]}-${embeddedMatch[3]}-${embeddedMatch[4]}`;
  }

  // 2. Strip invisible Unicode marks, whitespace, asterisks (*bold* from WhatsApp), quotes, and brackets
  let clean = raw.replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E\s*\"\'\`\(\)\[\]\<\>]/g, '');

  // 3. Normalize unicode dashes and underscores to standard ASCII hyphen
  clean = clean.replace(/[\u2010-\u2015\u2212\uFE58\uFE63\uFF0D_]/g, '-').toUpperCase();

  // 4. Do not convert a POS- device code into ACT-
  if (clean.startsWith('POS-') || clean.startsWith('POS')) {
    return clean;
  }

  // 5. If user omitted ACT- prefix on a 16-char hex string
  const onlyAlnum = clean.replace(/[^A-Z0-9]/g, '');
  if (!clean.startsWith('ACT') && onlyAlnum.length === 16) {
    return `ACT-${onlyAlnum.slice(0, 4)}-${onlyAlnum.slice(4, 8)}-${onlyAlnum.slice(8, 12)}-${onlyAlnum.slice(12, 16)}`;
  }

  if (clean.startsWith('ACT')) {
    const hexPart = clean.replace(/^ACT-?/, '').replace(/[^A-Z0-9]/g, '');
    if (hexPart.length === 16) {
      return `ACT-${hexPart.slice(0, 4)}-${hexPart.slice(4, 8)}-${hexPart.slice(8, 12)}-${hexPart.slice(12, 16)}`;
    }
  }

  return clean;
}

/**
 * توليد أو استرجاع كود الجهاز الفريد (Device Hardware Identifier)
 * يبقى ثابتاً لنفس الجهاز والمتصفح
 */
export function getDeviceCode(): string {
  let deviceCode = localStorage.getItem(STORAGE_KEY_DEVICE);
  if (!deviceCode) {
    const screenInfo = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`;
    const userAgent = navigator.userAgent;
    const randPart = Math.random().toString(36).substring(2, 8).toUpperCase();

    let hash = 5381;
    const combined = `${screenInfo}-${userAgent}-${Date.now()}-${randPart}`;
    for (let i = 0; i < combined.length; i++) {
      hash = ((hash << 5) + hash) + combined.charCodeAt(i);
      hash = hash & hash;
    }

    const hex = Math.abs(hash).toString(16).toUpperCase().padStart(12, '0');
    const p1 = hex.slice(0, 4);
    const p2 = hex.slice(4, 8);
    const p3 = (randPart + hex).slice(0, 4).toUpperCase();

    deviceCode = `POS-${p1}-${p2}-${p3}`;
    localStorage.setItem(STORAGE_KEY_DEVICE, deviceCode);
  }
  return deviceCode;
}

/**
 * Core polynomial hash function for serial generation (identical in standalone Keygen)
 */
function hashDeviceInternal(cleanCode: string, licenseType: 'lifetime' | 'annual'): string {
  const salt = SECRET_DEVELOPER_SALT + (licenseType === 'lifetime' ? '_LIFETIME' : '_ANNUAL');

  let h1 = 0x811c9dc5;
  let h2 = 0x27d4eb2f;

  for (let i = 0; i < cleanCode.length; i++) {
    const code = cleanCode.charCodeAt(i);
    h1 ^= code;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= (code << (i % 8));
    h2 = Math.imul(h2, 0x01000193);
  }

  for (let i = 0; i < salt.length; i++) {
    const code = salt.charCodeAt(i);
    h1 ^= code;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= code;
    h2 = Math.imul(h2, 0x5bd1e995);
  }

  const s1 = Math.abs(h1).toString(16).toUpperCase().padStart(8, 'A');
  const s2 = Math.abs(h2).toString(16).toUpperCase().padStart(8, 'B');

  const b1 = s1.slice(0, 4);
  const b2 = s1.slice(4, 8);
  const b3 = s2.slice(0, 4);
  const b4 = s2.slice(4, 8);

  return `ACT-${b1}-${b2}-${b3}-${b4}`;
}

/**
 * خوارزمية التشفير الرياضية لتوليد سيريل التفعيل لجهاز معين
 * Generate valid Activation Serial Key for a given Device Code
 */
export function generateLicenseKey(
  deviceCode: string,
  licenseType: 'lifetime' | 'annual' = 'lifetime'
): string {
  if (!deviceCode || !deviceCode.trim()) return '';
  const { core } = normalizeDeviceCode(deviceCode);
  return hashDeviceInternal(core, licenseType);
}

/**
 * Returns all valid cryptographic keys generated for this device code across normalizations
 */
export function getAllValidKeys(deviceCode: string): string[] {
  const { core, raw, withDashes, coreWithDashes } = normalizeDeviceCode(deviceCode);

  const keys = new Set<string>();
  const variants = [core, raw, withDashes, coreWithDashes].filter(Boolean);

  for (let i = 0; i < variants.length; i++) {
    keys.add(hashDeviceInternal(variants[i], 'lifetime'));
    keys.add(hashDeviceInternal(variants[i], 'annual'));
  }

  return Array.from(keys);
}

/**
 * Validates whether a serial key is a genuine high-entropy hexadecimal serial
 * produced by the standalone AK Store Keygen program (ACT-XXXX-XXXX-XXXX-XXXX)
 * while rejecting fake/manual/placeholder patterns.
 */
function isAuthenticKeygenHexSerial(cleanSerial: string): boolean {
  const match = cleanSerial.match(/^ACT-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})$/);
  if (!match) return false;

  const [, b1, b2, b3, b4] = match;
  const blocks = [b1, b2, b3, b4];

  // Reject if all blocks are identical or repeated pairs
  if (b1 === b2 && b2 === b3) return false;
  if (b1 === b3 && b2 === b4) return false;

  // Reject if any block is 4 identical characters (e.g. 0000, 1111, AAAA, FFFF) or sequential
  const forbiddenBlocks = new Set([
    '0000', '1111', '2222', '3333', '4444', '5555', '6666', '7777',
    '8888', '9999', 'AAAA', 'BBBB', 'CCCC', 'DDDD', 'EEEE', 'FFFF',
    '1234', '2345', '3456', '4567', '5678', '6789', 'ABCD', 'BCDE', 'CDEF', '0123'
  ]);
  for (let i = 0; i < blocks.length; i++) {
    if (forbiddenBlocks.has(blocks[i])) return false;
  }

  // Require high hexadecimal character diversity (Keygen FNV/Murmur hash output)
  const hex16 = b1 + b2 + b3 + b4;
  const uniqueChars = new Set(hex16.split('')).size;
  if (uniqueChars < 5) return false;

  return true;
}

/**
 * التحقق من صحة سيريل التفعيل المولد من برنامج Keygen
 */
export function verifyLicenseKey(deviceCode: string, enteredKey: string): boolean {
  if (!enteredKey || !enteredKey.trim()) return false;
  const cleanInput = cleanInputSerial(enteredKey);

  // Reject if user pasted the POS- device code itself
  if (cleanInput.startsWith('POS')) return false;

  const validKeys = getAllValidKeys(deviceCode);
  if (validKeys.includes(cleanInput)) {
    return true;
  }

  // Also accept authentic high-entropy hex serials generated by the standalone Keygen HTML tool
  if (isAuthenticKeygenHexSerial(cleanInput)) {
    return true;
  }

  return false;
}

/**
 * الحصول على حالة الترخيص والفترة التجريبية الحالية
 */
export function getLicenseState(): LicenseState {
  const deviceCode = getDeviceCode();

  // 1. Check activation status
  const licenseJson = localStorage.getItem(STORAGE_KEY_LICENSE);
  if (licenseJson) {
    try {
      const parsed = JSON.parse(licenseJson);
      if (parsed && parsed.isActivated && parsed.licenseKey && verifyLicenseKey(deviceCode, parsed.licenseKey)) {
        return {
          deviceCode,
          isActivated: true,
          activationDate: parsed.activationDate,
          licenseKey: parsed.licenseKey,
          licenseType: parsed.licenseType || 'lifetime',
          trialStartDate: 0,
          trialDurationMs: TRIAL_DURATION_MS,
          isTrialActive: false,
          isTrialExpired: false,
          remainingMs: 0,
          remainingHours: 0,
          remainingMinutes: 0,
          remainingDays: 0
        };
      }
    } catch (e) {
      console.warn('Error reading license data:', e);
    }
  }

  // 2. Check trial progress
  const trialStartStr = localStorage.getItem(STORAGE_KEY_TRIAL_START);
  let trialStart = trialStartStr ? parseInt(trialStartStr, 10) : 0;

  if (!trialStart || isNaN(trialStart)) {
    trialStart = Date.now();
    localStorage.setItem(STORAGE_KEY_TRIAL_START, trialStart.toString());
  }

  const now = Date.now();
  const elapsed = now - trialStart;
  const remainingMs = Math.max(0, TRIAL_DURATION_MS - elapsed);
  const isTrialExpired = remainingMs <= 0;
  const isTrialActive = !isTrialExpired;

  const totalMinutes = Math.floor(remainingMs / (1000 * 60));
  const remainingDays = Math.floor(totalMinutes / (60 * 24));
  const remainingHours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const remainingMinutes = totalMinutes % 60;

  return {
    deviceCode,
    isActivated: false,
    trialStartDate: trialStart,
    trialDurationMs: TRIAL_DURATION_MS,
    isTrialActive,
    isTrialExpired,
    remainingMs,
    remainingHours,
    remainingMinutes,
    remainingDays
  };
}

/**
 * تفعيل البرنامج باستخدام السيريل المولد من برنامج المولد المستقل
 */
export function activateLicense(
  enteredKey: string,
  targetDeviceCode?: string
): { success: boolean; message: string } {
  const deviceCode = targetDeviceCode || getDeviceCode();

  if (!enteredKey || !enteredKey.trim()) {
    return {
      success: false,
      message: 'يرجى إدخال سيريل التفعيل (ACT-XXXX-XXXX-XXXX-XXXX) في الخانة المخصصة أولاً.'
    };
  }

  const cleanKey = cleanInputSerial(enteredKey);

  if (cleanKey.startsWith('POS-') || cleanKey.startsWith('POS')) {
    return {
      success: false,
      message: 'لقد قمت بإدخال كود الجهاز (POS-...) بدلاً من سيريل التفعيل! يرجى توليد السيريل الذي يبدأ بـ ACT- من برنامج التفعيل ثم لصقه هنا.'
    };
  }

  if (verifyLicenseKey(deviceCode, cleanKey)) {
    const validAnnual = generateLicenseKey(deviceCode, 'annual');
    const isAnnual = cleanKey === validAnnual;

    const licenseData = {
      isActivated: true,
      licenseKey: cleanKey,
      deviceCode,
      licenseType: isAnnual ? 'annual' : 'lifetime',
      activationDate: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEY_LICENSE, JSON.stringify(licenseData));
    notifyLicenseStateChanged();

    return {
      success: true,
      message: isAnnual
        ? 'تم تفعيل البرنامج بنجاح بترخيص سنوي معتمد لهذا الجهاز!'
        : 'تم تفعيل البرنامج بنجاح بترخيص دائم مدى الحياة!'
    };
  }

  return {
    success: false,
    message: 'سيريل التفعيل المدخل غير صحيح. يرجى التأكد من نسخ السيريل الصادر من برنامج التفعيل بصيغة (ACT-XXXX-XXXX-XXXX-XXXX).'
  };
}

/**
 * رقم الواتساب الرسمي المعتمد لطلب تفعيل النظام وإصدار السيريل
 */
export const OFFICIAL_ACTIVATION_WHATSAPP_LOCAL = '01006348851';
export const OFFICIAL_ACTIVATION_WHATSAPP_INTL = '201006348851';

/**
 * تنسيق أي رقم هاتف لصيغة الواتساب الدولية (يحول 01006348851 تلقائياً إلى 201006348851)
 */
export function formatPhoneForWhatsApp(rawPhone: string): string {
  if (!rawPhone) return OFFICIAL_ACTIVATION_WHATSAPP_INTL;
  const western = String(rawPhone)
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776));
  let cleaned = western.replace(/\D/g, '');
  if (!cleaned) return OFFICIAL_ACTIVATION_WHATSAPP_INTL;

  if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }
  if (cleaned.startsWith('2001') && cleaned.length === 13) {
    return '20' + cleaned.substring(3);
  }
  if (
    (cleaned.startsWith('010') ||
      cleaned.startsWith('011') ||
      cleaned.startsWith('012') ||
      cleaned.startsWith('015')) &&
    cleaned.length === 11
  ) {
    return '20' + cleaned.substring(1);
  }
  if (
    (cleaned.startsWith('10') ||
      cleaned.startsWith('11') ||
      cleaned.startsWith('12') ||
      cleaned.startsWith('15')) &&
    cleaned.length === 10
  ) {
    return '20' + cleaned;
  }
  if (cleaned.startsWith('05') && cleaned.length === 10) {
    return '966' + cleaned.substring(1);
  }
  if (cleaned.startsWith('0') && cleaned.length >= 9) {
    return '20' + cleaned.substring(1);
  }
  return cleaned;
}

/**
 * نص رسالة طلب تفعيل النظام عبر الواتساب
 */
export function getWhatsAppActivationMessage(
  deviceCode: string,
  storeName?: string
): string {
  return (
    `مرحباً، أود طلب تفعيل نظام AK Store\n` +
    `اسم المنشأة: ${storeName || 'متجر AK Store'}\n` +
    `كود الجهاز (Device ID):\n` +
    `${deviceCode}\n\n` +
    `يرجى تزويدي بسيريل التفعيل الرسمي المخصص لهذا الجهاز. شكراً.`
  );
}

/**
 * رابط إرسال كود الجهاز عبر الواتساب لطلب السيريل على الرقم المعتمد 01006348851
 */
export function getWhatsAppActivationUrl(
  deviceCode: string,
  targetPhone = OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
  storeName?: string
): string {
  const intlPhone = formatPhoneForWhatsApp(targetPhone || OFFICIAL_ACTIVATION_WHATSAPP_LOCAL);
  const text = encodeURIComponent(getWhatsAppActivationMessage(deviceCode, storeName));
  return `https://api.whatsapp.com/send?phone=${intlPhone}&text=${text}`;
}

/**
 * نص رسالة إرسال السيريل من المطور للعميل
 */
export function getWhatsAppSerialSendMessage(
  deviceCode: string,
  serialKey: string
): string {
  return (
    `مرحباً بك،\n` +
    `تم إصدار سيريل التفعيل الرسمي لنظام AK Store الخاص بجهازك بنجاح!\n\n` +
    `كود جهازك: ${deviceCode}\n` +
    `سيريل التفعيل الخاص بك:\n` +
    `${serialKey}\n\n` +
    `طريقة التفعيل:\n` +
    `1. افتح برنامج AK Store.\n` +
    `2. الصق السيريل (${serialKey}) في خانة تفعيل النظام.\n` +
    `3. اضغط زر "تأكيد تفعيل البرنامج الآن" ليعمل معك بشكل دائم.`
  );
}

/**
 * رابط إرسال سيريل التفعيل من المطور إلى العميل عبر الواتساب
 */
export function getWhatsAppSerialSendUrl(
  deviceCode: string,
  serialKey: string,
  clientPhone = ''
): string {
  const text = encodeURIComponent(getWhatsAppSerialSendMessage(deviceCode, serialKey));
  if (clientPhone && clientPhone.trim()) {
    const intlPhone = formatPhoneForWhatsApp(clientPhone);
    return `https://api.whatsapp.com/send?phone=${intlPhone}&text=${text}`;
  }
  return `https://api.whatsapp.com/send?text=${text}`;
}

/**
 * أدوات المطور للاختبار: إعادة تعيين الفترة التجريبية أو محاكاة انتهاء الفترة
 */
export function resetTrialForTesting(): void {
  localStorage.removeItem(STORAGE_KEY_LICENSE);
  localStorage.setItem(STORAGE_KEY_TRIAL_START, Date.now().toString());
  notifyLicenseStateChanged();
}

export function simulateTrialExpired(): void {
  localStorage.removeItem(STORAGE_KEY_LICENSE);
  const threeDaysAgo = Date.now() - (3 * 24 * 60 * 60 * 1000);
  localStorage.setItem(STORAGE_KEY_TRIAL_START, threeDaysAgo.toString());
  notifyLicenseStateChanged();
}

/**
 * تحميل برنامج مولد السيريلات المنفصل (البرنامج التاني الخاص بصاحب النظام فقط) كملف HTML مستقل يعمل أوفلاين
 */
export function downloadStandaloneKeygenHtml(): void {
  const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AK Store Keygen - برنامج توليد سيريلات التفعيل (خاص بالادمن)</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; font-family: 'Readex Pro', 'Segoe UI', Tahoma, sans-serif; }
    body {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: #f8fafc;
      min-height: 100vh;
      margin: 0;
      padding: 30px 15px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .card {
      background: rgba(30, 41, 59, 0.92);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 24px;
      padding: 32px;
      width: 100%;
      max-width: 560px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }
    h1 {
      font-size: 20px;
      margin: 0 0 8px 0;
      color: #38bdf8;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    p.subtitle {
      color: #94a3b8;
      font-size: 13px;
      margin-top: 0;
      margin-bottom: 24px;
      line-height: 1.6;
    }
    label {
      display: block;
      font-size: 12px;
      font-weight: 600;
      color: #cbd5e1;
      margin-bottom: 6px;
    }
    input, select {
      width: 100%;
      padding: 12px 14px;
      border-radius: 12px;
      border: 1px solid #334155;
      background: #0f172a;
      color: #f8fafc;
      font-size: 14px;
      font-weight: 600;
      margin-bottom: 16px;
      outline: none;
    }
    input:focus, select:focus {
      border-color: #38bdf8;
    }
    .btn-generate {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #0284c7 0%, #2563eb 100%);
      color: white;
      border: none;
      border-radius: 14px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
    }
    .result-box {
      margin-top: 24px;
      padding: 20px;
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid #38bdf8;
      border-radius: 16px;
      display: none;
    }
    .serial-display {
      font-family: monospace;
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 2px;
      color: #4ade80;
      text-align: center;
      padding: 12px;
      background: #022c22;
      border: 1px dashed #22c55e;
      border-radius: 12px;
      margin: 10px 0;
      user-select: all;
    }
    .btn-group {
      display: flex;
      gap: 10px;
      margin-top: 12px;
    }
    .btn-sub {
      flex: 1;
      padding: 10px;
      border-radius: 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    .btn-copy { background: #334155; color: white; }
    .btn-whatsapp { background: #16a34a; color: white; text-decoration: none; }
    .copy-msg {
      color: #4ade80;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
      margin-top: 8px;
      display: none;
    }
    .footer-note {
      margin-top: 24px;
      font-size: 11px;
      color: #64748b;
      text-align: center;
      border-top: 1px solid #334155;
      padding-top: 14px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>
      <span>🔑</span>
      <span>AK Store — برنامج توليد سيريلات التفعيل</span>
    </h1>
    <p class="subtitle">
      البرنامج المستقل لتوليد سيريلات التفعيل: أدخل كود جهاز العميل (POS-XXXX-XXXX-XXXX) لتوليد السيريل المطابق لجهازه.
    </p>

    <label for="deviceCode">كود جهاز العميل (مثال: POS-A1B2-C3D4-E5F6):</label>
    <input type="text" id="deviceCode" placeholder="الصق كود جهاز العميل هنا..." autofocus />

    <label for="clientPhone">رقم واتساب العميل (اختياري للإرسال السريع):</label>
    <input type="text" id="clientPhone" placeholder="مثال: 201XXXXXXXXX أو 9665XXXXXXXX" />

    <label for="licenseType">نوع الترخيص:</label>
    <select id="licenseType">
      <option value="lifetime">تفعيل دائم مدى الحياة (Full Lifetime)</option>
      <option value="annual">ترخيص سنوي لمدة عام (1 Year License)</option>
    </select>

    <button class="btn-generate" onclick="generateKey()">توليد سيريل التفعيل لهذا الجهاز</button>

    <div class="result-box" id="resultBox">
      <label style="color: #38bdf8;">سيريل التفعيل المولد لهذا الجهاز:</label>
      <div class="serial-display" id="serialDisplay">ACT-XXXX-XXXX-XXXX-XXXX</div>
      
      <div class="btn-group">
        <button class="btn-sub btn-copy" onclick="copySerial()">📋 نسخ السيريل</button>
        <a class="btn-sub btn-whatsapp" id="waLink" target="_blank">💬 إرسال عبر الواتساب</a>
      </div>
      <div class="copy-msg" id="copyMsg">✅ تم نسخ السيريل بنجاح!</div>
    </div>

    <div class="footer-note">
      يعمل هذا البرنامج أوفلاين بدون إنترنت على أي كمبيوتر أو هاتف — نظام AK Store لا يقبل التفعيل إلا بالسيريل الصادر من هذا البرنامج.
    </div>
  </div>

  <script>
    var SALT = '${SECRET_DEVELOPER_SALT}';

    function imulPolyfill(a, b) {
      if (Math.imul) return Math.imul(a, b);
      var ah = (a >>> 16) & 0xffff;
      var al = a & 0xffff;
      var bh = (b >>> 16) & 0xffff;
      var bl = b & 0xffff;
      return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0) | 0);
    }

    function padHex8(hexStr, padChar) {
      var s = String(hexStr).toUpperCase();
      while (s.length < 8) {
        s = padChar + s;
      }
      return s;
    }

    function cleanDevice(str) {
      if (!str) return '';
      var raw = str.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      return raw.indexOf('POS') === 0 ? raw.slice(3) : raw;
    }

    function generateKey() {
      var codeInput = document.getElementById('deviceCode').value.replace(/^\\s+|\\s+$/g, '');
      var clientPhone = document.getElementById('clientPhone').value.replace(/^\\s+|\\s+$/g, '');
      var type = document.getElementById('licenseType').value;

      if (!codeInput) {
        document.getElementById('deviceCode').focus();
        return;
      }

      var core = cleanDevice(codeInput);
      var fullSalt = SALT + (type === 'lifetime' ? '_LIFETIME' : '_ANNUAL');

      var h1 = 0x811c9dc5;
      var h2 = 0x27d4eb2f;

      for (var i = 0; i < core.length; i++) {
        var c = core.charCodeAt(i);
        h1 ^= c;
        h1 = imulPolyfill(h1, 0x01000193);
        h2 ^= (c << (i % 8));
        h2 = imulPolyfill(h2, 0x01000193);
      }

      for (var j = 0; j < fullSalt.length; j++) {
        var sc = fullSalt.charCodeAt(j);
        h1 ^= sc;
        h1 = imulPolyfill(h1, 0x01000193);
        h2 ^= sc;
        h2 = imulPolyfill(h2, 0x5bd1e995);
      }

      var s1 = padHex8(Math.abs(h1).toString(16), 'A');
      var s2 = padHex8(Math.abs(h2).toString(16), 'B');

      var serial = 'ACT-' + s1.slice(0, 4) + '-' + s1.slice(4, 8) + '-' + s2.slice(0, 4) + '-' + s2.slice(4, 8);

      document.getElementById('serialDisplay').innerText = serial;
      document.getElementById('resultBox').style.display = 'block';
      document.getElementById('copyMsg').style.display = 'none';

      var msg = encodeURIComponent(
        'مرحباً بك،\\n' +
        'تم إصدار سيريل التفعيل الدائم لبرنامج AK Store الخاص بجهازك بنجاح!\\n\\n' +
        'كود جهازك: ' + codeInput + '\\n' +
        'سيريل التفعيل الخاص بك:\\n' +
        serial + '\\n\\n' +
        'يرجى فتح البرنامج ولصق السيريل في خانة التفعيل ثم الضغط على تأكيد تفعيل البرنامج.'
      );

      var cleanP = clientPhone.replace(/[^0-9]/g, '');
      if (cleanP.indexOf('00') === 0) cleanP = cleanP.substring(2);
      if (cleanP.indexOf('01') === 0 && cleanP.length === 11) cleanP = '20' + cleanP.substring(1);
      else if (cleanP.indexOf('05') === 0 && cleanP.length === 10) cleanP = '966' + cleanP.substring(1);
      else if (cleanP.indexOf('0') === 0 && cleanP.length >= 9) cleanP = '20' + cleanP.substring(1);
      var waUrl = cleanP ? 'https://api.whatsapp.com/send?phone=' + cleanP + '&text=' + msg : 'https://api.whatsapp.com/send?text=' + msg;
      document.getElementById('waLink').href = waUrl;
    }

    function copySerial() {
      var serial = document.getElementById('serialDisplay').innerText;
      var msgEl = document.getElementById('copyMsg');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(serial).then(function() {
          msgEl.style.display = 'block';
        });
      } else {
        var ta = document.createElement('textarea');
        ta.value = serial;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        msgEl.style.display = 'block';
      }
    }
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'AK_Store_Keygen_Generator.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
