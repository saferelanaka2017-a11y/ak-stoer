/**
 * @file pages/SalesInvoicesPage.tsx
 * شاشة فواتير المبيعات المحاسبية (بيع مباشر بدون شاشة الكاشير)
 * Non-Cashier Standard Sales Invoices Screen (B2B / Accounting Tabular Invoice Builder & Registry)
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Trash2,
  Edit2,
  Printer,
  Search,
  UserPlus,
  Building2,
  Calendar,
  CreditCard,
  Banknote,
  Clock,
  FileText,
  CheckCircle2,
  AlertCircle,
  Package,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Eye,
  Filter,
  Sparkles,
  X,
  Keyboard,
  Users,
  Smartphone,
  Camera
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { SaleInvoice, CartItem, PaymentMethod, Product } from '../types';
import { playScannerBeep } from '../hooks/useBarcodeScanner';
import { MobileBarcodeScannerModal } from '../components/MobileBarcodeScannerModal';
import { NumberStepperInput } from '../components/NumberStepperInput';

interface InvoiceLineDraft {
  productId: string;
  product: Product;
  quantity: number;
  unitPrice: number;
  discount: number;
}

export const SalesInvoicesPage: React.FC = () => {
  const {
    products,
    customers,
    sales,
    warehouses,
    settings,
    currencies,
    activeCurrency,
    switchActiveCurrency,
    formatCurrency,
    refreshData,
    showToast,
    requestConfirm,
    openInvoiceModal,
    installmentPlans,
    tr,
    language
  } = useApp();

  const { user, hasPermission } = useAuth();

  // Toggle visibility of the direct invoice form (open by default so user immediately sees non-cashier sales form)
  const [isFormExpanded, setIsFormExpanded] = useState<boolean>(true);
  const [editingSale, setEditingSale] = useState<SaleInvoice | null>(null);

  // Invoice Header State
  const [customerId, setCustomerId] = useState<string>('');
  const [warehouseId, setWarehouseId] = useState<string>(
    settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main'
  );
  const [invoiceDate, setInvoiceDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [notes, setNotes] = useState<string>('');
  const [vatPercentInput, setVatPercentInput] = useState<number>(() =>
    Number(settings.vatPercentage) > 0 ? Number(settings.vatPercentage) : 0
  );
  const [extraInvoiceDiscount, setExtraInvoiceDiscount] = useState<number>(0);
  const [updateDefaultSalePrice, setUpdateDefaultSalePrice] = useState<boolean>(false);

  // Sync VAT input with store settings when not editing an existing sale
  useEffect(() => {
    if (!editingSale) {
      setVatPercentInput(Number(settings.vatPercentage) > 0 ? Number(settings.vatPercentage) : 0);
    }
  }, [settings.vatPercentage, editingSale]);

  // Line Item Entry Bar State
  const [productSearchCode, setProductSearchCode] = useState<string>('');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [entryQty, setEntryQty] = useState<number>(1);
  const [entryPrice, setEntryPrice] = useState<number>(0);
  const [entryDiscount, setEntryDiscount] = useState<number>(0);

  // Invoice Draft Items Table
  const [draftItems, setDraftItems] = useState<InvoiceLineDraft[]>([]);

  // Paid Amount State (can be auto-synced with grandTotal when paymentMethod === 'cash' | 'card', or manual)
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [isPaidManuallyEdited, setIsPaidManuallyEdited] = useState<boolean>(false);

  // Installment Plan State for Credit/Partial Sales
  const [enableInstallments, setEnableInstallments] = useState<boolean>(false);
  const [installmentCount, setInstallmentCount] = useState<number>(3);
  const [installmentStartDate, setInstallmentStartDate] = useState<string>(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().split('T')[0];
  });

  // Quick Add Customer Modal State
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState<boolean>(false);
  const [newCustomerName, setNewCustomerName] = useState<string>('');
  const [newCustomerPhone, setNewCustomerPhone] = useState<string>('');
  const [newCustomerAddress, setNewCustomerAddress] = useState<string>('');
  const [newCustomerTax, setNewCustomerTax] = useState<string>('');

  // Registry Search & Filter State
  const [registrySearch, setRegistrySearch] = useState<string>('');
  const [methodFilter, setMethodFilter] = useState<'all' | PaymentMethod>('all');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<'all' | 'paid' | 'credit_due'>('all');

  // Keyboard Navigation & Modals (F4 Customer Search, F8 Delete Row, F1 Shortcuts Help)
  const [selectedRowIndex, setSelectedRowIndex] = useState<number>(-1);
  const [isCustomerSearchOpen, setIsCustomerSearchOpen] = useState<boolean>(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');
  const [highlightedCustIndex, setHighlightedCustIndex] = useState<number>(0);
  const [isShortcutsHelpOpen, setIsShortcutsHelpOpen] = useState<boolean>(false);
  const [isMobileScannerOpen, setIsMobileScannerOpen] = useState<boolean>(false);

  const barcodeSearchInputRef = useRef<HTMLInputElement>(null);
  const customerSearchInputRef = useRef<HTMLInputElement>(null);
  const extraDiscountInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (draftItems.length === 0) {
      setSelectedRowIndex(-1);
    } else if (selectedRowIndex < 0 || selectedRowIndex >= draftItems.length) {
      setSelectedRowIndex(draftItems.length - 1);
    }
  }, [draftItems.length]);

  const filteredCustomersForModal = useMemo(() => {
    const q = customerSearchQuery.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      c =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        (c.address && c.address.toLowerCase().includes(q))
    );
  }, [customers, customerSearchQuery]);

  useEffect(() => {
    setHighlightedCustIndex(0);
  }, [customerSearchQuery, isCustomerSearchOpen]);

  // Helper: get stock in selected warehouse
  const getProductWarehouseStock = (prod: Product, whId: string): number => {
    if (prod.warehouseStock && prod.warehouseStock[whId] !== undefined) {
      return prod.warehouseStock[whId];
    }
    return prod.stock;
  };

  // Filtered products for fast search in entry bar
  const filteredProductsForSelect = useMemo(() => {
    if (!productSearchCode.trim()) return products;
    const q = productSearchCode.toLowerCase().trim();
    return products.filter(
      p =>
        p.name.toLowerCase().includes(q) ||
        p.barcode.toLowerCase().includes(q) ||
        (p.sku && p.sku.toLowerCase().includes(q)) ||
        p.category.toLowerCase().includes(q)
    );
  }, [products, productSearchCode]);

  // Financial Calculations for the Draft Invoice
  const invoiceCalculations = useMemo(() => {
    let grossSubtotal = 0;
    let itemsDiscountTotal = 0;

    draftItems.forEach(item => {
      grossSubtotal += item.unitPrice * item.quantity;
      itemsDiscountTotal += item.discount;
    });

    const totalDiscount = itemsDiscountTotal + (Number(extraInvoiceDiscount) || 0);
    const netBeforeTax = Math.max(0, grossSubtotal - totalDiscount);
    const cleanVatPercent = Number(vatPercentInput) > 0 ? Number(vatPercentInput) : 0;
    const vatRate = cleanVatPercent / 100;
    // Calculate tax ONLY when a number > 0 is entered in the VAT field
    const taxTotal = cleanVatPercent > 0 ? Number((netBeforeTax * vatRate).toFixed(2)) : 0;
    const subtotalWithoutTax = Number(netBeforeTax.toFixed(2));
    const grandTotal = Number((netBeforeTax + taxTotal).toFixed(2));

    return {
      grossSubtotal,
      itemsDiscountTotal,
      totalDiscount,
      subtotalWithoutTax,
      taxTotal,
      grandTotal,
      vatPercent: cleanVatPercent
    };
  }, [draftItems, extraInvoiceDiscount, vatPercentInput]);

  // Effective Paid Amount & Remaining Debt
  const effectivePaidAmount = useMemo(() => {
    if (isPaidManuallyEdited) {
      return Math.max(0, paidAmount);
    }
    if (paymentMethod === 'credit') {
      return 0;
    }
    return invoiceCalculations.grandTotal;
  }, [isPaidManuallyEdited, paidAmount, paymentMethod, invoiceCalculations.grandTotal]);

  const remainingDebt = useMemo(() => {
    return Math.max(0, Number((invoiceCalculations.grandTotal - effectivePaidAmount).toFixed(2)));
  }, [invoiceCalculations.grandTotal, effectivePaidAmount]);

  const changeAmount = useMemo(() => {
    return Math.max(0, Number((effectivePaidAmount - invoiceCalculations.grandTotal).toFixed(2)));
  }, [effectivePaidAmount, invoiceCalculations.grandTotal]);

  // Select product in entry bar
  const handleSelectProduct = (prodId: string) => {
    setSelectedProductId(prodId);
    const prod = products.find(p => p.id === prodId);
    if (prod) {
      setEntryPrice(prod.salePrice);
      setEntryQty(1);
      setEntryDiscount(0);
    }
  };

  // Barcode Enter key handler
  const handleBarcodeSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const q = productSearchCode.trim();
      if (!q) return;

      const exactMatch =
        products.find(p => p.barcode === q || p.sku === q) ||
        filteredProductsForSelect[0];

      if (exactMatch) {
        addProductToDraftTable(exactMatch, 1, exactMatch.salePrice, 0);
        setProductSearchCode('');
      } else {
        showToast(
          tr('لم يتم العثور على صنف مطابق لهذا الباركود أو الاسم', 'No matching product found'),
          'error'
        );
      }
    }
  };

  // Mobile Camera Barcode Scan Handler
  const handleMobileBarcodeScan = (scannedCode: string) => {
    const clean = scannedCode.trim();
    if (!clean) return;

    const exactMatch =
      products.find(
        p =>
          p.barcode.trim().toLowerCase() === clean.toLowerCase() ||
          (p.sku && p.sku.trim().toLowerCase() === clean.toLowerCase())
      ) || db.getProductByBarcode(clean);

    if (exactMatch) {
      addProductToDraftTable(exactMatch, 1, exactMatch.salePrice, 0);
      setProductSearchCode('');
      showToast(
        tr(
          `تم مسح وإدراج "${exactMatch.name}" (${formatCurrency(exactMatch.salePrice)}) في جدول الفاتورة`,
          `Scanned & added "${exactMatch.name}" (${formatCurrency(exactMatch.salePrice)}) to invoice`
        ),
        'success'
      );
    } else {
      playScannerBeep('error');
      setProductSearchCode(clean);
      showToast(
        tr(`لم يتم العثور على صنف بالباركود: ${clean}`, `No product found with barcode: ${clean}`),
        'error'
      );
    }
  };

  // Core function to insert/increment item in draft table
  const addProductToDraftTable = (
    prod: Product,
    qtyToAdd: number,
    unitPriceVal: number,
    discountVal: number
  ) => {
    if (qtyToAdd <= 0) {
      showToast(tr('يرجى إدخال كمية صحيحة أكبر من صفر', 'Please enter a valid quantity > 0'), 'error');
      return;
    }
    if (unitPriceVal < 0) {
      showToast(tr('سعر الوحدة لا يمكن أن يكون سالباً', 'Unit price cannot be negative'), 'error');
      return;
    }

    const availableStock = getProductWarehouseStock(prod, warehouseId);
    const existingIndex = draftItems.findIndex(i => i.productId === prod.id);
    const currentQtyInDraft = existingIndex > -1 ? draftItems[existingIndex].quantity : 0;

    // Account for original quantity if editing an existing invoice
    const originalQtyInEditedSale = editingSale
      ? editingSale.items.find(i => i.product.id === prod.id)?.quantity || 0
      : 0;

    if (currentQtyInDraft + qtyToAdd > availableStock + originalQtyInEditedSale) {
      showToast(
        tr(
          `الكمية المطلوبة (${currentQtyInDraft + qtyToAdd}) تتجاوز الرصيد المتاح في المستودع المحدد (${availableStock + originalQtyInEditedSale})`,
          `Requested quantity exceeds available warehouse stock (${availableStock + originalQtyInEditedSale})`
        ),
        'error'
      );
      return;
    }

    setDraftItems(prev => {
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + qtyToAdd,
          unitPrice: unitPriceVal,
          discount: updated[existingIndex].discount + discountVal
        };
        return updated;
      }
      return [
        ...prev,
        {
          productId: prod.id,
          product: prod,
          quantity: qtyToAdd,
          unitPrice: unitPriceVal,
          discount: discountVal
        }
      ];
    });
  };

  const handleAddLineFromBar = () => {
    const prod = products.find(p => p.id === selectedProductId);
    if (!prod) {
      showToast(tr('يرجى اختيار الصنف أولاً لإدراجه في الفاتورة', 'Please select a product first'), 'error');
      return;
    }
    addProductToDraftTable(prod, entryQty, entryPrice, entryDiscount);
    setSelectedProductId('');
    setEntryQty(1);
    setEntryPrice(0);
    setEntryDiscount(0);
    setProductSearchCode('');
  };

  // Inline table editors
  const handleUpdateRowQty = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveRow(productId);
      return;
    }
    const row = draftItems.find(i => i.productId === productId);
    if (!row) return;

    const availableStock = getProductWarehouseStock(row.product, warehouseId);
    const originalQtyInEditedSale = editingSale
      ? editingSale.items.find(i => i.product.id === productId)?.quantity || 0
      : 0;

    if (newQty > availableStock + originalQtyInEditedSale) {
      showToast(
        tr(
          `أقصى كمية متوفرة في هذا المستودع هي (${availableStock + originalQtyInEditedSale})`,
          `Max available stock in this warehouse is (${availableStock + originalQtyInEditedSale})`
        ),
        'error'
      );
      return;
    }

    setDraftItems(prev =>
      prev.map(i => (i.productId === productId ? { ...i, quantity: newQty } : i))
    );
  };

  const handleUpdateRowPrice = (productId: string, newPrice: number) => {
    setDraftItems(prev =>
      prev.map(i =>
        i.productId === productId ? { ...i, unitPrice: Math.max(0, newPrice) } : i
      )
    );
  };

  const handleUpdateRowDiscount = (productId: string, newDisc: number) => {
    setDraftItems(prev =>
      prev.map(i =>
        i.productId === productId ? { ...i, discount: Math.max(0, newDisc) } : i
      )
    );
  };

  const handleRemoveRow = (productId: string) => {
    setDraftItems(prev => prev.filter(i => i.productId !== productId));
  };

  // Reset form to clean state
  const resetInvoiceForm = () => {
    setEditingSale(null);
    setCustomerId('');
    setWarehouseId(settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main');
    setInvoiceDate(new Date().toISOString().split('T')[0]);
    setPaymentMethod('cash');
    setNotes('');
    setVatPercentInput(Number(settings.vatPercentage) > 0 ? Number(settings.vatPercentage) : 0);
    setExtraInvoiceDiscount(0);
    setDraftItems([]);
    setPaidAmount(0);
    setIsPaidManuallyEdited(false);
    setEnableInstallments(false);
    setInstallmentCount(3);
    setSelectedProductId('');
    setEntryQty(1);
    setEntryPrice(0);
    setEntryDiscount(0);
    setProductSearchCode('');
  };

  // Load existing invoice for editing
  const handleEditInvoice = (sale: SaleInvoice) => {
    setEditingSale(sale);
    setCustomerId(sale.customerId || '');
    setWarehouseId(sale.warehouseId || settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main');
    setInvoiceDate(sale.date ? sale.date.split('T')[0] : new Date().toISOString().split('T')[0]);
    setPaymentMethod(sale.paymentMethod || 'cash');
    setNotes(sale.notes || '');
    const editVatPct =
      sale.taxTotal > 0 && sale.subtotal > 0
        ? Math.round((sale.taxTotal / sale.subtotal) * 10000) / 100
        : 0;
    setVatPercentInput(editVatPct);

    const mappedDrafts: InvoiceLineDraft[] = sale.items.map(item => ({
      productId: item.product.id,
      product: item.product,
      quantity: item.quantity,
      unitPrice: item.price,
      discount: item.discount || 0
    }));

    const sumLineDiscounts = mappedDrafts.reduce((acc, d) => acc + d.discount, 0);
    const extraDisc = Math.max(0, (sale.discountTotal || 0) - sumLineDiscounts);
    setExtraInvoiceDiscount(extraDisc);
    setDraftItems(mappedDrafts);
    setPaidAmount(sale.paidAmount);
    setIsPaidManuallyEdited(true);
    const matchedPlan = installmentPlans.find(p => p.invoiceNumber === sale.invoiceNumber);
    if (sale.hasInstallment || matchedPlan) {
      setEnableInstallments(true);
      setInstallmentCount(sale.installmentCount || matchedPlan?.installmentCount || 3);
    } else {
      setEnableInstallments(false);
    }
    setIsFormExpanded(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Delete invoice with stock & customer balance reversal
  const handleDeleteInvoice = (sale: SaleInvoice) => {
    if (!hasPermission('canDelete')) {
      showToast(tr('ليس لديك صلاحية لحذف الفواتير', 'You do not have permission to delete invoices'), 'error');
      return;
    }

    requestConfirm({
      title: tr('حذف فاتورة المبيعات', 'Delete Sales Invoice'),
      message: tr(
        `هل أنت متأكد من حذف فاتورة المبيعات رقم "${sale.invoiceNumber}"؟ سيتم إرجاع الكميات المباعة إلى المستودع وتحديث رصيد العميل تلقائياً.`,
        `Are you sure you want to delete invoice "${sale.invoiceNumber}"? Sold stock will be restored to the warehouse and customer balance will be updated.`
      ),
      confirmText: tr('نعم، حذف الفاتورة واسترجاع المخزون', 'Yes, Delete & Restore Stock'),
      onConfirm: () => {
        db.deleteSale(sale.id);
        refreshData();
        if (editingSale?.id === sale.id) {
          resetInvoiceForm();
        }
        showToast(
          tr(
            `تم حذف الفاتورة #${sale.invoiceNumber} وإرجاع البضاعة للمخزون بنجاح`,
            `Invoice #${sale.invoiceNumber} deleted and stock restored`
          ),
          'success'
        );
      }
    });
  };

  // Quick Add New Customer handler
  const handleQuickAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName.trim()) {
      showToast(tr('يرجى إدخال اسم العميل', 'Please enter customer name'), 'error');
      return;
    }
    const created = db.addCustomer({
      name: newCustomerName.trim(),
      phone: newCustomerPhone.trim() || '01000000000',
      address: newCustomerAddress.trim(),
      taxNumber: newCustomerTax.trim(),
      balance: 0
    });
    refreshData();
    setCustomerId(created.id);
    setNewCustomerName('');
    setNewCustomerPhone('');
    setNewCustomerAddress('');
    setNewCustomerTax('');
    setIsAddCustomerOpen(false);
    showToast(
      tr(`تم تسجيل العميل "${created.name}" واختياره للفاتورة`, `Customer "${created.name}" created and selected`),
      'success'
    );
  };

  // Save / Submit Sales Invoice
  const handleSaveInvoice = (shouldPrintAfterSave: boolean) => {
    if (draftItems.length === 0) {
      showToast(
        tr('لا يمكن حفظ فاتورة فارغة! يرجى إضافة صنف واحد على الأقل.', 'Cannot save an empty invoice! Please add at least one item.'),
        'error'
      );
      return;
    }

    // If there is remaining debt (credit / partial payment / installments), customer selection is required
    if ((remainingDebt > 0 || enableInstallments) && !customerId) {
      showToast(
        tr(
          'الفاتورة تحتوي على مبلغ متبقٍ أو تقسيط! يرجى تحديد العميل أولاً لتسجيل المديونية أو خطة الأقساط على حسابه.',
          'This invoice has a remaining unpaid balance or installment plan! Please select a customer to record it.'
        ),
        'error'
      );
      return;
    }

    if (enableInstallments && remainingDebt <= 0) {
      showToast(
        tr(
          'اخترت نظام التقسيط الشهري ولكن المبلغ المسدد يساوي إجمالي الفاتورة بالكامل! يرجى إدخال الدفعة المقدمة (المقدم) أقل من إجمالي الفاتورة لاحتساب الأقساط.',
          'You selected Monthly Installments, but the paid amount equals the full invoice total! Please enter a down payment less than the grand total.'
        ),
        'error'
      );
      return;
    }

    const selectedCustomer = customers.find(c => c.id === customerId);
    const selectedWarehouse = warehouses.find(w => w.id === warehouseId);
    const cleanVatPercent = Number(vatPercentInput) > 0 ? Number(vatPercentInput) : 0;
    const vatRate = cleanVatPercent / 100;

    // Update default salePrice in inventory if user checked the option
    if (updateDefaultSalePrice) {
      draftItems.forEach(item => {
        if (item.unitPrice > 0 && item.unitPrice !== item.product.salePrice) {
          db.updateProduct(item.productId, { salePrice: item.unitPrice });
        }
      });
    }

    // Build CartItem[] for SaleInvoice
    const finalCartItems: CartItem[] = draftItems.map(item => {
      const lineTotal = Math.max(0, item.unitPrice * item.quantity - item.discount);
      const lineTax = cleanVatPercent > 0 ? Number((lineTotal * vatRate).toFixed(2)) : 0;
      return {
        product: item.product,
        quantity: item.quantity,
        price: item.unitPrice,
        discount: item.discount,
        tax: lineTax,
        total: lineTotal
      };
    });

    const finalPaymentMethod: PaymentMethod =
      remainingDebt > 0 && effectivePaidAmount === 0
        ? 'credit'
        : remainingDebt > 0 && effectivePaidAmount > 0
        ? 'split'
        : paymentMethod;

    const isInstallmentSale = Boolean(enableInstallments && remainingDebt > 0 && selectedCustomer);
    const cleanInstCount = isInstallmentSale ? Math.max(1, Number(installmentCount) || 3) : undefined;
    const monthlyInstAmount =
      isInstallmentSale && cleanInstCount
        ? Math.round((remainingDebt / cleanInstCount) * 100) / 100
        : undefined;

    const invoicePayload = {
      date: new Date(invoiceDate).toISOString(),
      cashierId: user?.id || 'user-admin',
      cashierName: user?.name || tr('محاسب المبيعات', 'Sales Accountant'),
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer ? selectedCustomer.name : tr('عميل نقدي عام', 'Walk-in Customer'),
      items: finalCartItems,
      subtotal: invoiceCalculations.subtotalWithoutTax,
      discountTotal: invoiceCalculations.totalDiscount,
      taxTotal: invoiceCalculations.taxTotal,
      grandTotal: invoiceCalculations.grandTotal,
      paidAmount: effectivePaidAmount,
      changeAmount,
      paymentMethod: finalPaymentMethod,
      notes: notes.trim() || undefined,
      currency: activeCurrency?.code || settings.currency,
      currencySymbol: activeCurrency?.symbol || settings.currencySymbol,
      exchangeRate: activeCurrency?.exchangeRate || 1,
      warehouseId: selectedWarehouse?.id || warehouseId,
      warehouseName: selectedWarehouse?.name || tr('المستودع الرئيسي', 'Main Warehouse'),
      hasInstallment: isInstallmentSale,
      installmentCount: cleanInstCount,
      downPayment: isInstallmentSale ? effectivePaidAmount : undefined,
      remainingInstallmentAmount: isInstallmentSale ? remainingDebt : undefined,
      monthlyInstallmentAmount: monthlyInstAmount
    };

    let savedInvoice: SaleInvoice | null = null;

    if (editingSale) {
      savedInvoice = db.updateSale(editingSale.id, invoicePayload);
      showToast(
        tr(
          `تم تحديث فاتورة المبيعات #${editingSale.invoiceNumber} وتعديل أرصدة المخزون والعميل بنجاح!`,
          `Sales Invoice #${editingSale.invoiceNumber} updated successfully!`
        ),
        'success'
      );
    } else {
      savedInvoice = db.createSale(invoicePayload);
      if (isInstallmentSale && selectedCustomer && cleanInstCount) {
        const monthlyAmt = Math.round((remainingDebt / cleanInstCount) * 100) / 100;
        const installmentsList = [];
        for (let i = 1; i <= cleanInstCount; i++) {
          const due = new Date(invoiceDate || new Date().toISOString());
          due.setMonth(due.getMonth() + i);
          installmentsList.push({
            id: `inst-${Date.now()}-${i}`,
            installmentNumber: i,
            dueDate: due.toISOString().split('T')[0],
            amount:
              i === cleanInstCount
                ? Math.round((remainingDebt - monthlyAmt * (cleanInstCount - 1)) * 100) / 100
                : monthlyAmt,
            status: 'pending' as const
          });
        }

        db.createInstallmentPlan({
          invoiceNumber: savedInvoice.invoiceNumber,
          customerId: selectedCustomer.id,
          customerName: selectedCustomer.name,
          customerPhone: selectedCustomer.phone,
          originalAmount: invoiceCalculations.grandTotal,
          interestAmount: 0,
          interestRate: 0,
          totalAmount: invoiceCalculations.grandTotal,
          downPayment: effectivePaidAmount,
          remainingAmount: remainingDebt,
          installmentCount: cleanInstCount,
          startDate: installmentStartDate || new Date().toISOString().split('T')[0],
          installments: installmentsList
        });
      }
      showToast(
        tr(
          `تم إصدار فاتورة المبيعات #${savedInvoice.invoiceNumber} وخصم البضاعة من [${invoicePayload.warehouseName}] بنجاح!`,
          `Sales Invoice #${savedInvoice.invoiceNumber} created and stock deducted from [${invoicePayload.warehouseName}]!`
        ),
        'success'
      );
    }

    refreshData();
    resetInvoiceForm();

    if (shouldPrintAfterSave && savedInvoice) {
      openInvoiceModal(savedInvoice);
    }
  };

  // Delete selected or last row in draft table (F8)
  const handleDeleteSelectedRow = () => {
    if (draftItems.length === 0) {
      showToast(tr('جدول الفاتورة فارغ حالياً، لا يوجد منتج لحذفه', 'Invoice table is empty, no item to delete'), 'error');
      return;
    }
    const targetIdx =
      selectedRowIndex >= 0 && selectedRowIndex < draftItems.length
        ? selectedRowIndex
        : draftItems.length - 1;
    const targetItem = draftItems[targetIdx];
    if (targetItem) {
      handleRemoveRow(targetItem.productId);
      showToast(
        tr(
          `تم حذف الصنف "${targetItem.product.name}" من جدول الفاتورة (F8)`,
          `Removed "${targetItem.product.name}" from invoice table (F8)`
        ),
        'info'
      );
      setSelectedRowIndex(Math.max(0, targetIdx - 1));
    }
  };

  // Cycle Payment Method (F6)
  const handleCyclePaymentMethod = () => {
    const methods: PaymentMethod[] = ['cash', 'card', 'credit', 'split'];
    const labels: Record<PaymentMethod, string> = {
      cash: tr('نقداً (Cash)', 'Cash'),
      card: tr('شبكة / بنكي (Card)', 'Card / Bank'),
      credit: tr('آجل (Credit)', 'Credit'),
      split: tr('دفعة مقدمة والباقي آجل (Split)', 'Partial / Split')
    };
    const nextIdx = (methods.indexOf(paymentMethod) + 1) % methods.length;
    const nextMethod = methods[nextIdx];
    setPaymentMethod(nextMethod);
    if (nextMethod === 'credit') {
      setPaidAmount(0);
      setIsPaidManuallyEdited(true);
    } else if (nextMethod === 'cash' || nextMethod === 'card') {
      setIsPaidManuallyEdited(false);
    }
    showToast(
      tr(`تم تغيير طريقة الدفع إلى: ${labels[nextMethod]} (F6)`, `Payment method changed to: ${labels[nextMethod]} (F6)`),
      'info'
    );
  };

  // Keyboard Shortcuts Listener for Mouse-Free Sales Invoice Creation
  useEffect(() => {
    const handleShortcuts = (e: KeyboardEvent) => {
      const activeEl = document.activeElement as HTMLElement | null;
      const isInputFocused =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          activeEl.tagName === 'SELECT');

      if (e.key === 'Escape') {
        if (isCustomerSearchOpen) {
          e.preventDefault();
          setIsCustomerSearchOpen(false);
          barcodeSearchInputRef.current?.focus();
          return;
        }
        if (isShortcutsHelpOpen) {
          e.preventDefault();
          setIsShortcutsHelpOpen(false);
          barcodeSearchInputRef.current?.focus();
          return;
        }
        if (isAddCustomerOpen) {
          e.preventDefault();
          setIsAddCustomerOpen(false);
          return;
        }
      }

      // Customer Search Modal (F4) Navigation
      if (isCustomerSearchOpen) {
        const totalOptions = filteredCustomersForModal.length + 1;
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setHighlightedCustIndex(prev => (prev + 1) % totalOptions);
          return;
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          setHighlightedCustIndex(prev => (prev - 1 + totalOptions) % totalOptions);
          return;
        }
        if (e.key === 'Enter') {
          e.preventDefault();
          if (highlightedCustIndex === 0) {
            setCustomerId('');
            showToast(tr('تم اختيار: عميل نقدي عام', 'Selected: Walk-in Cash Customer'), 'success');
          } else {
            const chosen = filteredCustomersForModal[highlightedCustIndex - 1];
            if (chosen) {
              setCustomerId(chosen.id);
              showToast(tr(`تم اختيار العميل: ${chosen.name}`, `Selected customer: ${chosen.name}`), 'success');
            }
          }
          setIsCustomerSearchOpen(false);
          setCustomerSearchQuery('');
          barcodeSearchInputRef.current?.focus();
          return;
        }
      }

      // F1: Shortcuts Help Modal
      if (e.key === 'F1') {
        e.preventDefault();
        setIsShortcutsHelpOpen(prev => !prev);
        return;
      }

      // F2: Complete Sale & Print Invoice (إتمام البيع والطباعة)
      if (e.key === 'F2') {
        e.preventDefault();
        if (!isFormExpanded) setIsFormExpanded(true);
        handleSaveInvoice(true);
        return;
      }

      // F3: Focus Product / Barcode Search
      if (e.key === 'F3') {
        e.preventDefault();
        if (!isFormExpanded) setIsFormExpanded(true);
        setTimeout(() => {
          barcodeSearchInputRef.current?.focus();
          barcodeSearchInputRef.current?.select();
        }, 30);
        return;
      }

      // F4: Open Customer Search Modal (البحث عن عميل)
      if (e.key === 'F4') {
        e.preventDefault();
        if (!isFormExpanded) setIsFormExpanded(true);
        setIsCustomerSearchOpen(prev => {
          const next = !prev;
          if (next) {
            setCustomerSearchQuery('');
            setHighlightedCustIndex(0);
            setTimeout(() => customerSearchInputRef.current?.focus(), 50);
          }
          return next;
        });
        return;
      }

      // F6: Cycle Payment Method
      if (e.key === 'F6') {
        e.preventDefault();
        handleCyclePaymentMethod();
        return;
      }

      // F7: Focus Extra Invoice Discount Input
      if (e.key === 'F7') {
        e.preventDefault();
        if (!isFormExpanded) setIsFormExpanded(true);
        setTimeout(() => {
          extraDiscountInputRef.current?.focus();
          extraDiscountInputRef.current?.select();
        }, 30);
        return;
      }

      // F8: Delete Selected or Last Product Row (حذف منتج)
      if (e.key === 'F8') {
        e.preventDefault();
        handleDeleteSelectedRow();
        return;
      }

      // F9: Save Invoice Without Printing
      if (e.key === 'F9') {
        e.preventDefault();
        if (!isFormExpanded) setIsFormExpanded(true);
        handleSaveInvoice(false);
        return;
      }

      // F10: Reset Invoice Form
      if (e.key === 'F10') {
        e.preventDefault();
        resetInvoiceForm();
        showToast(tr('تم تفريغ نموذج الفاتورة (F10)', 'Invoice form reset (F10)'), 'info');
        return;
      }

      // Navigate draft rows when not typing inside inputs (or when barcode search input is empty)
      const isBarcodeEmpty =
        activeEl === barcodeSearchInputRef.current && productSearchCode.trim() === '';

      if ((!isInputFocused || isBarcodeEmpty) && draftItems.length > 0 && !isCustomerSearchOpen) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setSelectedRowIndex(prev => (prev + 1) % draftItems.length);
          return;
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          setSelectedRowIndex(prev => (prev - 1 + draftItems.length) % draftItems.length);
          return;
        }
        if (e.key === '+' || e.key === '=') {
          e.preventDefault();
          const idx = selectedRowIndex >= 0 && selectedRowIndex < draftItems.length ? selectedRowIndex : draftItems.length - 1;
          const target = draftItems[idx];
          if (target) {
            handleUpdateRowQty(target.productId, target.quantity + 1);
          }
          return;
        }
        if (e.key === '-' || e.key === '_') {
          e.preventDefault();
          const idx = selectedRowIndex >= 0 && selectedRowIndex < draftItems.length ? selectedRowIndex : draftItems.length - 1;
          const target = draftItems[idx];
          if (target) {
            handleUpdateRowQty(target.productId, target.quantity - 1);
          }
          return;
        }
      }
    };

    window.addEventListener('keydown', handleShortcuts);
    return () => window.removeEventListener('keydown', handleShortcuts);
  }, [
    draftItems,
    selectedRowIndex,
    paymentMethod,
    isCustomerSearchOpen,
    filteredCustomersForModal,
    highlightedCustIndex,
    isShortcutsHelpOpen,
    isAddCustomerOpen,
    isFormExpanded,
    productSearchCode,
    customerId,
    warehouseId,
    invoiceDate,
    notes,
    vatPercentInput,
    extraInvoiceDiscount,
    paidAmount,
    isPaidManuallyEdited
  ]);

  // Filtered Sales Invoices for Registry Table
  const filteredSales = useMemo(() => {
    return sales.filter(sale => {
      if (methodFilter !== 'all' && sale.paymentMethod !== methodFilter) {
        return false;
      }
      const isCreditDue = sale.grandTotal > sale.paidAmount;
      if (paymentStatusFilter === 'paid' && isCreditDue) return false;
      if (paymentStatusFilter === 'credit_due' && !isCreditDue) return false;

      if (!registrySearch.trim()) return true;
      const q = registrySearch.toLowerCase().trim();
      const matchInv = sale.invoiceNumber.toLowerCase().includes(q);
      const matchCust = (sale.customerName || '').toLowerCase().includes(q);
      const matchNotes = (sale.notes || '').toLowerCase().includes(q);
      const matchItem = sale.items.some(
        i =>
          i.product.name.toLowerCase().includes(q) ||
          i.product.barcode.toLowerCase().includes(q)
      );
      return matchInv || matchCust || matchNotes || matchItem;
    });
  }, [sales, methodFilter, paymentStatusFilter, registrySearch]);

  // Summary KPIs across all sales invoices
  const kpiStats = useMemo(() => {
    let totalRevenue = 0;
    let totalCollected = 0;
    let totalReceivables = 0;

    sales.forEach(s => {
      totalRevenue += s.grandTotal;
      const collected = Math.min(s.grandTotal, s.paidAmount);
      totalCollected += collected;
      if (s.grandTotal > s.paidAmount) {
        totalReceivables += s.grandTotal - s.paidAmount;
      }
    });

    return {
      count: sales.length,
      totalRevenue,
      totalCollected,
      totalReceivables
    };
  }, [sales]);

  const getPaymentBadge = (sale: SaleInvoice) => {
    const unpaid = Math.max(0, sale.grandTotal - sale.paidAmount);
    const matchedPlan = installmentPlans.find(p => p.invoiceNumber === sale.invoiceNumber);
    const isInst = Boolean(sale.hasInstallment || matchedPlan);
    const instCount = sale.installmentCount || matchedPlan?.installmentCount || 0;
    const downPay = sale.downPayment !== undefined ? sale.downPayment : matchedPlan?.downPayment ?? sale.paidAmount;
    const remAmount = sale.remainingInstallmentAmount ?? matchedPlan?.remainingAmount ?? Math.max(0, sale.grandTotal - downPay);
    const monthlyAmt = sale.monthlyInstallmentAmount || (instCount > 0 ? Math.round((remAmount / instCount) * 100) / 100 : 0);

    if (isInst) {
      return (
        <div className="flex flex-col items-center gap-1">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 inline-flex items-center gap-1">
            <Calendar className="w-3 h-3 text-amber-700" />
            {tr(`تقسيط (${instCount} شهر)`, `Installment (${instCount} mo)`)}
          </span>
          <span className="text-[10px] font-bold text-slate-600 tabular-nums">
            {tr(`مقدم: ${formatCurrency(downPay)} | قسط: ${formatCurrency(monthlyAmt)}`, `Down: ${formatCurrency(downPay)} | Mo: ${formatCurrency(monthlyAmt)}`)}
          </span>
        </div>
      );
    }
    if (unpaid > 0 && sale.paidAmount === 0) {
      return (
        <div className="flex flex-col items-center gap-1">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-100 text-red-700 inline-flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {tr('آجل بالكامل', 'Full Credit')}
          </span>
          <span className="text-[10px] font-bold text-red-600 tabular-nums">
            {tr(`مدفوع: 0 | متبقي: ${formatCurrency(unpaid)}`, `Paid: 0 | Due: ${formatCurrency(unpaid)}`)}
          </span>
        </div>
      );
    }
    if (unpaid > 0 && sale.paidAmount > 0) {
      return (
        <div className="flex flex-col items-center gap-1">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 inline-flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            {tr('دفعة مقدمة والباقي آجل', 'Partial / Credit')}
          </span>
          <span className="text-[10px] font-bold text-amber-800 tabular-nums">
            {tr(`مقدم: ${formatCurrency(sale.paidAmount)} | متبقي: ${formatCurrency(unpaid)}`, `Paid: ${formatCurrency(sale.paidAmount)} | Due: ${formatCurrency(unpaid)}`)}
          </span>
        </div>
      );
    }
    if (sale.paymentMethod === 'card') {
      return (
        <div className="flex flex-col items-center gap-1">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-100 text-blue-700 inline-flex items-center gap-1">
            <CreditCard className="w-3 h-3" />
            {tr('شبكة / تحويل بنكي', 'Card / Bank')}
          </span>
          <span className="text-[10px] font-bold text-blue-700 tabular-nums">
            {tr(`مسدد بالكامل: ${formatCurrency(sale.grandTotal)}`, `Paid in Full: ${formatCurrency(sale.grandTotal)}`)}
          </span>
        </div>
      );
    }
    return (
      <div className="flex flex-col items-center gap-1">
        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-700 inline-flex items-center gap-1">
          <Banknote className="w-3 h-3" />
          {tr('نقداً (كاش بالكامل)', 'Cash (Paid)')}
        </span>
        <span className="text-[10px] font-bold text-emerald-700 tabular-nums">
          {tr(`مسدد نقداً: ${formatCurrency(sale.grandTotal)}`, `Paid Cash: ${formatCurrency(sale.grandTotal)}`)}
        </span>
      </div>
    );
  };

  const selectedCustomerObj = customers.find(c => c.id === customerId);

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
                <span>
                  {tr(
                    'شاشة فواتير المبيعات (بيع مباشر غير كاشير)',
                    'Standard Sales Invoices (Non-Cashier Direct Sales)'
                  )}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700">
                  {tr('نظام الفواتير الجدولية B2B', 'Tabular Invoicing')}
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {tr(
                  'إصدار فواتير مبيعات تفصيلية للعملاء والتجار، التحكم في الأسعار والخصومات، البيع النقدي والآجل، وطباعة فواتير A4 رسمية',
                  'Create detailed accounting sales invoices, customize unit prices & discounts, manage credit sales, and print A4/Thermal invoices'
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap w-full lg:w-auto justify-end">
          {/* Active Currency Switcher */}
          <select
            value={activeCurrency?.code || settings.currency || 'EGP'}
            onChange={e => {
              const res = switchActiveCurrency(e.target.value);
              if (res.success) {
                showToast(res.message, 'success');
              }
            }}
            className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-emerald-700"
            title={tr('عملة الفاتورة والتسعير', 'Invoice Currency')}
          >
            {currencies.map(c => (
              <option key={c.code} value={c.code}>
                💱 {tr('عملة البيع:', 'Sale Currency:')} {c.name} ({c.symbol}) — {tr('صرف:', 'Rate:')} {c.exchangeRate}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => {
              if (!isFormExpanded) {
                setIsFormExpanded(true);
              } else {
                resetInvoiceForm();
              }
            }}
            className="neu-button-primary px-4 py-2.5 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{tr('فاتورة مبيعات جديدة', 'New Sales Invoice')}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsFormExpanded(!isFormExpanded)}
            className="neu-button px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer"
          >
            {isFormExpanded ? (
              <>
                <ChevronUp className="w-4 h-4 text-blue-600" />
                <span>{tr('طي نموذج الفاتورة', 'Collapse Form')}</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4 text-blue-600" />
                <span>{tr('فتح نموذج الفاتورة', 'Expand Invoice Form')}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 4 Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="neu-card p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block">
              {tr('إجمالي عدد فواتير المبيعات', 'Total Sales Invoices')}
            </span>
            <span className="text-xl font-black text-slate-800 tabular-nums mt-1 block">
              {kpiStats.count} {tr('فاتورة', 'Invoices')}
            </span>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block">
              {tr('إجمالي قيمة المبيعات الصافية', 'Total Net Sales Revenue')}
            </span>
            <span className="text-lg font-black text-blue-700 tabular-nums mt-1 block">
              {formatCurrency(kpiStats.totalRevenue)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block">
              {tr('إجمالي المبالغ المحصلة', 'Total Collected Amount')}
            </span>
            <span className="text-lg font-black text-emerald-600 tabular-nums mt-1 block">
              {formatCurrency(kpiStats.totalCollected)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block">
              {tr('المتبقي آجل بذمة العملاء', 'Total Customer Credit Due')}
            </span>
            <span className="text-lg font-black text-red-600 tabular-nums mt-1 block">
              {formatCurrency(kpiStats.totalReceivables)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Direct Accounting Sales Invoice Builder (Non-Cashier Workspace) */}
      {isFormExpanded && (
        <div className="neu-card p-5 sm:p-6 rounded-3xl space-y-5 border-2 border-blue-500/20">
          {/* Interactive Keyboard Shortcuts Bar */}
          <div className="flex items-center justify-between gap-2 px-3.5 py-2 rounded-2xl neu-pressed overflow-x-auto no-scrollbar select-none border border-blue-200/60 bg-blue-50/40">
            <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700 shrink-0">
              <Keyboard className="w-4 h-4 text-blue-600 shrink-0" />
              <span>{tr('اختصارات العمل السريع بدون ماوس:', 'Keyboard Shortcuts:')}</span>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => handleSaveInvoice(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold hover:bg-emerald-700 transition-colors cursor-pointer shadow-xs"
                title={tr('إتمام البيع وحفظ وطباعة الفاتورة (F2)', 'Complete Sale & Print (F2)')}
              >
                <kbd className="px-1 bg-black/20 rounded font-mono text-[10px]">F2</kbd>
                <span>{tr('إتمام البيع والطباعة', 'Complete Sale')}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  barcodeSearchInputRef.current?.focus();
                  barcodeSearchInputRef.current?.select();
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-200 text-[11px] font-bold hover:border-blue-400 transition-colors cursor-pointer"
                title={tr('التركيز على حقل الباركود والبحث عن صنف (F3)', 'Focus Barcode / Product Search (F3)')}
              >
                <kbd className="px-1 bg-slate-100 text-blue-700 rounded font-mono text-[10px]">F3</kbd>
                <span>{tr('بحث صنف', 'Find Item')}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCustomerSearchQuery('');
                  setHighlightedCustIndex(0);
                  setIsCustomerSearchOpen(true);
                  setTimeout(() => customerSearchInputRef.current?.focus(), 50);
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-bold hover:bg-blue-700 transition-colors cursor-pointer shadow-xs"
                title={tr('البحث عن عميل واختياره بالأسهم بدون ماوس (F4)', 'Search & Select Customer (F4)')}
              >
                <kbd className="px-1 bg-black/20 rounded font-mono text-[10px]">F4</kbd>
                <span>{tr('بحث عن عميل', 'Find Customer')}</span>
              </button>

              <button
                type="button"
                onClick={handleCyclePaymentMethod}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-200 text-[11px] font-bold hover:border-purple-400 transition-colors cursor-pointer"
                title={tr('تبديل طريقة الدفع: نقداً / شبكة / آجل / جزئي (F6)', 'Cycle Payment Method (F6)')}
              >
                <kbd className="px-1 bg-slate-100 text-purple-700 rounded font-mono text-[10px]">F6</kbd>
                <span>{tr('طريقة الدفع', 'Payment')}</span>
              </button>

              <button
                type="button"
                onClick={handleDeleteSelectedRow}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-600 text-white text-[11px] font-bold hover:bg-red-700 transition-colors cursor-pointer shadow-xs"
                title={tr('حذف المنتج المحدد أو الأخير من الفاتورة (F8)', 'Delete Selected / Last Product (F8)')}
              >
                <kbd className="px-1 bg-black/20 rounded font-mono text-[10px]">F8</kbd>
                <span>{tr('حذف منتج', 'Delete Item')}</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveInvoice(false)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-200 text-[11px] font-bold hover:border-indigo-400 transition-colors cursor-pointer"
                title={tr('حفظ الفاتورة بدون طباعة (F9)', 'Save Invoice Only (F9)')}
              >
                <kbd className="px-1 bg-slate-100 text-indigo-700 rounded font-mono text-[10px]">F9</kbd>
                <span>{tr('حفظ فقط', 'Save Only')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsShortcutsHelpOpen(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-white text-[11px] font-bold hover:bg-slate-700 transition-colors cursor-pointer"
                title={tr('عرض دليل جميع اختصارات لوحة المفاتيح (F1)', 'Show All Keyboard Shortcuts (F1)')}
              >
                <kbd className="px-1 bg-white/20 rounded font-mono text-[10px]">F1</kbd>
                <span>{tr('كل الاختصارات', 'All Keys')}</span>
              </button>
            </div>
          </div>

          {/* Builder Title Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
              <h3 className="font-extrabold text-slate-800 text-sm sm:text-base">
                {editingSale
                  ? tr(
                      `تعديل فاتورة المبيعات رقم: #${editingSale.invoiceNumber}`,
                      `Editing Sales Invoice: #${editingSale.invoiceNumber}`
                    )
                  : tr(
                      'إصدار فاتورة مبيعات جديدة (نموذج بيع محاسبي جدولي)',
                      'Create New Sales Invoice (Accounting Tabular Form)'
                    )}
              </h3>
            </div>

            {editingSale && (
              <button
                type="button"
                onClick={resetInvoiceForm}
                className="neu-button px-3 py-1.5 rounded-xl text-xs font-bold text-red-600 flex items-center gap-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>{tr('إلغاء التعديل وبدء فاتورة جديدة', 'Cancel Edit & Start New')}</span>
              </button>
            )}
          </div>

          {/* 1. Invoice Metadata Row: Customer, Warehouse, Date, Payment Method */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Customer Select + Quick Search (F4) + Quick Add */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <span>{tr('العميل / المشتري:', 'Customer / Buyer:')}</span>
                  <kbd className="px-1 py-0.2 rounded bg-blue-100 text-blue-700 font-mono text-[10px]">F4</kbd>
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCustomerSearchQuery('');
                      setHighlightedCustIndex(0);
                      setIsCustomerSearchOpen(true);
                      setTimeout(() => customerSearchInputRef.current?.focus(), 50);
                    }}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 cursor-pointer"
                    title={tr('بحث سريع عن عميل بالاسم أو الهاتف (F4)', 'Quick search customer (F4)')}
                  >
                    <Search className="w-3 h-3" />
                    <span>{tr('بحث (F4)', 'Search (F4)')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddCustomerOpen(true)}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer"
                  >
                    <UserPlus className="w-3 h-3" />
                    <span>{tr('+ جديد', '+ New')}</span>
                  </button>
                </div>
              </div>
              <select
                value={customerId}
                onChange={e => setCustomerId(e.target.value)}
                className="neu-input w-full px-3 py-2.5 rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="">
                  {tr('👤 عميل نقدي عام (مبيعات مباشرة)', '👤 Walk-in Cash Customer')}
                </option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.phone}) — {tr('الرصيد:', 'Bal:')} {formatCurrency(c.balance)}
                  </option>
                ))}
              </select>
              {selectedCustomerObj && (
                <div className="mt-1.5 flex items-center justify-between text-[11px] px-2 py-1 rounded-lg bg-blue-50/80 text-blue-800 font-semibold">
                  <span>
                    {tr('هاتف:', 'Phone:')} {selectedCustomerObj.phone}
                  </span>
                  <span>
                    {tr('مديونية سابقة:', 'Prior Debt:')}{' '}
                    <strong className={selectedCustomerObj.balance > 0 ? 'text-red-600' : 'text-emerald-600'}>
                      {formatCurrency(selectedCustomerObj.balance)}
                    </strong>
                  </span>
                </div>
              )}
            </div>

            {/* Warehouse Select */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                <Building2 className="w-3.5 h-3.5 inline mx-1 text-blue-600" />
                {tr('المستودع المنصرف منه:', 'Source Warehouse:')}
              </label>
              <select
                value={warehouseId}
                onChange={e => setWarehouseId(e.target.value)}
                className="neu-input w-full px-3 py-2.5 rounded-xl text-xs font-bold text-slate-800"
              >
                {warehouses.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.name} ({w.code}) {w.isDefault ? tr('— افتراضي', '— Default') : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Invoice Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                <Calendar className="w-3.5 h-3.5 inline mx-1 text-blue-600" />
                {tr('تاريخ الفاتورة:', 'Invoice Date:')}
              </label>
              <input
                type="date"
                value={invoiceDate}
                onChange={e => setInvoiceDate(e.target.value)}
                className="neu-input w-full px-3 py-2.5 rounded-xl text-xs font-bold text-slate-800 tabular-nums"
              />
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                <CreditCard className="w-3.5 h-3.5 inline mx-1 text-blue-600" />
                {tr('طريقة الدفع ونظام السداد (F6):', 'Payment System & Method (F6):')}
              </label>
              <select
                value={enableInstallments ? 'installment' : paymentMethod}
                onChange={e => {
                  const val = e.target.value;
                  if (val === 'installment') {
                    setEnableInstallments(true);
                    setPaymentMethod('split');
                    if (!isPaidManuallyEdited || paidAmount >= invoiceCalculations.grandTotal) {
                      setPaidAmount(0);
                      setIsPaidManuallyEdited(true);
                    }
                  } else {
                    const nextMethod = val as PaymentMethod;
                    setEnableInstallments(false);
                    setPaymentMethod(nextMethod);
                    if (nextMethod === 'credit') {
                      setPaidAmount(0);
                      setIsPaidManuallyEdited(true);
                    } else if (nextMethod === 'split') {
                      if (!isPaidManuallyEdited || paidAmount >= invoiceCalculations.grandTotal) {
                        setPaidAmount(Number((invoiceCalculations.grandTotal / 2).toFixed(2)));
                        setIsPaidManuallyEdited(true);
                      }
                    } else if (nextMethod === 'cash' || nextMethod === 'card') {
                      setIsPaidManuallyEdited(false);
                    }
                  }
                }}
                className="neu-input w-full px-3 py-2.5 rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="cash">{tr('💵 نقداً (كاش بالكامل)', '💵 Cash (Full Payment)')}</option>
                <option value="card">{tr('💳 شبكة / تحويل بنكي', '💳 Card / Bank Transfer')}</option>
                <option value="credit">{tr('📒 آجل بالكامل (على حساب العميل)', '📒 Full Credit (On Customer Account)')}</option>
                <option value="split">{tr('⚖️ دفعة مقدمة والباقي آجل', '⚖️ Down Payment & Remaining Credit')}</option>
                <option value="installment">{tr('📅 تقسيط شهري (مقدم + أقساط 3 أو 12 شهر)', '📅 Monthly Installments (Down Payment + Installments)')}</option>
              </select>
            </div>
          </div>

          {/* 2. Tabular Line-Item Entry Bar (Non-Cashier Style) */}
          <div className="neu-flat p-4 rounded-2xl space-y-3 border border-white/70">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                <Package className="w-4 h-4 text-blue-600" />
                <span>
                  {tr(
                    'إدراج الأصناف في جدول الفاتورة (بحث بالاسم أو الباركود - F3):',
                    'Insert Items into Invoice Table (Search by Name or Barcode - F3):'
                  )}
                </span>
              </span>

              <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={updateDefaultSalePrice}
                  onChange={e => setUpdateDefaultSalePrice(e.target.checked)}
                  className="w-3.5 h-3.5 text-blue-600 rounded"
                />
                <span>
                  {tr(
                    'تحديث سعر البيع الافتراضي للصنف في المخزون عند تغييره هنا',
                    'Update product default sale price in inventory if changed here'
                  )}
                </span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
              {/* Quick Barcode / Search Filter + Mobile Camera Scanner */}
              <div className="sm:col-span-3">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  {tr('بحث سريع / قارئ باركود أو موبايل (F3):', 'Barcode / Mobile Scan (F3):')}
                </label>
                <div className="flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute top-1/2 -translate-y-1/2 right-2.5 pointer-events-none" />
                    <input
                      ref={barcodeSearchInputRef}
                      type="text"
                      value={productSearchCode}
                      onChange={e => setProductSearchCode(e.target.value)}
                      onKeyDown={handleBarcodeSearchKeyDown}
                      placeholder={tr('امسح الباركود أو اكتب الاسم...', 'Scan barcode or type...')}
                      className="neu-input w-full pr-8 pl-2.5 py-2 rounded-xl text-xs font-semibold"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsMobileScannerOpen(true)}
                    className="px-2.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                    title={tr('مسح الباركود بكاميرا الموبايل وإدراجه مباشرة في جدول الفاتورة', 'Scan barcode with mobile camera directly into invoice table')}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <Camera className="w-3.5 h-3.5 hidden xl:inline" />
                    <span>{tr('بالموبايل', 'Scan')}</span>
                  </button>
                </div>
              </div>

              {/* Product Dropdown Selector */}
              <div className="sm:col-span-4">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  {tr('اختر الصنف من القائمة:', 'Select Product:')}
                </label>
                <select
                  value={selectedProductId}
                  onChange={e => handleSelectProduct(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs font-bold text-slate-800"
                >
                  <option value="">
                    {tr(
                      `-- اختر الصنف (${filteredProductsForSelect.length} متاح) --`,
                      `-- Select Product (${filteredProductsForSelect.length} items) --`
                    )}
                  </option>
                  {filteredProductsForSelect.map(p => {
                    const whQty = getProductWarehouseStock(p, warehouseId);
                    return (
                      <option key={p.id} value={p.id}>
                        {p.name} | {tr('المتاح:', 'Avail:')} {whQty} {p.unit} | {formatCurrency(p.salePrice)}
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Quantity */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  {tr('الكمية (▲/▼):', 'Qty (▲/▼):')}
                </label>
                <NumberStepperInput
                  min={1}
                  step={1}
                  fallbackOnBlur={1}
                  value={entryQty}
                  onChange={(val) => setEntryQty(Math.max(1, Math.round(val)))}
                  className="w-full bg-white"
                  inputClassName="font-black text-center text-slate-800"
                />
              </div>

              {/* Unit Sale Price */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  {tr('سعر الوحدة:', 'Unit Price:')}
                </label>
                <NumberStepperInput
                  min={0}
                  step={1}
                  value={entryPrice}
                  onChange={(val) => setEntryPrice(val)}
                  className="w-full bg-white"
                  inputClassName="font-black text-center text-blue-700"
                />
              </div>

              {/* Item Discount */}
              <div className="sm:col-span-1">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  {tr('خصم:', 'Disc:')}
                </label>
                <NumberStepperInput
                  min={0}
                  step={1}
                  value={entryDiscount}
                  onChange={(val) => setEntryDiscount(val)}
                  className="w-full bg-white"
                  inputClassName="font-bold text-center text-amber-700"
                />
              </div>

              {/* Insert Button */}
              <div className="sm:col-span-12 lg:col-span-12 flex justify-end pt-1">
                <button
                  type="button"
                  onClick={handleAddLineFromBar}
                  className="neu-button-primary py-2 px-5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  title={tr('إدراج الصنف في جدول الفاتورة', 'Insert item into invoice table')}
                >
                  <Plus className="w-4 h-4" />
                  <span>{tr('إدراج الصنف في جدول الفاتورة', 'Add Item to Invoice Table')}</span>
                </button>
              </div>
            </div>
          </div>

          {/* 3. Invoice Line Items Table (Editable Rows) */}
          <div className="border border-slate-200/90 rounded-2xl overflow-hidden bg-white/50">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-100/90 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3 w-10 text-center">#</th>
                    <th className="py-3 px-3">{tr('الباركود', 'Barcode')}</th>
                    <th className="py-3 px-3">{tr('اسم الصنف والوحدة', 'Product & Unit')}</th>
                    <th className="py-3 px-3 text-center">{tr('المتاح بالمستودع', 'Warehouse Stock')}</th>
                    <th className="py-3 px-3 text-center w-28">{tr('الكمية', 'Quantity')}</th>
                    <th className="py-3 px-3 text-center w-32">{tr('سعر الوحدة', 'Unit Price')}</th>
                    <th className="py-3 px-3 text-center w-28">{tr('خصم البند', 'Line Discount')}</th>
                    <th className="py-3 px-3 text-left">{tr('صافي الإجمالي', 'Net Total')}</th>
                    <th className="py-3 px-3 text-center w-14">{tr('حذف', 'Remove')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {draftItems.map((item, idx) => {
                    const whStock = getProductWarehouseStock(item.product, warehouseId);
                    const lineNet = Math.max(0, item.unitPrice * item.quantity - item.discount);
                    const isSelectedRow =
                      (selectedRowIndex >= 0 ? selectedRowIndex : draftItems.length - 1) === idx;
                    return (
                      <tr
                        key={item.productId}
                        onClick={() => setSelectedRowIndex(idx)}
                        className={`transition-colors cursor-pointer ${
                          isSelectedRow ? 'bg-blue-50/70' : 'hover:bg-blue-50/30'
                        }`}
                      >
                        <td className="py-2.5 px-3 text-center font-bold text-slate-400 tabular-nums">
                          {idx + 1}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[11px] font-semibold text-slate-500">
                          {item.product.barcode}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-800">{item.product.name}</span>
                            {isSelectedRow && (
                              <span className="px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 font-mono text-[9px] font-bold">
                                {tr('محدد • F8 حذف', 'Selected • F8')}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {tr('الوحدة:', 'Unit:')} {item.product.unit} | {tr('التصنيف:', 'Category:')} {item.product.category}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-bold tabular-nums">
                            {whStock} {item.product.unit}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <NumberStepperInput
                            size="sm"
                            min={1}
                            max={whStock}
                            step={1}
                            fallbackOnBlur={1}
                            value={item.quantity}
                            onChange={(val) => {
                              if (val >= 1) {
                                handleUpdateRowQty(item.productId, Math.round(val));
                              }
                            }}
                            className="w-24 bg-white"
                            inputClassName="text-center font-black text-slate-800"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <NumberStepperInput
                            size="sm"
                            min={0}
                            step={1}
                            value={item.unitPrice}
                            onChange={(val) => handleUpdateRowPrice(item.productId, val)}
                            className="w-28 bg-white"
                            inputClassName="text-center font-bold text-blue-700"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <NumberStepperInput
                            size="sm"
                            min={0}
                            step={1}
                            value={item.discount}
                            onChange={(val) => handleUpdateRowDiscount(item.productId, val)}
                            className="w-24 bg-white"
                            inputClassName="text-center font-bold text-amber-700"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-left font-black text-slate-900 tabular-nums">
                          {formatCurrency(lineNet)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveRow(item.productId);
                            }}
                            className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 cursor-pointer"
                            title={tr('حذف البند من الفاتورة (F8)', 'Remove row (F8)')}
                          >
                            <Trash2 className="w-4 h-4 mx-auto" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {draftItems.length === 0 && (
                <div className="py-10 text-center text-xs text-slate-400 space-y-1">
                  <FileSpreadsheet className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                  <p className="font-bold text-slate-500">
                    {tr(
                      'جدول الفاتورة فارغ حالياً — اختر الأصناف من الشريط أعلاه أو امسح الباركود لإضافتها (F3 للبحث، F4 للعميل، F2 لإتمام البيع)',
                      'Invoice table is empty — select products above or press F3 to search, F4 for customer, F2 to complete sale'
                    )}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* 4. Financial Summary, Tax/Discount Controls, Paid/Remaining & Save Buttons */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-2">
            {/* Left Side: Notes, VAT Field & Extra Discount */}
            <div className="lg:col-span-6 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="neu-flat p-3 rounded-2xl flex items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">
                      {tr('الضريبة المضافة (%):', 'VAT (%):')}
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold block">
                      {tr('طالما هي 0 لا تُحسب أي ضريبة', '0 = No tax calculated')}
                    </span>
                  </div>
                  <NumberStepperInput
                    size="sm"
                    min={0}
                    max={100}
                    step={1}
                    value={vatPercentInput}
                    onChange={(val) => setVatPercentInput(Math.max(0, Number(val) || 0))}
                    placeholder="0"
                    className="w-28 bg-white"
                    inputClassName="text-center font-bold text-blue-700"
                  />
                </div>

                <div className="neu-flat p-3 rounded-2xl flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-700">
                    {tr('خصم إضافي (F7):', 'Extra Discount (F7):')}
                  </span>
                  <NumberStepperInput
                    size="sm"
                    min={0}
                    step={1}
                    inputRef={extraDiscountInputRef}
                    value={extraInvoiceDiscount}
                    onChange={(val) => setExtraInvoiceDiscount(Math.max(0, val))}
                    className="w-28 bg-white"
                    inputClassName="text-center font-bold text-amber-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {tr('ملاحظات الفاتورة / شروط التسليم والتوريد:', 'Invoice Notes / Delivery & Payment Terms:')}
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder={tr(
                    'اكتب أي ملاحظات تظهر في الفاتورة المطبوعة (مثل: رقم أمر التوريد، عنوان التسليم، شروط الضمان)...',
                    'Enter any notes or terms to print on the invoice (e.g., PO number, delivery address, warranty)...'
                  )}
                  className="neu-input w-full p-3 rounded-2xl text-xs font-medium"
                />
              </div>
            </div>

            {/* Right Side: Totals & Settlement Box */}
            <div className="lg:col-span-6 neu-flat p-4 sm:p-5 rounded-2xl space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-600 font-semibold">
                <span>{tr('إجمالي الأصناف (قبل الخصم):', 'Gross Items Subtotal:')}</span>
                <span className="tabular-nums font-bold">{formatCurrency(invoiceCalculations.grossSubtotal)}</span>
              </div>

              <div className="flex justify-between text-amber-700 font-semibold">
                <span>{tr('إجمالي الخصومات الممنوحة:', 'Total Discounts:')}</span>
                <span className="tabular-nums font-bold">- {formatCurrency(invoiceCalculations.totalDiscount)}</span>
              </div>

              <div className="flex justify-between text-slate-600 font-semibold">
                <span>
                  {invoiceCalculations.vatPercent > 0
                    ? tr(
                        `ضريبة القيمة المضافة (${invoiceCalculations.vatPercent}%):`,
                        `VAT (${invoiceCalculations.vatPercent}%):`
                      )
                    : tr('ضريبة القيمة المضافة (0% — بدون ضريبة):', 'VAT (0% — No Tax):')}
                </span>
                <span className={`tabular-nums font-bold ${invoiceCalculations.taxTotal > 0 ? 'text-blue-700' : 'text-slate-400'}`}>
                  {invoiceCalculations.taxTotal > 0 ? `+ ${formatCurrency(invoiceCalculations.taxTotal)}` : formatCurrency(0)}
                </span>
              </div>

              <div className="flex justify-between items-center pt-2.5 border-t border-slate-200/90 text-sm sm:text-base font-black text-slate-900">
                <span>{tr('الصافي النهائي للفاتورة:', 'Invoice Grand Total:')}</span>
                <span className="tabular-nums text-blue-700 text-lg">
                  {formatCurrency(invoiceCalculations.grandTotal)}
                </span>
              </div>

              {/* Paid Amount Input + Quick Presets */}
              <div className="pt-2.5 border-t border-slate-200/90 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-bold text-slate-700">
                    {enableInstallments || paymentMethod === 'split'
                      ? tr('الدفعة المقدمة (المبلغ المسدد الآن):', 'Down Payment (Paid Now):')
                      : tr('المبلغ المسدد (المدفوع فعلياً):', 'Paid Amount:')}
                  </span>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      type="button"
                      onClick={() => {
                        setEnableInstallments(false);
                        setPaidAmount(invoiceCalculations.grandTotal);
                        setIsPaidManuallyEdited(false);
                        if (paymentMethod === 'credit' || paymentMethod === 'split') setPaymentMethod('cash');
                      }}
                      className="px-2 py-1 rounded-lg bg-emerald-100 text-emerald-700 text-[10px] font-bold hover:bg-emerald-200 cursor-pointer"
                    >
                      {tr('سداد كامل', 'Full Pay')}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEnableInstallments(false);
                        setPaidAmount(Number((invoiceCalculations.grandTotal / 2).toFixed(2)));
                        setIsPaidManuallyEdited(true);
                        setPaymentMethod('split');
                      }}
                      className="px-2 py-1 rounded-lg bg-blue-100 text-blue-700 text-[10px] font-bold hover:bg-blue-200 cursor-pointer"
                    >
                      {tr('نصف المبلغ (دفعة مقدمة)', '50% Down Payment')}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEnableInstallments(false);
                        setPaidAmount(0);
                        setIsPaidManuallyEdited(true);
                        setPaymentMethod('credit');
                      }}
                      className="px-2 py-1 rounded-lg bg-red-100 text-red-700 text-[10px] font-bold hover:bg-red-200 cursor-pointer"
                    >
                      {tr('آجل بالكامل (0)', 'Full Credit (0)')}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEnableInstallments(true);
                        setPaymentMethod('split');
                        if (!isPaidManuallyEdited || paidAmount >= invoiceCalculations.grandTotal) {
                          setPaidAmount(0);
                          setIsPaidManuallyEdited(true);
                        }
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer ${
                        enableInstallments
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                      }`}
                    >
                      {tr('📅 تقسيط شهري', '📅 Installments')}
                    </button>

                    <NumberStepperInput
                      size="sm"
                      min={0}
                      step={10}
                      value={effectivePaidAmount}
                      onChange={(val) => {
                        setPaidAmount(Math.max(0, val));
                        setIsPaidManuallyEdited(true);
                      }}
                      className="w-32 bg-white"
                      inputClassName="text-center font-black text-emerald-700"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center font-bold">
                  <span className="text-slate-600">
                    {enableInstallments
                      ? tr('المتبقي للتقسيط على العميل:', 'Remaining Balance for Installments:')
                      : tr('المتبقي آجل (يُسجل في ذمة العميل):', 'Remaining Credit (Added to Customer Balance):')}
                  </span>
                  <span
                    className={`tabular-nums text-sm font-black ${
                      remainingDebt > 0 ? 'text-red-600' : 'text-emerald-600'
                    }`}
                  >
                    {formatCurrency(remainingDebt)}
                  </span>
                </div>

                {/* Installment Toggle when remainingDebt > 0 or already enabled */}
                {(remainingDebt > 0 || enableInstallments) && (
                  <div className="pt-1.5 border-t border-slate-200/80">
                    <label className="flex items-center justify-between cursor-pointer bg-amber-50/90 border border-amber-200 px-3 py-2 rounded-xl">
                      <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-amber-600" />
                        <span>
                          {tr(
                            'تفعيل نظام التقسيط الشهري (إظهار الدفعة المقدمة وعدد الأقساط 3 أو 12 شهر في الفاتورة)',
                            'Enable Monthly Installment Plan (Show Down Payment & Installments on Invoice)'
                          )}
                        </span>
                      </span>
                      <input
                        type="checkbox"
                        checked={enableInstallments}
                        onChange={e => setEnableInstallments(e.target.checked)}
                        className="w-4 h-4 accent-amber-600 rounded cursor-pointer"
                      />
                    </label>
                  </div>
                )}

                {/* Unified Live Payment System Breakdown Card (Appears for ALL Payment Systems just like Installments) */}
                <div className="pt-1.5">
                  {enableInstallments ? (
                    <div className="p-3.5 rounded-2xl bg-amber-50/80 border-2 border-amber-300 space-y-2.5 text-xs shadow-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-amber-200">
                        <span className="font-black text-amber-900 flex items-center gap-1.5 text-xs">
                          <Calendar className="w-4 h-4 text-amber-600" />
                          {tr(
                            `تفصيل نظام السداد في الفاتورة: تقسيط شهري (دفعة مقدمة والباقي على ${installmentCount} قسط)`,
                            `Invoice Payment Breakdown: Monthly Installments (${installmentCount} Months)`
                          )}
                        </span>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {[3, 6, 12, 24].map(m => (
                            <button
                              key={m}
                              type="button"
                              onClick={() => setInstallmentCount(m)}
                              className={`px-2.5 py-1 rounded-lg font-extrabold text-[11px] cursor-pointer transition-colors ${
                                installmentCount === m
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'bg-white text-slate-700 border border-amber-300 hover:bg-amber-100'
                              }`}
                            >
                              {m} {tr('شهور', 'Months')}
                            </button>
                          ))}
                          <select
                            value={installmentCount}
                            onChange={e => setInstallmentCount(Number(e.target.value))}
                            className="neu-input px-2.5 py-1 rounded-lg text-xs font-bold text-slate-800 bg-white"
                          >
                            {[2, 3, 4, 6, 9, 10, 12, 18, 24, 36].map(n => (
                              <option key={n} value={n}>
                                {n} {tr('قسط شهري', 'Installments')}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div className="bg-white p-2 rounded-xl border border-amber-200 text-center">
                          <span className="text-[10px] text-slate-500 block">
                            {tr('إجمالي الفاتورة', 'Invoice Total')}
                          </span>
                          <span className="font-black text-slate-800 text-xs tabular-nums">
                            {formatCurrency(invoiceCalculations.grandTotal)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-amber-200 text-center">
                          <span className="text-[10px] text-slate-500 block">
                            {tr('الدفعة المقدمة (المقدم)', 'Down Payment')}
                          </span>
                          <span className="font-black text-emerald-700 text-xs tabular-nums">
                            {formatCurrency(effectivePaidAmount)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-amber-200 text-center">
                          <span className="text-[10px] text-slate-500 block">
                            {tr('المتبقي للتقسيط', 'Remaining to Install')}
                          </span>
                          <span className="font-black text-red-600 text-xs tabular-nums">
                            {formatCurrency(remainingDebt)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-amber-200 text-center">
                          <span className="text-[10px] text-slate-500 block">
                            {tr(`قيمة القسط (${installmentCount} شهر)`, `Monthly (${installmentCount} mo)`)}
                          </span>
                          <span className="font-black text-blue-700 text-xs tabular-nums">
                            {formatCurrency(
                              installmentCount > 0
                                ? Math.round((remainingDebt / installmentCount) * 100) / 100
                                : 0
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="bg-amber-100/80 px-3 py-1.5 rounded-lg text-[11px] font-bold text-amber-950 text-center">
                        {tr(
                          `سيُطبع في الفاتورة: تم دفع مقدم (${formatCurrency(effectivePaidAmount)}) والباقي (${formatCurrency(remainingDebt)}) مقسط على (${installmentCount}) أقساط شهرية بقيمة (${formatCurrency(installmentCount > 0 ? Math.round((remainingDebt / installmentCount) * 100) / 100 : 0)}) لكل قسط`,
                          `Printed on Invoice: Paid down payment (${formatCurrency(effectivePaidAmount)}) and remaining (${formatCurrency(remainingDebt)}) in (${installmentCount}) monthly installments of (${formatCurrency(installmentCount > 0 ? Math.round((remainingDebt / installmentCount) * 100) / 100 : 0)})`
                        )}
                      </div>
                    </div>
                  ) : remainingDebt > 0 && effectivePaidAmount > 0 ? (
                    <div className="p-3.5 rounded-2xl bg-orange-50/80 border-2 border-orange-300 space-y-2.5 text-xs shadow-xs">
                      <div className="flex items-center justify-between pb-1.5 border-b border-orange-200">
                        <span className="font-black text-orange-900 flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-orange-600" />
                          {tr(
                            'تفصيل نظام السداد في الفاتورة: دفعة مقدمة والباقي آجل (سداد جزئي)',
                            'Invoice Payment Breakdown: Down Payment & Remaining Credit'
                          )}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="bg-white p-2 rounded-xl border border-orange-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('إجمالي الفاتورة', 'Invoice Total')}</span>
                          <span className="font-black text-slate-800 text-xs tabular-nums">{formatCurrency(invoiceCalculations.grandTotal)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-orange-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('الدفعة المقدمة (المدفوع)', 'Paid Down Payment')}</span>
                          <span className="font-black text-emerald-700 text-xs tabular-nums">{formatCurrency(effectivePaidAmount)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-orange-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المبلغ المتبقي (آجل بذمة العميل)', 'Remaining Credit Due')}</span>
                          <span className="font-black text-red-600 text-xs tabular-nums">{formatCurrency(remainingDebt)}</span>
                        </div>
                      </div>
                      <div className="bg-orange-100/80 px-3 py-1.5 rounded-lg text-[11px] font-bold text-orange-950 text-center">
                        {tr(
                          `سيُطبع في الفاتورة: تم سداد دفعة مقدمة (${formatCurrency(effectivePaidAmount)}) والمتبقي آجل على حساب العميل (${formatCurrency(remainingDebt)})`,
                          `Printed on Invoice: Paid down payment (${formatCurrency(effectivePaidAmount)}) and remaining credit balance (${formatCurrency(remainingDebt)})`
                        )}
                      </div>
                    </div>
                  ) : remainingDebt > 0 && effectivePaidAmount === 0 ? (
                    <div className="p-3.5 rounded-2xl bg-red-50/80 border-2 border-red-300 space-y-2.5 text-xs shadow-xs">
                      <div className="flex items-center justify-between pb-1.5 border-b border-red-200">
                        <span className="font-black text-red-900 flex items-center gap-1.5">
                          <Clock className="w-4 h-4 text-red-600" />
                          {tr(
                            'تفصيل نظام السداد في الفاتورة: بيع آجل بالكامل (على حساب العميل)',
                            'Invoice Payment Breakdown: Full Credit Sale (On Customer Account)'
                          )}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="bg-white p-2 rounded-xl border border-red-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('إجمالي الفاتورة', 'Invoice Total')}</span>
                          <span className="font-black text-slate-800 text-xs tabular-nums">{formatCurrency(invoiceCalculations.grandTotal)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-red-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المبلغ المدفوع عند الإصدار', 'Paid Now')}</span>
                          <span className="font-black text-slate-600 text-xs tabular-nums">{formatCurrency(0)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-red-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('إجمالي المديونية الآجلة', 'Full Credit Balance')}</span>
                          <span className="font-black text-red-600 text-xs tabular-nums">{formatCurrency(remainingDebt)}</span>
                        </div>
                      </div>
                      <div className="bg-red-100/80 px-3 py-1.5 rounded-lg text-[11px] font-bold text-red-950 text-center">
                        {tr(
                          `سيُطبع في الفاتورة: فاتورة بيع آجل بالكامل — كامل المبلغ (${formatCurrency(remainingDebt)}) مقيد في ذمة العميل`,
                          `Printed on Invoice: Full credit invoice — entire balance (${formatCurrency(remainingDebt)}) recorded on customer account`
                        )}
                      </div>
                    </div>
                  ) : paymentMethod === 'card' ? (
                    <div className="p-3.5 rounded-2xl bg-blue-50/80 border-2 border-blue-300 space-y-2.5 text-xs shadow-xs">
                      <div className="flex items-center justify-between pb-1.5 border-b border-blue-200">
                        <span className="font-black text-blue-900 flex items-center gap-1.5">
                          <CreditCard className="w-4 h-4 text-blue-600" />
                          {tr(
                            'تفصيل نظام السداد في الفاتورة: سداد عبر بطاقة شبكة / تحويل بنكي',
                            'Invoice Payment Breakdown: Card / Bank Transfer Payment'
                          )}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="bg-white p-2 rounded-xl border border-blue-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('إجمالي الفاتورة', 'Invoice Total')}</span>
                          <span className="font-black text-slate-800 text-xs tabular-nums">{formatCurrency(invoiceCalculations.grandTotal)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-blue-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المسدد عبر الشبكة / البنك', 'Paid via Card / Bank')}</span>
                          <span className="font-black text-blue-700 text-xs tabular-nums">{formatCurrency(effectivePaidAmount)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-blue-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المتبقي على العميل', 'Remaining Balance')}</span>
                          <span className="font-black text-emerald-700 text-xs tabular-nums">{formatCurrency(0)}</span>
                        </div>
                      </div>
                      <div className="bg-blue-100/80 px-3 py-1.5 rounded-lg text-[11px] font-bold text-blue-950 text-center">
                        {tr(
                          `سيُطبع في الفاتورة: الفاتورة مسددة بالكامل عبر الشبكة / التحويل البنكي (${formatCurrency(invoiceCalculations.grandTotal)}) ولا يوجد متبقي`,
                          `Printed on Invoice: Paid in full via Card / Bank Transfer (${formatCurrency(invoiceCalculations.grandTotal)}) with zero balance due`
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-2xl bg-emerald-50/80 border-2 border-emerald-300 space-y-2.5 text-xs shadow-xs">
                      <div className="flex items-center justify-between pb-1.5 border-b border-emerald-200">
                        <span className="font-black text-emerald-900 flex items-center gap-1.5">
                          <Banknote className="w-4 h-4 text-emerald-600" />
                          {tr(
                            'تفصيل نظام السداد في الفاتورة: سداد نقدي بالكامل (كاش)',
                            'Invoice Payment Breakdown: Full Cash Payment'
                          )}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="bg-white p-2 rounded-xl border border-emerald-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('إجمالي الفاتورة', 'Invoice Total')}</span>
                          <span className="font-black text-slate-800 text-xs tabular-nums">{formatCurrency(invoiceCalculations.grandTotal)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-emerald-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المبلغ المسدد نقداً (كاش)', 'Cash Paid')}</span>
                          <span className="font-black text-emerald-700 text-xs tabular-nums">{formatCurrency(effectivePaidAmount)}</span>
                        </div>
                        <div className="bg-white p-2 rounded-xl border border-emerald-200 text-center">
                          <span className="text-[10px] text-slate-500 block">{tr('المتبقي على العميل', 'Remaining Balance')}</span>
                          <span className="font-black text-emerald-700 text-xs tabular-nums">{formatCurrency(0)}</span>
                        </div>
                      </div>
                      <div className="bg-emerald-100/80 px-3 py-1.5 rounded-lg text-[11px] font-bold text-emerald-950 text-center">
                        {tr(
                          `سيُطبع في الفاتورة: الفاتورة مسددة نقداً بالكامل (${formatCurrency(invoiceCalculations.grandTotal)}) ولا يوجد أي مبالغ متبقية`,
                          `Printed on Invoice: Paid in full in Cash (${formatCurrency(invoiceCalculations.grandTotal)}) with zero remaining balance`
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-200/90 flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={resetInvoiceForm}
                  className="neu-button px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-600 flex items-center gap-1.5 cursor-pointer"
                  title={tr('تفريغ النموذج (F10)', 'Reset Form (F10)')}
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{tr('تفريغ النموذج', 'Reset Form')}</span>
                  <kbd className="px-1.5 py-0.5 rounded bg-slate-200/80 text-slate-600 font-mono text-[10px]">F10</kbd>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveInvoice(false)}
                  className="neu-button px-4 py-2.5 rounded-xl text-xs font-extrabold text-blue-700 flex items-center gap-1.5 cursor-pointer"
                  title={tr('حفظ وإصدار الفاتورة بدون طباعة (F9)', 'Save Invoice Only (F9)')}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {editingSale
                      ? tr('حفظ التعديلات فقط', 'Save Changes Only')
                      : tr('حفظ وإصدار الفاتورة', 'Save Invoice')}
                  </span>
                  <kbd className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-mono text-[10px]">F9</kbd>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveInvoice(true)}
                  className="neu-button-primary px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 cursor-pointer shadow-md"
                  title={tr('إتمام البيع وحفظ وطباعة الفاتورة (F2)', 'Complete Sale & Print Invoice (F2)')}
                >
                  <Printer className="w-4 h-4" />
                  <span>
                    {editingSale
                      ? tr('حفظ التعديلات وطباعة الفاتورة', 'Update & Print Invoice')
                      : tr('حفظ وطباعة فاتورة (A4 / إيصال)', 'Save & Print Invoice (A4 / Receipt)')}
                  </span>
                  <kbd className="px-2 py-0.5 rounded-lg bg-white/25 text-white font-mono text-[11px] font-black">
                    F2
                  </kbd>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sales Invoices Registry & History Table */}
      <div className="neu-card p-5 sm:p-6 rounded-3xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <h3 className="font-extrabold text-slate-800 text-sm sm:text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <span>
                {tr(
                  `سجل فواتير المبيعات الصادرة (${filteredSales.length})`,
                  `Issued Sales Invoices Registry (${filteredSales.length})`
                )}
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {tr(
                'يمكنك البحث في الفواتير، طباعتها بصيغة A4 رسمية أو إيصال حراري، أو تعديلها وحذفها مع تسوية المخزون تلقائياً',
                'Search, print (A4 or thermal), edit, or delete sales invoices with automatic stock & customer ledger reconciliation'
              )}
            </p>
          </div>

          {/* Search & Filters */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
              <input
                type="text"
                value={registrySearch}
                onChange={e => setRegistrySearch(e.target.value)}
                placeholder={tr('بحث برقم الفاتورة، اسم العميل، الصنف...', 'Search invoice #, customer, item...')}
                className="neu-input w-full pr-8 pl-3 py-2 rounded-xl text-xs font-semibold"
              />
            </div>

            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={paymentStatusFilter}
                onChange={e => setPaymentStatusFilter(e.target.value as 'all' | 'paid' | 'credit_due')}
                className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-slate-700"
              >
                <option value="all">{tr('كل حالات السداد', 'All Statuses')}</option>
                <option value="paid">{tr('مسددة بالكامل', 'Fully Paid')}</option>
                <option value="credit_due">{tr('آجل / متبقي عليها', 'Credit / Unpaid Balance')}</option>
              </select>

              <select
                value={methodFilter}
                onChange={e => setMethodFilter(e.target.value as 'all' | PaymentMethod)}
                className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-slate-700"
              >
                <option value="all">{tr('كل طرق الدفع', 'All Methods')}</option>
                <option value="cash">{tr('نقداً', 'Cash')}</option>
                <option value="card">{tr('شبكة / بنكي', 'Card')}</option>
                <option value="credit">{tr('آجل', 'Credit')}</option>
                <option value="split">{tr('سداد جزئي', 'Split / Partial')}</option>
              </select>
            </div>
          </div>
        </div>

        {/* Invoices Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-3 pr-2">{tr('رقم الفاتورة', 'Invoice #')}</th>
                <th className="pb-3">{tr('التاريخ', 'Date')}</th>
                <th className="pb-3">{tr('العميل', 'Customer')}</th>
                <th className="pb-3">{tr('المستودع', 'Warehouse')}</th>
                <th className="pb-3 text-center">{tr('الأصناف', 'Items')}</th>
                <th className="pb-3 text-center">{tr('حالة وطريقة الدفع', 'Payment Status')}</th>
                <th className="pb-3 text-left">{tr('الصافي النهائي', 'Grand Total')}</th>
                <th className="pb-3 text-left">{tr('المدفوع', 'Paid')}</th>
                <th className="pb-3 text-left">{tr('المتبقي (آجل)', 'Remaining')}</th>
                <th className="pb-3 text-left">{tr('الإجراءات', 'Actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSales.map(sale => {
                const unpaidAmount = Math.max(0, sale.grandTotal - sale.paidAmount);
                return (
                  <tr key={sale.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 pr-2 font-mono font-bold text-blue-700">
                      {sale.invoiceNumber}
                    </td>
                    <td className="py-3 text-slate-500 tabular-nums">
                      {new Date(sale.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                    </td>
                    <td className="py-3 font-bold text-slate-800">
                      {sale.customerName || tr('عميل نقدي عام', 'Walk-in Customer')}
                    </td>
                    <td className="py-3 text-slate-600 font-medium">
                      {sale.warehouseName || tr('المستودع الرئيسي', 'Main Warehouse')}
                    </td>
                    <td className="py-3 text-center">
                      <span
                        className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-bold tabular-nums"
                        title={sale.items.map(i => `${i.product.name} (${i.quantity})`).join(' ، ')}
                      >
                        {sale.items.length} {tr('أصناف', 'items')}
                      </span>
                    </td>
                    <td className="py-3 text-center">{getPaymentBadge(sale)}</td>
                    <td className="py-3 text-left font-black text-slate-900 tabular-nums">
                      {formatCurrency(sale.grandTotal)}
                    </td>
                    <td className="py-3 text-left font-bold text-emerald-600 tabular-nums">
                      {formatCurrency(Math.min(sale.grandTotal, sale.paidAmount))}
                    </td>
                    <td className="py-3 text-left font-bold text-red-600 tabular-nums">
                      {formatCurrency(unpaidAmount)}
                    </td>
                    <td className="py-3 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          type="button"
                          onClick={() => openInvoiceModal(sale)}
                          className="neu-button px-2.5 py-1.5 rounded-lg text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer font-bold text-[11px]"
                          title={tr('معاينة وطباعة الفاتورة (A4 / حراري / PDF)', 'View & Print Invoice')}
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>{tr('طباعة / عرض', 'Print / View')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleEditInvoice(sale)}
                          className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                          title={tr('تعديل بيانات وبنود الفاتورة', 'Edit Invoice')}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {hasPermission('canDelete') && (
                          <button
                            type="button"
                            onClick={() => handleDeleteInvoice(sale)}
                            className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-600 cursor-pointer"
                            title={tr('حذف الفاتورة واسترجاع المخزون', 'Delete Invoice')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredSales.length === 0 && (
            <div className="py-12 text-center text-xs text-slate-400">
              {tr(
                'لا توجد فواتير مبيعات مطابقة للبحث حالياً.',
                'No matching sales invoices found.'
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick Add Customer Modal */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <form
            onSubmit={handleQuickAddCustomer}
            className="neu-card rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-blue-600" />
                <span>{tr('إضافة عميل جديد سريعاً للفاتورة', 'Quick Add New Customer')}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddCustomerOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {tr('اسم العميل / الشركة *', 'Customer / Company Name *')}
                </label>
                <input
                  type="text"
                  required
                  value={newCustomerName}
                  onChange={e => setNewCustomerName(e.target.value)}
                  placeholder={tr('مثال: مؤسسة النور للتجارة', 'e.g., Al-Noor Trading Co.')}
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {tr('رقم الهاتف / الجوال', 'Phone Number')}
                </label>
                <input
                  type="text"
                  value={newCustomerPhone}
                  onChange={e => setNewCustomerPhone(e.target.value)}
                  placeholder="01012345678"
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {tr('العنوان', 'Address')}
                </label>
                <input
                  type="text"
                  value={newCustomerAddress}
                  onChange={e => setNewCustomerAddress(e.target.value)}
                  placeholder={tr('القاهرة - مدينة نصر', 'Cairo, Nasr City')}
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {tr('الرقم الضريبي (اختياري)', 'Tax Number (Optional)')}
                </label>
                <input
                  type="text"
                  value={newCustomerTax}
                  onChange={e => setNewCustomerTax(e.target.value)}
                  placeholder="300000000000003"
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold tabular-nums"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsAddCustomerOpen(false)}
                className="neu-button px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
              >
                {tr('إلغاء', 'Cancel')}
              </button>
              <button
                type="submit"
                className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold"
              >
                {tr('حفظ العميل واختياره', 'Save & Select Customer')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Interactive Customer Search Modal (F4) */}
      {isCustomerSearchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="neu-card rounded-3xl w-full max-w-lg p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <span>{tr('البحث السريع عن عميل', 'Quick Customer Search')}</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-mono text-[10px]">F4</kbd>
                  </h3>
                  <p className="text-[10px] text-slate-500">
                    {tr('استخدم الأسهم (↑ ↓) للتنقل وزر (Enter) لاختيار العميل بدون ماوس', 'Use Arrow keys (↑ ↓) and press Enter to select customer without mouse')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCustomerSearchOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
                <input
                  ref={customerSearchInputRef}
                  type="text"
                  autoFocus
                  value={customerSearchQuery}
                  onChange={e => setCustomerSearchQuery(e.target.value)}
                  placeholder={tr('اكتب اسم العميل أو رقم الهاتف للبحث الفوري...', 'Type customer name or phone number...')}
                  className="neu-input w-full pr-9 pl-3 py-2.5 rounded-xl text-xs font-bold text-slate-800"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCustomerSearchOpen(false);
                  setIsAddCustomerOpen(true);
                }}
                className="neu-button-primary px-3 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{tr('+ عميل جديد', '+ New')}</span>
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1">
              <div
                onClick={() => {
                  setCustomerId('');
                  setIsCustomerSearchOpen(false);
                  showToast(tr('تم اختيار: عميل نقدي عام', 'Selected: Walk-in Cash Customer'), 'success');
                  barcodeSearchInputRef.current?.focus();
                }}
                className={`p-2.5 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-all ${
                  highlightedCustIndex === 0
                    ? 'bg-blue-600 text-white font-bold shadow-md'
                    : 'neu-flat text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>👤</span>
                  <span>{tr('عميل نقدي عام (مبيعات مباشرة)', 'Walk-in Cash Customer')}</span>
                </div>
                <span className="text-[10px] opacity-80 font-mono">Enter ↵</span>
              </div>

              {filteredCustomersForModal.map((c, idx) => {
                const isHighlighted = highlightedCustIndex === idx + 1;
                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      setCustomerId(c.id);
                      setIsCustomerSearchOpen(false);
                      showToast(tr(`تم اختيار العميل: ${c.name}`, `Selected customer: ${c.name}`), 'success');
                      barcodeSearchInputRef.current?.focus();
                    }}
                    className={`p-2.5 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-all ${
                      isHighlighted
                        ? 'bg-blue-600 text-white font-bold shadow-md'
                        : 'neu-flat text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div>
                      <div className="font-bold">{c.name}</div>
                      <div className={`text-[10px] ${isHighlighted ? 'text-blue-100' : 'text-slate-400'}`}>
                        {tr('هاتف:', 'Phone:')} {c.phone}
                      </div>
                    </div>
                    <div className="text-left">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isHighlighted
                            ? 'bg-white/20 text-white'
                            : c.balance > 0
                            ? 'bg-red-100 text-red-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {tr('الرصيد:', 'Bal:')} {formatCurrency(c.balance)}
                      </span>
                    </div>
                  </div>
                );
              })}

              {filteredCustomersForModal.length === 0 && (
                <div className="py-6 text-center text-xs text-slate-400">
                  {tr('لا يوجد عميل مطابق للبحث', 'No matching customer found')}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Keyboard Shortcuts Reference Modal (F1) */}
      {isShortcutsHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="neu-card rounded-3xl w-full max-w-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-slate-800 text-white flex items-center justify-center">
                  <Keyboard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">
                    {tr('دليل اختصارات لوحة المفاتيح لشاشة المبيعات', 'Sales Screen Keyboard Shortcuts Guide')}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {tr('تحكم كامل في الفاتورة بدون استخدام الماوس', 'Full mouse-free control over sales invoices')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShortcutsHelpOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {[
                { key: 'F2', label: tr('إتمام البيع وحفظ وطباعة الفاتورة', 'Complete Sale & Print Invoice'), color: 'bg-emerald-600 text-white' },
                { key: 'F4', label: tr('البحث عن عميل واختياره بالأسهم', 'Search & Select Customer'), color: 'bg-blue-600 text-white' },
                { key: 'F8', label: tr('حذف المنتج المحدد أو الأخير من الفاتورة', 'Delete Selected/Last Product'), color: 'bg-red-600 text-white' },
                { key: 'F3', label: tr('التركيز على حقل الباركود / بحث الأصناف', 'Focus Barcode / Product Search'), color: 'bg-slate-800 text-white' },
                { key: 'F6', label: tr('تبديل طريقة الدفع (نقداً / شبكة / آجل)', 'Cycle Payment Method'), color: 'bg-purple-600 text-white' },
                { key: 'F7', label: tr('التركيز على حقل الخصم الإضافي', 'Focus Extra Invoice Discount'), color: 'bg-amber-600 text-white' },
                { key: 'F9', label: tr('حفظ وإصدار الفاتورة بدون طباعة', 'Save Invoice Without Printing'), color: 'bg-indigo-600 text-white' },
                { key: 'F10', label: tr('تفريغ النموذج وبدء فاتورة جديدة', 'Reset Invoice Form'), color: 'bg-rose-600 text-white' },
                { key: '↑ / ↓', label: tr('التنقل بين بنود جدول الفاتورة', 'Navigate Invoice Table Rows'), color: 'bg-slate-700 text-white' },
                { key: '+ / -', label: tr('زيادة أو إنقاص كمية الصنف المحدد', 'Increase / Decrease Row Qty'), color: 'bg-teal-600 text-white' }
              ].map(sc => (
                <div key={sc.key} className="neu-flat p-2.5 rounded-2xl flex items-center justify-between gap-2">
                  <span className="font-bold text-slate-700">{sc.label}</span>
                  <kbd className={`px-2.5 py-1 rounded-xl font-mono text-[11px] font-black shrink-0 shadow-xs ${sc.color}`}>
                    {sc.key}
                  </kbd>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsShortcutsHelpOpen(false)}
                className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold cursor-pointer"
              >
                {tr('حسناً، فهمت (Esc)', 'Got it (Esc)')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Camera Barcode Scanner Modal */}
      <MobileBarcodeScannerModal
        isOpen={isMobileScannerOpen}
        onClose={() => setIsMobileScannerOpen(false)}
        defaultContinuous={true}
        title={tr('مسح أصناف فاتورة المبيعات بكاميرا الموبايل', 'Scan Invoice Items with Mobile Camera')}
        onScan={handleMobileBarcodeScan}
      />
    </div>
  );
};
