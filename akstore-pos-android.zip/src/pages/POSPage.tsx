/**
 * @file pages/POSPage.tsx
 * شاشة نقطة البيع (الكاشير) مع الباركود الفوري وتعدد طرق الدفع والطباعة
 * High-performance POS Cashier Terminal with Hardware Barcode Reader & Cart Management
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Search,
  Barcode,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  Pause,
  Play,
  RotateCcw,
  CreditCard,
  Banknote,
  Split,
  UserPlus,
  Tag,
  Percent,
  CalendarClock,
  Printer,
  EyeOff,
  Volume2,
  Building2,
  Coins,
  Keyboard,
  Users,
  X,
  Smartphone,
  Camera,
  ShoppingCart,
  LayoutGrid,
  Calculator,
  Delete,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { useBarcodeScanner, playScannerBeep } from '../hooks/useBarcodeScanner';
import { Product, PaymentMethod } from '../types';
import { printInvoiceDirect } from '../utils/exportUtils';
import { MobileBarcodeScannerModal } from '../components/MobileBarcodeScannerModal';
import { NumberStepperInput } from '../components/NumberStepperInput';
import {
  getOrCreatePosScannerSessionId,
  subscribeToMobileScannerSession
} from '../utils/barcodeDecoderEngine';

const DEFAULT_PRODUCT_CATEGORIES = [
  'غذاء',
  'مشروبات',
  'ألبان وأجبان',
  'حلويات وسناكس',
  'مخبوزات ومعجنات',
  'لحوم ودواجن',
  'خضروات وفواكه',
  'منظفات وعناية منزلية',
  'عناية شخصية وتجميل',
  'إلكترونيات وإكسسوارات',
  'أجهزة منزلية وكهربائية',
  'ملابس وأحذية',
  'أدوات مكتبية وقرطاسية',
  'أدوية ومستلزمات طبية',
  'قطع غيار وعدد',
  'عام'
];

const DEFAULT_PRODUCT_UNITS = [
  'حبة',
  'قطعة',
  'علبة',
  'زجاجة',
  'كرتونة',
  'كيلو',
  'لتر',
  'كيس',
  'باكو'
];

export const POSPage: React.FC = () => {
  const {
    products,
    customers,
    sales,
    cart,
    addToCart,
    updateCartQty,
    updateCartPrice,
    updateCartDiscount,
    removeFromCart,
    clearCart,
    cartSubtotal,
    cartDiscount,
    cartTax,
    cartTotal,
    heldCarts,
    holdCurrentCart,
    resumeHeldCart,
    deleteHeldCart,
    settings,
    updateSettings,
    formatCurrency,
    showToast,
    openInvoiceModal,
    refreshData,
    t,
    tr,
    dir,
    requestConfirm,
    warehouses,
    currencies,
    activeCurrency,
    switchActiveCurrency
  } = useApp();

  const { user } = useAuth();

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [mobilePosView, setMobilePosView] = useState<'both' | 'products' | 'cart'>('both');
  const cartPanelRef = useRef<HTMLDivElement>(null);

  const totalCartQty = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Customer & Payment State
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [isInstallmentSale, setIsInstallmentSale] = useState(false);
  const [installmentMonths, setInstallmentMonths] = useState(3);
  const [downPayment, setDownPayment] = useState(0);
  const [installmentInterestPercent, setInstallmentInterestPercent] = useState<number>(settings.installmentInterestPercentage ?? 10);
  const [orderNotes, setOrderNotes] = useState('');
  const [isHeldCartOpen, setIsHeldCartOpen] = useState(false);
  const [selectedPosWarehouseId, setSelectedPosWarehouseId] = useState<string>(
    settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main'
  );

  // Sync installment interest with settings when settings change
  useEffect(() => {
    if (settings.installmentInterestPercentage !== undefined) {
      setInstallmentInterestPercent(settings.installmentInterestPercentage);
    }
  }, [settings.installmentInterestPercentage]);

  // Installment interest calculated STRICTLY from remaining balance after down payment
  const remainingBeforeInterest = Math.max(0, cartTotal - downPayment);
  const posInterestAmount = useMemo(() => {
    return Math.round((remainingBeforeInterest * ((installmentInterestPercent || 0) / 100)) * 100) / 100;
  }, [remainingBeforeInterest, installmentInterestPercent]);

  const remainingWithInterest = remainingBeforeInterest + posInterestAmount;
  const posMonthlyInstallment = installmentMonths > 0 ? Math.round((remainingWithInterest / installmentMonths) * 100) / 100 : 0;

  // Quick Action Modals
  const [isQuickAddProdOpen, setIsQuickAddProdOpen] = useState(false);
  const [quickProdName, setQuickProdName] = useState('');
  const [quickProdBarcode, setQuickProdBarcode] = useState('');
  const [quickProdCategory, setQuickProdCategory] = useState('غذاء');
  const [quickProdCustomCategory, setQuickProdCustomCategory] = useState('');
  const [quickProdUnit, setQuickProdUnit] = useState('حبة');
  const [quickProdStock, setQuickProdStock] = useState<number>(50);
  const [quickProdSalePrice, setQuickProdSalePrice] = useState<number>(0);
  const [quickProdCostPrice, setQuickProdCostPrice] = useState<number>(0);

  const [isQuickAddCustOpen, setIsQuickAddCustOpen] = useState(false);
  const [quickCustName, setQuickCustName] = useState('');
  const [quickCustPhone, setQuickCustPhone] = useState('');

  const [isRecentInvoicesOpen, setIsRecentInvoicesOpen] = useState(false);

  // Keyboard Navigation & Customer Search Modal (F4) + Shortcuts Help Modal (F1)
  const [selectedCartIndex, setSelectedCartIndex] = useState<number>(-1);
  const [isCustomerSearchOpen, setIsCustomerSearchOpen] = useState(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [highlightedCustIndex, setHighlightedCustIndex] = useState<number>(0);
  const [isShortcutsHelpOpen, setIsShortcutsHelpOpen] = useState(false);

  // Mobile Camera Barcode Scanner Modal State
  const [isMobileScannerOpen, setIsMobileScannerOpen] = useState(false);
  const [mobileScannerTarget, setMobileScannerTarget] = useState<'cart' | 'quickProd'>('cart');

  // On-Screen Touch Numpad State (لوحة مفاتيح رقمية للمس والموبايل)
  type NumpadMode = 'qty' | 'price' | 'discount' | 'paid' | 'barcode';
  const [isNumpadOpen, setIsNumpadOpen] = useState<boolean>(false);
  const [numpadMode, setNumpadMode] = useState<NumpadMode>('qty');
  const [numpadBuffer, setNumpadBuffer] = useState<string>('');
  const [numpadFreshReplace, setNumpadFreshReplace] = useState<boolean>(true);

  // Hardware barcode scanner live states
  const [lastScannedItem, setLastScannedItem] = useState<{
    name: string;
    barcode: string;
    price: number;
    time: string;
  } | null>(null);
  const [isScanPulse, setIsScanPulse] = useState(false);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const customerSearchInputRef = useRef<HTMLInputElement>(null);
  const discountInputsRef = useRef<Record<string, HTMLInputElement | null>>({});

  // Keep selectedCartIndex pointing to the latest item when cart changes
  useEffect(() => {
    if (cart.length === 0) {
      setSelectedCartIndex(-1);
    } else if (selectedCartIndex < 0 || selectedCartIndex >= cart.length) {
      setSelectedCartIndex(cart.length - 1);
    }
  }, [cart.length]);

  // Filtered customers for F4 Customer Search Modal
  const filteredCustomersForModal = useMemo(() => {
    const q = customerSearchQuery.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      c =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        (c.address && c.address.toLowerCase().includes(q))
    );
  }, [customers, customerSearchQuery]);

  // Reset highlight index when customer search query changes
  useEffect(() => {
    setHighlightedCustIndex(0);
  }, [customerSearchQuery, isCustomerSearchOpen]);

  // Clear cart with confirmation
  const handleClearCart = () => {
    if (cart.length === 0) return;
    requestConfirm({
      title: tr('إفراغ سلة البيع', 'Clear Shopping Cart'),
      message: tr('هل أنت متأكد من رغبتك في حذف جميع الأصناف المضافة من سلة المبيعات؟', 'Are you sure you want to remove all items from the current cart?'),
      confirmText: tr('نعم، إفراغ السلة', 'Yes, Clear Cart'),
      onConfirm: clearCart
    });
  };

  const handleSaveQuickProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickProdName.trim() || quickProdSalePrice <= 0) {
      showToast('يرجى إدخال اسم المنتج وسعر بيع صحيح', 'error');
      return;
    }
    const finalCategory =
      quickProdCategory === '__custom__'
        ? quickProdCustomCategory.trim() || 'عام'
        : quickProdCategory || 'غذاء';

    const newProd = db.addProduct({
      barcode: quickProdBarcode.trim() || Date.now().toString().slice(-8),
      name: quickProdName.trim(),
      category: finalCategory,
      costPrice: quickProdCostPrice || 0,
      salePrice: quickProdSalePrice,
      stock: Math.max(1, Number(quickProdStock) || 50),
      minStockAlert: 5,
      unit: quickProdUnit || 'حبة'
    });
    refreshData();
    addToCart(newProd, 1);
    showToast(`تمت إضافة "${newProd.name}" (${finalCategory}) وإدراجه في السلة بنجاح!`, 'success');
    setIsQuickAddProdOpen(false);
    setQuickProdName('');
    setQuickProdBarcode('');
    setQuickProdCustomCategory('');
    setQuickProdSalePrice(0);
    setQuickProdCostPrice(0);
  };

  const handleSaveQuickCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickCustName.trim() || !quickCustPhone.trim()) {
      showToast('يرجى إدخال اسم العميل ورقم الهاتف', 'error');
      return;
    }
    const newCust = db.addCustomer({
      name: quickCustName.trim(),
      phone: quickCustPhone.trim(),
      balance: 0
    });
    refreshData();
    setSelectedCustomerId(newCust.id);
    showToast(`تمت إضافة العميل "${newCust.name}" واختياره بنجاح!`, 'success');
    setIsQuickAddCustOpen(false);
    setQuickCustName('');
    setQuickCustPhone('');
  };

  // Sync paidAmount default whenever cart total changes
  useEffect(() => {
    setPaidAmount(cartTotal);
  }, [cartTotal]);

  // Delete currently selected or last product in cart (F8)
  const handleDeleteSelectedCartItem = () => {
    if (cart.length === 0) {
      showToast(tr('السلة فارغة حالياً، لا يوجد منتج لحذفه', 'Cart is empty, no product to delete'), 'error');
      return;
    }
    const targetIndex =
      selectedCartIndex >= 0 && selectedCartIndex < cart.length
        ? selectedCartIndex
        : cart.length - 1;
    const targetItem = cart[targetIndex];
    if (targetItem) {
      removeFromCart(targetItem.product.id);
      showToast(
        tr(
          `تم حذف الصنف "${targetItem.product.name}" من السلة (F8)`,
          `Removed "${targetItem.product.name}" from cart (F8)`
        ),
        'info'
      );
      setSelectedCartIndex(Math.max(0, targetIndex - 1));
    }
  };

  // Cycle payment methods (F6)
  const handleCyclePaymentMethod = () => {
    const methods: PaymentMethod[] = ['cash', 'card', 'split', 'credit'];
    const labels: Record<PaymentMethod, string> = {
      cash: tr('نقداً (Cash)', 'Cash'),
      card: tr('شبكة / بطاقة (Card)', 'Card'),
      split: tr('متعدد (Split)', 'Split'),
      credit: tr('آجل (Credit)', 'Credit')
    };
    const nextIdx = (methods.indexOf(paymentMethod) + 1) % methods.length;
    const nextMethod = methods[nextIdx];
    setPaymentMethod(nextMethod);
    showToast(
      tr(`تم تغيير طريقة الدفع إلى: ${labels[nextMethod]} (F6)`, `Payment method changed to: ${labels[nextMethod]} (F6)`),
      'info'
    );
  };

  // Helper to get active cart item for Numpad operations
  const activeCartItemIndex =
    selectedCartIndex >= 0 && selectedCartIndex < cart.length
      ? selectedCartIndex
      : cart.length - 1;
  const activeCartItem = activeCartItemIndex >= 0 ? cart[activeCartItemIndex] : null;

  // Open or switch Numpad mode and sync initial value buffer
  const openNumpadFor = (mode: NumpadMode, targetIndex?: number) => {
    const idx =
      typeof targetIndex === 'number'
        ? targetIndex
        : selectedCartIndex >= 0 && selectedCartIndex < cart.length
        ? selectedCartIndex
        : cart.length - 1;

    if (typeof targetIndex === 'number' && targetIndex >= 0) {
      setSelectedCartIndex(targetIndex);
    }

    const item = idx >= 0 && idx < cart.length ? cart[idx] : null;
    setNumpadMode(mode);
    setIsNumpadOpen(true);
    setNumpadFreshReplace(true);

    if (mode === 'qty') {
      setNumpadBuffer(item ? String(item.quantity) : '');
    } else if (mode === 'price') {
      setNumpadBuffer(item && item.price > 0 ? String(item.price) : '');
    } else if (mode === 'discount') {
      setNumpadBuffer(item && item.discount > 0 ? String(item.discount) : '');
    } else if (mode === 'paid') {
      const pVal = isInstallmentSale ? downPayment : paidAmount;
      setNumpadBuffer(pVal > 0 ? String(pVal) : '');
    } else if (mode === 'barcode') {
      setNumpadBuffer(searchQuery);
    }
  };

  // Apply numeric value from Numpad to the selected target immediately
  const commitNumpadBuffer = (rawBuffer: string, mode: NumpadMode = numpadMode) => {
    if (mode === 'barcode') {
      setSearchQuery(rawBuffer);
      return;
    }

    const numVal = parseFloat(rawBuffer);
    const safeVal = isNaN(numVal) ? 0 : Math.max(0, numVal);

    if (mode === 'paid') {
      if (isInstallmentSale) {
        setDownPayment(Math.min(cartTotal, safeVal));
      } else {
        setPaidAmount(safeVal);
      }
      return;
    }

    if (!activeCartItem) {
      showToast(tr('يرجى إضافة أو اختيار صنف في السلة أولاً لتعديل قيمته', 'Please add or select an item in the cart first'), 'info');
      return;
    }

    if (mode === 'qty') {
      if (rawBuffer === '' || safeVal <= 0) {
        // Allow buffer to be empty while user is typing new quantity without deleting item
        return;
      }
      const qtyInt = Math.max(1, Math.round(safeVal));
      if (qtyInt > activeCartItem.product.stock) {
        showToast(
          tr(
            `الكمية المتاحة بالمخزون (${activeCartItem.product.stock}) فقط`,
            `Only (${activeCartItem.product.stock}) available in stock`
          ),
          'error'
        );
        updateCartQty(activeCartItem.product.id, activeCartItem.product.stock);
        setNumpadBuffer(String(activeCartItem.product.stock));
      } else {
        updateCartQty(activeCartItem.product.id, qtyInt);
      }
    } else if (mode === 'price') {
      updateCartPrice(activeCartItem.product.id, safeVal);
    } else if (mode === 'discount') {
      updateCartDiscount(activeCartItem.product.id, safeVal);
    }
  };

  const handleNumpadKeyPress = (key: string) => {
    if (key === 'C') {
      setNumpadBuffer('');
      setNumpadFreshReplace(false);
      if (numpadMode === 'barcode') {
        setSearchQuery('');
      } else if (numpadMode === 'price' && activeCartItem) {
        updateCartPrice(activeCartItem.product.id, 0);
      } else if (numpadMode === 'discount' && activeCartItem) {
        updateCartDiscount(activeCartItem.product.id, 0);
      } else if (numpadMode === 'paid') {
        if (isInstallmentSale) setDownPayment(0);
        else setPaidAmount(0);
      }
      return;
    }

    if (key === 'BACKSPACE') {
      const sliced = numpadBuffer.slice(0, -1);
      const next = sliced === '0' ? '' : sliced;
      setNumpadFreshReplace(false);
      setNumpadBuffer(next);
      if (next !== '') {
        commitNumpadBuffer(next);
      } else if (numpadMode === 'barcode') {
        setSearchQuery('');
      } else if (numpadMode === 'price' && activeCartItem) {
        updateCartPrice(activeCartItem.product.id, 0);
      } else if (numpadMode === 'discount' && activeCartItem) {
        updateCartDiscount(activeCartItem.product.id, 0);
      } else if (numpadMode === 'paid') {
        if (isInstallmentSale) setDownPayment(0);
        else setPaidAmount(0);
      }
      return;
    }

    if (key === 'ENTER') {
      if (numpadMode === 'barcode') {
        if (numpadBuffer.trim()) {
          handleProcessBarcode(numpadBuffer.trim());
          setNumpadBuffer('');
          setNumpadFreshReplace(true);
        }
      } else {
        if (numpadMode === 'qty' && (!numpadBuffer || parseFloat(numpadBuffer) <= 0)) {
          setNumpadBuffer('1');
          commitNumpadBuffer('1');
        } else {
          commitNumpadBuffer(numpadBuffer || '0');
        }
        setNumpadFreshReplace(true);
        showToast(tr('تم تطبيق القيمة بنجاح', 'Value applied'), 'success');
      }
      return;
    }

    if (key === '.') {
      if (numpadMode === 'qty' || numpadMode === 'barcode') return;
      const base = numpadFreshReplace ? '0' : numpadBuffer || '0';
      if (base.includes('.')) return;
      const next = base + '.';
      setNumpadFreshReplace(false);
      setNumpadBuffer(next);
      return;
    }

    // Standard digit or '00'
    const base = numpadFreshReplace ? '' : numpadBuffer;
    const rawNext = base + key;
    const next = (rawNext.length > 1 && rawNext.startsWith('0') && !rawNext.startsWith('0.')
      ? rawNext.replace(/^0+/, '') || '0'
      : rawNext
    ).slice(0, 14);
    setNumpadFreshReplace(false);
    setNumpadBuffer(next);
    commitNumpadBuffer(next);
  };

  const handleNumpadQuickIncrement = (delta: number) => {
    const fallbackCurrent =
      numpadMode === 'qty'
        ? activeCartItem?.quantity || 0
        : numpadMode === 'price'
        ? activeCartItem?.price || 0
        : numpadMode === 'discount'
        ? activeCartItem?.discount || 0
        : numpadMode === 'paid'
        ? isInstallmentSale
          ? downPayment
          : paidAmount
        : 0;
    const current = numpadBuffer !== '' ? parseFloat(numpadBuffer) || 0 : fallbackCurrent;
    const minAllowed = numpadMode === 'qty' ? 1 : 0;
    const nextVal = Math.max(minAllowed, current + delta);
    const nextStr = nextVal === 0 ? '' : String(Math.round(nextVal * 100) / 100);
    setNumpadFreshReplace(false);
    setNumpadBuffer(nextStr);
    commitNumpadBuffer(nextStr || '0');
  };

  // Central barcode processing for both hardware barcode scanners and manual input
  const handleProcessBarcode = (scannedBarcode: string) => {
    const clean = scannedBarcode.trim();
    if (!clean) return;

    // Search reactive products list first, then fallback to db
    const match = products.find(p => 
      p.barcode.trim() === clean ||
      p.barcode.trim().toLowerCase() === clean.toLowerCase() ||
      (p.sku && p.sku.trim().toLowerCase() === clean.toLowerCase())
    ) || db.getProductByBarcode(clean);

    if (match) {
      if (match.stock <= 0) {
        playScannerBeep('error');
        showToast(`تنبيه: المنتج "${match.name}" نافد من المخزون!`, 'error');
        return;
      }

      addToCart(match, 1);
      playScannerBeep('success');
      setSearchQuery('');
      setLastScannedItem({
        name: match.name,
        barcode: match.barcode,
        price: match.salePrice,
        time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      });
      setIsScanPulse(true);
      setTimeout(() => setIsScanPulse(false), 850);
      showToast(`تم مسح الباركود وإضافة "${match.name}" (${formatCurrency(match.salePrice)}) للفاتورة الحالية`, 'success');
    } else {
      playScannerBeep('error');
      showToast(`لم يتم العثور على منتج بالباركود: ${clean}`, 'error');
      // Prefill quick product creation after barcode scan
      setQuickProdBarcode(clean);
      setQuickProdName('');
      setQuickProdCategory(selectedCategory !== 'all' ? selectedCategory : 'غذاء');
      setQuickProdCustomCategory('');
      setQuickProdUnit('حبة');
      setQuickProdStock(50);
      setQuickProdSalePrice(0);
      setQuickProdCostPrice(0);
      setIsQuickAddProdOpen(true);
    }
  };

  // Hardware barcode scanner listener (USB / Bluetooth / Wireless HID)
  useBarcodeScanner({
    enabled: true,
    onScan: (barcode) => {
      handleProcessBarcode(barcode);
    }
  });

  // Background Wireless Mobile-to-PC Scanner listener (active when modal is closed so paired phone keeps working)
  const handleProcessBarcodeRef = useRef(handleProcessBarcode);
  useEffect(() => {
    handleProcessBarcodeRef.current = handleProcessBarcode;
  });

  useEffect(() => {
    if (isMobileScannerOpen) return;
    const sessionId = getOrCreatePosScannerSessionId();
    const unsubscribe = subscribeToMobileScannerSession(sessionId, {
      onBarcodeScanned: (barcode) => {
        handleProcessBarcodeRef.current(barcode);
      }
    });
    return () => unsubscribe();
  }, [isMobileScannerOpen]);

  // Unique categories list + standard product types for ComboBox
  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach(p => {
      if (p.category) set.add(p.category);
    });
    return Array.from(set);
  }, [products]);

  const allProductTypeOptions = useMemo(() => {
    const set = new Set<string>(DEFAULT_PRODUCT_CATEGORIES);
    products.forEach(p => {
      if (p.category && p.category.trim()) set.add(p.category.trim());
    });
    return Array.from(set);
  }, [products]);

  // Filtered products list
  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return products.filter(p => {
      const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.barcode.includes(q) ||
        (p.category && p.category.toLowerCase().includes(q));
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Handle Enter key on manual search/barcode input
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const q = searchQuery.trim();
      if (!q) return;

      // 1. Check exact barcode or SKU match
      const exactBarcodeMatch = products.find(p => 
        p.barcode.trim().toLowerCase() === q.toLowerCase() ||
        (p.sku && p.sku.trim().toLowerCase() === q.toLowerCase())
      );

      if (exactBarcodeMatch) {
        e.preventDefault();
        handleProcessBarcode(exactBarcodeMatch.barcode);
        return;
      }

      // 2. If exactly one product matches current search filter, add it
      if (filteredProducts.length === 1) {
        e.preventDefault();
        handleProcessBarcode(filteredProducts[0].barcode);
        return;
      }

      // 3. If no match at all, treat as barcode scan
      if (filteredProducts.length === 0) {
        e.preventDefault();
        handleProcessBarcode(q);
      }
    }
  };

  // Change amount calculation
  const changeAmount = useMemo(() => {
    if (isInstallmentSale) return 0;
    return Math.max(0, paidAmount - cartTotal);
  }, [paidAmount, cartTotal, isInstallmentSale]);

  // Finalize Sale
  const handleCheckout = () => {
    if (cart.length === 0) {
      showToast('سلة المشتريات فارغة!', 'error');
      return;
    }

    if (isInstallmentSale && !selectedCustomerId) {
      showToast('يجب تحديد العميل لإنشاء خطة أقساط!', 'error');
      return;
    }

    const customer = customers.find(c => c.id === selectedCustomerId);

    const remainingDebtBeforeInterest = isInstallmentSale
      ? Math.max(0, cartTotal - downPayment)
      : 0;
    const interestCalculatedFromRemaining = isInstallmentSale
      ? Math.round(remainingDebtBeforeInterest * ((installmentInterestPercent || 0) / 100) * 100) / 100
      : 0;
    const finalRemainingDebt = remainingDebtBeforeInterest + interestCalculatedFromRemaining;
    const totalFinanced = downPayment + finalRemainingDebt;
    const monthlyAmount =
      isInstallmentSale && installmentMonths > 0
        ? Math.round((finalRemainingDebt / installmentMonths) * 100) / 100
        : 0;

    // Create Sale invoice in database
    const newInvoice = db.createSale({
      cashierId: user?.id || 'cashier',
      cashierName: user?.name || 'كاشير الفرع',
      customerId: customer?.id,
      customerName: customer?.name,
      items: [...cart],
      subtotal: cartSubtotal,
      discountTotal: cartDiscount,
      taxTotal: cartTax,
      grandTotal: cartTotal,
      paidAmount: isInstallmentSale ? downPayment : Math.min(paidAmount, cartTotal),
      changeAmount: changeAmount,
      paymentMethod: paymentMethod,
      notes: orderNotes,
      hasInstallment: isInstallmentSale,
      installmentCount: isInstallmentSale ? installmentMonths : undefined,
      downPayment: isInstallmentSale ? downPayment : undefined,
      remainingInstallmentAmount: isInstallmentSale ? finalRemainingDebt : undefined,
      monthlyInstallmentAmount: isInstallmentSale ? monthlyAmount : undefined,
      warehouseId: selectedPosWarehouseId,
      warehouseName: warehouses.find(w => w.id === selectedPosWarehouseId)?.name || 'المستودع الرئيسي',
      currency: activeCurrency?.code || settings.currency,
      currencySymbol: activeCurrency?.symbol || settings.currencySymbol,
      exchangeRate: activeCurrency?.exchangeRate || 1
    });

    // If installment sale, generate installment schedule
    if (isInstallmentSale && customer) {
      const installmentsList = [];

      for (let i = 1; i <= installmentMonths; i++) {
        const due = new Date();
        due.setMonth(due.getMonth() + i);
        installmentsList.push({
          id: `inst-${Date.now()}-${i}`,
          installmentNumber: i,
          dueDate: due.toISOString().split('T')[0],
          amount:
            i === installmentMonths
              ? Math.round((finalRemainingDebt - monthlyAmount * (installmentMonths - 1)) * 100) / 100
              : monthlyAmount,
          status: 'pending' as const
        });
      }

      db.createInstallmentPlan({
        invoiceNumber: newInvoice.invoiceNumber,
        customerId: customer.id,
        customerName: customer.name,
        customerPhone: customer.phone,
        originalAmount: cartTotal,
        interestAmount: interestCalculatedFromRemaining,
        interestRate: installmentInterestPercent,
        totalAmount: totalFinanced,
        downPayment: downPayment,
        remainingAmount: finalRemainingDebt,
        installmentCount: installmentMonths,
        startDate: new Date().toISOString().split('T')[0],
        installments: installmentsList
      });

      // Update customer ledger
      db.adjustCustomerBalance(customer.id, finalRemainingDebt);
    }

    // Trigger celebration effects
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.7 }
    });

    showToast(`تم إصدار الفاتورة #${newInvoice.invoiceNumber} بنجاح!`, 'success');

    // Refresh context data
    refreshData();
    clearCart();
    setOrderNotes('');
    setIsInstallmentSale(false);
    setInstallmentInterestPercent(settings.installmentInterestPercentage ?? 10);

    // Auto-print immediately if enabled in settings
    if (settings.autoPrintOnSale && settings.selectedPrinter) {
      try {
        printInvoiceDirect(newInvoice, settings);
      } catch (e) {
        console.warn('Auto print failed:', e);
      }
    }

    // Open print preview modal immediately
    openInvoiceModal(newInvoice);
  };

  // Comprehensive Keyboard Shortcuts for Mouse-Free POS Operation
  useEffect(() => {
    const handleShortcuts = (e: KeyboardEvent) => {
      const activeEl = document.activeElement as HTMLElement | null;
      const isInputFocused =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          activeEl.tagName === 'SELECT');

      // Escape: close any open modal and return focus to barcode input
      if (e.key === 'Escape') {
        if (isCustomerSearchOpen) {
          e.preventDefault();
          setIsCustomerSearchOpen(false);
          barcodeInputRef.current?.focus();
          return;
        }
        if (isShortcutsHelpOpen) {
          e.preventDefault();
          setIsShortcutsHelpOpen(false);
          barcodeInputRef.current?.focus();
          return;
        }
        if (isQuickAddProdOpen || isQuickAddCustOpen || isRecentInvoicesOpen) {
          e.preventDefault();
          setIsQuickAddProdOpen(false);
          setIsQuickAddCustOpen(false);
          setIsRecentInvoicesOpen(false);
          barcodeInputRef.current?.focus();
          return;
        }
      }

      // When Customer Search Modal (F4) is open, handle ArrowUp/ArrowDown/Enter inside it
      if (isCustomerSearchOpen) {
        const totalOptions = filteredCustomersForModal.length + 1; // index 0 = Walk-in Cash Customer
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setHighlightedCustIndex(prev => (prev + 1) % totalOptions);
          return;
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          setHighlightedCustIndex(prev => (prev - 1 + totalOptions) % totalOptions);
          return;
        }
        if (e.key === 'Enter') {
          e.preventDefault();
          if (highlightedCustIndex === 0) {
            setSelectedCustomerId('');
            showToast(tr('تم اختيار: عميل نقدي (Walk-in Customer)', 'Selected: Walk-in Cash Customer'), 'success');
          } else {
            const chosen = filteredCustomersForModal[highlightedCustIndex - 1];
            if (chosen) {
              setSelectedCustomerId(chosen.id);
              showToast(tr(`تم اختيار العميل: ${chosen.name}`, `Selected customer: ${chosen.name}`), 'success');
            }
          }
          setIsCustomerSearchOpen(false);
          setCustomerSearchQuery('');
          barcodeInputRef.current?.focus();
          return;
        }
      }

      // F1: Toggle Keyboard Shortcuts Guide Modal
      if (e.key === 'F1') {
        e.preventDefault();
        setIsShortcutsHelpOpen(prev => !prev);
        return;
      }

      // F2: Complete Sale & Print Invoice (إتمام البيع)
      if (e.key === 'F2') {
        e.preventDefault();
        if (cart.length > 0) {
          handleCheckout();
        } else {
          showToast(tr('السلة فارغة! أضف أصنافاً أولاً لإتمام البيع (F2)', 'Cart is empty! Add items first to complete sale (F2)'), 'error');
        }
        return;
      }

      // F3: Focus Product / Barcode Search Input
      if (e.key === 'F3') {
        e.preventDefault();
        barcodeInputRef.current?.focus();
        barcodeInputRef.current?.select();
        return;
      }

      // F4: Search / Select Customer Modal (البحث عن عميل)
      if (e.key === 'F4') {
        e.preventDefault();
        setIsCustomerSearchOpen(prev => {
          const next = !prev;
          if (next) {
            setCustomerSearchQuery('');
            setHighlightedCustIndex(0);
            setTimeout(() => customerSearchInputRef.current?.focus(), 50);
          }
          return next;
        });
        return;
      }

      // F6: Cycle Payment Method (تبديل طريقة الدفع)
      if (e.key === 'F6') {
        e.preventDefault();
        handleCyclePaymentMethod();
        return;
      }

      // F7: Focus Line Discount Input of Selected Cart Item
      if (e.key === 'F7') {
        e.preventDefault();
        if (cart.length > 0) {
          const idx = selectedCartIndex >= 0 && selectedCartIndex < cart.length ? selectedCartIndex : cart.length - 1;
          const targetProdId = cart[idx]?.product.id;
          if (targetProdId && discountInputsRef.current[targetProdId]) {
            discountInputsRef.current[targetProdId]?.focus();
            discountInputsRef.current[targetProdId]?.select();
          }
        }
        return;
      }

      // F8: Delete Selected / Last Product from Cart (حذف منتج)
      if (e.key === 'F8') {
        e.preventDefault();
        handleDeleteSelectedCartItem();
        return;
      }

      // F9: Hold Current Cart or Open Held Carts (تعليق/استرجاع الفاتورة)
      if (e.key === 'F9') {
        e.preventDefault();
        if (cart.length > 0) {
          holdCurrentCart();
        } else if (heldCarts.length > 0) {
          setIsHeldCartOpen(prev => !prev);
        } else {
          showToast(tr('لا توجد أصناف بالسلة لتعليقها حالياً', 'No items in cart to hold'), 'info');
        }
        return;
      }

      // F10: Clear Cart (إفراغ السلة)
      if (e.key === 'F10') {
        e.preventDefault();
        handleClearCart();
        return;
      }

      // Cart Navigation & Quantity Control when not typing inside a text field (or when barcode search is empty)
      const isBarcodeEmpty =
        activeEl === barcodeInputRef.current && searchQuery.trim() === '';

      if ((!isInputFocused || isBarcodeEmpty) && cart.length > 0 && !isCustomerSearchOpen) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setSelectedCartIndex(prev => (prev + 1) % cart.length);
          return;
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          setSelectedCartIndex(prev => (prev - 1 + cart.length) % cart.length);
          return;
        }
        if (e.key === '+' || e.key === '=') {
          e.preventDefault();
          const idx = selectedCartIndex >= 0 && selectedCartIndex < cart.length ? selectedCartIndex : cart.length - 1;
          const target = cart[idx];
          if (target) {
            if (target.quantity < target.product.stock) {
              updateCartQty(target.product.id, target.quantity + 1);
            } else {
              showToast(tr('تم الوصول للحد الأقصى للمخزون المتاح', 'Maximum available stock reached'), 'error');
            }
          }
          return;
        }
        if (e.key === '-' || e.key === '_') {
          e.preventDefault();
          const idx = selectedCartIndex >= 0 && selectedCartIndex < cart.length ? selectedCartIndex : cart.length - 1;
          const target = cart[idx];
          if (target) {
            if (target.quantity > 1) {
              updateCartQty(target.product.id, target.quantity - 1);
            } else {
              removeFromCart(target.product.id);
            }
          }
          return;
        }
      }
    };

    window.addEventListener('keydown', handleShortcuts);
    return () => window.removeEventListener('keydown', handleShortcuts);
  }, [
    cart,
    cartTotal,
    selectedCartIndex,
    paymentMethod,
    isCustomerSearchOpen,
    filteredCustomersForModal,
    highlightedCustIndex,
    isShortcutsHelpOpen,
    isQuickAddProdOpen,
    isQuickAddCustOpen,
    isRecentInvoicesOpen,
    searchQuery,
    heldCarts.length
  ]);

  return (
    <div className="flex flex-col md:flex-row gap-3.5 lg:gap-4 h-auto md:h-full min-h-[500px] pb-20 md:pb-0">
      {/* MOBILE QUICK SWITCHER BAR (Visible only on mobile < md) */}
      <div className="flex md:hidden items-center gap-1.5 p-1.5 rounded-2xl neu-card border border-blue-200/70 bg-white/90 sticky top-0 z-30 shadow-md">
        <button
          type="button"
          onClick={() => setMobilePosView('both')}
          className={`flex-1 py-2 px-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            mobilePosView === 'both'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5 shrink-0" />
          <span>{tr('الأصناف + السلة', 'Items + Cart')}</span>
        </button>

        <button
          type="button"
          onClick={() => setMobilePosView('products')}
          className={`flex-1 py-2 px-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            mobilePosView === 'products'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Tag className="w-3.5 h-3.5 shrink-0" />
          <span>{tr(`أزرار الأصناف (${filteredProducts.length})`, `Products (${filteredProducts.length})`)}</span>
        </button>

        <button
          type="button"
          onClick={() => setMobilePosView('cart')}
          className={`flex-1 py-2 px-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
            mobilePosView === 'cart'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <ShoppingCart className="w-3.5 h-3.5 shrink-0" />
          <span>{tr('السلة والدفع', 'Cart')}</span>
          {totalCartQty > 0 && (
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black tabular-nums ${
              mobilePosView === 'cart' ? 'bg-white text-emerald-700' : 'bg-emerald-600 text-white'
            }`}>
              {totalCartQty}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => {
            setMobilePosView('cart');
            if (!isNumpadOpen) {
              openNumpadFor(cart.length > 0 ? 'qty' : 'barcode');
            } else {
              setIsNumpadOpen(false);
            }
          }}
          className={`py-2 px-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer shrink-0 ${
            isNumpadOpen
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
          }`}
          title={tr('لوحة المفاتيح الرقمية للمس (إدخال الكميات والأسعار والخصم)', 'On-screen Touch Numpad')}
        >
          <Calculator className="w-3.5 h-3.5 shrink-0" />
          <span>{tr('أرقام', 'Numpad')}</span>
        </button>
      </div>

      {/* LEFT/RIGHT AREA: Product Catalog & Search */}
      <div className={`${mobilePosView === 'cart' ? 'hidden md:flex' : 'flex'} flex-1 flex-col min-w-0 md:min-h-0 neu-card rounded-3xl p-3 sm:p-3.5 lg:p-4 md:overflow-hidden`}>
        {/* Interactive Keyboard Shortcuts Bar (Desktop Only - Mouse-Free Operation) */}
        <div className="hidden md:flex items-center justify-between gap-2 mb-2.5 px-3 py-1.5 rounded-2xl neu-pressed overflow-x-auto no-scrollbar select-none border border-blue-200/50 bg-blue-50/30">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700 shrink-0">
            <Keyboard className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>{tr('اختصارات الكيبورد:', 'Shortcuts:')}</span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => (cart.length > 0 ? handleCheckout() : showToast(tr('السلة فارغة!', 'Cart is empty!'), 'error'))}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-600 text-white text-[10px] font-bold hover:bg-emerald-700 transition-colors cursor-pointer shadow-xs"
              title={tr('إتمام البيع والطباعة (F2)', 'Complete Sale & Print (F2)')}
            >
              <kbd className="px-1 py-0.2 bg-black/20 rounded font-mono text-[10px]">F2</kbd>
              <span>{tr('إتمام البيع', 'Checkout')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                barcodeInputRef.current?.focus();
                barcodeInputRef.current?.select();
              }}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white text-slate-700 border border-slate-200 text-[10px] font-bold hover:border-blue-400 transition-colors cursor-pointer"
              title={tr('التركيز على حقل الباركود والبحث عن صنف (F3)', 'Focus Barcode / Product Search (F3)')}
            >
              <kbd className="px-1 bg-slate-100 text-blue-700 rounded font-mono text-[10px]">F3</kbd>
              <span>{tr('بحث صنف', 'Item Search')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCustomerSearchQuery('');
                setHighlightedCustIndex(0);
                setIsCustomerSearchOpen(true);
                setTimeout(() => customerSearchInputRef.current?.focus(), 50);
              }}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-blue-600 text-white text-[10px] font-bold hover:bg-blue-700 transition-colors cursor-pointer shadow-xs"
              title={tr('البحث عن عميل واختياره بدون ماوس (F4)', 'Search & Select Customer (F4)')}
            >
              <kbd className="px-1 bg-black/20 rounded font-mono text-[10px]">F4</kbd>
              <span>{tr('بحث عميل', 'Customer')}</span>
            </button>

            <button
              type="button"
              onClick={handleCyclePaymentMethod}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white text-slate-700 border border-slate-200 text-[10px] font-bold hover:border-purple-400 transition-colors cursor-pointer"
              title={tr('تبديل طريقة الدفع: نقداً / شبكة / متعدد / آجل (F6)', 'Cycle Payment Method (F6)')}
            >
              <kbd className="px-1 bg-slate-100 text-purple-700 rounded font-mono text-[10px]">F6</kbd>
              <span>{tr('طريقة الدفع', 'Payment')}</span>
            </button>

            <button
              type="button"
              onClick={handleDeleteSelectedCartItem}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-red-600 text-white text-[10px] font-bold hover:bg-red-700 transition-colors cursor-pointer shadow-xs"
              title={tr('حذف المنتج المحدد أو الأخير من السلة (F8)', 'Delete Selected / Last Product (F8)')}
            >
              <kbd className="px-1 bg-black/20 rounded font-mono text-[10px]">F8</kbd>
              <span>{tr('حذف منتج', 'Delete Item')}</span>
            </button>

            <button
              type="button"
              onClick={() => (cart.length > 0 ? holdCurrentCart() : setIsHeldCartOpen(!isHeldCartOpen))}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white text-slate-700 border border-slate-200 text-[10px] font-bold hover:border-amber-400 transition-colors cursor-pointer"
              title={tr('تعليق الفاتورة الحالية أو استرجاع معلقة (F9)', 'Hold / Recall Cart (F9)')}
            >
              <kbd className="px-1 bg-slate-100 text-amber-700 rounded font-mono text-[10px]">F9</kbd>
              <span>{tr('تعليق', 'Hold')}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsShortcutsHelpOpen(true)}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-800 text-white text-[10px] font-bold hover:bg-slate-700 transition-colors cursor-pointer"
              title={tr('عرض دليل جميع اختصارات لوحة المفاتيح (F1)', 'Show All Keyboard Shortcuts (F1)')}
            >
              <kbd className="px-1 bg-white/20 rounded font-mono text-[10px]">F1</kbd>
              <span>{tr('كل الاختصارات', 'All Keys')}</span>
            </button>
          </div>
        </div>

        {/* Search & Barcode Bar (Responsive for Mobile & Desktop) */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-2.5 mb-3">
          <div className="relative flex-1 min-w-0">
            <input
              ref={barcodeInputRef}
              id="barcode-search-input"
              data-barcode-scanner="true"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder={tr('امسح الباركود أو ابحث عن اسم الصنف...', 'Scan barcode or search product name...')}
              className="neu-input w-full pl-10 sm:pl-12 pr-9 py-2.5 rounded-2xl text-xs font-bold text-slate-800 transition-all focus:ring-2 focus:ring-emerald-500/40"
            />
            <Search className="w-4 h-4 text-slate-400 absolute top-3 right-3 pointer-events-none" />
            {searchQuery ? (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute top-2.5 left-2.5 p-0.5 rounded-lg bg-slate-200 text-slate-600 hover:bg-slate-300 cursor-pointer"
                title={tr('مسح البحث', 'Clear search')}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <kbd className="hidden sm:inline-block absolute top-2 left-2.5 px-1.5 py-0.5 rounded-md bg-slate-200/80 text-slate-600 font-mono text-[10px] font-bold pointer-events-none">
                F3
              </kbd>
            )}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
            {/* Laptop Webcam & Mobile Camera Barcode Scanner Button */}
            <button
              type="button"
              onClick={() => {
                setMobileScannerTarget('cart');
                setIsMobileScannerOpen(true);
              }}
              className="flex-1 sm:flex-initial justify-center px-3 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 text-xs font-bold shadow-md shadow-emerald-600/20 cursor-pointer transition-all shrink-0 whitespace-nowrap"
              title={tr(
                'مسح الباركود بكاميرا اللاب توب أو كاميرا الموبايل وإضافته للسلة مباشرة',
                'Scan barcode using Laptop Webcam or Mobile Camera directly into cart'
              )}
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span>{tr('مسح بالكاميرا', 'Camera Scan')}</span>
            </button>

            {/* On-Screen Touch Numpad Toggle Button */}
            <button
              type="button"
              onClick={() => {
                if (isNumpadOpen) {
                  setIsNumpadOpen(false);
                } else {
                  openNumpadFor(cart.length > 0 ? 'qty' : 'barcode');
                }
              }}
              className={`flex-1 sm:flex-initial justify-center px-3 py-2.5 rounded-2xl flex items-center gap-1.5 text-xs font-bold cursor-pointer transition-all shrink-0 whitespace-nowrap ${
                isNumpadOpen
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25 ring-2 ring-indigo-300'
                  : 'neu-button text-indigo-700 hover:bg-indigo-50 border border-indigo-200/80'
              }`}
              title={tr(
                'فتح/إغلاق لوحة المفاتيح الرقمية للمس والموبايل (الكمية، السعر، الخصم، الباركود)',
                'Toggle On-screen Numpad for touchscreens and mobile'
              )}
            >
              <Calculator className="w-4 h-4 shrink-0" />
              <span>{tr('لوحة أرقام', 'Numpad')}</span>
            </button>

            {/* Active Barcode Scanner Status Indicator */}
            <div
              onClick={() => {
                playScannerBeep('success');
                showToast(tr('قارئ الباركود الخارجي (USB / لاسلكي) نشط وجاهز للاستماع!', 'External barcode scanner (USB / Wireless) is active and ready!'), 'success');
              }}
              className={`px-3 py-2 rounded-2xl hidden xl:flex items-center gap-2 text-xs font-semibold cursor-pointer select-none transition-all duration-300 ${
                isScanPulse
                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30 ring-2 ring-emerald-400'
                  : 'neu-pressed text-slate-700 hover:text-emerald-700'
              }`}
              title={tr('قارئ الباركود الخارجي مفعل تلقائياً بنظام الاستماع الفوري. انقر لتجربة نغمة المسح', 'Hardware barcode scanner is active. Click to test scan beep')}
            >
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isScanPulse ? 'bg-white' : 'bg-emerald-400'}`}></span>
                <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isScanPulse ? 'bg-white' : 'bg-emerald-500'}`}></span>
              </span>
              <Barcode className={`w-4 h-4 ${isScanPulse ? 'text-white' : 'text-emerald-600'}`} />
              <span className="hidden sm:inline font-bold">{tr('قارئ الباركود نشط', 'Scanner Active')}</span>
              <Volume2 className={`w-3.5 h-3.5 ${isScanPulse ? 'text-white' : 'text-slate-400'}`} />
            </div>

            {/* Product Type ComboBox right after Barcode Scanner */}
            <div className="flex items-center gap-1.5 px-2.5 py-2 rounded-2xl neu-pressed border border-blue-200/80 bg-white/80 shrink-0">
              <Tag className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <select
                value={selectedCategory}
                onChange={(e) => {
                  const val = e.target.value;
                  setSelectedCategory(val);
                  if (val !== 'all') {
                    setQuickProdCategory(val);
                  }
                }}
                className="bg-transparent font-bold text-slate-800 outline-none text-xs cursor-pointer"
                title={tr('نوع المنتج / التصنيف (غذاء، مشروبات، ...)', 'Product Type / Category (Food, Drinks, ...)')}
              >
                <option value="all">{tr(`كل أنواع المنتجات (${products.length})`, `All Product Types (${products.length})`)}</option>
                {allProductTypeOptions.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Add Product Button */}
            <button
              type="button"
              onClick={() => {
                setQuickProdBarcode(searchQuery && !isNaN(Number(searchQuery)) ? searchQuery.trim() : Date.now().toString().slice(-8));
                setQuickProdName(searchQuery && isNaN(Number(searchQuery)) ? searchQuery : '');
                setQuickProdCategory(selectedCategory !== 'all' ? selectedCategory : 'غذاء');
                setQuickProdCustomCategory('');
                setQuickProdUnit('حبة');
                setQuickProdStock(50);
                setQuickProdSalePrice(0);
                setQuickProdCostPrice(0);
                setIsQuickAddProdOpen(true);
              }}
              className="neu-button-primary px-3 py-2.5 rounded-2xl flex items-center justify-center gap-1.5 text-xs font-bold cursor-pointer whitespace-nowrap shrink-0"
              title={tr('إضافة صنف سريع جديد مباشرة للسلة', 'Quickly add a new product directly to the cart')}
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>{tr('إضافة صنف', 'Add Item')}</span>
            </button>

            {/* Recent Invoices Button */}
            {sales.length > 0 && (
              <button
                type="button"
                onClick={() => setIsRecentInvoicesOpen(true)}
                className="neu-button px-3 py-2.5 rounded-2xl flex items-center justify-center gap-1.5 text-xs font-bold text-slate-700 hover:text-blue-600 cursor-pointer whitespace-nowrap shrink-0"
                title={tr('سجل الفواتير السريع وإعادة الطباعة', 'Recent invoices log & reprint')}
              >
                <Printer className="w-4 h-4 text-blue-600 shrink-0" />
                <span>{tr(`الفواتير (${sales.length})`, `Invoices (${sales.length})`)}</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Scanned Barcode Feedback Alert */}
        {lastScannedItem && (
          <div
            className={`mb-2 px-3 py-2 rounded-2xl flex items-center justify-between text-xs transition-all duration-300 ${
              isScanPulse
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 scale-[1.01]'
                : 'neu-pressed text-slate-700'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${isScanPulse ? 'bg-white animate-ping' : 'bg-emerald-500'}`} />
              <span className="font-bold truncate">{tr('تم مسح الصنف:', 'Scanned:')} {lastScannedItem.name}</span>
              <span className="text-[11px] opacity-75 font-mono">[{lastScannedItem.barcode}]</span>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <span className="font-black tabular-nums">{formatCurrency(lastScannedItem.price)}</span>
              <span className="text-[10px] opacity-75">{lastScannedItem.time}</span>
            </div>
          </div>
        )}

        {/* Category Pill Filters & Warehouse Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 select-none">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 no-scrollbar">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-all shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'neu-button text-slate-700'
              }`}
            >
              {tr(`جميع الأصناف (${products.length})`, `All Items (${products.length})`)}
            </button>
            {categories.map((cat) => (
              <button
                type="button"
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-all shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'neu-button text-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
            {/* Active Currency Switcher in POS */}
            {currencies.length > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl neu-pressed text-xs border border-emerald-200 bg-emerald-50/40 shrink-0">
                <Coins className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="text-slate-400 text-[10px] hidden xl:inline">{tr('العملة:', 'Currency:')}</span>
                <select
                  value={activeCurrency?.code || settings.currency || 'EGP'}
                  onChange={(e) => {
                    const res = switchActiveCurrency(e.target.value);
                    if (res.success) {
                      showToast(res.message, 'success');
                    }
                  }}
                  className="bg-transparent font-bold text-emerald-800 outline-none text-xs cursor-pointer"
                  title={tr('تبديل عملة البيع وتحديث أسعار السلة والأصناف', 'Switch selling currency and recalculate cart & product prices')}
                >
                  {currencies.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.name} ({c.symbol}) • {tr('صرف:', 'Rate:')} {c.exchangeRate}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Active Warehouse Dropdown */}
            {warehouses.length > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl neu-pressed text-xs border border-indigo-100 shrink-0">
                <Building2 className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span className="text-slate-400 text-[10px] hidden md:inline">{tr('صرف من:', 'From WH:')}</span>
                <select
                  value={selectedPosWarehouseId}
                  onChange={(e) => setSelectedPosWarehouseId(e.target.value)}
                  className="bg-transparent font-bold text-indigo-700 outline-none text-xs cursor-pointer"
                  title={tr('المستودع الذي يتم خصم البضاعة المباعة منه', 'Warehouse from which sold items are deducted')}
                >
                  {warehouses.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.code}) {w.isDefault ? tr('• الافتراضي', '• Default') : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Product Cards Grid (Guaranteed Visible on Mobile & Desktop) */}
        <div className="flex-1 min-h-[320px] md:min-h-0 overflow-y-auto pt-2 pr-0.5 sm:pr-1 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2 sm:gap-2.5 lg:gap-3 content-start">
          {filteredProducts.map((product) => {
            const isOutOfStock = product.stock <= 0;
            const isLowStock = product.stock <= product.minStockAlert && !isOutOfStock;
            const cartItem = cart.find((item) => item.product.id === product.id);
            const addedQty = cartItem ? cartItem.quantity : 0;

            return (
              <div
                key={product.id}
                onClick={() => !isOutOfStock && addToCart(product)}
                className={`neu-button rounded-2xl p-2.5 sm:p-3 flex flex-col justify-between cursor-pointer transition-all relative overflow-hidden group select-none ${
                  isOutOfStock
                    ? 'opacity-40 cursor-not-allowed'
                    : addedQty > 0
                    ? 'ring-2 ring-blue-500 shadow-md -translate-y-0.5'
                    : 'hover:-translate-y-1 active:scale-[0.98]'
                }`}
              >
                {/* Floating Cart Quantity Badge on Top of Product Button */}
                {addedQty > 0 && (
                  <div className={`absolute top-2 ${dir === 'rtl' ? 'left-2' : 'right-2'} z-10 flex items-center gap-1 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full neu-button-primary text-white text-[10px] sm:text-[11px] font-black shadow-lg`}>
                    <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
                    <span className="tabular-nums">{tr(`بالسلة: ${addedQty}`, `In Cart: ${addedQty}`)}</span>
                  </div>
                )}

                {/* Product Image / Icon Fallback */}
                <div className="w-full h-20 sm:h-24 rounded-xl bg-slate-100 flex items-center justify-center mb-2 overflow-hidden border border-slate-200/50 relative">
                  {product.image ? (
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="text-center p-2">
                      <Tag className="w-5 h-5 sm:w-6 sm:h-6 mx-auto text-blue-500 group-hover:scale-110 transition-transform" />
                      <span className="text-[10px] text-slate-500 font-semibold block mt-1 truncate max-w-full">{product.category}</span>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 text-xs leading-snug line-clamp-2">
                    {product.name}
                  </h4>
                  <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                    {product.barcode}
                  </span>
                </div>

                <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-200/60">
                  <div>
                    <span className="text-xs font-extrabold text-blue-600 tabular-nums">
                      {formatCurrency(product.salePrice)}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full tabular-nums ${
                      isOutOfStock
                        ? 'bg-red-100 text-red-600'
                        : isLowStock
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-50 text-emerald-700'
                    }`}
                  >
                    {isOutOfStock ? tr('نافد', 'Out of Stock') : `${product.stock} ${product.unit}`}
                  </span>
                </div>

                {/* Quick Quantity Control Bar on Product Card when Added to Cart */}
                {addedQty > 0 && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="mt-2 pt-2 border-t border-blue-200/60 flex items-center justify-between gap-1.5"
                  >
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (addedQty <= 1) {
                          removeFromCart(product.id);
                        } else {
                          updateCartQty(product.id, addedQty - 1);
                        }
                      }}
                      className="w-6 h-6 rounded-lg bg-red-100 hover:bg-red-200 text-red-700 flex items-center justify-center font-bold text-xs transition-colors cursor-pointer"
                      title={tr('إنقاص الكمية', 'Decrease quantity')}
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-[11px] font-black text-blue-700 tabular-nums">
                      {addedQty} {product.unit} {tr('بالسلة', 'in cart')}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (addedQty < product.stock) {
                          addToCart(product, 1);
                        } else {
                          showToast(tr('تم الوصول للحد الأقصى للمخزون المتاح', 'Maximum available stock reached'), 'error');
                        }
                      }}
                      className="w-6 h-6 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-700 flex items-center justify-center font-bold text-xs transition-colors cursor-pointer"
                      title={tr('زيادة الكمية', 'Increase quantity')}
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          {filteredProducts.length === 0 && (
            <div className="col-span-full py-16 text-center text-slate-400 text-xs">
              {tr('لا توجد منتجات تطابق البحث أو التصنيف المحدد', 'No products match the current search or category')}
            </div>
          )}
        </div>
      </div>

      {/* CART & CHECKOUT TERMINAL PANEL */}
      <div
        ref={cartPanelRef}
        className={`${mobilePosView === 'products' ? 'hidden md:flex' : 'flex'} w-full md:w-80 lg:w-88 xl:w-96 2xl:w-[410px] shrink-0 flex-col md:min-h-0 neu-card rounded-3xl p-3.5 lg:p-4 shadow-xl transition-all duration-300 ${
          isScanPulse ? 'ring-2 ring-emerald-500 shadow-emerald-500/30' : ''
        }`}
      >
        {/* Customer Selector & Cart Controls */}
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/60">
          <div className="flex-1 flex items-center gap-1.5 min-w-0">
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="neu-input flex-1 min-w-0 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-700 truncate"
            >
              <option value="">{tr('عميل نقدي (Walk-in Customer)', 'Walk-in Customer (Cash)')}</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => {
                setCustomerSearchQuery('');
                setHighlightedCustIndex(0);
                setIsCustomerSearchOpen(true);
                setTimeout(() => customerSearchInputRef.current?.focus(), 50);
              }}
              title={tr('البحث السريع عن عميل بالاسم أو الهاتف (F4)', 'Quick Search Customer (F4)')}
              className="neu-button px-2 py-1.5 rounded-xl text-blue-600 hover:text-blue-700 cursor-pointer shrink-0 flex items-center gap-1 text-[10px] font-bold"
            >
              <Search className="w-3.5 h-3.5" />
              <kbd className="font-mono text-[9px] bg-blue-100 text-blue-700 px-1 rounded">F4</kbd>
            </button>
            <button
              type="button"
              onClick={() => setIsQuickAddCustOpen(true)}
              title={tr('إضافة عميل جديد سريع', 'Quick Add Customer')}
              className="neu-button p-1.5 rounded-xl text-emerald-600 hover:text-emerald-700 cursor-pointer shrink-0"
            >
              <UserPlus className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1">
            {/* Hold Cart */}
            <button
              onClick={() => holdCurrentCart()}
              title={tr('تعليق السلة الحالية (F9)', 'Hold Current Cart (F9)')}
              disabled={cart.length === 0}
              className="neu-button p-1.5 rounded-xl text-slate-600 hover:text-amber-600 disabled:opacity-40 cursor-pointer flex items-center gap-0.5"
            >
              <Pause className="w-3.5 h-3.5" />
              <kbd className="text-[9px] font-mono text-slate-400">F9</kbd>
            </button>

            {/* View Held Carts */}
            {heldCarts.length > 0 && (
              <button
                onClick={() => setIsHeldCartOpen(!isHeldCartOpen)}
                className="relative neu-button px-2 py-1.5 rounded-xl text-xs font-bold text-amber-600 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 inline mr-0.5" />
                <span>{heldCarts.length}</span>
              </button>
            )}

            {/* Toggle On-Screen Numpad inside Cart Header */}
            <button
              type="button"
              onClick={() => {
                if (isNumpadOpen) {
                  setIsNumpadOpen(false);
                } else {
                  openNumpadFor(cart.length > 0 ? 'qty' : 'paid');
                }
              }}
              title={tr('لوحة مفاتيح رقمية لإدخال الكمية أو السعر أو الخصم باللمس', 'On-screen Touch Numpad')}
              className={`p-1.5 rounded-xl cursor-pointer flex items-center gap-1 text-[10px] font-extrabold transition-all ${
                isNumpadOpen
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'neu-button text-indigo-600 hover:text-indigo-700'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{tr('أرقام', 'Pad')}</span>
            </button>

            {/* Clear Cart with Confirm */}
            <button
              onClick={handleClearCart}
              title={tr('إفراغ السلة بالكامل (F10)', 'Clear Cart (F10)')}
              disabled={cart.length === 0}
              className="neu-button p-1.5 rounded-xl text-slate-400 hover:text-red-500 disabled:opacity-40 cursor-pointer flex items-center gap-0.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <kbd className="text-[9px] font-mono text-slate-400">F10</kbd>
            </button>
          </div>
        </div>

        {/* Held Carts Dropdown Drawer */}
        {isHeldCartOpen && (
          <div className="p-3 neu-pressed rounded-2xl my-2 space-y-2">
            <span className="text-[11px] font-bold text-slate-600 block">{tr('الفواتير المعلقة:', 'Held Carts:')}</span>
            {heldCarts.map((hc) => (
              <div key={hc.id} className="flex items-center justify-between text-xs bg-white p-2 rounded-xl shadow-sm">
                <div>
                  <span className="font-bold text-slate-800 block">{hc.name}</span>
                  <span className="text-[10px] text-slate-400">{hc.items.length} {tr('أصناف', 'items')} · {hc.date}</span>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => {
                      resumeHeldCart(hc.id);
                      setIsHeldCartOpen(false);
                    }}
                    className="px-2 py-1 bg-emerald-500 text-white rounded-lg text-[10px] font-bold"
                  >
                    {tr('استرجاع', 'Resume')}
                  </button>
                  <button
                    onClick={() => deleteHeldCart(hc.id)}
                    className="p-1 text-red-500 hover:bg-red-50 rounded-lg"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 min-h-[160px] max-h-[320px] md:max-h-none md:min-h-0 overflow-y-auto py-2 pr-1 space-y-2">
          {cart.map((item, idx) => {
            const isSelectedRow =
              (selectedCartIndex >= 0 ? selectedCartIndex : cart.length - 1) === idx;
            return (
              <div
                key={item.product.id}
                onClick={() => setSelectedCartIndex(idx)}
                className={`neu-flat p-2.5 rounded-2xl flex flex-col gap-1.5 text-xs cursor-pointer transition-all ${
                  isSelectedRow
                    ? 'ring-2 ring-blue-500/70 bg-blue-50/40'
                    : 'hover:bg-slate-50/60'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h5 className="font-bold text-slate-800 leading-tight truncate">
                        {item.product.name}
                      </h5>
                      {isSelectedRow && (
                        <span className="px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 font-mono text-[9px] font-bold shrink-0">
                          {tr('محدد • F8 حذف', 'Selected • F8')}
                        </span>
                      )}
                    </div>
                    {/* Direct Editable Unit Price with Up/Down Arrows (▲ / ▼) & Numpad Sync */}
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="mt-1 flex items-center gap-1.5 flex-wrap"
                    >
                      <span className="text-[10px] font-semibold text-slate-500">
                        {tr('السعر:', 'Price:')}
                      </span>
                      <NumberStepperInput
                        size="xs"
                        min={0}
                        step={1}
                        value={item.price}
                        onChange={(newPrice) => {
                          updateCartPrice(item.product.id, newPrice);
                          if (isNumpadOpen && numpadMode === 'price' && isSelectedRow) {
                            setNumpadBuffer(newPrice === 0 ? '' : String(newPrice));
                          }
                        }}
                        onFocus={() => {
                          setSelectedCartIndex(idx);
                          if (isNumpadOpen) {
                            setNumpadMode('price');
                            setNumpadBuffer(item.price === 0 ? '' : String(item.price));
                          }
                        }}
                        className="w-28 bg-white/95"
                        inputClassName="text-center font-bold text-blue-700"
                        title={tr('اكتب السعر مباشرة أو استخدم الأسهم (▲ / ▼) لزيادة وإنقاص السعر', 'Type price or use Up/Down arrows')}
                      />
                      <span className="text-[10px] text-slate-400">
                        {settings.currencySymbol} / {item.product.unit}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          openNumpadFor('price', idx);
                        }}
                        className={`p-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                          isSelectedRow && isNumpadOpen && numpadMode === 'price'
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-slate-200/70 hover:bg-indigo-100 text-slate-600 hover:text-indigo-700'
                        }`}
                        title={tr('فتح لوحة الأرقام للسعر', 'Open Numpad for Price')}
                      >
                        <Calculator className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                  <span className="font-black text-slate-800 tabular-nums shrink-0">
                    {formatCurrency(item.total)}
                  </span>
                </div>

                {/* Quantity Controls (Editable Input + ▲/▼ Arrows + +/- Buttons) & Line Discount */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-200/50 gap-1.5">
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        updateCartQty(item.product.id, item.quantity - 1);
                      }}
                      className="neu-button w-6 h-6 rounded-lg flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                      title={tr('إنقاص الكمية (-)', 'Decrease Qty (-)')}
                    >
                      <Minus className="w-3 h-3" />
                    </button>

                    <NumberStepperInput
                      size="xs"
                      min={1}
                      max={item.product.stock}
                      step={1}
                      fallbackOnBlur={1}
                      value={item.quantity}
                      onChange={(newQty) => {
                        if (newQty >= 1) {
                          updateCartQty(item.product.id, Math.round(newQty));
                        }
                        if (isNumpadOpen && numpadMode === 'qty' && isSelectedRow) {
                          setNumpadBuffer(newQty <= 0 ? '' : String(Math.round(newQty)));
                        }
                      }}
                      onFocus={() => {
                        setSelectedCartIndex(idx);
                        if (isNumpadOpen) {
                          setNumpadMode('qty');
                          setNumpadBuffer(String(item.quantity));
                        }
                      }}
                      className="w-20 bg-white/95"
                      inputClassName="text-center font-extrabold text-slate-800"
                      title={tr('اكتب الكمية أو امسحها بالكامل أو استخدم الأسهم (▲ / ▼)', 'Type quantity, clear digits, or use Up/Down arrows')}
                    />

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        updateCartQty(item.product.id, item.quantity + 1);
                      }}
                      className="neu-button w-6 h-6 rounded-lg flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                      title={tr('زيادة الكمية (+)', 'Increase Qty (+)')}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                    {/* Discount input per line with Up/Down Arrows */}
                    <div className="flex items-center gap-1 text-[10px]">
                      <span className="text-slate-400 hidden sm:inline">{tr('خصم:', 'Disc:')}</span>
                      <NumberStepperInput
                        size="xs"
                        min={0}
                        step={1}
                        inputRef={(el) => {
                          discountInputsRef.current[item.product.id] = el;
                        }}
                        value={item.discount || 0}
                        onChange={(val) => {
                          updateCartDiscount(item.product.id, val);
                          if (isNumpadOpen && numpadMode === 'discount' && isSelectedRow) {
                            setNumpadBuffer(val === 0 ? '' : String(val));
                          }
                        }}
                        onFocus={() => {
                          setSelectedCartIndex(idx);
                          if (isNumpadOpen) {
                            setNumpadMode('discount');
                            setNumpadBuffer(item.discount ? String(item.discount) : '');
                          }
                        }}
                        className="w-20 bg-white/95"
                        inputClassName="text-center font-bold text-emerald-700"
                        title={tr('خصم الصنف (F7) — يدعم المسح والأسهم (▲ / ▼)', 'Line discount (F7) with Up/Down arrows')}
                      />
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFromCart(item.product.id);
                      }}
                      title={tr('حذف المنتج من السلة (F8)', 'Remove product from cart (F8)')}
                      className="text-slate-400 hover:text-red-500 p-1 cursor-pointer flex items-center gap-0.5 shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Barcode className="w-10 h-10 mb-2 opacity-30" />
              <p className="text-xs font-semibold">{tr('السلة فارغة', 'Cart is Empty')}</p>
              <p className="text-[10px] mt-1">{tr('انقر على أي منتج أو امسح الباركود للبدء (F3 للبحث، F4 للعميل، F2 لإتمام البيع)', 'Scan barcode or press F3 to search, F4 for customer, F2 to checkout')}</p>
            </div>
          )}
        </div>

        {/* ON-SCREEN TOUCH NUMPAD PANEL (لوحة مفاتيح رقمية للمس والموبايل) */}
        {isNumpadOpen && (
          <div className="my-2 p-2.5 rounded-2xl bg-slate-900 text-white shadow-xl border border-indigo-500/40 select-none space-y-2">
            {/* Header & Mode Tabs */}
            <div className="flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
                {(
                  [
                    { id: 'qty', label: tr('الكمية', 'Qty') },
                    { id: 'price', label: tr('السعر', 'Price') },
                    { id: 'discount', label: tr('الخصم', 'Disc') },
                    { id: 'paid', label: tr('المدفوع', 'Paid') },
                    { id: 'barcode', label: tr('باركود', 'Barcode') }
                  ] as { id: NumpadMode; label: string }[]
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => openNumpadFor(tab.id)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer whitespace-nowrap ${
                      numpadMode === tab.id
                        ? 'bg-indigo-500 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setIsNumpadOpen(false)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-red-500/80 text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
                title={tr('إغلاق لوحة الأرقام', 'Close Numpad')}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Active Target & Digital Value Screen with Up/Down Arrows (▲ / ▼) */}
            <div className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <span className="text-[10px] text-indigo-400 font-bold block truncate">
                  {numpadMode === 'qty' &&
                    (activeCartItem
                      ? tr(`تعديل كمية: ${activeCartItem.product.name}`, `Qty: ${activeCartItem.product.name}`)
                      : tr('اختر صنفاً لتعديل كميته', 'Select item for Qty'))}
                  {numpadMode === 'price' &&
                    (activeCartItem
                      ? tr(`تعديل سعر الوحدة: ${activeCartItem.product.name}`, `Unit Price: ${activeCartItem.product.name}`)
                      : tr('اختر صنفاً لتعديل سعره', 'Select item for Price'))}
                  {numpadMode === 'discount' &&
                    (activeCartItem
                      ? tr(`خصم الصنف: ${activeCartItem.product.name}`, `Discount: ${activeCartItem.product.name}`)
                      : tr('اختر صنفاً لإضافة خصم', 'Select item for Discount'))}
                  {numpadMode === 'paid' &&
                    (isInstallmentSale
                      ? tr('إدخال الدفعة المقدمة للتقسيط', 'Enter Down Payment')
                      : tr('إدخال المبلغ المستلم من العميل', 'Enter Paid Amount'))}
                  {numpadMode === 'barcode' && tr('اكتب رقم الباركود واضغط (تم ↵)', 'Enter Barcode & press (OK ↵)')}
                </span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <div className="text-left font-mono text-base font-black tabular-nums tracking-wider min-w-[60px] text-right">
                  {numpadBuffer !== '' ? (
                    <span className="text-emerald-400">{numpadBuffer}</span>
                  ) : (
                    <span className="text-slate-600 text-xs">{tr('فارغ', 'Empty')}</span>
                  )}
                  {numpadMode === 'price' || numpadMode === 'discount' || numpadMode === 'paid' ? (
                    <span className="text-[10px] text-slate-400 font-sans mr-1">{settings.currencySymbol}</span>
                  ) : null}
                </div>

                {/* Up / Down Stepper Arrows inside Numpad Display */}
                {numpadMode !== 'barcode' && (
                  <div className="flex flex-col gap-0.5">
                    <button
                      type="button"
                      onClick={() => handleNumpadQuickIncrement(1)}
                      className="px-1.5 py-0.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center cursor-pointer active:scale-95"
                      title={tr('سهم زيادة الرقم (+1)', 'Increase (+1)')}
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNumpadQuickIncrement(-1)}
                      className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center cursor-pointer active:scale-95"
                      title={tr('سهم إنقاص الرقم (-1)', 'Decrease (-1)')}
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Presets Row */}
            {numpadMode !== 'barcode' && (
              <div className="grid grid-cols-5 gap-1">
                <button
                  type="button"
                  onClick={() => handleNumpadQuickIncrement(-1)}
                  className="py-1 rounded-lg bg-rose-900/60 hover:bg-rose-600 text-rose-200 hover:text-white text-[10px] font-extrabold transition-colors cursor-pointer tabular-nums"
                >
                  -1 ▼
                </button>
                {[1, 5, 10, 50].map((inc) => (
                  <button
                    key={inc}
                    type="button"
                    onClick={() => handleNumpadQuickIncrement(inc)}
                    className="py-1 rounded-lg bg-slate-800 hover:bg-indigo-600/80 text-indigo-300 hover:text-white text-[10px] font-extrabold transition-colors cursor-pointer tabular-nums"
                  >
                    +{inc} ▲
                  </button>
                ))}
              </div>
            )}

            {/* Touch Keypad Grid */}
            <div className="grid grid-cols-4 gap-1.5" dir="ltr">
              {['7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleNumpadKeyPress(digit)}
                  className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-black text-sm tabular-nums transition-all cursor-pointer shadow-xs"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleNumpadKeyPress('BACKSPACE')}
                className="py-2 rounded-xl bg-amber-600/90 hover:bg-amber-600 active:scale-95 text-white font-black text-xs flex items-center justify-center transition-all cursor-pointer shadow-xs"
                title={tr('مسح آخر رقم', 'Backspace')}
              >
                <Delete className="w-4 h-4" />
              </button>

              {['4', '5', '6'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleNumpadKeyPress(digit)}
                  className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-black text-sm tabular-nums transition-all cursor-pointer shadow-xs"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleNumpadKeyPress('C')}
                className="py-2 rounded-xl bg-red-600/90 hover:bg-red-600 active:scale-95 text-white font-black text-xs transition-all cursor-pointer shadow-xs"
                title={tr('مسح الكل (تصفير)', 'Clear')}
              >
                C
              </button>

              {['1', '2', '3'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleNumpadKeyPress(digit)}
                  className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-black text-sm tabular-nums transition-all cursor-pointer shadow-xs"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  const modes: NumpadMode[] = ['qty', 'price', 'discount', 'paid', 'barcode'];
                  const next = modes[(modes.indexOf(numpadMode) + 1) % modes.length];
                  openNumpadFor(next);
                }}
                className="py-2 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 active:scale-95 text-white font-extrabold text-[10px] transition-all cursor-pointer shadow-xs"
                title={tr('تبديل الحقل التالي (الكمية / السعر / الخصم / المدفوع)', 'Next Field')}
              >
                {tr('التالي ⇄', 'Next ⇄')}
              </button>

              <button
                type="button"
                onClick={() => handleNumpadKeyPress('0')}
                className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-black text-sm tabular-nums transition-all cursor-pointer shadow-xs"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => handleNumpadKeyPress('00')}
                className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-black text-xs tabular-nums transition-all cursor-pointer shadow-xs"
              >
                00
              </button>
              <button
                type="button"
                onClick={() => handleNumpadKeyPress('.')}
                disabled={numpadMode === 'qty' || numpadMode === 'barcode'}
                className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-35 active:scale-95 text-white font-black text-base tabular-nums transition-all cursor-pointer shadow-xs"
              >
                .
              </button>
              <button
                type="button"
                onClick={() => handleNumpadKeyPress('ENTER')}
                className="py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs flex items-center justify-center gap-0.5 transition-all cursor-pointer shadow-md shadow-emerald-600/30"
              >
                <span>{tr('تم ↵', 'OK ↵')}</span>
              </button>
            </div>
          </div>
        )}

        {/* Calculation Totals */}
        <div className="pt-3 border-t border-white/60 space-y-1.5 text-xs">
          <div className="flex justify-between text-slate-500">
            <span>{tr('المجموع الصافي:', 'Subtotal:')}</span>
            <span className="tabular-nums font-semibold">{formatCurrency(cartSubtotal)}</span>
          </div>
          {cartDiscount > 0 && (
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>{tr('إجمالي الخصم:', 'Total Discount:')}</span>
              <span className="tabular-nums">-{formatCurrency(cartDiscount)}</span>
            </div>
          )}
          <div className="flex items-center justify-between text-slate-600 gap-2 py-0.5">
            <span className="font-semibold">
              {tr('الضريبة المضافة (%):', 'VAT (%):')}
            </span>
            <div className="flex items-center gap-2">
              <NumberStepperInput
                size="xs"
                min={0}
                max={100}
                step={1}
                value={Number(settings.vatPercentage) > 0 ? Number(settings.vatPercentage) : 0}
                onChange={(val) => {
                  const cleanVal = Math.max(0, Number(val) || 0);
                  updateSettings({ vatPercentage: cleanVal });
                }}
                placeholder="0"
                className="w-20 bg-white"
                inputClassName="text-center font-bold text-slate-800"
              />
              {cartTax > 0 ? (
                <span className="tabular-nums font-bold text-amber-700">
                  +{formatCurrency(cartTax)}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400 font-semibold">
                  {tr('بدون ضريبة (0)', 'No VAT (0)')}
                </span>
              )}
            </div>
          </div>
          <div className="flex justify-between text-base font-black text-slate-800 pt-1 border-t border-slate-200">
            <span>{tr('الإجمالي النهائي:', 'Grand Total:')}</span>
            <span className="tabular-nums text-blue-600">{formatCurrency(cartTotal)}</span>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="pt-3 space-y-2">
          <div className="grid grid-cols-4 gap-1.5">
            <button
              onClick={() => {
                setIsInstallmentSale(false);
                setPaymentMethod('cash');
                setPaidAmount(cartTotal);
              }}
              className={`py-2 rounded-xl flex flex-col items-center gap-1 text-[11px] font-bold cursor-pointer transition-all ${
                !isInstallmentSale && paymentMethod === 'cash' ? 'neu-pressed text-emerald-600' : 'neu-button text-slate-600'
              }`}
            >
              <Banknote className="w-4 h-4" />
              <span>{tr('نقداً', 'Cash')}</span>
            </button>
            <button
              onClick={() => {
                setIsInstallmentSale(false);
                setPaymentMethod('card');
                setPaidAmount(cartTotal);
              }}
              className={`py-2 rounded-xl flex flex-col items-center gap-1 text-[11px] font-bold cursor-pointer transition-all ${
                !isInstallmentSale && paymentMethod === 'card' ? 'neu-pressed text-blue-600' : 'neu-button text-slate-600'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>{tr('شبكة', 'Card')}</span>
            </button>
            <button
              onClick={() => {
                setIsInstallmentSale(false);
                setPaymentMethod('split');
                setPaidAmount(Number((cartTotal / 2).toFixed(2)));
              }}
              className={`py-2 rounded-xl flex flex-col items-center gap-1 text-[11px] font-bold cursor-pointer transition-all ${
                !isInstallmentSale && paymentMethod === 'split' ? 'neu-pressed text-purple-600' : 'neu-button text-slate-600'
              }`}
            >
              <Split className="w-4 h-4" />
              <span>{tr('دفعة وآجل', 'Split')}</span>
            </button>
            <button
              onClick={() => {
                setIsInstallmentSale(false);
                setPaymentMethod('credit');
                setPaidAmount(0);
              }}
              className={`py-2 rounded-xl flex flex-col items-center gap-1 text-[11px] font-bold cursor-pointer transition-all ${
                !isInstallmentSale && paymentMethod === 'credit' ? 'neu-pressed text-amber-600' : 'neu-button text-slate-600'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span>{tr('آجل', 'Credit')}</span>
            </button>
          </div>

          {/* Installment Switcher */}
          <div className="flex items-center justify-between p-2 rounded-xl neu-flat text-xs">
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
              <input
                type="checkbox"
                checked={isInstallmentSale}
                onChange={(e) => setIsInstallmentSale(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded"
              />
              <CalendarClock className="w-3.5 h-3.5 text-blue-600" />
              <span>{tr('بيع بالتقسيط ومتابعة الأقساط', 'Installment Plan Sale')}</span>
            </label>
          </div>

          {isInstallmentSale ? (
            <div className="neu-pressed p-2.5 rounded-2xl space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span>{tr('الدفعة المقدمة:', 'Down Payment:')}</span>
                <NumberStepperInput
                  size="sm"
                  min={0}
                  max={cartTotal}
                  step={10}
                  value={downPayment}
                  onChange={(val) => setDownPayment(val)}
                  className="w-28 bg-white"
                  inputClassName="text-left font-bold"
                />
              </div>

              {/* Interest input (percentage only, from Settings, calculated from remaining amount) */}
              <div className="flex items-center justify-between">
                <div className="text-right">
                  <span className="block font-medium">{tr('نسبة فائدة التقسيط (%):', 'Installment Interest (%):')}</span>
                  <span className="text-[10px] text-amber-600 font-bold block">{tr('(تحتسب من الباقي فقط)', '(Calculated on remaining balance)')}</span>
                </div>
                <div className="w-28">
                  <NumberStepperInput
                    size="sm"
                    min={0}
                    max={100}
                    step={1}
                    value={installmentInterestPercent}
                    onChange={(val) => setInstallmentInterestPercent(val)}
                    placeholder="10"
                    className="w-full bg-white"
                    inputClassName="text-left font-bold text-amber-800"
                  />
                </div>
              </div>

              {/* Dynamic Interest Detail from Remaining */}
              <div className="bg-amber-50/90 p-2 rounded-xl border border-amber-200/70 text-[11px] space-y-1 text-amber-900">
                <div className="flex justify-between font-semibold">
                  <span>{tr('المبلغ الباقي بعد المقدم', 'Remaining after Down Payment')} ({formatCurrency(cartTotal)} - {formatCurrency(downPayment)}):</span>
                  <span className="tabular-nums font-bold text-slate-800">{formatCurrency(remainingBeforeInterest)}</span>
                </div>
                <div className="flex justify-between font-bold text-amber-900">
                  <span>{tr(`قيمة الفائدة المحسوبة من الباقي (${installmentInterestPercent}%):`, `Interest on Remaining (${installmentInterestPercent}%):`)}</span>
                  <span className="tabular-nums font-black text-amber-700">+{formatCurrency(posInterestAmount)}</span>
                </div>
                <div className="text-[10px] text-emerald-800 font-semibold pt-1 border-t border-amber-200/60 flex items-center gap-1">
                  <EyeOff className="w-3 h-3 text-emerald-600 shrink-0" />
                  <span>{tr('مضمون: الفائدة للأقساط فقط ولا تظهر إطلاقاً في فاتورة العميل', 'Guaranteed: Interest applies to installments only and is hidden from receipt')}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span>{tr('عدد الأقساط (أشهر):', 'Number of Months:')}</span>
                <select
                  value={installmentMonths}
                  onChange={(e) => setInstallmentMonths(parseInt(e.target.value) || 3)}
                  className="neu-input px-2 py-1 rounded-lg font-bold"
                >
                  <option value={2}>{tr('شهرين', '2 Months')}</option>
                  <option value={3}>{tr('3 أشهر', '3 Months')}</option>
                  <option value={4}>{tr('4 أشهر', '4 Months')}</option>
                  <option value={6}>{tr('6 أشهر', '6 Months')}</option>
                  <option value={10}>{tr('10 أشهر', '10 Months')}</option>
                  <option value={12}>{tr('12 شهراً', '12 Months')}</option>
                  <option value={24}>{tr('24 شهراً', '24 Months')}</option>
                </select>
              </div>

              <div className="space-y-1 pt-1 border-t border-slate-200 text-xs">
                <div className="flex justify-between text-slate-700">
                  <span>{tr('إجمالي المتبقي المقسط:', 'Total Financed Balance:')}</span>
                  <span className="font-bold tabular-nums text-slate-800">{formatCurrency(remainingWithInterest)}</span>
                </div>
                <div className="flex justify-between text-blue-700 font-bold">
                  <span>{tr('القسط الشهري المطلوب:', 'Monthly Installment:')}</span>
                  <span className="tabular-nums text-sm font-black">
                    {formatCurrency(posMonthlyInstallment)} / {tr('شهر', 'mo')}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[10px] text-slate-500">
                      {paymentMethod === 'split'
                        ? tr('الدفعة المقدمة (المدفوع):', 'Down Payment:')
                        : tr('المبلغ المستلم:', 'Paid Amount:')}
                    </span>
                    <button
                      type="button"
                      onClick={() => openNumpadFor('paid')}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-0.5 cursor-pointer"
                      title={tr('إدخال المبلغ المستلم بلوحة الأرقام', 'Enter paid amount via Numpad')}
                    >
                      <Calculator className="w-3 h-3" />
                      <span>{tr('لوحة أرقام', 'Numpad')}</span>
                    </button>
                  </div>
                  <NumberStepperInput
                    size="sm"
                    min={0}
                    step={5}
                    value={paymentMethod === 'credit' ? 0 : paidAmount}
                    onChange={(val) => setPaidAmount(val)}
                    className="w-full"
                    inputClassName="font-bold text-slate-800"
                  />
                </div>
                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 block mb-0.5">
                    {(paymentMethod === 'credit' || paidAmount < cartTotal)
                      ? tr('المتبقي آجل على العميل:', 'Remaining Credit Due:')
                      : tr('الباقي للعميل:', 'Change Due:')}
                  </span>
                  <div
                    className={`neu-pressed px-3 py-1.5 rounded-xl text-xs font-bold tabular-nums ${
                      paymentMethod === 'credit' || paidAmount < cartTotal ? 'text-red-600' : 'text-emerald-600'
                    }`}
                  >
                    {paymentMethod === 'credit'
                      ? formatCurrency(cartTotal)
                      : paidAmount < cartTotal
                      ? formatCurrency(Math.max(0, cartTotal - paidAmount))
                      : formatCurrency(changeAmount)}
                  </div>
                </div>
              </div>

              {/* Live Payment Breakdown Summary Box in POS */}
              <div
                className={`p-2 rounded-xl border text-[11px] space-y-1 ${
                  paymentMethod === 'credit'
                    ? 'bg-red-50/90 border-red-200 text-red-900'
                    : paymentMethod === 'split' || paidAmount < cartTotal
                    ? 'bg-amber-50/90 border-amber-200 text-amber-900'
                    : paymentMethod === 'card'
                    ? 'bg-blue-50/90 border-blue-200 text-blue-900'
                    : 'bg-emerald-50/90 border-emerald-200 text-emerald-900'
                }`}
              >
                <div className="font-extrabold flex items-center justify-between border-b border-current/15 pb-1">
                  <span>{tr('تفصيل نظام السداد في الفاتورة:', 'Invoice Payment Breakdown:')}</span>
                  <span>
                    {paymentMethod === 'credit'
                      ? tr('بيع آجل بالكامل', 'Full Credit')
                      : paymentMethod === 'split' || paidAmount < cartTotal
                      ? tr('دفعة مقدمة والباقي آجل', 'Down Payment + Credit')
                      : paymentMethod === 'card'
                      ? tr('بطاقة شبكة / تحويل بنكي', 'Card / Bank')
                      : tr('سداد نقدي بالكامل (كاش)', 'Full Cash')}
                  </span>
                </div>
                <div className="flex justify-between font-bold tabular-nums pt-0.5">
                  <span>
                    {tr('الإجمالي:', 'Total:')} {formatCurrency(cartTotal)}
                  </span>
                  <span>
                    {tr('المدفوع:', 'Paid:')}{' '}
                    {formatCurrency(
                      paymentMethod === 'credit' ? 0 : Math.min(paidAmount, cartTotal)
                    )}
                  </span>
                  <span>
                    {tr('المتبقي آجل:', 'Credit Due:')}{' '}
                    {formatCurrency(
                      paymentMethod === 'credit'
                        ? cartTotal
                        : Math.max(0, cartTotal - paidAmount)
                    )}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Checkout Button (F2) */}
          <button
            onClick={handleCheckout}
            disabled={cart.length === 0}
            className="neu-button-primary w-full py-3 rounded-2xl flex items-center justify-center gap-2 text-xs font-black shadow-lg disabled:opacity-40 cursor-pointer"
            title={tr('إتمام البيع وطباعة الفاتورة (اختصار لوحة المفاتيح: F2)', 'Complete Sale & Print Invoice (Shortcut: F2)')}
          >
            <Printer className="w-4 h-4" />
            <span>{t('payAndPrint')} ({formatCurrency(cartTotal)})</span>
            <kbd className="hidden sm:inline-block px-2 py-0.5 rounded-lg bg-white/25 text-white font-mono text-[11px] font-black">
              F2
            </kbd>
          </button>
        </div>
      </div>

      {/* FLOATING MOBILE STICKY CART & QUICK CHECKOUT BAR */}
      {cart.length > 0 && mobilePosView !== 'cart' && (
        <div className="md:hidden fixed bottom-2.5 inset-x-3 z-40 rounded-2xl bg-slate-900/95 text-white p-2.5 shadow-2xl border border-white/15 backdrop-blur-md flex items-center justify-between gap-2">
          <div
            onClick={() => {
              setMobilePosView('cart');
              cartPanelRef.current?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
              {totalCartQty}
            </div>
            <div className="min-w-0">
              <span className="text-[10px] text-slate-300 block leading-tight">
                {tr(`إجمالي السلة (${cart.length} صنف)`, `Cart Total (${cart.length} items)`)}
              </span>
              <span className="text-sm font-black text-emerald-400 tabular-nums block truncate">
                {formatCurrency(cartTotal)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setMobilePosView('cart')}
              className="px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-[11px] font-bold cursor-pointer"
            >
              {tr('مراجعة السلة', 'View Cart')}
            </button>
            <button
              type="button"
              onClick={handleCheckout}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] font-black flex items-center gap-1 shadow-md cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{tr('بيع فوري', 'Checkout')}</span>
            </button>
          </div>
        </div>
      )}

      {/* Interactive Customer Search & Selection Modal (F4) */}
      {isCustomerSearchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="neu-card rounded-3xl w-full max-w-lg p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <span>{tr('البحث السريع عن عميل', 'Quick Customer Search')}</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-mono text-[10px]">F4</kbd>
                  </h3>
                  <p className="text-[10px] text-slate-500">
                    {tr('استخدم الأسهم (↑ ↓) للتنقل وزر (Enter) لاختيار العميل بدون ماوس', 'Use Arrow keys (↑ ↓) and press Enter to select customer without mouse')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCustomerSearchOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
                <input
                  ref={customerSearchInputRef}
                  type="text"
                  autoFocus
                  value={customerSearchQuery}
                  onChange={(e) => setCustomerSearchQuery(e.target.value)}
                  placeholder={tr('اكتب اسم العميل أو رقم الهاتف للبحث الفوري...', 'Type customer name or phone number...')}
                  className="neu-input w-full pr-9 pl-3 py-2.5 rounded-xl text-xs font-bold text-slate-800"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCustomerSearchOpen(false);
                  setIsQuickAddCustOpen(true);
                }}
                className="neu-button-primary px-3 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{tr('+ عميل جديد', '+ New')}</span>
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1">
              {/* Option 0: Walk-in Cash Customer */}
              <div
                onClick={() => {
                  setSelectedCustomerId('');
                  setIsCustomerSearchOpen(false);
                  showToast(tr('تم اختيار: عميل نقدي (Walk-in Customer)', 'Selected: Walk-in Cash Customer'), 'success');
                  barcodeInputRef.current?.focus();
                }}
                className={`p-2.5 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-all ${
                  highlightedCustIndex === 0
                    ? 'bg-blue-600 text-white font-bold shadow-md'
                    : 'neu-flat text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>👤</span>
                  <span>{tr('عميل نقدي عام (Walk-in Customer)', 'Walk-in Customer (Cash)')}</span>
                </div>
                <span className="text-[10px] opacity-80 font-mono">Enter ↵</span>
              </div>

              {filteredCustomersForModal.map((c, idx) => {
                const isHighlighted = highlightedCustIndex === idx + 1;
                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      setSelectedCustomerId(c.id);
                      setIsCustomerSearchOpen(false);
                      showToast(tr(`تم اختيار العميل: ${c.name}`, `Selected customer: ${c.name}`), 'success');
                      barcodeInputRef.current?.focus();
                    }}
                    className={`p-2.5 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-all ${
                      isHighlighted
                        ? 'bg-blue-600 text-white font-bold shadow-md'
                        : 'neu-flat text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div>
                      <div className="font-bold">{c.name}</div>
                      <div className={`text-[10px] ${isHighlighted ? 'text-blue-100' : 'text-slate-400'}`}>
                        {tr('هاتف:', 'Phone:')} {c.phone}
                      </div>
                    </div>
                    <div className="text-left">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isHighlighted
                            ? 'bg-white/20 text-white'
                            : c.balance > 0
                            ? 'bg-red-100 text-red-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {tr('الرصيد:', 'Bal:')} {formatCurrency(c.balance)}
                      </span>
                    </div>
                  </div>
                );
              })}

              {filteredCustomersForModal.length === 0 && (
                <div className="py-6 text-center text-xs text-slate-400">
                  {tr('لا يوجد عميل مطابق للبحث', 'No matching customer found')}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Keyboard Shortcuts Reference Modal (F1) */}
      {isShortcutsHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="neu-card rounded-3xl w-full max-w-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-slate-800 text-white flex items-center justify-center">
                  <Keyboard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">
                    {tr('دليل اختصارات لوحة المفاتيح (العمل السريع بدون ماوس)', 'Keyboard Shortcuts Guide (Mouse-Free POS)')}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {tr('جميع الاختصارات تعمل مباشرة أثناء البيع لتسريع عمل الكاشير', 'All shortcuts work directly during sales for rapid checkout')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShortcutsHelpOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {[
                { key: 'F2', label: tr('إتمام البيع وحفظ وطباعة الفاتورة', 'Complete Sale & Print Invoice'), color: 'bg-emerald-600 text-white' },
                { key: 'F4', label: tr('البحث عن عميل واختياره بالأسهم', 'Search & Select Customer'), color: 'bg-blue-600 text-white' },
                { key: 'F8', label: tr('حذف المنتج المحدد أو الأخير من السلة', 'Delete Selected/Last Product'), color: 'bg-red-600 text-white' },
                { key: 'F3', label: tr('التركيز على حقل الباركود / بحث الأصناف', 'Focus Barcode / Product Search'), color: 'bg-slate-800 text-white' },
                { key: 'F6', label: tr('تبديل طريقة الدفع (نقداً / شبكة / آجل)', 'Cycle Payment Method'), color: 'bg-purple-600 text-white' },
                { key: 'F7', label: tr('تعديل خصم الصنف المحدد في السلة', 'Edit Selected Item Discount'), color: 'bg-amber-600 text-white' },
                { key: 'F9', label: tr('تعليق الفاتورة الحالية أو استرجاع معلقة', 'Hold or Recall Invoice'), color: 'bg-indigo-600 text-white' },
                { key: 'F10', label: tr('إفراغ السلة بالكامل', 'Clear Shopping Cart'), color: 'bg-rose-600 text-white' },
                { key: '↑ / ↓', label: tr('التنقل بين أصناف السلة لتحديد منتج', 'Navigate Cart Items Up/Down'), color: 'bg-slate-700 text-white' },
                { key: '+ / -', label: tr('زيادة أو إنقاص كمية الصنف المحدد', 'Increase / Decrease Item Qty'), color: 'bg-teal-600 text-white' },
                { key: 'Enter', label: tr('إدراج الصنف من بحث الباركود أو تأكيد العميل', 'Add Searched Item / Confirm'), color: 'bg-slate-700 text-white' },
                { key: 'Esc', label: tr('إغلاق النوافذ المنبثقة والعودة للباركود', 'Close Modals & Focus Barcode'), color: 'bg-slate-500 text-white' }
              ].map((sc) => (
                <div key={sc.key} className="neu-flat p-2.5 rounded-2xl flex items-center justify-between gap-2">
                  <span className="font-bold text-slate-700">{sc.label}</span>
                  <kbd className={`px-2.5 py-1 rounded-xl font-mono text-[11px] font-black shrink-0 shadow-xs ${sc.color}`}>
                    {sc.key}
                  </kbd>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsShortcutsHelpOpen(false)}
                className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold cursor-pointer"
              >
                {tr('حسناً، فهمت (Esc)', 'Got it (Esc)')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Add Product Modal (Opens after scanning unknown barcode or clicking Add Item) */}
      {isQuickAddProdOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">
                    {tr('إضافة صنف جديد بعد مسح الباركود', 'Add New Product After Barcode Scan')}
                  </h3>
                  <p className="text-[10px] text-slate-500">
                    {tr('اختر نوع المنتج (غذاء، مشروبات، ...) وسيتم حفظه وإضافته للسلة فوراً', 'Select product type (Food, Drinks, ...) to save and add to cart')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsQuickAddProdOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickProduct} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {tr('الباركود الممسوح:', 'Scanned Barcode:')}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="رقم الباركود..."
                    value={quickProdBarcode}
                    onChange={(e) => setQuickProdBarcode(e.target.value)}
                    className="neu-input flex-1 px-3 py-2 rounded-xl font-mono font-bold text-blue-800"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setMobileScannerTarget('quickProd');
                      setIsMobileScannerOpen(true);
                    }}
                    className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 cursor-pointer shrink-0 shadow-xs"
                    title={tr('مسح باركود الصنف الجديد بكاميرا الموبايل أو اللاب', 'Scan new product barcode with camera')}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{tr('مسح الباركود', 'Scan')}</span>
                  </button>
                </div>
              </div>

              {/* Product Type / Category ComboBox (كومبوبوكس نوع المنتج: غذاء، مشروبات، ...) */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {tr('نوع المنتج / التصنيف (ComboBox):', 'Product Type / Category:')}
                </label>
                <select
                  value={quickProdCategory}
                  onChange={(e) => setQuickProdCategory(e.target.value)}
                  className="neu-input w-full px-3 py-2.5 rounded-xl font-extrabold text-slate-800 cursor-pointer border border-blue-200/80"
                >
                  {allProductTypeOptions.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                  <option value="__custom__">{tr('+ نوع آخر (كتابة نوع جديد...)', '+ Other (Type custom category...)')}</option>
                </select>

                {/* Quick 1-Tap Category Chips */}
                <div className="flex items-center gap-1.5 mt-1.5 overflow-x-auto pb-1 no-scrollbar">
                  {['غذاء', 'مشروبات', 'ألبان وأجبان', 'حلويات وسناكس', 'منظفات وعناية منزلية', 'عام'].map((preset) => (
                    <button
                      type="button"
                      key={preset}
                      onClick={() => setQuickProdCategory(preset)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap cursor-pointer transition-all ${
                        quickProdCategory === preset
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'bg-slate-200/70 text-slate-700 hover:bg-slate-300/70'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>

                {quickProdCategory === '__custom__' && (
                  <input
                    type="text"
                    required
                    placeholder={tr('اكتب نوع المنتج الجديد (مثال: مجمدات، عطارة...)', 'Enter custom product type...')}
                    value={quickProdCustomCategory}
                    onChange={(e) => setQuickProdCustomCategory(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold mt-2 border border-blue-300"
                  />
                )}
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {tr('اسم الصنف:', 'Product Name:')}
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="مثال: عصير برتقال طبيعي / أرز مصري 1 كجم..."
                  value={quickProdName}
                  onChange={(e) => setQuickProdName(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {tr(`سعر البيع (${settings.currencySymbol}):`, `Sale Price (${settings.currencySymbol}):`)}
                  </label>
                  <NumberStepperInput
                    min={0}
                    step={1}
                    required
                    value={quickProdSalePrice}
                    onChange={(val) => setQuickProdSalePrice(val)}
                    className="w-full"
                    inputClassName="font-bold text-blue-600"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {tr(`سعر التكلفة (${settings.currencySymbol}):`, `Cost Price (${settings.currencySymbol}):`)}
                  </label>
                  <NumberStepperInput
                    min={0}
                    step={1}
                    value={quickProdCostPrice}
                    onChange={(val) => setQuickProdCostPrice(val)}
                    className="w-full"
                    inputClassName="font-semibold text-slate-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {tr('وحدة القياس:', 'Unit:')}
                  </label>
                  <select
                    value={quickProdUnit}
                    onChange={(e) => setQuickProdUnit(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold text-slate-700 cursor-pointer"
                  >
                    {DEFAULT_PRODUCT_UNITS.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {tr('الكمية المتوفرة بالمخزن:', 'Initial Stock:')}
                  </label>
                  <NumberStepperInput
                    min={1}
                    step={1}
                    fallbackOnBlur={1}
                    value={quickProdStock}
                    onChange={(val) => setQuickProdStock(Math.round(val))}
                    className="w-full"
                    inputClassName="font-bold text-emerald-700"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200/60">
                <button
                  type="button"
                  onClick={() => setIsQuickAddProdOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-semibold text-slate-600 cursor-pointer"
                >
                  {tr('إلغاء', 'Cancel')}
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  {tr('حفظ الصنف وإدراجه بالسلة', 'Save & Add to Cart')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Add Customer Modal */}
      {isQuickAddCustOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-800 text-sm">إضافة عميل جديد سريع</h3>
            <form onSubmit={handleSaveQuickCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">اسم العميل:</label>
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="الاسم الكامل للعميل..."
                  value={quickCustName}
                  onChange={(e) => setQuickCustName(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">رقم الهاتف / الجوال:</label>
                <input
                  type="tel"
                  required
                  placeholder="05XXXXXXXX..."
                  value={quickCustPhone}
                  onChange={(e) => setQuickCustPhone(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsQuickAddCustOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-semibold text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  حفظ واختيار العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Recent Invoices Modal */}
      {isRecentInvoicesOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/60 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-800 text-sm">سجل فواتير اليوم وإعادة الطباعة</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">يمكنك إعادة طباعة أي فاتورة سابقة أو معاينتها</p>
              </div>
              <button
                onClick={() => setIsRecentInvoicesOpen(false)}
                className="text-slate-400 hover:text-slate-700 font-bold text-xs"
              >
                إغلاق ✕
              </button>
            </div>

            <div className="p-5 flex-1 overflow-y-auto space-y-2.5 text-xs">
              {sales.slice(0, 15).map((sale) => (
                <div
                  key={sale.id}
                  className="neu-flat p-3 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-blue-700">{sale.invoiceNumber}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {sale.paymentMethod === 'cash' ? 'نقداً' : sale.paymentMethod === 'card' ? 'بطاقة' : 'متعدد'}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      العميل: {sale.customerName || 'عميل نقدي'} · {new Date(sale.date).toLocaleTimeString('ar-SA')} ({sale.items.length} أصناف)
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-black text-slate-800 tabular-nums text-sm">
                      {formatCurrency(sale.grandTotal)}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        openInvoiceModal(sale);
                        setIsRecentInvoicesOpen(false);
                      }}
                      className="neu-button px-3 py-1.5 rounded-xl font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>طباعة</span>
                    </button>
                  </div>
                </div>
              ))}

              {sales.length === 0 && (
                <div className="py-12 text-center text-slate-400 text-xs">
                  لا توجد فواتير تم إصدارها اليوم بعد
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mobile Camera Barcode Scanner Modal */}
      <MobileBarcodeScannerModal
        isOpen={isMobileScannerOpen}
        onClose={() => setIsMobileScannerOpen(false)}
        defaultContinuous={mobileScannerTarget === 'cart'}
        title={
          mobileScannerTarget === 'cart'
            ? tr('مسح أصناف الفاتورة بكاميرا الموبايل', 'Scan Cart Items with Mobile Camera')
            : tr('مسح باركود الصنف الجديد بالموبايل', 'Scan New Product Barcode')
        }
        onScan={(scannedCode) => {
          if (mobileScannerTarget === 'quickProd') {
            setQuickProdBarcode(scannedCode);
            showToast(tr(`تم قراءة الباركود: ${scannedCode}`, `Scanned barcode: ${scannedCode}`), 'success');
          } else {
            handleProcessBarcode(scannedCode);
          }
        }}
      />
    </div>
  );
};
