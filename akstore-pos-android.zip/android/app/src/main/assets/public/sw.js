/**
 * AK Store — True Offline-First & Local-DB-First Service Worker (v4.2)
 * - Prevents Chrome's ERR_FAILED ("This site can't be reached") when offline
 * - Strips `response.redirected` on all cached & served responses (required by Chromium for manual-redirect navigation requests)
 * - Searches across all CacheStorage versions + IndexedDB (`AKStore_Local_SQLite_Engine_v1`) for the App Shell
 * - Includes a built-in Offline Local Database & POS Recovery Shell if cache is ever cleared while offline
 */

const CACHE_NAME = 'ak-store-offline-v4';
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/icon.svg',
  '/favicon.ico',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png'
];

/**
 * Checks if an HTML string is the real AK Store application and NOT Cloud Run's warmup.html
 */
function isValidAppHtml(htmlText) {
  if (!htmlText || typeof htmlText !== 'string') return false;
  if (
    htmlText.indexOf('Please wait while your application starts') !== -1 ||
    htmlText.indexOf('Starting Server...') !== -1 ||
    htmlText.indexOf('warmup_start_time') !== -1 ||
    htmlText.indexOf('Your application failed to start') !== -1
  ) {
    return false;
  }
  return htmlText.indexOf('id="root"') !== -1;
}

/**
 * Clones a Response into a clean, non-redirected Response.
 * CRITICAL: In Chrome/Android, returning a Response with `redirected === true` for a navigation request
 * (where request.redirect === 'manual') causes Chrome to fail with `ERR_FAILED` ("This site can't be reached").
 */
async function toCleanResponse(response, overrideContentType) {
  if (!response) return null;
  if (response.status === 0 || response.type === 'opaque') {
    return response;
  }
  try {
    const buffer = await response.clone().arrayBuffer();
    const headers = new Headers();
    response.headers.forEach((val, key) => {
      const lower = key.toLowerCase();
      if (
        lower !== 'content-encoding' &&
        lower !== 'content-length' &&
        lower !== 'transfer-encoding'
      ) {
        headers.set(key, val);
      }
    });
    if (overrideContentType) {
      headers.set('Content-Type', overrideContentType);
    }
    return new Response(buffer, {
      status: response.status || 200,
      statusText: response.statusText || 'OK',
      headers
    });
  } catch (_e) {
    return response;
  }
}

/**
 * Opens local IndexedDB inside Service Worker and optionally reads/writes the backup App Shell HTML
 */
function openLocalEngineIdb() {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve(null);
        return;
      }
      const timer = setTimeout(() => resolve(null), 350);
      const req = indexedDB.open('AKStore_Local_SQLite_Engine_v1', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('sqlite_tables')) db.createObjectStore('sqlite_tables');
        if (!db.objectStoreNames.contains('sqlite_snapshots')) db.createObjectStore('sqlite_snapshots');
        if (!db.objectStoreNames.contains('sync_outbox')) db.createObjectStore('sync_outbox');
        if (!db.objectStoreNames.contains('engine_meta')) db.createObjectStore('engine_meta');
      };
      req.onsuccess = () => {
        clearTimeout(timer);
        resolve(req.result);
      };
      req.onerror = () => {
        clearTimeout(timer);
        resolve(null);
      };
    } catch (_e) {
      resolve(null);
    }
  });
}

async function saveAppShellToIndexedDb(htmlText) {
  if (!isValidAppHtml(htmlText)) return;
  const db = await openLocalEngineIdb();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(['engine_meta'], 'readwrite');
      tx.objectStore('engine_meta').put(htmlText, 'offline_app_shell_html');
      tx.oncomplete = () => {
        try { db.close(); } catch (_e) {}
        resolve(true);
      };
      tx.onerror = () => {
        try { db.close(); } catch (_e) {}
        resolve(false);
      };
    } catch (_e) {
      try { db.close(); } catch (_err) {}
      resolve(false);
    }
  });
}

async function loadAppShellFromIndexedDb() {
  const db = await openLocalEngineIdb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(['engine_meta'], 'readonly');
      const req = tx.objectStore('engine_meta').get('offline_app_shell_html');
      req.onsuccess = () => {
        try { db.close(); } catch (_e) {}
        const html = req.result;
        if (typeof html === 'string' && isValidAppHtml(html)) {
          resolve(
            new Response(html, {
              status: 200,
              statusText: 'OK',
              headers: { 'Content-Type': 'text/html; charset=utf-8' }
            })
          );
        } else {
          resolve(null);
        }
      };
      req.onerror = () => {
        try { db.close(); } catch (_e) {}
        resolve(null);
      };
    } catch (_e) {
      try { db.close(); } catch (_err) {}
      resolve(null);
    }
  });
}

/**
 * Built-in Emergency Offline HTML Shell (200 OK) so Chrome NEVER displays ERR_FAILED
 * Reads directly from IndexedDB (`AKStore_Local_SQLite_Engine_v1`) and localStorage (`soft_glass_pos_db_v1`)
 */
function createEmergencyOfflineShellResponse() {
  const html = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>AK Store - وضع العمل بدون إنترنت (Offline-First)</title>
  <style>
    * { box-sizing: border-box; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { margin: 0; background: #0f172a; color: #f8fafc; padding: 16px; }
    .container { max-width: 900px; margin: 0 auto; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 16px; padding: 20px; margin-bottom: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
    .badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); padding: 6px 12px; border-radius: 999px; font-size: 13px; font-weight: 700; }
    h1 { margin: 12px 0 8px; font-size: 22px; color: #fff; }
    p { margin: 0 0 12px; color: #94a3b8; font-size: 14px; line-height: 1.6; }
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-top: 16px; }
    .stat-box { background: #0f172a; border: 1px solid #334155; border-radius: 12px; padding: 14px; text-align: center; }
    .stat-val { font-size: 24px; font-weight: 800; color: #38bdf8; }
    .stat-lbl { font-size: 12px; color: #94a3b8; margin-top: 4px; }
    .btn { background: #2563eb; color: #fff; border: none; border-radius: 10px; padding: 12px 20px; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
    .btn:hover { background: #1d4ed8; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }
    th, td { padding: 10px; border-bottom: 1px solid #334155; text-align: right; }
    th { color: #94a3b8; font-weight: 600; background: rgba(15,23,42,0.5); }
    .search { width: 100%; padding: 10px 14px; border-radius: 10px; border: 1px solid #475569; background: #0f172a; color: #fff; font-size: 14px; margin-bottom: 10px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="badge">● متصل محلياً بـ IndexedDB + SQLite (بدون إنترنت)</div>
      <h1>AK Store — نظام الكريم لإدارة المبيعات</h1>
      <p>أنت الآن في وضع عدم الاتصال بالشبكة. جميع بياناتك محفوظة بأمان داخل قاعدة البيانات المحلية على جهازك.</p>
      <button class="btn" onclick="window.location.reload()">تحديث وإعادة فتح الواجهة الكاملة</button>
      <div class="stats">
        <div class="stat-box"><div class="stat-val" id="cnt-products">0</div><div class="stat-lbl">الأصناف المسجلة محلياً</div></div>
        <div class="stat-box"><div class="stat-val" id="cnt-invoices">0</div><div class="stat-lbl">الفواتير المحفوظة</div></div>
        <div class="stat-box"><div class="stat-val" id="cnt-customers">0</div><div class="stat-lbl">العملاء</div></div>
        <div class="stat-box"><div class="stat-val" id="cnt-installments">0</div><div class="stat-lbl">خطط الأقساط</div></div>
      </div>
    </div>
    <div class="card">
      <h2 style="margin-top:0;font-size:17px;">البحث السريع في الأصناف والأسعار (أوفلاين)</h2>
      <input type="text" id="q" class="search" placeholder="ابحث باسم الصنف أو الكود..." oninput="renderProducts()" />
      <div style="overflow-x:auto;">
        <table>
          <thead><tr><th>الكود</th><th>اسم الصنف</th><th>سعر البيع</th><th>الرصيد</th></tr></thead>
          <tbody id="prod-body"><tr><td colspan="4">جاري قراءة قاعدة البيانات المحلية...</td></tr></tbody>
        </table>
      </div>
    </div>
  </div>
  <script>
    var allProducts = [];
    function renderProducts() {
      var q = (document.getElementById('q').value || '').trim().toLowerCase();
      var tbody = document.getElementById('prod-body');
      var list = allProducts.filter(function(p) {
        if (!q) return true;
        return (p.name && p.name.toLowerCase().indexOf(q) !== -1) || (p.code && String(p.code).toLowerCase().indexOf(q) !== -1);
      }).slice(0, 50);
      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#94a3b8;">لا توجد أصناف مطابقة</td></tr>';
        return;
      }
      tbody.innerHTML = list.map(function(p) {
        return '<tr><td>' + (p.code || '-') + '</td><td>' + (p.name || '-') + '</td><td>' + (p.sellPrice || p.price || 0) + ' ج.م</td><td>' + (p.stock || p.quantity || 0) + '</td></tr>';
      }).join('');
    }
    function applyData(data) {
      if (!data) return;
      allProducts = Array.isArray(data.products) ? data.products : [];
      document.getElementById('cnt-products').textContent = allProducts.length;
      document.getElementById('cnt-invoices').textContent = Array.isArray(data.invoices) ? data.invoices.length : 0;
      document.getElementById('cnt-customers').textContent = Array.isArray(data.customers) ? data.customers.length : 0;
      document.getElementById('cnt-installments').textContent = Array.isArray(data.installmentPlans) ? data.installmentPlans.length : 0;
      renderProducts();
    }
    try {
      var raw = localStorage.getItem('soft_glass_pos_db_v1');
      if (raw) applyData(JSON.parse(raw));
    } catch (e) {}
    try {
      var req = indexedDB.open('AKStore_Local_SQLite_Engine_v1', 1);
      req.onsuccess = function() {
        var db = req.result;
        if (db.objectStoreNames.contains('sqlite_snapshots')) {
          var tx = db.transaction(['sqlite_snapshots'], 'readonly');
          var getReq = tx.objectStore('sqlite_snapshots').get('latest_snapshot');
          getReq.onsuccess = function() {
            if (getReq.result && getReq.result.payload) {
              applyData(getReq.result.payload);
            }
          };
        }
      };
    } catch (e) {}
    window.addEventListener('online', function() { window.location.reload(); });
  </script>
</body>
</html>`;
  return new Response(html, {
    status: 200,
    statusText: 'OK',
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  });
}

/**
 * Fetch with fast timeout and same-origin credentials so Cloud Run / AI Studio session cookies are included
 */
function fetchWithTimeout(requestOrUrl, timeoutMs) {
  return new Promise((resolve, reject) => {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      controller.abort();
      reject(new Error('Network timeout'));
    }, timeoutMs);

    const fetchOpts = {
      signal: controller.signal,
      credentials: 'same-origin'
    };

    fetch(requestOrUrl, fetchOpts)
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

/**
 * Finds a cached response across the active cache first, then falls back to any cache in CacheStorage
 */
async function matchFromAnyCache(requestOrUrl, ignoreSearch = true) {
  try {
    const primaryCache = await caches.open(CACHE_NAME);
    const primaryHit = await primaryCache.match(requestOrUrl, { ignoreSearch });
    if (primaryHit) return primaryHit;

    const anyHit = await caches.match(requestOrUrl, { ignoreSearch });
    if (anyHit) return anyHit;
  } catch (_e) {}
  return null;
}

/**
 * Pre-caches all core & compiled bundle assets from /api/offline-manifest
 */
async function precacheAppAssets() {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return;
  }
  const cache = await caches.open(CACHE_NAME);

  let manifestAssets = [...CORE_ASSETS];
  try {
    const res = await fetchWithTimeout('/api/offline-manifest?t=' + Date.now(), 2500);
    if (res && res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.assets)) {
        for (const item of data.assets) {
          if (typeof item === 'string' && !manifestAssets.includes(item)) {
            manifestAssets.push(item);
          }
        }
      }
    }
  } catch (_err) {
    // Ignore if offline
  }

  await Promise.allSettled(
    manifestAssets.map(async (urlPath) => {
      try {
        const response = await fetchWithTimeout(urlPath, 4000);
        if (!response || !response.ok || response.status !== 200) return;

        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('text/html') || urlPath === '/' || urlPath === '/index.html') {
          const text = await response.clone().text();
          if (!isValidAppHtml(text)) {
            return;
          }
          const cleanCopy = new Response(text, {
            status: 200,
            statusText: 'OK',
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
          });
          await cache.put('/', cleanCopy.clone());
          await cache.put('/index.html', cleanCopy);
          await saveAppShellToIndexedDb(text);
        } else {
          const cleanAsset = await toCleanResponse(response);
          if (cleanAsset) {
            await cache.put(urlPath, cleanAsset);
          }
        }
      } catch (_e) {
        // Ignore individual asset failure
      }
    })
  );
}

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    (async () => {
      await openLocalEngineIdb();
      await precacheAppAssets();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      await self.clients.claim();
      await openLocalEngineIdb();
      await precacheAppAssets();

      // Only clean up legacy caches AFTER confirming current cache has /index.html
      try {
        const cache = await caches.open(CACHE_NAME);
        const cachedRoot = await cache.match('/index.html', { ignoreSearch: true });
        let hasValidHtml = false;
        if (cachedRoot) {
          const text = await cachedRoot.clone().text();
          if (isValidAppHtml(text)) {
            hasValidHtml = true;
          } else {
            await cache.delete('/');
            await cache.delete('/index.html');
          }
        }

        if (hasValidHtml) {
          const keys = await caches.keys();
          await Promise.all(
            keys.map((key) => {
              if (key !== CACHE_NAME) {
                return caches.delete(key);
              }
              return Promise.resolve();
            })
          );
        }
      } catch (_e) {}
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data && (event.data.type === 'SKIP_WAITING' || event.data === 'SKIP_WAITING')) {
    self.skipWaiting();
  }
  if (event.data && event.data.type === 'PRECACHE_NOW') {
    event.waitUntil(precacheAppAssets());
  }
  if (event.data && event.data.type === 'CACHE_CURRENT_HTML' && typeof event.data.html === 'string') {
    event.waitUntil(
      (async () => {
        if (!isValidAppHtml(event.data.html)) return;
        const cache = await caches.open(CACHE_NAME);
        const cleanCopy = new Response(event.data.html, {
          status: 200,
          statusText: 'OK',
          headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
        await cache.put('/', cleanCopy.clone());
        await cache.put('/index.html', cleanCopy);
        await saveAppShellToIndexedDb(event.data.html);
      })()
    );
  }
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (!url.protocol.startsWith('http')) return;

  // Never intercept AI Studio internal auth verification endpoints when online
  if (
    url.pathname.startsWith('/__cookie_check') ||
    url.pathname.startsWith('/__aistudio_') ||
    url.pathname.startsWith('/applet-auth-bridge')
  ) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      event.respondWith(new Response('', { status: 200 }));
    }
    return;
  }

  // Handle /_aistudio-iframe.js with Cache-First so it never blocks when offline
  if (url.pathname.startsWith('/_aistudio-iframe.js')) {
    event.respondWith(
      (async () => {
        const cached = await matchFromAnyCache(request, true);
        if (cached) {
          return (await toCleanResponse(cached, 'application/javascript; charset=utf-8')) || cached;
        }
        try {
          if (typeof navigator !== 'undefined' && navigator.onLine === false) {
            throw new Error('Offline');
          }
          const netRes = await fetchWithTimeout(request, 1200);
          if (netRes && netRes.ok) {
            const cleanRes = await toCleanResponse(netRes, 'application/javascript; charset=utf-8');
            if (cleanRes) {
              const cache = await caches.open(CACHE_NAME);
              cache.put(request, cleanRes.clone());
              return cleanRes;
            }
          }
        } catch (_e) {}
        return new Response('// offline-safe noop\n', {
          status: 200,
          headers: { 'Content-Type': 'application/javascript; charset=utf-8' }
        });
      })()
    );
    return;
  }

  // Handle API calls (/api/* and /version.json): Fast Offline-First fallback
  if (url.pathname.startsWith('/api/') || url.pathname === '/version.json') {
    if (url.pathname.includes('/stream')) {
      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        event.respondWith(new Response('', { status: 200 }));
      }
      return;
    }
    event.respondWith(
      (async () => {
        if (typeof navigator !== 'undefined' && navigator.onLine === false) {
          return new Response(
            JSON.stringify({
              success: false,
              offline: true,
              status: 'offline',
              error: 'Offline-First mode active — using local IndexedDB + SQLite database'
            }),
            {
              status: 200,
              headers: { 'Content-Type': 'application/json; charset=utf-8' }
            }
          );
        }
        try {
          return await fetchWithTimeout(request, 2000);
        } catch (_err) {
          return new Response(
            JSON.stringify({
              success: false,
              offline: true,
              status: 'offline',
              error: 'Offline-First mode active — using local IndexedDB + SQLite database'
            }),
            {
              status: 200,
              headers: { 'Content-Type': 'application/json; charset=utf-8' }
            }
          );
        }
      })()
    );
    return;
  }

  // 1. HTML Navigation Requests (/, /index.html, SPA routes)
  // TRUE OFFLINE-FIRST: Serve cached app shell IMMEDIATELY (0ms wait!) and NEVER reject with ERR_FAILED
  const isNavigation =
    request.mode === 'navigate' ||
    (request.headers.get('accept') || '').includes('text/html');

  if (isNavigation) {
    event.respondWith(
      (async () => {
        try {
          const cache = await caches.open(CACHE_NAME);

          // Search primary cache, then any cache, then IndexedDB backup
          let cachedAppHtml =
            (await matchFromAnyCache('/index.html', true)) ||
            (await matchFromAnyCache('/', true)) ||
            (await matchFromAnyCache(request, true));

          let cachedHtmlText = '';
          if (cachedAppHtml) {
            const text = await cachedAppHtml.clone().text();
            if (isValidAppHtml(text)) {
              cachedHtmlText = text;
              cachedAppHtml = new Response(text, {
                status: 200,
                statusText: 'OK',
                headers: { 'Content-Type': 'text/html; charset=utf-8' }
              });
            } else {
              cachedAppHtml = null;
            }
          }

          if (!cachedAppHtml) {
            cachedAppHtml = await loadAppShellFromIndexedDb();
            if (cachedAppHtml) {
              try {
                cachedHtmlText = await cachedAppHtml.clone().text();
              } catch (_e) {}
            }
          }

          // When offline, return cachedAppHtml in 0ms without touching the network
          if (typeof navigator !== 'undefined' && navigator.onLine === false) {
            if (cachedAppHtml) return cachedAppHtml;
            return createEmergencyOfflineShellResponse();
          }

          const refreshHtmlFromServer = async (timeoutMs = 1400) => {
            if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;
            try {
              const networkResponse = await fetchWithTimeout('/index.html?t=' + Date.now(), timeoutMs);
              if (networkResponse && networkResponse.ok) {
                const htmlText = await networkResponse.clone().text();
                if (isValidAppHtml(htmlText)) {
                  const isDifferentBuild = cachedHtmlText && htmlText.trim() !== cachedHtmlText.trim();
                  const cleanResponse = new Response(htmlText, {
                    status: 200,
                    statusText: 'OK',
                    headers: { 'Content-Type': 'text/html; charset=utf-8' }
                  });
                  await cache.put('/', cleanResponse.clone());
                  await cache.put('/index.html', cleanResponse.clone());
                  await saveAppShellToIndexedDb(htmlText);
                  precacheAppAssets()
                    .then(async () => {
                      if (isDifferentBuild) {
                        const allClients = await self.clients.matchAll({ type: 'window' });
                        allClients.forEach((client) => {
                          client.postMessage({ type: 'AK_LIVE_UPDATE_READY' });
                        });
                      }
                    })
                    .catch(() => {});
                  return cleanResponse;
                }
              }
            } catch (_e) {}
            return null;
          };

          // When online, try fast 1.3s network check first so any new modification appears immediately,
          // with instant fallback to cachedAppHtml if network is slow
          const freshRes = await refreshHtmlFromServer(1300);
          if (freshRes) return freshRes;
          if (cachedAppHtml) return cachedAppHtml;

          // Try direct request fetch if online
          if (typeof navigator === 'undefined' || navigator.onLine !== false) {
            try {
              const directRes = await fetchWithTimeout(request, 2500);
              if (directRes && directRes.ok) {
                const cleanDirect = await toCleanResponse(directRes, 'text/html; charset=utf-8');
                if (cleanDirect) return cleanDirect;
              }
            } catch (_e) {}
          }

          // NEVER throw or reject when offline — return Emergency Offline POS & Local DB Shell
          return createEmergencyOfflineShellResponse();
        } catch (_fatalErr) {
          return createEmergencyOfflineShellResponse();
        }
      })()
    );
    return;
  }

  // 2. Static Assets (JS, CSS, Fonts, Images, Icons): Instant Cache-First
  const isStaticAsset =
    url.pathname.startsWith('/assets/') ||
    /\.(js|mjs|css|png|jpg|jpeg|svg|gif|webp|ico|woff|woff2|ttf|webmanifest|json)$/i.test(
      url.pathname
    ) ||
    url.hostname.includes('fonts.googleapis.com') ||
    url.hostname.includes('fonts.gstatic.com');

  if (isStaticAsset) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        const cachedResponse =
          (await matchFromAnyCache(request, true)) ||
          (await matchFromAnyCache(url.pathname, true));

        if (cachedResponse) {
          if (
            !url.pathname.startsWith('/assets/') &&
            (typeof navigator === 'undefined' || navigator.onLine !== false)
          ) {
            fetchWithTimeout(request, 2000)
              .then(async (netRes) => {
                if (netRes && netRes.ok && netRes.status === 200) {
                  const cleanNet = await toCleanResponse(netRes);
                  if (cleanNet) cache.put(request, cleanNet);
                }
              })
              .catch(() => {});
          }
          return (await toCleanResponse(cachedResponse)) || cachedResponse;
        }

        if (typeof navigator !== 'undefined' && navigator.onLine === false) {
          if (url.hostname.includes('fonts.googleapis.com') || url.pathname.endsWith('.css')) {
            return new Response('/* offline fallback */', {
              status: 200,
              headers: { 'Content-Type': 'text/css; charset=utf-8' }
            });
          }
          if (url.pathname.endsWith('.js') || url.pathname.endsWith('.mjs')) {
            return new Response('// offline fallback\n', {
              status: 200,
              headers: { 'Content-Type': 'application/javascript; charset=utf-8' }
            });
          }
          return new Response('', { status: 200, statusText: 'Offline' });
        }

        try {
          const networkResponse = await fetchWithTimeout(request, 3500);
          if (networkResponse && networkResponse.ok && networkResponse.status === 200) {
            const contentType = networkResponse.headers.get('content-type') || '';
            if (!contentType.includes('text/html')) {
              const cleanNet = await toCleanResponse(networkResponse);
              if (cleanNet) {
                await cache.put(request, cleanNet.clone());
                await cache.put(url.pathname, cleanNet.clone());
                return cleanNet;
              }
            }
          }
          return (await toCleanResponse(networkResponse)) || networkResponse;
        } catch (_err) {
          if (url.hostname.includes('fonts.googleapis.com') || url.pathname.endsWith('.css')) {
            return new Response('/* offline fallback */', {
              status: 200,
              headers: { 'Content-Type': 'text/css; charset=utf-8' }
            });
          }
          return new Response('', { status: 200, statusText: 'Offline' });
        }
      })()
    );
    return;
  }

  // 3. Any other GET requests: Cache-First with safe offline fallback (never reject!)
  event.respondWith(
    (async () => {
      const cached = await matchFromAnyCache(request, true);
      if (cached) return (await toCleanResponse(cached)) || cached;

      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        return new Response('', { status: 200, statusText: 'Offline' });
      }
      try {
        const netRes = await fetchWithTimeout(request, 2500);
        if (netRes && netRes.ok && netRes.status === 200) {
          const ct = netRes.headers.get('content-type') || '';
          const cleanNet = await toCleanResponse(netRes);
          if (!ct.includes('text/html') && cleanNet) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, cleanNet.clone());
          }
          return cleanNet || netRes;
        }
        return netRes;
      } catch (_err) {
        return new Response('', { status: 200, statusText: 'Offline' });
      }
    })()
  );
});
