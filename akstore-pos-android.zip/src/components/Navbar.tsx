/**
 * @file components/Navbar.tsx
 * شريط التنقل العلوي بتصميم Soft Glass Neumorphism مع أداة التكيف التلقائي لحجم شاشة الكمبيوتر
 * Glass Neumorphic Top Navigation Bar with Auto-Fit Screen Size Controller & Installment Bell
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Clock,
  Globe,
  User as UserIcon,
  LogOut,
  AlertTriangle,
  Menu,
  Key,
  ShieldCheck,
  BellRing,
  MessageCircle,
  X,
  ExternalLink,
  Monitor,
  Coins,
  Palette,
  Check,
  Zap,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  RefreshCw,
  Smartphone,
  Download,
  Mail,
  Copy,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import { normalizeSyncEmailClient } from '../db/database';
import { copyTextFallback } from '../utils/win7Polyfills';
import { AppThemeId } from '../types';
import { LicenseState } from '../utils/licenseManager';
import {
  getApproachingInstallments,
  createWhatsAppUrl,
  generateReminderMessage,
  formatWhatsAppPhone,
  openSmartWhatsAppModal
} from '../utils/installmentAlerts';
import { AKStoreLogo } from './AKStoreLogo';
import {
  ScreenScalePreset,
  ScreenResolutionInfo,
  toggleBrowserFullscreen
} from '../utils/screenAdapter';

interface NavbarProps {
  onNavigate: (tab: string) => void;
  activeTab: string;
  onToggleMobileMenu?: () => void;
  licenseState?: LicenseState;
  onOpenActivation?: () => void;
  onOpenWindowsModal?: () => void;
  screenScalePreset?: ScreenScalePreset;
  screenInfo?: ScreenResolutionInfo;
  onChangeScreenScale?: (preset: ScreenScalePreset) => void;
  isSidebarCollapsed?: boolean;
  onToggleSidebarCollapse?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  activeTab,
  onToggleMobileMenu,
  licenseState,
  onOpenActivation,
  onOpenWindowsModal,
  screenScalePreset = 'auto',
  screenInfo,
  onChangeScreenScale,
  isSidebarCollapsed,
  onToggleSidebarCollapse
}) => {
  const { user, logout, isAdmin } = useAuth();
  const {
    language,
    setLanguage,
    t,
    tr,
    dir,
    settings,
    products,
    installmentPlans,
    formatCurrency,
    showToast,
    currencies,
    activeCurrency,
    switchActiveCurrency,
    appTheme,
    setAppTheme,
    lowSpecMode,
    setLowSpecMode,
    syncStatus,
    syncEmail,
    emailSyncLocked,
    setSyncEmail,
    setEmailSyncFieldLocked,
    syncNow
  } = useApp();

  const isSuperAdmin = user?.username?.toLowerCase() === 'admin';
  const showEmailSyncControl = !emailSyncLocked || isSuperAdmin;

  const [isManualSyncing, setIsManualSyncing] = useState(false);
  const [isSyncMenuOpen, setIsSyncMenuOpen] = useState(false);
  const [syncEmailDraft, setSyncEmailDraft] = useState<string>(syncEmail || '');

  useEffect(() => {
    setSyncEmailDraft(syncEmail || '');
  }, [syncEmail]);

  const [currentTime, setCurrentTime] = useState<string>('');
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const [isThemeMenuOpen, setIsThemeMenuOpen] = useState(false);
  const [isScreenMenuOpen, setIsScreenMenuOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const alertsDropdownRef = useRef<HTMLDivElement>(null);
  const themeDropdownRef = useRef<HTMLDivElement>(null);
  const screenDropdownRef = useRef<HTMLDivElement>(null);
  const syncDropdownRef = useRef<HTMLDivElement>(null);

  const scalePresets: {
    id: ScreenScalePreset;
    label: string;
    desc: string;
  }[] = [
    {
      id: 'auto',
      label: tr('تلقائي ذكي (Auto-Fit)', 'Smart Auto-Fit'),
      desc: tr('يتوافق تلقائياً مع مقاس ودقة شاشة الكمبيوتر الحالية', 'Automatically adapts to your current PC monitor resolution')
    },
    {
      id: '75',
      label: '75% · ' + tr('مدمج جداً', 'Ultra Compact'),
      desc: tr('مناسب لشاشات الكاشير الصغيرة 800×600 و 1024×768', 'Best for small 800×600 & 1024×768 POS screens')
    },
    {
      id: '85',
      label: '85% · ' + tr('شاشات اللابتوب', 'Laptop Screen'),
      desc: tr('مثالي لشاشات اللابتوب 1280×720 و 1366×768', 'Ideal for 1280×720 & 1366×768 laptop displays')
    },
    {
      id: '90',
      label: '90% · ' + tr('متوسط متوازن', 'Balanced Medium'),
      desc: tr('مناسب لشاشات المكتب 1440×900 و 1600×900', 'Great for 1440×900 & 1600×900 desktop monitors')
    },
    {
      id: '100',
      label: '100% · ' + tr('الحجم القياسي (Full HD)', 'Standard (Full HD)'),
      desc: tr('الحجم الافتراضي لشاشات 1920×1080 الكاملة', 'Standard size for 1920×1080 Full HD screens')
    },
    {
      id: '110',
      label: '110% · ' + tr('مكبّر ومريح للعين', 'Large Comfortable'),
      desc: tr('خطوط وأزرار أكبر لشاشات اللمس والشاشات العريضة', 'Larger buttons & text for touchscreens & wide monitors')
    },
    {
      id: '125',
      label: '125% · ' + tr('كبير جداً (2K / 4K)', 'Extra Large (2K / 4K)'),
      desc: tr('للشاشات العملاقة عالية الدقة أو الرؤية عن بُعد', 'For ultra-high-res 2K/4K displays')
    }
  ];

  const orderedScaleSteps: ScreenScalePreset[] = ['75', '80', '85', '90', '95', '100', '105', '110', '115', '125'];

  const handleStepScale = (direction: 'in' | 'out') => {
    if (!onChangeScreenScale) return;
    const currentEffective = String(screenInfo?.effectiveScalePercent || 100);
    let closestIdx = orderedScaleSteps.findIndex((s) => Number(s) >= Number(currentEffective));
    if (closestIdx === -1) closestIdx = orderedScaleSteps.length - 1;

    const nextIdx =
      direction === 'in'
        ? Math.min(orderedScaleSteps.length - 1, closestIdx + 1)
        : Math.max(0, closestIdx - 1);
    const nextPreset = orderedScaleSteps[nextIdx];
    onChangeScreenScale(nextPreset);
  };

  const themeOptions: {
    id: AppThemeId;
    name: string;
    subtitle: string;
    gradient: string;
    dotColor: string;
  }[] = [
    {
      id: 'ocean-blue',
      name: tr('الأزرق الكلاسيكي', 'Classic Ocean Blue'),
      subtitle: tr('واجهة زجاجية زرقاء هادئة', 'Calm blue glassmorphism'),
      gradient: 'from-blue-500 to-indigo-600',
      dotColor: '#3b82f6'
    },
    {
      id: 'emerald-mint',
      name: tr('الزمردي العصري', 'Modern Emerald Mint'),
      subtitle: tr('أخضر زمردي مريح للعين', 'Eye-friendly emerald green'),
      gradient: 'from-emerald-500 to-teal-600',
      dotColor: '#10b981'
    },
    {
      id: 'royal-violet',
      name: tr('البنفسجي الملكي', 'Royal Violet'),
      subtitle: tr('تدرج بنفسجي عصري أنيق', 'Elegant modern purple'),
      gradient: 'from-violet-500 to-purple-700',
      dotColor: '#8b5cf6'
    },
    {
      id: 'rose-sunset',
      name: tr('الوردي المرجاني', 'Coral Rose Sunset'),
      subtitle: tr('ألوان غروب دافئة وحيوية', 'Warm vibrant sunset tones'),
      gradient: 'from-rose-500 to-pink-600',
      dotColor: '#f43f5e'
    },
    {
      id: 'amber-gold',
      name: tr('العنبري الذهبي', 'Amber Gold'),
      subtitle: tr('مظهر ذهبي دافئ وفاخر', 'Warm luxury golden style'),
      gradient: 'from-amber-500 to-orange-600',
      dotColor: '#f59e0b'
    },
    {
      id: 'cyber-teal',
      name: tr('الفيروزي المحيطي', 'Cyber Teal'),
      subtitle: tr('سماوي فيروزي حديث ومشرق', 'Bright modern cyan-teal'),
      gradient: 'from-cyan-500 to-sky-600',
      dotColor: '#06b6d4'
    },
    {
      id: 'midnight-dark',
      name: tr('الوضع الليلي الداكن', 'Midnight Dark Mode'),
      subtitle: tr('مظهر داكن فاخر للعمل الطويل', 'Sleek dark mode for long shifts'),
      gradient: 'from-slate-800 to-indigo-950',
      dotColor: '#6366f1'
    }
  ];

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [language]);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  // Close dropdowns on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (alertsDropdownRef.current && !alertsDropdownRef.current.contains(e.target as Node)) {
        setIsAlertsOpen(false);
      }
      if (themeDropdownRef.current && !themeDropdownRef.current.contains(e.target as Node)) {
        setIsThemeMenuOpen(false);
      }
      if (screenDropdownRef.current && !screenDropdownRef.current.contains(e.target as Node)) {
        setIsScreenMenuOpen(false);
      }
      if (syncDropdownRef.current && !syncDropdownRef.current.contains(e.target as Node)) {
        setIsSyncMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Check low stock count
  const lowStockCount = products.filter((p) => p.stock <= p.minStockAlert).length;

  // Automated Approaching Installments (threshold 7 days)
  const approachingInstallments = useMemo(() => {
    return getApproachingInstallments(installmentPlans, 7);
  }, [installmentPlans]);

  const overdueCount = approachingInstallments.filter((i) => i.urgency === 'overdue').length;
  const todayCount = approachingInstallments.filter((i) => i.urgency === 'today').length;
  const upcomingCount = approachingInstallments.filter((i) => i.urgency === 'upcoming').length;
  const totalAlertsCount = approachingInstallments.length;

  const toggleLanguage = () => {
    const nextLang = language === 'ar' ? 'en' : 'ar';
    setLanguage(nextLang);
    showToast(
      nextLang === 'en'
        ? 'Switched to English (Left-to-Right LTR Layout)'
        : 'تم التبديل إلى اللغة العربية (اتجاه من اليمين لليسار RTL)',
      'info'
    );
  };

  const handleQuickWhatsApp = (item: (typeof approachingInstallments)[0], e: React.MouseEvent) => {
    e.stopPropagation();
    const formatted = formatWhatsAppPhone(item.customerPhone);
    if (!formatted) {
      showToast(tr('رقم هاتف العميل غير صحيح', 'Invalid customer phone number'), 'error');
      return;
    }

    const msg = generateReminderMessage({
      customerName: item.customerName,
      installmentNumber: item.installment.installmentNumber,
      amount: item.amount,
      dueDate: item.dueDate,
      currencySymbol: settings.currencySymbol || 'ج.م',
      storeName: settings.storeName || tr('المتجر', 'Store'),
      storePhone: settings.storePhone,
      daysDiff: item.daysDiff,
      templateType:
        item.urgency === 'overdue' ? 'overdue' : item.urgency === 'today' ? 'due_today' : 'gentle'
    });

    setIsAlertsOpen(false);
    openSmartWhatsAppModal({
      recipientName: item.customerName,
      phone: item.customerPhone,
      message: msg,
      title: tr('إرسال تذكير بالقسط عبر واتساب', 'Send Installment Reminder via WhatsApp'),
      subtitle: `${tr('فاتورة', 'Invoice')} #${item.invoiceNumber} · ${tr('قسط', 'Installment')} #${item.installment.installmentNumber}`
    });
  };

  return (
    <header className="neu-flat sticky top-0 z-40 px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2 sm:gap-3 border-b border-white/60 shrink-0">
      {/* Brand & Store Name */}
      <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 rounded-xl neu-button text-slate-700 cursor-pointer"
            title={tr('القائمة', 'Menu')}
          >
            <Menu className="w-5 h-5" />
          </button>
        )}
        <AKStoreLogo
          logoUrl={settings.logoUrl}
          size="md"
          className="ring-2 ring-white/80 hover:scale-105 transition-transform duration-200"
        />
        <div>
          <div className="flex items-center gap-1.5">
            <h1 className="text-sm sm:text-base font-black text-slate-800 tracking-tight leading-tight whitespace-nowrap">
              {settings.storeName || 'AK Store'}
            </h1>
            <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded-md text-[9px] font-black tracking-wider uppercase bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-2xs">
              POS
            </span>
          </div>
          <span className="text-[11px] text-slate-500 font-medium hidden xl:inline whitespace-nowrap">
            {isAdmin ? t('roleAdmin') : t('roleCashier')} ·{' '}
            {settings.printLayout === 'thermal'
              ? tr('طابعة حرارية 80mm', 'Thermal 80mm')
              : tr('طابعة A4', 'A4 Printer')}
          </span>
        </div>
      </div>

      {/* Center Live Clock & Quick Dashboard/POS Switcher */}
      <div className="hidden md:flex items-center gap-2">
        <div className="flex items-center gap-1 p-1 rounded-2xl neu-pressed">
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'dashboard'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('لوحة البيانات', 'Dashboard')}
          </button>
          <button
            type="button"
            onClick={() => onNavigate('pos')}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'pos'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('شاشة البيع (POS)', 'POS Terminal')}
          </button>
        </div>

        <div className="hidden lg:flex items-center gap-2 neu-pressed px-3 py-1.5 rounded-full text-slate-600 text-xs font-medium">
          <Clock className="w-3.5 h-3.5 text-blue-500" />
          <span className="tabular-nums font-semibold text-slate-700 whitespace-nowrap">{currentTime}</span>
        </div>
      </div>

      {/* Right/End Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* REAL-TIME BIDIRECTIONAL PC <-> MOBILE SYNC BUTTON & EMAIL ISOLATION POPOVER (Shown Once Until Synced, or Always for Super Admin) */}
        {showEmailSyncControl && (
          <div className="relative" ref={syncDropdownRef}>
            <button
              type="button"
              onClick={() => setIsSyncMenuOpen(!isSyncMenuOpen)}
              className={`neu-button px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-bold cursor-pointer border transition-all shrink-0 ${
                syncStatus.status === 'syncing' || isManualSyncing
                  ? 'border-blue-300 bg-blue-50/80 text-blue-700'
                  : syncEmail && syncStatus.status === 'connected'
                  ? 'border-emerald-200/90 bg-emerald-50/60 text-emerald-800 hover:bg-emerald-100/70'
                  : 'border-amber-300 bg-amber-50/80 text-amber-900 hover:bg-amber-100/80'
              }`}
              title={tr(
                syncEmail
                  ? `المزامنة الخاصة بالإيميل (${syncEmail}) بين الكمبيوتر والتليفون`
                  : 'اضغط لإدخال بريدك الإلكتروني لتفعيل المزامنة الخاصة بين الكمبيوتر والتليفون',
                'Private Email Sync (PC ⇄ Mobile)'
              )}
            >
              <span className="relative flex h-2 w-2 shrink-0">
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    !syncEmail || syncStatus.status === 'offline' ? 'bg-amber-400' : 'bg-emerald-400'
                  }`}
                />
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    !syncEmail || syncStatus.status === 'offline' ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                />
              </span>
              <RefreshCw
                className={`w-3.5 h-3.5 shrink-0 ${
                  syncStatus.status === 'syncing' || isManualSyncing
                    ? 'animate-spin text-blue-600'
                    : syncEmail
                    ? 'text-emerald-600'
                    : 'text-amber-600'
                }`}
              />
              <span className="hidden lg:inline whitespace-nowrap max-w-[165px] truncate">
                {syncStatus.status === 'syncing' || isManualSyncing
                  ? tr('جاري المزامنة...', 'Syncing...')
                  : syncEmail
                  ? syncEmail
                  : tr('ربط الإيميل للمزامنة', 'Link Email for Sync')}
              </span>
            </button>

            {isSyncMenuOpen && (
              <div
                className={`absolute ${
                  dir === 'rtl' ? 'left-0' : 'right-0'
                } mt-2 w-80 sm:w-96 neu-card rounded-3xl p-4 shadow-2xl z-50 border border-blue-200/90 bg-white/95 backdrop-blur-xl space-y-3`}
              >
                <div className="flex items-center justify-between pb-2.5 border-b border-slate-200/80">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-800 text-xs">
                        {tr(
                          'مزامنة الكمبيوتر والتليفون عبر الإيميل',
                          'Private PC ⇄ Mobile Sync via Email'
                        )}
                      </h4>
                      <span className="text-[10px] text-slate-500 block">
                        {tr(
                          'بياناتك معزولة وخاصة بإيميلك فقط ولا تُشارك مع غيرك',
                          'Your data is 100% isolated to your email address'
                        )}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsSyncMenuOpen(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="block text-[11px] font-bold text-slate-700">
                    {tr(
                      'البريد الإلكتروني الخاص بك (اكتبه على الكمبيوتر والتليفون):',
                      'Your Personal Email (Enter on both PC & Phone):'
                    )}
                  </label>
                  <input
                    type="email"
                    dir="ltr"
                    value={syncEmailDraft}
                    onChange={(e) => setSyncEmailDraft(e.target.value)}
                    placeholder="your.email@gmail.com"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-bold text-slate-800 outline-none focus:border-blue-500 focus:bg-white text-left"
                  />

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={isManualSyncing}
                      onClick={async () => {
                        const clean = normalizeSyncEmailClient(syncEmailDraft);
                        if (!clean) {
                          showToast(
                            tr(
                              'يرجى إدخال بريد إلكتروني صحيح (مثال: name@gmail.com)',
                              'Please enter a valid email address'
                            ),
                            'error'
                          );
                          return;
                        }
                        setIsManualSyncing(true);
                        if (clean !== syncEmail) {
                          await setSyncEmail(clean);
                        } else {
                          await syncNow();
                          setEmailSyncFieldLocked(true);
                        }
                        setIsManualSyncing(false);
                        if (!isSuperAdmin) {
                          setIsSyncMenuOpen(false);
                        }
                        showToast(
                          tr(
                            `✅ تمت مزامنة البيانات على الإيميل (${clean}) بين الكمبيوتر والتليفون بنجاح!`,
                            `✅ Synced data privately for (${clean})!`
                          ),
                          'success'
                        );
                      }}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? 'animate-spin' : ''}`} />
                      <span>
                        {syncEmail && normalizeSyncEmailClient(syncEmailDraft) === syncEmail
                          ? tr('مزامنة فورية الآن', 'Sync Now')
                          : tr('حفظ الإيميل والمزامنة', 'Save Email & Sync')}
                      </span>
                    </button>

                    {syncEmail && isSuperAdmin && (
                      <button
                        type="button"
                        onClick={async () => {
                          await setSyncEmail('');
                          setSyncEmailDraft('');
                          showToast(
                            tr(
                              'تم إيقاف ربط الإيميل، وسيظهر حقل الإيميل للعميل لربط إيميل جديد.',
                              'Email unlinked. Email field is now visible to link a new email.'
                            ),
                            'info'
                          );
                        }}
                        className="px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 text-[11px] font-bold cursor-pointer"
                      >
                        {tr('إلغاء الربط', 'Unlink')}
                      </button>
                    )}
                  </div>
                </div>

                {syncEmail && (
                  <div className="p-2.5 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-emerald-900 font-bold flex items-center gap-1">
                        <Lock className="w-3 h-3 text-emerald-600" />
                        <span>{tr('الحساب النشط:', 'Active Email:')}</span>
                      </span>
                      <span className="font-mono font-bold text-emerald-800">{syncEmail}</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        const origin =
                          typeof window !== 'undefined' ? window.location.origin : '';
                        const link = `${origin}/?syncEmail=${encodeURIComponent(syncEmail)}`;
                        copyTextFallback(link);
                        showToast(
                          tr(
                            'تم نسخ رابط التليفون المرتبط بإيميلك! افتحه على تليفونك ليتم الربط تلقائياً.',
                            'Copied your personal mobile sync link!'
                          ),
                          'success'
                        );
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-white hover:bg-emerald-100/70 text-emerald-800 border border-emerald-300 text-[11px] font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Copy className="w-3.5 h-3.5 text-emerald-600" />
                      <span>
                        {tr(
                          'نسخ رابط التليفون المرتبط بإيميلك',
                          'Copy Personal Mobile Sync Link'
                        )}
                      </span>
                    </button>
                  </div>
                )}

                {isSuperAdmin && syncEmail && (
                  <div className="p-2.5 rounded-2xl bg-indigo-50/90 border border-indigo-200 space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-extrabold text-indigo-950 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{tr('تحكم الأدمن في ظهور الحقل للعميل:', 'Admin Client Field Visibility:')}</span>
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          emailSyncLocked
                            ? 'bg-slate-200 text-slate-700'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {emailSyncLocked
                          ? tr('مخفي عن العميل', 'Hidden from Client')
                          : tr('ظاهر للعميل حالياً', 'Visible to Client')}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        const nextLocked = !emailSyncLocked;
                        setEmailSyncFieldLocked(nextLocked);
                        showToast(
                          nextLocked
                            ? tr(
                                'تم إخفاء حقول إيميل المزامنة عن العميل.',
                                'Email sync fields are now hidden from the client.'
                              )
                            : tr(
                                'تم إظهار حقول إيميل المزامنة للعميل! ستختفي تلقائياً بمجرد قيامه بالمزامنة.',
                                'Email sync fields are now visible to the client and will auto-hide once synced!'
                              ),
                          'info'
                        );
                      }}
                      className={`w-full py-2 px-3 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-colors border ${
                        emailSyncLocked
                          ? 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-600'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      {emailSyncLocked ? (
                        <>
                          <Eye className="w-3.5 h-3.5" />
                          <span>
                            {tr(
                              'إظهار حقل الإيميل للعميل (يختفي بعد المزامنة)',
                              'Show Email Field to Client (Once)'
                            )}
                          </span>
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>
                            {tr('إخفاء حقل الإيميل عن العميل الآن', 'Hide Email Field from Client Now')}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                <div className="p-2.5 rounded-xl bg-slate-100/90 text-[10px] text-slate-600 leading-relaxed">
                  {tr(
                    '💡 يظهر حقل الإيميل للعميل مرة واحدة فقط عند الربط، وبمجرد المزامنة يختفي تلقائياً وتستمر المزامنة في الخلفية.',
                    '💡 The email field appears once for pairing, then automatically hides while background sync continues.'
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* SCREEN SIZE & AUTO-FIT CONTROLLER FOR ALL PC MONITORS */}
        {onChangeScreenScale && (
          <div className="relative" ref={screenDropdownRef}>
            <button
              type="button"
              onClick={() => setIsScreenMenuOpen(!isScreenMenuOpen)}
              className="neu-button px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer border border-blue-200/70 bg-blue-50/40"
              title={tr(
                'ضبط حجم النظام ليتوافق مع أي مقاس شاشة كمبيوتر (تلقائي / تكبير / تصغير / ملء الشاشة)',
                'Adjust system UI scale to fit any PC screen size (Auto-Fit / Zoom / Fullscreen)'
              )}
            >
              <Monitor className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="tabular-nums whitespace-nowrap">
                {screenScalePreset === 'auto'
                  ? tr(`تلقائي (${screenInfo?.effectiveScalePercent || 100}%)`, `Auto (${screenInfo?.effectiveScalePercent || 100}%)`)
                  : `${screenScalePreset}%`}
              </span>
            </button>

            {isScreenMenuOpen && (
              <div
                className={`absolute ${
                  dir === 'rtl' ? 'left-0' : 'right-0'
                } mt-2 w-80 sm:w-88 neu-card rounded-3xl p-4 shadow-2xl z-50 border border-blue-200/80 bg-white/95 backdrop-blur-xl`}
              >
                <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-slate-200/70">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                      <Monitor className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-800 text-xs">
                        {tr('توافق مقاس الشاشة (Screen Fit)', 'Screen Size & Display Fit')}
                      </h4>
                      <span className="text-[10px] text-slate-500 tabular-nums block">
                        {screenInfo
                          ? `${tr('مقاس شاشتك الحالي:', 'Detected Screen:')} ${screenInfo.width}×${screenInfo.height}px`
                          : tr('ملاءمة تلقائية لجميع شاشات الكمبيوتر', 'Auto-fit for all PC monitors')}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsScreenMenuOpen(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Zoom Out / Reset Auto / Zoom In Bar */}
                <div className="flex items-center gap-1.5 mb-3 p-1.5 rounded-2xl neu-pressed">
                  <button
                    type="button"
                    onClick={() => handleStepScale('out')}
                    className="neu-button px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1 cursor-pointer"
                    title={tr('تصغير حجم الواجهة (Ctrl -)', 'Zoom Out UI')}
                  >
                    <ZoomOut className="w-3.5 h-3.5 text-blue-600" />
                    <span>{tr('تصغير', 'Smaller')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onChangeScreenScale('auto')}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-black text-center cursor-pointer transition-all ${
                      screenScalePreset === 'auto'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'neu-button text-slate-700'
                    }`}
                  >
                    {tr('تلقائي', 'Auto')}{' '}
                    <span className="tabular-nums">({screenInfo?.effectiveScalePercent || 100}%)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleStepScale('in')}
                    className="neu-button px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1 cursor-pointer"
                    title={tr('تكبير حجم الواجهة (Ctrl +)', 'Zoom In UI')}
                  >
                    <ZoomIn className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{tr('تكبير', 'Larger')}</span>
                  </button>
                </div>

                {/* Fullscreen & Sidebar Collapse Quick Toggles */}
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <button
                    type="button"
                    onClick={async () => {
                      const fs = await toggleBrowserFullscreen();
                      setIsFullscreen(fs);
                    }}
                    className="neu-button p-2 rounded-xl text-[11px] font-bold text-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isFullscreen ? (
                      <>
                        <Minimize2 className="w-3.5 h-3.5 text-amber-600" />
                        <span>{tr('إنهاء ملء الشاشة', 'Exit Fullscreen')}</span>
                      </>
                    ) : (
                      <>
                        <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                        <span>{tr('ملء الشاشة (F11)', 'Fullscreen (F11)')}</span>
                      </>
                    )}
                  </button>

                  {onToggleSidebarCollapse && (
                    <button
                      type="button"
                      onClick={onToggleSidebarCollapse}
                      className="neu-button p-2 rounded-xl text-[11px] font-bold text-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-indigo-600" />
                      <span>
                        {isSidebarCollapsed
                          ? tr('توسيع القائمة الجانبية', 'Expand Sidebar')
                          : tr('تصغير القائمة الجانبية', 'Compact Sidebar')}
                      </span>
                    </button>
                  )}
                </div>

                {/* Preset List */}
                <div className="space-y-1.5 max-h-60 overflow-y-auto pr-0.5">
                  {scalePresets.map((item) => {
                    const isSelected = screenScalePreset === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          onChangeScreenScale(item.id);
                          showToast(
                            tr(
                              `تم ضبط مقاس عرض النظام على: ${item.label}`,
                              `Display scale set to: ${item.label}`
                            ),
                            'info'
                          );
                          setIsScreenMenuOpen(false);
                        }}
                        className={`w-full p-2 rounded-2xl flex items-center justify-between gap-2 text-right transition-all cursor-pointer ${
                          isSelected
                            ? 'neu-pressed border border-blue-400/60 bg-blue-50/40'
                            : 'hover:bg-slate-100/70 border border-transparent'
                        }`}
                      >
                        <div>
                          <div className="font-bold text-slate-800 text-xs">{item.label}</div>
                          <div className="text-[10px] text-slate-500">{item.desc}</div>
                        </div>
                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* AUTOMATED INSTALLMENT NOTIFICATION BELL */}
        <div className="relative" ref={alertsDropdownRef}>
          <button
            onClick={() => setIsAlertsOpen(!isAlertsOpen)}
            title={tr('تنبيهات استحقاق الأقساط', 'Due Installments Alerts')}
            className={`relative p-2 rounded-xl transition-all cursor-pointer ${
              totalAlertsCount > 0
                ? 'neu-button text-emerald-700 bg-emerald-50/60 border border-emerald-200'
                : 'neu-button text-slate-600'
            }`}
          >
            <BellRing className={`w-4 h-4 ${totalAlertsCount > 0 ? 'text-emerald-600' : ''}`} />
            {totalAlertsCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-md tabular-nums">
                {totalAlertsCount}
              </span>
            )}
          </button>

          {/* Floating Dropdown Modal/Card */}
          {isAlertsOpen && (
            <div
              className={`absolute ${
                dir === 'rtl' ? 'left-0' : 'right-0'
              } mt-2 w-80 sm:w-96 neu-card rounded-3xl p-4 shadow-2xl z-50 border border-emerald-200/80 bg-white/95 backdrop-blur-md`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200/70">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs">
                    <BellRing className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-xs">
                      {tr('تنبيهات استحقاق الأقساط', 'Installment Due Alerts')}
                    </h4>
                    <span className="text-[10px] text-slate-500">
                      {tr('مواعيد السداد القادمة والمتأخرة', 'Upcoming & overdue payments')}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsAlertsOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Counts row */}
              <div className="grid grid-cols-3 gap-1.5 my-3 text-center">
                <div className="p-2 rounded-xl bg-red-50 text-red-800 text-[11px] font-bold">
                  <span className="block text-base font-black tabular-nums">{overdueCount}</span>
                  <span>{tr('متأخر', 'Overdue')}</span>
                </div>
                <div className="p-2 rounded-xl bg-amber-50 text-amber-800 text-[11px] font-bold">
                  <span className="block text-base font-black tabular-nums">{todayCount}</span>
                  <span>{tr('مستحق اليوم', 'Due Today')}</span>
                </div>
                <div className="p-2 rounded-xl bg-blue-50 text-blue-800 text-[11px] font-bold">
                  <span className="block text-base font-black tabular-nums">{upcomingCount}</span>
                  <span>{tr('قادم (7 أيام)', 'Next 7 Days')}</span>
                </div>
              </div>

              {/* Urgent List */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {approachingInstallments.length > 0 ? (
                  approachingInstallments.slice(0, 5).map((item) => (
                    <div
                      key={`${item.planId}-${item.installment.id}`}
                      className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-800 text-[11px]">{item.customerName}</span>
                          <span
                            className={`text-[9px] font-bold ${
                              item.urgency === 'overdue'
                                ? 'text-red-700'
                                : item.urgency === 'today'
                                ? 'text-amber-700'
                                : 'text-blue-700'
                            }`}
                          >
                            {item.urgency === 'overdue'
                              ? tr(`متأخر ${Math.abs(item.daysDiff)}ي`, `${Math.abs(item.daysDiff)}d late`)
                              : item.urgency === 'today'
                              ? tr('اليوم', 'Today')
                              : tr(`${item.daysDiff}ي`, `in ${item.daysDiff}d`)}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5 tabular-nums">
                          {formatCurrency(item.amount)} · {tr('قسط', 'Inst')} #{item.installment.installmentNumber}
                        </div>
                      </div>

                      {/* Quick WhatsApp button */}
                      <button
                        onClick={(e) => handleQuickWhatsApp(item, e)}
                        className="p-1.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 transition-colors cursor-pointer flex items-center gap-1 text-[10px] font-bold shadow-xs shrink-0"
                        title={tr('إرسال تذكير عبر واتساب', 'Send WhatsApp Reminder')}
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">{tr('واتساب', 'WhatsApp')}</span>
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-400">
                    {tr('لا توجد أقساط تستحق حالياً', 'No due installments right now')}
                  </div>
                )}
              </div>

              {/* View All Button */}
              <div className="pt-3 mt-3 border-t border-slate-200/70">
                <button
                  onClick={() => {
                    setIsAlertsOpen(false);
                    onNavigate('installments');
                  }}
                  className="neu-button-primary w-full py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>{tr('عرض وإدارة جميع الأقساط والتنبيهات', 'View All Installments & Alerts')}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Low Stock Warning Button */}
        {lowStockCount > 0 && (
          <button
            onClick={() => onNavigate('products')}
            title={tr('منتجات قاربت على النفاد', 'Low stock items')}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-300/60 text-amber-700 text-xs font-semibold hover:bg-amber-500/20 transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span className="tabular-nums">{lowStockCount}</span>
            <span className="hidden xl:inline">{tr('نواقص', 'Low stock')}</span>
          </button>
        )}

        {/* Windows 7-11 Ultra-Lite Performance Mode Quick Toggle (Admin Only) */}
        {isAdmin && (
          <button
            onClick={() => {
              const next = !lowSpecMode;
              setLowSpecMode(next);
              showToast(
                next
                  ? tr(
                      '⚡ تم تفعيل وضع الأجهزة الضعيفة وويندوز 7–11 (أقصى سرعة وأقل استهلاك رامات)',
                      '⚡ Enabled Low-Spec Mode for Windows 7-11 (Maximum speed & minimal RAM)'
                    )
                  : tr(
                      'تم العودة إلى وضع المؤثرات البصرية القياسي',
                      'Switched back to standard visual effects mode'
                    ),
                'info'
              );
            }}
            className={`neu-button px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all border shrink-0 ${
              lowSpecMode
                ? 'text-emerald-800 bg-emerald-100/90 border-emerald-300'
                : 'text-amber-800 bg-amber-50/80 border-amber-200 hover:bg-amber-100/80'
            }`}
            title={tr(
              'تفعيل/إيقاف وضع السرعة القصوى للأجهزة الضعيفة وويندوز 7 إلى 11 (للأدمن فقط)',
              'Toggle Ultra-Lite Performance Mode for Low-Spec Windows 7-11 PCs (Admin Only)'
            )}
          >
            <Zap className={`w-3.5 h-3.5 ${lowSpecMode ? 'text-emerald-600 fill-emerald-600' : 'text-amber-600'}`} />
            <span className="hidden xl:inline whitespace-nowrap">
              {lowSpecMode ? tr('وضع خفيف ⚡', 'Lite ON ⚡') : tr('تسريع النظام', 'Lite Mode')}
            </span>
          </button>
        )}

        {/* License & Activation Status Badge (Admin Only) */}
        {isAdmin && licenseState && onOpenActivation && (
          licenseState.isActivated ? (
            <button
              onClick={onOpenActivation}
              className="neu-button px-2.5 py-1.5 rounded-xl text-emerald-700 bg-emerald-50/70 border border-emerald-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0"
              title={tr('البرنامج مفعل بالكامل بترخيص دائم مدى الحياة', 'Permanently licensed lifetime activation')}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden xl:inline whitespace-nowrap">{tr('مرخص دائم', 'Licensed')}</span>
            </button>
          ) : (
            <button
              onClick={onOpenActivation}
              className="neu-button px-2.5 py-1.5 rounded-xl text-amber-800 bg-amber-500/15 border border-amber-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
              title={tr('نسخة تجريبية - انقر لتفعيل البرنامج بالسيريل', 'Trial Version - Click to activate with serial')}
            >
              <Key className="w-3.5 h-3.5 text-amber-600" />
              <span className="whitespace-nowrap tabular-nums">
                {tr(`تجريبي (${licenseState.remainingHours}س)`, `Trial (${licenseState.remainingHours}h)`)}
              </span>
            </button>
          )
        )}

        {/* Quick Currency Switcher */}
        <div className="flex items-center gap-1 px-2 py-1 rounded-xl neu-pressed border border-emerald-200/70 bg-emerald-50/40 text-xs shrink-0">
          <Coins className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <select
            value={activeCurrency?.code || settings.currency || 'EGP'}
            onChange={(e) => {
              const res = switchActiveCurrency(e.target.value);
              if (res.success) {
                showToast(res.message, 'success');
              }
            }}
            className="bg-transparent font-bold text-emerald-800 outline-none text-xs cursor-pointer"
            title={tr('تبديل عملة النظام النشطة وتحديث أسعار البيع والشراء', 'Switch active system currency and update prices')}
          >
            {currencies.map((c) => (
              <option key={c.code} value={c.code}>
                {c.code} ({c.symbol})
              </option>
            ))}
          </select>
        </div>

        {/* Modern Multi-Color Theme Switcher */}
        <div className="relative" ref={themeDropdownRef}>
          <button
            onClick={() => setIsThemeMenuOpen(!isThemeMenuOpen)}
            className="neu-button px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer border border-white/80 shrink-0"
            title={tr('تغيير لون ومظهر البرنامج', 'Change app color theme')}
          >
            <span
              className="w-4 h-4 rounded-full flex items-center justify-center text-white shadow-xs shrink-0"
              style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #10b981 35%, #8b5cf6 70%, #f43f5e 100%)'
              }}
            >
              <Palette className="w-2.5 h-2.5" />
            </span>
            <span className="hidden 2xl:inline whitespace-nowrap">{tr('ألوان البرنامج', 'Themes')}</span>
          </button>

          {isThemeMenuOpen && (
            <div
              className={`absolute ${
                dir === 'rtl' ? 'left-0' : 'right-0'
              } mt-2 w-72 neu-card rounded-3xl p-3.5 shadow-2xl z-50 border border-white/80 backdrop-blur-xl`}
            >
              <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-200/70">
                <div className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded-xl text-white flex items-center justify-center shadow-sm"
                    style={{
                      background: 'linear-gradient(135deg, #3b82f6, #8b5cf6, #ec4899)'
                    }}
                  >
                    <Palette className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-xs">
                      {tr('ألوان ومظهر البرنامج', 'App Color Themes')}
                    </h4>
                    <span className="text-[10px] text-slate-500">
                      {tr('اختر الطابع اللوني العصري المفضل', 'Select your preferred modern theme')}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsThemeMenuOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-1.5 max-h-80 overflow-y-auto pr-0.5">
                {themeOptions.map((theme) => {
                  const isSelected = appTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      onClick={() => {
                        setAppTheme(theme.id);
                        showToast(
                          tr(`تم تطبيق مظهر "${theme.name}" بنجاح`, `Applied "${theme.name}" theme`),
                          'info'
                        );
                        setIsThemeMenuOpen(false);
                      }}
                      className={`w-full p-2 rounded-2xl flex items-center justify-between gap-2.5 text-right transition-all cursor-pointer ${
                        isSelected
                          ? 'neu-pressed border border-blue-400/50'
                          : 'hover:bg-white/60 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-xl bg-gradient-to-br ${theme.gradient} flex items-center justify-center text-white shadow-sm shrink-0`}
                        >
                          {isSelected ? (
                            <Check className="w-4 h-4 stroke-[3]" />
                          ) : (
                            <span className="w-2.5 h-2.5 rounded-full bg-white/80" />
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-slate-800 text-xs">{theme.name}</div>
                          <div className="text-[10px] text-slate-500">{theme.subtitle}</div>
                        </div>
                      </div>
                      {isSelected && (
                        <span className="text-[10px] font-bold text-emerald-700">
                          {tr('نشط', 'Active')}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Language & Direction Switcher (AR RTL <-> EN LTR) */}
        <button
          onClick={toggleLanguage}
          className="neu-button px-2.5 py-1.5 rounded-xl flex items-center gap-1 text-xs font-bold text-slate-700 cursor-pointer shrink-0"
          title={tr('تبديل اللغة إلى الإنجليزية (LTR)', 'Switch language to Arabic (RTL)')}
        >
          <Globe className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span className="hidden lg:inline whitespace-nowrap">
            {language === 'ar' ? 'EN' : 'عربي'}
          </span>
        </button>

        {/* User Card & Logout */}
        <div className="flex items-center gap-1.5 pl-1 pr-1 py-1 rounded-2xl neu-card shrink-0">
          <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold shadow-sm">
            <UserIcon className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-semibold text-slate-700 hidden xl:inline max-w-[95px] truncate">
            {user?.name || user?.username}
          </span>
          <button
            onClick={logout}
            title={t('logout')}
            className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
