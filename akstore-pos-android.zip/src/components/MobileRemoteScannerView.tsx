/**
 * @file components/MobileRemoteScannerView.tsx
 * شاشة قارئ الباركود اللاسلكي على الهاتف المحمول (تفتح عند مسح رمز QR من شاشة الكمبيوتر)
 * Standalone Mobile Phone Wireless Barcode Scanner Remote Connected to PC POS
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Smartphone,
  Camera,
  CheckCircle2,
  RefreshCw,
  Zap,
  ZapOff,
  Wifi,
  Send,
  Image as ImageIcon,
  ScanLine,
  Plus,
  AlertCircle,
  ArrowLeft
} from 'lucide-react';
import {
  openCameraStreamWithFallback,
  setStreamTorch,
  decodeVideoFrame,
  decodeBarcodeFromImageFile,
  notifyMobileConnected,
  sendScannedBarcodeToPos
} from '../utils/barcodeDecoderEngine';
import { playScannerBeep } from '../hooks/useBarcodeScanner';
import { initialProducts } from '../db/initialData';

interface MobileRemoteScannerViewProps {
  sessionId: string;
  onExitRemoteMode?: () => void;
}

export const MobileRemoteScannerView: React.FC<MobileRemoteScannerViewProps> = ({
  sessionId,
  onExitRemoteMode
}) => {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [isStarting, setIsStarting] = useState<boolean>(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [torchSupported, setTorchSupported] = useState<boolean>(false);
  const [torchOn, setTorchOn] = useState<boolean>(false);
  const [scanFlash, setScanFlash] = useState<boolean>(false);
  const [manualBarcode, setManualBarcode] = useState<string>('');
  const [isScanningFile, setIsScanningFile] = useState<boolean>(false);
  const [sentHistory, setSentHistory] = useState<{ code: string; time: string; count: number }[]>([]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const lastScanRef = useRef<{ code: string; timestamp: number }>({ code: '', timestamp: 0 });
  const isDecodingRef = useRef<boolean>(false);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsStreaming(false);
    setTorchOn(false);
  }, []);

  const handleSendBarcode = useCallback(
    async (rawCode: string, bypassCooldown = false) => {
      const cleanCode = rawCode.trim();
      if (!cleanCode) return;

      const now = Date.now();
      if (
        !bypassCooldown &&
        lastScanRef.current.code === cleanCode &&
        now - lastScanRef.current.timestamp < 1500
      ) {
        return;
      }
      lastScanRef.current = { code: cleanCode, timestamp: now };

      playScannerBeep('success');
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(120);
        } catch {
          // ignore
        }
      }

      setScanFlash(true);
      setTimeout(() => setScanFlash(false), 450);

      await sendScannedBarcodeToPos(sessionId, cleanCode, 'كاميرا الموبايل اللاسلكية');

      const timeStr = new Date().toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });

      setSentHistory((prev) => {
        const idx = prev.findIndex((i) => i.code === cleanCode);
        if (idx > -1) {
          const copy = [...prev];
          const existing = copy[idx];
          copy.splice(idx, 1);
          return [{ code: cleanCode, time: timeStr, count: existing.count + 1 }, ...copy];
        }
        return [{ code: cleanCode, time: timeStr, count: 1 }, ...prev.slice(0, 14)];
      });
    },
    [sessionId]
  );

  const startCamera = useCallback(
    async (camId?: string, facing: 'environment' | 'user' = 'environment') => {
      setIsStarting(true);
      setCameraError(null);
      stopCamera();

      try {
        const { stream, cameras: camList, torchSupported: hasTorch } =
          await openCameraStreamWithFallback(camId, facing);
        streamRef.current = stream;
        setCameras(camList);
        setTorchSupported(hasTorch);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
        setIsStreaming(true);
      } catch (err: any) {
        setIsStreaming(false);
        setCameraError(
          'تعذر فتح البث المباشر للكاميرا تلقائياً. يمكنك الضغط على زر "تصوير الباركود بالكاميرا" بالأسفل أو إدخال الباركود مباشرة.'
        );
      } finally {
        setIsStarting(false);
      }
    },
    [stopCamera]
  );

  // Connect heartbeat to PC POS session
  useEffect(() => {
    notifyMobileConnected(sessionId, 'هاتف الكاشير المحمول').then((ok) => setIsConnected(ok));
    const pingTimer = setInterval(() => {
      notifyMobileConnected(sessionId, 'هاتف الكاشير المحمول').then((ok) => setIsConnected(ok));
    }, 8000);
    return () => clearInterval(pingTimer);
  }, [sessionId]);

  // Start camera on mount
  useEffect(() => {
    startCamera(undefined, 'environment');
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  // Continuous frame decoding loop when video stream is active
  useEffect(() => {
    if (!isStreaming) return;
    let tickCount = 0;

    const interval = setInterval(async () => {
      if (isDecodingRef.current) return;
      const video = videoRef.current;
      if (!video || video.readyState < 2) return;

      if (!canvasRef.current) {
        canvasRef.current = document.createElement('canvas');
      }

      isDecodingRef.current = true;
      tickCount += 1;
      try {
        const code = await decodeVideoFrame(video, canvasRef.current, {
          digitalZoom: 1.4,
          enhanceForLaptop: true,
          scanCycle: tickCount
        });
        if (code) {
          await handleSendBarcode(code, false);
        }
      } finally {
        isDecodingRef.current = false;
      }
    }, 180);

    return () => clearInterval(interval);
  }, [isStreaming, handleSendBarcode]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsScanningFile(true);
    setCameraError(null);
    try {
      const code = await decodeBarcodeFromImageFile(file);
      if (code) {
        await handleSendBarcode(code, true);
      } else {
        playScannerBeep('error');
        setCameraError('لم يتم العثور على باركود واضح في الصورة. يرجى تقريب الكاميرا من الباركود والمحاولة مجدداً.');
      }
    } finally {
      setIsScanningFile(false);
      e.target.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col p-3 sm:p-5 select-none" dir="rtl">
      {/* Top Status Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-black text-sm text-white">قارئ باركود الموبايل اللاسلكي</h1>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
              <Wifi className="w-3.5 h-3.5" />
              <span>
                {isConnected
                  ? `متصل بشاشة الكمبيوتر (${sessionId})`
                  : `جاهز للإرسال إلى (${sessionId})`}
              </span>
            </div>
          </div>
        </div>

        {onExitRemoteMode && (
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onExitRemoteMode();
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <span>العودة للنظام</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Live Camera Viewfinder */}
      <div
        className={`relative rounded-3xl overflow-hidden bg-black border-2 transition-all h-64 sm:h-80 w-full mb-3 ${
          scanFlash ? 'border-emerald-400 ring-4 ring-emerald-500/40' : 'border-slate-800'
        }`}
      >
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          playsInline
          muted
          autoPlay
        />

        {/* Target Frame Overlay */}
        {isStreaming && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <div className="w-4/5 max-w-[280px] h-32 border-2 border-emerald-400/90 rounded-2xl relative shadow-[0_0_0_9999px_rgba(2,6,23,0.45)]">
              <div className="absolute inset-x-2 top-1/2 -translate-y-1/2 h-0.5 bg-red-500 shadow-[0_0_10px_#ef4444]" />
              <span className="absolute -top-6 inset-x-0 text-center text-[10px] font-bold text-white bg-slate-900/90 px-2.5 py-0.5 rounded-full mx-auto w-max">
                وجّه الكاميرا نحو الباركود لإرساله للكمبيوتر فوراً
              </span>
            </div>
          </div>
        )}

        {(isStarting || isScanningFile) && (
          <div className="absolute inset-0 bg-slate-950/85 flex flex-col items-center justify-center p-4 text-center">
            <RefreshCw className="w-7 h-7 text-emerald-400 animate-spin mb-2" />
            <span className="text-xs font-bold">
              {isScanningFile ? 'جاري قراءة الباركود من الصورة...' : 'جاري تشغيل كاميرا الموبايل...'}
            </span>
          </div>
        )}

        {scanFlash && (
          <div className="absolute inset-0 bg-emerald-500/35 flex items-center justify-center z-20">
            <div className="bg-emerald-600 text-white px-4 py-2 rounded-2xl font-black text-xs flex items-center gap-1.5 shadow-xl">
              <CheckCircle2 className="w-4 h-4" />
              <span>تم إرسال الباركود إلى شاشة الكمبيوتر!</span>
            </div>
          </div>
        )}
      </div>

      {/* Camera Action Controls */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
        <button
          type="button"
          onClick={() => {
            const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
            setFacingMode(nextFacing);
            startCamera(undefined, nextFacing);
          }}
          className="py-2.5 px-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <RefreshCw className="w-4 h-4 text-blue-400" />
          <span>تبديل الكاميرا</span>
        </button>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handlePhotoUpload}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="py-2.5 px-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <ImageIcon className="w-4 h-4" />
          <span>تصوير الباركود</span>
        </button>

        {torchSupported && (
          <button
            type="button"
            onClick={async () => {
              const next = await setStreamTorch(streamRef.current, !torchOn);
              setTorchOn(next);
            }}
            className={`py-2.5 px-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
              torchOn ? 'bg-amber-500 text-white' : 'bg-slate-900 border border-slate-800 text-slate-300'
            }`}
          >
            {torchOn ? <Zap className="w-4 h-4" /> : <ZapOff className="w-4 h-4" />}
            <span>الفلاش</span>
          </button>
        )}
      </div>

      {cameraError && (
        <div className="p-3 rounded-2xl bg-amber-950/70 border border-amber-700/80 text-amber-200 text-xs flex items-start gap-2 mb-3">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold">{cameraError}</p>
          </div>
        </div>
      )}

      {/* Manual Barcode Input & Quick Product Barcodes for Instant Testing */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 space-y-3 mb-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (manualBarcode.trim()) {
              handleSendBarcode(manualBarcode.trim(), true);
              setManualBarcode('');
            }
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={manualBarcode}
            onChange={(e) => setManualBarcode(e.target.value)}
            placeholder="أو اكتب رقم الباركود هنا لإرساله للكمبيوتر..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span>إرسال</span>
          </button>
        </form>

        <div>
          <span className="text-[11px] text-slate-400 font-bold block mb-1.5">
            أصناف سريعة (اضغط على أي صنف لإرسال باركوده فوراً لشاشة الكمبيوتر):
          </span>
          <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto">
            {initialProducts.slice(0, 6).map((prod) => (
              <button
                key={prod.id}
                type="button"
                onClick={() => handleSendBarcode(prod.barcode, true)}
                className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-right text-xs flex items-center justify-between gap-1 cursor-pointer"
              >
                <div className="truncate">
                  <div className="font-bold text-slate-200 truncate text-[11px]">{prod.name}</div>
                  <div className="font-mono text-[10px] text-emerald-400">{prod.barcode}</div>
                </div>
                <Plus className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Sent History Log */}
      {sentHistory.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span className="flex items-center gap-1.5">
              <ScanLine className="w-4 h-4 text-emerald-400" />
              <span>تم إرسالها للكمبيوتر:</span>
            </span>
            <span className="text-emerald-400 tabular-nums">
              {sentHistory.reduce((a, b) => a + b.count, 0)} عملية مسح
            </span>
          </div>
          <div className="space-y-1.5 max-h-36 overflow-y-auto">
            {sentHistory.map((item) => (
              <div
                key={item.code}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-mono font-bold text-white tabular-nums">{item.code}</span>
                  <span className="text-[10px] text-emerald-400 font-bold tabular-nums">×{item.count}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSendBarcode(item.code, true)}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold cursor-pointer"
                >
                  +1 تكرار
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
