/**
 * @file utils/win7Polyfills.ts
 * طبقة التوافق الشاملة ودعم الأنظمة القديمة والأجهزة الضعيفة (Windows 7 / 8 / 8.1 / 10 / 11 - 32bit & 64bit)
 * Comprehensive Runtime Polyfills & Hardware Compatibility Layer for Windows 7 through Windows 11
 */

export interface SystemCompatibilityInfo {
  osName: string;
  osVersion: string;
  isLegacyWindows: boolean; // Windows 7, 8, 8.1, Vista, XP
  isWindows: boolean;
  architecture: '32-bit (x86)' | '64-bit (x64)';
  cpuCores: number;
  ramGB: number | null;
  isLowSpecHardware: boolean;
  browserInfo: string;
  recommendedLiteMode: boolean;
}

/**
 * تطبيق كافة البدائل البرمجية (Polyfills) للدوال الحديثة غير الموجودة في متصفحات ويندوز 7 و 8
 * مثل Chrome 79-109, Edge 79-109, Firefox ESR, Electron 22
 */
export function applyWindows7Polyfills(): void {
  if (typeof window === 'undefined') return;

  try {
    // 1. globalThis polyfill
    if (typeof window.globalThis === 'undefined') {
      (window as any).globalThis = window;
    }

    // 2. Object.hasOwn (Added in Chrome 93 - missing in older Win7 browsers)
    if (typeof (Object as any).hasOwn !== 'function') {
      (Object as any).hasOwn = function (obj: any, prop: PropertyKey): boolean {
        if (obj == null) {
          throw new TypeError('Cannot convert undefined or null to object');
        }
        return Object.prototype.hasOwnProperty.call(Object(obj), prop);
      };
    }

    // 3. Array.prototype.at & String.prototype.at (Added in Chrome 92)
    if (typeof Array.prototype.at !== 'function') {
      Object.defineProperty(Array.prototype, 'at', {
        value: function (n: number) {
          n = Math.trunc(n) || 0;
          if (n < 0) n += this.length;
          if (n < 0 || n >= this.length) return undefined;
          return this[n];
        },
        writable: true,
        configurable: true
      });
    }

    if (typeof (String.prototype as any).at !== 'function') {
      Object.defineProperty(String.prototype, 'at', {
        value: function (n: number) {
          n = Math.trunc(n) || 0;
          if (n < 0) n += this.length;
          if (n < 0 || n >= this.length) return undefined;
          return this.charAt(n);
        },
        writable: true,
        configurable: true
      });
    }

    // 4. Array.prototype.findLast & findLastIndex (Added in Chrome 97)
    if (typeof (Array.prototype as any).findLast !== 'function') {
      Object.defineProperty(Array.prototype, 'findLast', {
        value: function (predicate: any, thisArg?: any) {
          for (let i = this.length - 1; i >= 0; i--) {
            if (predicate.call(thisArg, this[i], i, this)) {
              return this[i];
            }
          }
          return undefined;
        },
        writable: true,
        configurable: true
      });
    }

    if (typeof (Array.prototype as any).findLastIndex !== 'function') {
      Object.defineProperty(Array.prototype, 'findLastIndex', {
        value: function (predicate: any, thisArg?: any) {
          for (let i = this.length - 1; i >= 0; i--) {
            if (predicate.call(thisArg, this[i], i, this)) {
              return i;
            }
          }
          return -1;
        },
        writable: true,
        configurable: true
      });
    }

    // 5. Array.prototype.toSorted / toReversed / toSpliced (Added in Chrome 110 - NOT in Windows 7 Chrome 109!)
    if (typeof (Array.prototype as any).toSorted !== 'function') {
      Object.defineProperty(Array.prototype, 'toSorted', {
        value: function (compareFn?: any) {
          return Array.prototype.slice.call(this).sort(compareFn);
        },
        writable: true,
        configurable: true
      });
    }

    if (typeof (Array.prototype as any).toReversed !== 'function') {
      Object.defineProperty(Array.prototype, 'toReversed', {
        value: function () {
          return Array.prototype.slice.call(this).reverse();
        },
        writable: true,
        configurable: true
      });
    }

    if (typeof (Array.prototype as any).toSpliced !== 'function') {
      Object.defineProperty(Array.prototype, 'toSpliced', {
        value: function (start: number, deleteCount?: number, ...items: any[]) {
          const copy = Array.prototype.slice.call(this);
          if (arguments.length === 0) return copy;
          if (arguments.length === 1) {
            copy.splice(start);
          } else {
            copy.splice(start, deleteCount as number, ...items);
          }
          return copy;
        },
        writable: true,
        configurable: true
      });
    }

    // 6. String.prototype.replaceAll (Added in Chrome 85)
    if (typeof (String.prototype as any).replaceAll !== 'function') {
      Object.defineProperty(String.prototype, 'replaceAll', {
        value: function (search: string | RegExp, replacement: any) {
          if (search instanceof RegExp) {
            if (!search.global) {
              throw new TypeError('String.prototype.replaceAll called with a non-global RegExp argument');
            }
            return this.replace(search, replacement);
          }
          return this.split(String(search)).join(String(replacement));
        },
        writable: true,
        configurable: true
      });
    }

    // 7. window.structuredClone (Added in Chrome 98)
    if (typeof window.structuredClone !== 'function') {
      (window as any).structuredClone = function <T>(val: T): T {
        if (val === undefined || val === null || typeof val !== 'object') {
          return val;
        }
        try {
          return JSON.parse(JSON.stringify(val));
        } catch {
          return val;
        }
      };
    }

    // 8. crypto.randomUUID (Fails on non-HTTPS LAN or older Win7 browsers)
    if (typeof window.crypto !== 'undefined' && typeof window.crypto.randomUUID !== 'function') {
      try {
        (window.crypto as any).randomUUID = function () {
          return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = (Math.random() * 16) | 0;
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
          });
        };
      } catch {
        // Ignore if crypto object is read-only
      }
    }

    // 9. MediaQueryList.addEventListener fallback for older browsers
    if (typeof window.matchMedia === 'function') {
      const mql = window.matchMedia('(min-width: 1px)');
      if (mql && typeof mql.addEventListener !== 'function' && typeof mql.addListener === 'function') {
        const origMatchMedia = window.matchMedia.bind(window);
        window.matchMedia = function (query: string): MediaQueryList {
          const list = origMatchMedia(query);
          if (list && typeof list.addEventListener !== 'function') {
            (list as any).addEventListener = function (type: string, listener: any) {
              if (type === 'change' && typeof list.addListener === 'function') {
                list.addListener(listener);
              }
            };
            (list as any).removeEventListener = function (type: string, listener: any) {
              if (type === 'change' && typeof list.removeListener === 'function') {
                list.removeListener(listener);
              }
            };
          }
          return list;
        };
      }
    }

    // 10. Safe ResizeObserver fallback
    if (typeof window.ResizeObserver === 'undefined') {
      (window as any).ResizeObserver = class ResizeObserverFallback {
        observe() {}
        unobserve() {}
        disconnect() {}
      };
    }

    // 11. Safe Element.prototype.scrollIntoView (older browsers don't support object options)
    const origScrollIntoView = Element.prototype.scrollIntoView;
    if (origScrollIntoView) {
      Element.prototype.scrollIntoView = function (arg?: boolean | ScrollIntoViewOptions) {
        try {
          origScrollIntoView.call(this, arg);
        } catch {
          origScrollIntoView.call(this, true);
        }
      };
    }

    // 12. Safe navigator.clipboard.writeText fallback for HTTP / Windows 7
    if (!navigator.clipboard) {
      try {
        (navigator as any).clipboard = {
          writeText: (text: string) => copyTextFallback(text)
        };
      } catch {
        // Ignore if navigator.clipboard is getter-only
      }
    }
  } catch (err) {
    console.warn('Win7 polyfill warning:', err);
  }
}

/**
 * نسخ النصوص بأمان على ويندوز 7 والمتصفحات القديمة حتى بدون HTTPS
 */
export function copyTextFallback(text: string): Promise<void> {
  return new Promise((resolve) => {
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function' && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(resolve).catch(() => {
          execCopyCommand(text);
          resolve();
        });
        return;
      }
    } catch {
      // Fallback below
    }
    execCopyCommand(text);
    resolve();
  });
}

function execCopyCommand(text: string): void {
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-9999px';
    textArea.style.top = '0';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
  } catch (e) {
    console.warn('Copy fallback failed:', e);
  }
}

/**
 * فحص إمكانيات الجهاز ونظام التشغيل (Windows 7 / 8 / 8.1 / 10 / 11)
 */
export function detectSystemCompatibility(): SystemCompatibilityInfo {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  let osName = 'Windows 10 / 11';
  let osVersion = 'NT 10.0';
  let isLegacyWindows = false;
  const isWindows = /Windows/i.test(ua);

  if (/Windows NT 6\.1/i.test(ua)) {
    osName = 'Windows 7';
    osVersion = 'NT 6.1 (SP1)';
    isLegacyWindows = true;
  } else if (/Windows NT 6\.2/i.test(ua)) {
    osName = 'Windows 8';
    osVersion = 'NT 6.2';
    isLegacyWindows = true;
  } else if (/Windows NT 6\.3/i.test(ua)) {
    osName = 'Windows 8.1';
    osVersion = 'NT 6.3';
    isLegacyWindows = true;
  } else if (/Windows NT 6\.0/i.test(ua) || /Windows NT 5\./i.test(ua)) {
    osName = 'Windows Legacy (XP/Vista)';
    osVersion = 'NT 5.x/6.0';
    isLegacyWindows = true;
  } else if (/Windows NT 10\.0/i.test(ua)) {
    osName = 'Windows 10 / 11';
    osVersion = 'NT 10.0';
  } else if (!isWindows) {
    if (/Mac OS X/i.test(ua)) osName = 'macOS';
    else if (/Android/i.test(ua)) osName = 'Android';
    else if (/Linux/i.test(ua)) osName = 'Linux';
    else osName = 'Desktop OS';
    osVersion = 'Standard';
  }

  const is64Bit = /WOW64|Win64|x64|amd64|x86_64/i.test(ua);
  const architecture: '32-bit (x86)' | '64-bit (x64)' = is64Bit ? '64-bit (x64)' : '32-bit (x86)';

  const cpuCores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) ? navigator.hardwareConcurrency : 2;
  const ramGB = (typeof navigator !== 'undefined' && (navigator as any).deviceMemory)
    ? Number((navigator as any).deviceMemory)
    : null;

  // Detect browser engine & version
  let browserInfo = 'Modern Browser';
  const chromeMatch = ua.match(/Edg\/(\d+)/i) || ua.match(/Chrome\/(\d+)/i) || ua.match(/Firefox\/(\d+)/i);
  if (chromeMatch) {
    const brName = /Edg\//i.test(ua) ? 'Microsoft Edge' : /Firefox\//i.test(ua) ? 'Mozilla Firefox' : 'Google Chrome';
    browserInfo = `${brName} v${chromeMatch[1]}`;
    const majorVer = parseInt(chromeMatch[1], 10);
    if (majorVer > 0 && majorVer <= 109) {
      isLegacyWindows = true;
    }
  }

  // Check URL query param `?lite=1` or `?win7=1`
  const hasUrlLiteFlag = typeof window !== 'undefined' && (
    window.location.search.includes('lite=1') ||
    window.location.search.includes('win7=1')
  );

  const isLowSpecHardware =
    isLegacyWindows ||
    hasUrlLiteFlag ||
    cpuCores <= 2 ||
    (ramGB !== null && ramGB <= 4);

  return {
    osName,
    osVersion,
    isLegacyWindows,
    isWindows,
    architecture,
    cpuCores,
    ramGB,
    isLowSpecHardware,
    browserInfo,
    recommendedLiteMode: isLowSpecHardware
  };
}

/**
 * تحديد ما إذا كان وضع الأجهزة الضعيفة وويندوز 7 مفعلاً
 */
export function getInitialLowSpecMode(savedSetting?: boolean): boolean {
  if (typeof window === 'undefined') return false;

  // 1. Check URL parameter (?lite=1 or ?win7=1)
  if (window.location.search.includes('lite=1') || window.location.search.includes('win7=1')) {
    localStorage.setItem('pos_low_spec_mode', 'true');
    return true;
  }

  // 2. Check explicit localStorage preference
  const stored = localStorage.getItem('pos_low_spec_mode');
  if (stored === 'true') return true;
  if (stored === 'false') return false;

  // 3. Check saved store settings
  if (typeof savedSetting === 'boolean') {
    return savedSetting;
  }

  // 4. Auto-detect Windows 7 / 8 / 8.1 or low RAM/CPU hardware
  const sys = detectSystemCompatibility();
  return sys.recommendedLiteMode;
}

/**
 * تفعيل أو تعطيل وضع الأداء الخفيف لويندوز 7 والأجهزة الضعيفة في الـ DOM
 */
export function applyLowSpecModeToDOM(enabled: boolean): void {
  if (typeof document === 'undefined') return;
  if (enabled) {
    document.documentElement.classList.add('low-spec-mode');
    document.documentElement.setAttribute('data-low-spec', 'true');
    if (document.body) {
      document.body.classList.add('low-spec-mode');
    }
  } else {
    document.documentElement.classList.remove('low-spec-mode');
    document.documentElement.setAttribute('data-low-spec', 'false');
    if (document.body) {
      document.body.classList.remove('low-spec-mode');
    }
  }
}

// Execute polyfills immediately on module import
applyWindows7Polyfills();
