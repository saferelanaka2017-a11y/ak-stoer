/**
 * @file utils/screenAdapter.ts
 * نظام التكيف الذكي لحجم الشاشة (Auto-Adaptive Screen Size & UI Scaling Engine)
 * يجعل واجهة النظام تتوافق تلقائياً مع أي مقاس شاشة كمبيوتر:
 * من شاشات الكاشير المربعة القديمة (800x600 و 1024x768) واللابتوب (1366x768)
 * وحتى الشاشات العريضة الكاملة (1920x1080 Full HD و 2K و 4K)
 */

export type ScreenScalePreset = 'auto' | '75' | '80' | '85' | '90' | '95' | '100' | '105' | '110' | '115' | '125';

const STORAGE_SCALE_KEY = 'akstore_screen_scale_preset_v1';
const STORAGE_SIDEBAR_COLLAPSED_KEY = 'akstore_sidebar_collapsed_v1';

export interface ScreenResolutionInfo {
  width: number;
  height: number;
  computedRootFontSizePx: number;
  effectiveScalePercent: number;
  monitorCategoryAr: string;
  monitorCategoryEn: string;
}

/**
 * يحسب حجم الخط الأساسي (Root Font Size بالبكسل) تلقائياً بناءً على عرض وارتفاع شاشة الكمبيوتر
 * لأن جميع عناصر Tailwind تعتمد على وحدات rem، فإن تغيير font-size لوسم <html>
 * يغير حجم النظام بالكامل (الأزرار، الجداول، البطاقات، القوائم، الخطوط) بتناسب دقيق 100%
 * دون التأثير على إحداثيات الماوس أو المخططات البيانية (Recharts).
 */
export function computeAutoRootFontSize(width: number, height: number): {
  fontSizePx: number;
  scalePercent: number;
  categoryAr: string;
  categoryEn: string;
} {
  // شاشات الكاشير الصغيرة جداً أو اللمس القديمة (800x600 إلى 1024x768)
  if (width <= 1050 || height <= 650) {
    return {
      fontSizePx: 12.5,
      scalePercent: 78,
      categoryAr: 'شاشة كاشير مدمجة (1024×768 أو أصغر)',
      categoryEn: 'Compact POS Monitor (1024×768)'
    };
  }

  // شاشات اللابتوب القياسية وشاشات الكاشير المتوسطة (1280x720 / 1366x768)
  if (width <= 1380 || height <= 780) {
    return {
      fontSizePx: 13.6,
      scalePercent: 85,
      categoryAr: 'شاشة لابتوب / متوسطة (1366×768)',
      categoryEn: 'Standard Laptop / HD (1366×768)'
    };
  }

  // شاشات المكتب المتوسطة العريضة (1440x900 / 1536x864 / 1600x900)
  if (width <= 1650 || height <= 920) {
    return {
      fontSizePx: 14.8,
      scalePercent: 92,
      categoryAr: 'شاشة مكتبية متوسطة (1600×900)',
      categoryEn: 'Desktop HD+ (1600×900)'
    };
  }

  // شاشات Full HD القياسية (1920x1080)
  if (width <= 2100) {
    return {
      fontSizePx: 16,
      scalePercent: 100,
      categoryAr: 'شاشة كبيرة عالية الدقة (1920×1080 Full HD)',
      categoryEn: 'Full HD Monitor (1920×1080)'
    };
  }

  // شاشات 2K / QHD و 4K الكبيرة جداً (2560x1440 فأعلى)
  if (width <= 2800) {
    return {
      fontSizePx: 17.6,
      scalePercent: 110,
      categoryAr: 'شاشة فائقة الدقة (2K QHD)',
      categoryEn: '2K QHD Wide Monitor'
    };
  }

  return {
    fontSizePx: 19.2,
    scalePercent: 120,
    categoryAr: 'شاشة عملاقة (4K Ultra HD)',
    categoryEn: '4K Ultra HD Monitor'
  };
}

export function getSavedScreenScalePreset(): ScreenScalePreset {
  try {
    const saved = localStorage.getItem(STORAGE_SCALE_KEY) as ScreenScalePreset | null;
    if (
      saved &&
      ['auto', '75', '80', '85', '90', '95', '100', '105', '110', '115', '125'].includes(saved)
    ) {
      return saved;
    }
  } catch {
    // ignore storage errors
  }
  return 'auto';
}

export function saveScreenScalePreset(preset: ScreenScalePreset): void {
  try {
    localStorage.setItem(STORAGE_SCALE_KEY, preset);
  } catch {
    // ignore
  }
}

export function applyScreenScaleToDOM(preset: ScreenScalePreset): ScreenResolutionInfo {
  const width = typeof window !== 'undefined' ? window.innerWidth : 1366;
  const height = typeof window !== 'undefined' ? window.innerHeight : 768;

  const autoInfo = computeAutoRootFontSize(width, height);
  let fontSizePx = autoInfo.fontSizePx;
  let effectiveScalePercent = autoInfo.scalePercent;

  if (preset !== 'auto') {
    const numericPercent = parseInt(preset, 10) || 100;
    effectiveScalePercent = numericPercent;
    fontSizePx = Number(((16 * numericPercent) / 100).toFixed(2));
  }

  if (typeof document !== 'undefined') {
    document.documentElement.style.fontSize = `${fontSizePx}px`;
    document.documentElement.setAttribute('data-screen-scale', preset);
  }

  return {
    width,
    height,
    computedRootFontSizePx: fontSizePx,
    effectiveScalePercent,
    monitorCategoryAr: autoInfo.categoryAr,
    monitorCategoryEn: autoInfo.categoryEn
  };
}

export function getSavedSidebarCollapsed(): boolean {
  try {
    const saved = localStorage.getItem(STORAGE_SIDEBAR_COLLAPSED_KEY);
    if (saved !== null) {
      return saved === 'true';
    }
    // على الشاشات الصغيرة أقل من 1200 بكسل، يفضل طي القائمة الجانبية افتراضياً لتوسيع شاشة البيع
    if (typeof window !== 'undefined' && window.innerWidth < 1180) {
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

export function saveSidebarCollapsed(collapsed: boolean): void {
  try {
    localStorage.setItem(STORAGE_SIDEBAR_COLLAPSED_KEY, String(collapsed));
  } catch {
    // ignore
  }
}

export async function toggleBrowserFullscreen(): Promise<boolean> {
  if (typeof document === 'undefined') return false;
  try {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen();
      return true;
    } else if (document.exitFullscreen) {
      await document.exitFullscreen();
      return false;
    }
  } catch {
    // ignore if blocked by iframe policy
  }
  return !!document.fullscreenElement;
}
