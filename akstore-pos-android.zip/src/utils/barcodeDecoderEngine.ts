/**
 * @file utils/barcodeDecoderEngine.ts
 * محرك فك تشفير الباركود الفائق لكاميرا اللاب توب وكاميرا الموبايل
 * Ultra-Fast Hybrid Barcode Decoder Engine (ZXing MultiFormatReader TryHarder + Native BarcodeDetector + Laptop Webcam Auto-Sharpener)
 */

import {
  MultiFormatReader,
  BarcodeFormat,
  DecodeHintType,
  HTMLCanvasElementLuminanceSource,
  BinaryBitmap,
  HybridBinarizer,
  GlobalHistogramBinarizer
} from '@zxing/library';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';

export const SUPPORTED_BARCODE_FORMATS = [
  Html5QrcodeSupportedFormats.EAN_13,
  Html5QrcodeSupportedFormats.EAN_8,
  Html5QrcodeSupportedFormats.UPC_A,
  Html5QrcodeSupportedFormats.UPC_E,
  Html5QrcodeSupportedFormats.CODE_128,
  Html5QrcodeSupportedFormats.CODE_39,
  Html5QrcodeSupportedFormats.CODE_93,
  Html5QrcodeSupportedFormats.ITF,
  Html5QrcodeSupportedFormats.CODABAR,
  Html5QrcodeSupportedFormats.QR_CODE,
  Html5QrcodeSupportedFormats.DATA_MATRIX
];

const NATIVE_DETECTOR_FORMATS = [
  'ean_13',
  'ean_8',
  'upc_a',
  'upc_e',
  'code_128',
  'code_39',
  'code_93',
  'itf',
  'codabar',
  'qr_code',
  'data_matrix'
];

// Configure ZXing MultiFormatReader with TRY_HARDER enabled for fixed-focus laptop webcams
let sharedZxingReader: MultiFormatReader | null = null;

function getZxingReader(): MultiFormatReader {
  if (!sharedZxingReader) {
    const reader = new MultiFormatReader();
    const hints = new Map();
    hints.set(DecodeHintType.POSSIBLE_FORMATS, [
      BarcodeFormat.EAN_13,
      BarcodeFormat.EAN_8,
      BarcodeFormat.UPC_A,
      BarcodeFormat.UPC_E,
      BarcodeFormat.CODE_128,
      BarcodeFormat.CODE_39,
      BarcodeFormat.CODE_93,
      BarcodeFormat.ITF,
      BarcodeFormat.CODABAR,
      BarcodeFormat.QR_CODE,
      BarcodeFormat.DATA_MATRIX
    ]);
    hints.set(DecodeHintType.TRY_HARDER, true);
    reader.setHints(hints);
    sharedZxingReader = reader;
  }
  return sharedZxingReader;
}

/**
 * Decode a canvas directly in memory using ZXing with both HybridBinarizer & GlobalHistogramBinarizer
 * Zero JPEG compression overhead (< 5ms execution)
 */
function decodeCanvasWithZxing(canvas: HTMLCanvasElement): string | null {
  if (!canvas || canvas.width === 0 || canvas.height === 0) return null;
  const reader = getZxingReader();

  try {
    const luminanceSource = new HTMLCanvasElementLuminanceSource(canvas);

    // 1. Try HybridBinarizer (best for uneven lighting / shadows on laptop webcams)
    try {
      const hybridBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
      const res1 = reader.decodeWithState(hybridBitmap);
      if (res1 && res1.getText()) {
        return res1.getText().trim();
      }
    } catch {
      // continue
    }

    // 2. Try GlobalHistogramBinarizer (best for low-contrast / soft fixed-focus laptop webcams)
    try {
      const globalBitmap = new BinaryBitmap(new GlobalHistogramBinarizer(luminanceSource));
      const res2 = reader.decodeWithState(globalBitmap);
      if (res2 && res2.getText()) {
        return res2.getText().trim();
      }
    } catch {
      // continue
    }

    // 3. Try inverted luminance source (for light-on-dark barcodes)
    try {
      const invertedSource = luminanceSource.invert();
      const invBitmap = new BinaryBitmap(new HybridBinarizer(invertedSource));
      const res3 = reader.decodeWithState(invBitmap);
      if (res3 && res3.getText()) {
        return res3.getText().trim();
      }
    } catch {
      // continue
    }
  } catch {
    return null;
  }

  return null;
}

/**
 * Apply 1D horizontal unsharp mask + local contrast normalization on a Canvas
 * Specifically designed to make blurry fixed-focus laptop webcam barcode bars razor-sharp
 */
function enhanceCanvasForLaptopBarcode(canvas: HTMLCanvasElement): void {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  if (w < 10 || h < 10) return;

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Step 1: Convert to grayscale and find 5th–95th percentile luminance range
  const gray = new Uint8Array(w * h);
  let minLum = 255;
  let maxLum = 0;

  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    const lum = (data[i] * 77 + data[i + 1] * 150 + data[i + 2] * 29) >> 8;
    gray[p] = lum;
    if (lum < minLum) minLum = lum;
    if (lum > maxLum) maxLum = lum;
  }

  const range = Math.max(25, maxLum - minLum);

  // Step 2: Horizontal 1D sharpening kernel [-0.6, 2.2, -0.6] + contrast stretch
  for (let y = 0; y < h; y++) {
    const rowOffset = y * w;
    for (let x = 1; x < w - 1; x++) {
      const idx = rowOffset + x;
      const c = ((gray[idx] - minLum) * 255) / range;
      const l = ((gray[idx - 1] - minLum) * 255) / range;
      const r = ((gray[idx + 1] - minLum) * 255) / range;

      // Sharpen horizontal transitions (vertical barcode bars!)
      let sharpened = c * 2.3 - (l + r) * 0.65;
      if (sharpened < 0) sharpened = 0;
      else if (sharpened > 255) sharpened = 255;

      const outVal = sharpened | 0;
      const rgbaIdx = idx << 2;
      data[rgbaIdx] = outVal;
      data[rgbaIdx + 1] = outVal;
      data[rgbaIdx + 2] = outVal;
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

let sharedNativeDetector: any = null;

function getNativeBarcodeDetector(): any | null {
  if (typeof window === 'undefined') return null;
  const BarcodeDetectorCtor = (window as any).BarcodeDetector;
  if (!BarcodeDetectorCtor) return null;
  if (!sharedNativeDetector) {
    try {
      sharedNativeDetector = new BarcodeDetectorCtor({
        formats: NATIVE_DETECTOR_FORMATS
      });
    } catch {
      try {
        sharedNativeDetector = new BarcodeDetectorCtor();
      } catch {
        sharedNativeDetector = null;
      }
    }
  }
  return sharedNativeDetector;
}

let hiddenScannerInstance: Html5Qrcode | null = null;

function getHiddenHtml5Scanner(): Html5Qrcode | null {
  if (typeof document === 'undefined') return null;
  const hiddenId = 'akstore-hidden-barcode-decoder';
  let el = document.getElementById(hiddenId);
  if (!el) {
    el = document.createElement('div');
    el.id = hiddenId;
    el.style.position = 'fixed';
    el.style.left = '-9999px';
    el.style.top = '-9999px';
    el.style.width = '300px';
    el.style.height = '300px';
    el.style.overflow = 'hidden';
    el.style.pointerEvents = 'none';
    document.body.appendChild(el);
  }
  if (!hiddenScannerInstance) {
    try {
      hiddenScannerInstance = new Html5Qrcode(hiddenId, {
        formatsToSupport: SUPPORTED_BARCODE_FORMATS,
        verbose: false
      });
    } catch {
      hiddenScannerInstance = null;
    }
  }
  return hiddenScannerInstance;
}

/**
 * فتح كاميرا اللاب توب أو الموبايل بأعلى دقة متاحة (Full HD / HD) مع تفعيل التركيز المستمر إن وُجد
 */
export async function openCameraStreamWithFallback(
  preferredDeviceId?: string,
  preferredFacingMode: 'environment' | 'user' = 'environment'
): Promise<{
  stream: MediaStream;
  cameras: { id: string; label: string }[];
  torchSupported: boolean;
  isFrontOrLaptopCam: boolean;
}> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    throw new Error('CAMERA_API_UNSUPPORTED');
  }

  const constraintAttempts: MediaStreamConstraints[] = [];

  if (preferredDeviceId) {
    constraintAttempts.push(
      {
        video: {
          deviceId: { exact: preferredDeviceId },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          frameRate: { ideal: 30 }
        },
        audio: false
      },
      {
        video: {
          deviceId: { exact: preferredDeviceId },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      }
    );
  }

  constraintAttempts.push(
    {
      video: {
        facingMode: { ideal: preferredFacingMode },
        width: { ideal: 1920 },
        height: { ideal: 1080 },
        frameRate: { ideal: 30 }
      },
      audio: false
    },
    {
      video: {
        facingMode: { ideal: preferredFacingMode },
        width: { ideal: 1280 },
        height: { ideal: 720 }
      },
      audio: false
    },
    {
      video: {
        width: { ideal: 1280 },
        height: { ideal: 720 }
      },
      audio: false
    },
    {
      video: true,
      audio: false
    }
  );

  let acquiredStream: MediaStream | null = null;
  let lastError: unknown = null;

  for (const constraints of constraintAttempts) {
    try {
      acquiredStream = await navigator.mediaDevices.getUserMedia(constraints);
      if (acquiredStream) break;
    } catch (err) {
      lastError = err;
    }
  }

  if (!acquiredStream) {
    throw lastError || new Error('CAMERA_START_FAILED');
  }

  // Try to enable continuous autofocus / macro focus & sharpness on the active video track
  let torchSupported = false;
  let isFrontOrLaptopCam = false;
  try {
    const track = acquiredStream.getVideoTracks()[0];
    if (track) {
      const labelLower = (track.label || '').toLowerCase();
      const settings = track.getSettings?.() || {};
      if (
        settings.facingMode === 'user' ||
        labelLower.includes('front') ||
        labelLower.includes('webcam') ||
        labelLower.includes('integrated') ||
        labelLower.includes('hd camera') ||
        labelLower.includes('usb')
      ) {
        isFrontOrLaptopCam = true;
      }

      if (typeof track.getCapabilities === 'function') {
        const caps = track.getCapabilities() as any;
        torchSupported = Boolean(caps?.torch);

        const advancedConstraints: Record<string, any> = {};
        if (Array.isArray(caps?.focusMode) && caps.focusMode.includes('continuous')) {
          advancedConstraints.focusMode = 'continuous';
        }
        if (Array.isArray(caps?.exposureMode) && caps.exposureMode.includes('continuous')) {
          advancedConstraints.exposureMode = 'continuous';
        }
        if (Object.keys(advancedConstraints).length > 0) {
          await track.applyConstraints({ advanced: [advancedConstraints] as any }).catch(() => {});
        }
      }
    }
  } catch {
    // ignore capability errors
  }

  // Enumerate cameras AFTER stream is open so labels are populated
  let cameras: { id: string; label: string }[] = [];
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    cameras = devices
      .filter((d) => d.kind === 'videoinput')
      .map((d, idx) => ({
        id: d.deviceId,
        label: d.label || `Camera ${idx + 1}`
      }));
  } catch {
    cameras = [];
  }

  return {
    stream: acquiredStream,
    cameras,
    torchSupported,
    isFrontOrLaptopCam
  };
}

/**
 * تشغيل أو إيقاف فلاش الكاميرا (Torch)
 */
export async function setStreamTorch(stream: MediaStream | null, enable: boolean): Promise<boolean> {
  if (!stream) return false;
  try {
    const track = stream.getVideoTracks()[0];
    if (!track) return false;
    await track.applyConstraints({
      advanced: [{ torch: enable } as any]
    });
    return enable;
  } catch {
    return false;
  }
}

export interface VideoDecodeOptions {
  digitalZoom?: number; // 1 to 3
  enhanceForLaptop?: boolean; // true by default
  scanCycle?: number; // increments every frame to alternate passes smoothly
}

/**
 * قراءة الباركود من الفيديو الحي (يدعم كاميرا اللاب توب وكاميرا الموبايل بسرعة فائقة)
 * يفحص:
 * 1) منطقة التركيز الوسطى المكبّرة (Center ROI) مع ZXing + BarcodeDetector
 * 2) تمرير التنقية والتوضيح الفائق لخطوط الباركود الباهتة في كاميرا اللاب توب (1D Horizontal Unsharp + Contrast Stretch)
 * 3) تمرير معكوس أفقياً (Mirrored Pass) لكاميرات اللاب توب التي تعكس الصورة تلقائياً
 * 4) الإطار الكامل للرموز الكبيرة
 */
export async function decodeVideoFrame(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  options: VideoDecodeOptions = {}
): Promise<string | null> {
  if (!video || video.readyState < 2 || video.videoWidth === 0 || video.videoHeight === 0) {
    return null;
  }

  const vw = video.videoWidth;
  const vh = video.videoHeight;
  const zoom = Math.max(1, Math.min(3, options.digitalZoom || 1));
  const enhance = options.enhanceForLaptop !== false;
  const cycle = options.scanCycle || 0;

  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;

  // ---------------------------------------------------------------------------
  // 1. Native Hardware BarcodeDetector on live video (if OS supports it)
  // ---------------------------------------------------------------------------
  const nativeDetector = getNativeBarcodeDetector();
  if (nativeDetector) {
    try {
      const results = await nativeDetector.detect(video);
      if (results && results.length > 0) {
        const raw = String(results[0].rawValue || '').trim();
        if (raw) return raw;
      }
    } catch {
      // continue to ZXing & ROI passes
    }
  }

  // ---------------------------------------------------------------------------
  // 2. Center Target Box ROI (Where the user holds the barcode on Laptop/Mobile)
  //    By cropping the center region and scaling to 760px width, even a small
  //    barcode held 20-30cm from a laptop webcam fills the entire scan line!
  // ---------------------------------------------------------------------------
  const roiFractionW = Math.min(0.88, 0.72 / Math.sqrt(zoom));
  const roiFractionH = Math.min(0.75, 0.52 / Math.sqrt(zoom));

  const cropW = Math.max(160, Math.floor(vw * roiFractionW));
  const cropH = Math.max(100, Math.floor(vh * roiFractionH));
  const cropX = Math.floor((vw - cropW) / 2);
  const cropY = Math.floor((vh - cropH) / 2);

  const outW = 720;
  const outH = Math.max(200, Math.floor((cropH / cropW) * outW));

  canvas.width = outW;
  canvas.height = outH;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(video, cropX, cropY, cropW, cropH, 0, 0, outW, outH);

  // Try raw ROI decode with ZXing
  const rawRoiResult = decodeCanvasWithZxing(canvas);
  if (rawRoiResult) return rawRoiResult;

  // Try Native Detector on the zoomed ROI canvas
  if (nativeDetector) {
    try {
      const roiNative = await nativeDetector.detect(canvas);
      if (roiNative && roiNative.length > 0 && roiNative[0].rawValue) {
        return String(roiNative[0].rawValue).trim();
      }
    } catch {
      // continue
    }
  }

  // ---------------------------------------------------------------------------
  // 3. Laptop Webcam Super-Sharpener Pass (1D Unsharp Mask + Contrast Stretch)
  //    Turns blurry gray laptop webcam bars into crisp black-and-white bars!
  // ---------------------------------------------------------------------------
  if (enhance) {
    enhanceCanvasForLaptopBarcode(canvas);
    const enhancedResult = decodeCanvasWithZxing(canvas);
    if (enhancedResult) return enhancedResult;

    if (nativeDetector) {
      try {
        const enhNative = await nativeDetector.detect(canvas);
        if (enhNative && enhNative.length > 0 && enhNative[0].rawValue) {
          return String(enhNative[0].rawValue).trim();
        }
      } catch {
        // continue
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 4. Horizontally Flipped (Mirror-Safe) Pass on even cycles
  //    Many laptop webcams mirror the image horizontally; flipping it ensures
  //    1D barcodes decode regardless of camera driver mirroring!
  // ---------------------------------------------------------------------------
  if (cycle % 2 === 0) {
    ctx.save();
    ctx.scale(-1, 1);
    ctx.drawImage(video, cropX, cropY, cropW, cropH, -outW, 0, outW, outH);
    ctx.restore();

    if (enhance) {
      enhanceCanvasForLaptopBarcode(canvas);
    }
    const mirroredResult = decodeCanvasWithZxing(canvas);
    if (mirroredResult) return mirroredResult;
  }

  // ---------------------------------------------------------------------------
  // 5. Full Frame Pass on odd cycles (for large barcodes / QR codes near edges)
  // ---------------------------------------------------------------------------
  if (cycle % 2 === 1) {
    const fullW = 800;
    const fullH = Math.max(240, Math.floor((vh / vw) * fullW));
    canvas.width = fullW;
    canvas.height = fullH;
    ctx.drawImage(video, 0, 0, vw, vh, 0, 0, fullW, fullH);

    const fullResult = decodeCanvasWithZxing(canvas);
    if (fullResult) return fullResult;
  }

  return null;
}

/**
 * فك تشفير صورة باركود ملتقطة بكاميرا اللاب توب أو الموبايل (Multi-Pass Image Decoder)
 */
export async function decodeBarcodeFromImageFile(file: File): Promise<string | null> {
  // Pass 1: Native BarcodeDetector on ImageBitmap
  const nativeDetector = getNativeBarcodeDetector();
  if (nativeDetector && typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      const results = await nativeDetector.detect(bitmap);
      bitmap.close?.();
      if (results && results.length > 0 && results[0].rawValue) {
        return String(results[0].rawValue).trim();
      }
    } catch {
      // continue to canvas passes
    }
  }

  const imgUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = reject;
      image.src = imgUrl;
    });

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (ctx) {
      // Pass 2: Full image resized to 1000px + ZXing
      const maxDim = 1000;
      const ratio = Math.min(1, maxDim / Math.max(img.width, img.height));
      canvas.width = Math.max(200, Math.floor(img.width * ratio));
      canvas.height = Math.max(200, Math.floor(img.height * ratio));
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const resZxing1 = decodeCanvasWithZxing(canvas);
      if (resZxing1) return resZxing1;

      enhanceCanvasForLaptopBarcode(canvas);
      const resZxing1Enh = decodeCanvasWithZxing(canvas);
      if (resZxing1Enh) return resZxing1Enh;

      // Pass 3: Center crop + Laptop Sharpener + ZXing
      const cropW = Math.floor(img.width * 0.72);
      const cropH = Math.floor(img.height * 0.52);
      const cropX = Math.floor((img.width - cropW) / 2);
      const cropY = Math.floor((img.height - cropH) / 2);
      canvas.width = 800;
      canvas.height = Math.max(200, Math.floor((cropH / cropW) * 800));
      ctx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, canvas.width, canvas.height);

      const resZxing2 = decodeCanvasWithZxing(canvas);
      if (resZxing2) return resZxing2;

      enhanceCanvasForLaptopBarcode(canvas);
      const resZxing2Enh = decodeCanvasWithZxing(canvas);
      if (resZxing2Enh) return resZxing2Enh;
    }

    // Pass 4: Fallback to Html5Qrcode scanFile
    const scanner = getHiddenHtml5Scanner();
    if (scanner) {
      try {
        const directRes = await scanner.scanFile(file, false);
        if (directRes && directRes.trim()) return directRes.trim();
      } catch {
        return null;
      }
    }
  } catch {
    return null;
  } finally {
    URL.revokeObjectURL(imgUrl);
  }

  return null;
}

// ============================================================================
// Real-Time Mobile-to-PC Wireless Bridge Helpers
// ============================================================================

const SESSION_STORAGE_KEY = 'akstore_pos_scanner_session_id_v1';
const BROADCAST_CHANNEL_NAME = 'akstore_mobile_scanner_bridge_v1';

export function getOrCreatePosScannerSessionId(): string {
  try {
    const saved = localStorage.getItem(SESSION_STORAGE_KEY);
    if (saved && saved.length >= 6) return saved;
    const generated =
      'AK-' +
      Math.random().toString(36).substring(2, 6).toUpperCase() +
      '-' +
      Math.random().toString(36).substring(2, 6).toUpperCase();
    localStorage.setItem(SESSION_STORAGE_KEY, generated);
    return generated;
  } catch {
    return 'AK-POS-LIVE';
  }
}

export async function notifyMobileConnected(sessionId: string, deviceName = 'هاتف الكاشير'): Promise<boolean> {
  const cleanId = sessionId.trim().toUpperCase();
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      const bc = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      bc.postMessage({
        type: 'mobile_connected',
        sessionId: cleanId,
        mobileDeviceName: deviceName,
        timestamp: Date.now()
      });
      bc.close();
    }
  } catch {
    // ignore
  }

  try {
    const res = await fetch(`/api/mobile-scanner/${encodeURIComponent(cleanId)}/ping`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceName })
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function sendScannedBarcodeToPos(
  sessionId: string,
  barcode: string,
  deviceName = 'كاميرا الموبايل'
): Promise<boolean> {
  const cleanId = sessionId.trim().toUpperCase();
  const cleanCode = barcode.trim();
  if (!cleanCode) return false;

  const eventPayload = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    barcode: cleanCode,
    timestamp: Date.now(),
    deviceName
  };

  // 1. BroadcastChannel + localStorage for instant same-device/tab sync
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      const bc = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      bc.postMessage({
        type: 'barcode_scanned',
        sessionId: cleanId,
        event: eventPayload
      });
      bc.close();
    }
    localStorage.setItem(
      'akstore_last_mobile_scan_event',
      JSON.stringify({ sessionId: cleanId, event: eventPayload })
    );
  } catch {
    // ignore
  }

  // 2. Server REST API for cross-device Mobile-to-PC sync
  try {
    const res = await fetch(`/api/mobile-scanner/${encodeURIComponent(cleanId)}/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ barcode: cleanCode, deviceName })
    });
    return res.ok;
  } catch {
    return false;
  }
}

export function subscribeToMobileScannerSession(
  sessionId: string,
  callbacks: {
    onBarcodeScanned: (barcode: string, eventId: string) => void;
    onMobileStatusChange?: (connected: boolean, deviceName?: string) => void;
  }
): () => void {
  const cleanId = sessionId.trim().toUpperCase();
  const processedEventIds = new Set<string>();
  let lastTimestamp = Date.now() - 2000;

  const handleIncomingEvent = (evt: { id: string; barcode: string; timestamp: number }) => {
    if (!evt || !evt.id || !evt.barcode) return;
    if (processedEventIds.has(evt.id)) return;
    if (evt.timestamp < lastTimestamp) return;
    processedEventIds.add(evt.id);
    lastTimestamp = Math.max(lastTimestamp, evt.timestamp);
    callbacks.onBarcodeScanned(evt.barcode, evt.id);
  };

  // 1. Listen via BroadcastChannel
  let bc: BroadcastChannel | null = null;
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      bc = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      bc.onmessage = (msg) => {
        const data = msg.data;
        if (!data || data.sessionId !== cleanId) return;
        if (data.type === 'mobile_connected') {
          callbacks.onMobileStatusChange?.(true, data.mobileDeviceName);
        } else if (data.type === 'barcode_scanned' && data.event) {
          callbacks.onMobileStatusChange?.(true, data.event.deviceName);
          handleIncomingEvent(data.event);
        }
      };
    }
  } catch {
    bc = null;
  }

  // 2. Listen via Server-Sent Events (SSE)
  let es: EventSource | null = null;
  try {
    if (typeof EventSource !== 'undefined') {
      es = new EventSource(`/api/mobile-scanner/${encodeURIComponent(cleanId)}/stream`);
      es.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.type === 'init') {
            callbacks.onMobileStatusChange?.(Boolean(data.mobileConnected), data.mobileDeviceName);
          } else if (data.type === 'mobile_connected') {
            callbacks.onMobileStatusChange?.(true, data.mobileDeviceName);
          } else if (data.type === 'barcode_scanned' && data.event) {
            callbacks.onMobileStatusChange?.(true, data.event.deviceName);
            handleIncomingEvent(data.event);
          }
        } catch {
          // ignore parse error
        }
      };
    }
  } catch {
    es = null;
  }

  // 3. Fast HTTP Polling Fallback (every 1.2s) in case proxy buffers SSE
  const pollTimer = setInterval(async () => {
    try {
      const res = await fetch(
        `/api/mobile-scanner/${encodeURIComponent(cleanId)}?since=${lastTimestamp}`
      );
      if (!res.ok) return;
      const data = await res.json();
      if (data && data.success) {
        callbacks.onMobileStatusChange?.(Boolean(data.mobileConnected), data.mobileDeviceName);
        if (Array.isArray(data.events)) {
          data.events.forEach((ev: any) => handleIncomingEvent(ev));
        }
      }
    } catch {
      // ignore network error during poll
    }
  }, 1200);

  return () => {
    clearInterval(pollTimer);
    if (bc) {
      try {
        bc.close();
      } catch {
        // ignore
      }
    }
    if (es) {
      try {
        es.close();
      } catch {
        // ignore
      }
    }
  };
}
