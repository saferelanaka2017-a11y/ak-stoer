/**
 * @file components/Sidebar.tsx
 * شريط القائمة الجانبية المتجاوب مع أي مقاس شاشة كمبيوتر
 * يدعم الطي والتوسيع الذكي (Compact Rail / Expanded Sidebar) لتوفير أقصى مساحة عمل لشاشات الكاشير واللابتوب
 */

import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  ShoppingBag,
  RotateCcw,
  Undo2,
  Users,
  CalendarClock,
  ReceiptText,
  BarChart3,
  Settings as SettingsIcon,
  ShieldAlert,
  ShieldCheck,
  FileSpreadsheet,
  X,
  PanelLeftClose,
  PanelRightClose,
  Download,
  Smartphone,
  LogOut
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import { UserPermissions } from '../types';
import { AKStoreLogo } from './AKStoreLogo';
import { exportOfflineUpdatePackage } from '../utils/updateManager';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isOpenOnMobile?: boolean;
  onCloseMobile?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  onOpenWindowsModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpenOnMobile,
  onCloseMobile,
  isCollapsed = false,
  onToggleCollapse,
  onOpenWindowsModal
}) => {
  const { user, hasPermission, logout } = useAuth();
  const { t, tr, dir, settings, showToast } = useApp();
  const isSuperAdminAccount = user?.username?.toLowerCase() === 'admin';

  const menuItems: {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    highlight?: boolean;
    permissionKey: keyof UserPermissions;
    superAdminOnly?: boolean;
  }[] = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard, permissionKey: 'viewDashboard' },
    { id: 'pos', label: t('pos'), icon: ShoppingCart, highlight: true, permissionKey: 'accessPOS' },
    { id: 'sales-invoices', label: t('salesInvoices'), icon: FileSpreadsheet, permissionKey: 'viewSalesInvoices' },
    { id: 'products', label: t('products'), icon: Package, permissionKey: 'viewProducts' },
    { id: 'purchases', label: t('purchases'), icon: ShoppingBag, permissionKey: 'viewPurchases' },
    { id: 'sales-returns', label: t('salesReturns'), icon: RotateCcw, permissionKey: 'viewSalesReturns' },
    { id: 'purchase-returns', label: t('purchaseReturns'), icon: Undo2, permissionKey: 'viewPurchaseReturns' },
    { id: 'customers', label: t('customers'), icon: Users, permissionKey: 'viewCustomers' },
    { id: 'installments', label: t('installments'), icon: CalendarClock, permissionKey: 'viewInstallments' },
    { id: 'expenses', label: t('expenses'), icon: ReceiptText, permissionKey: 'viewExpenses' },
    { id: 'reports', label: t('reports'), icon: BarChart3, permissionKey: 'viewReports' },
    { id: 'users', label: t('users'), icon: ShieldCheck, permissionKey: 'manageUsers' },
    { id: 'settings', label: t('settings'), icon: SettingsIcon, permissionKey: 'viewSettings' },
    {
      id: 'admin-setup',
      label: tr('تسطيب النظام (الأدمن)', 'System Setup (Admin)'),
      icon: Download,
      permissionKey: 'viewSettings',
      superAdminOnly: true
    }
  ];

  const visibleMenuItems = menuItems.filter((item) => !item.superAdminOnly || isSuperAdminAccount);

  const handleItemClick = (id: string, isLocked: boolean) => {
    if (!isLocked) {
      onSelectTab(id);
      if (onCloseMobile) onCloseMobile();
    }
  };

  const renderSidebarBody = (compactMode: boolean) => (
    <div
      className={`${
        compactMode ? 'w-16 px-2 py-2.5' : 'w-60 xl:w-64 p-3'
      } flex flex-col neu-flat h-full transition-all duration-200 ${
        dir === 'rtl' ? 'border-l' : 'border-r'
      } border-white/50 no-print select-none`}
    >
      {/* Mobile Header with Close button */}
      <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-white/50 md:hidden">
        <div className="flex items-center gap-2">
          <AKStoreLogo logoUrl={settings.logoUrl} size="xs" />
          <span className="font-black text-xs text-slate-800">
            {settings.storeName || 'AK Store'}
          </span>
        </div>
        <button
          onClick={onCloseMobile}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Desktop Collapse / Expand Toggle Header */}
      {onToggleCollapse && (
        <div
          className={`hidden md:flex items-center ${
            compactMode ? 'justify-center' : 'justify-between px-1'
          } pb-2 mb-1.5 border-b border-slate-200/60`}
        >
          {!compactMode && (
            <span className="text-[11px] font-bold text-slate-500 truncate">
              {tr('القائمة الرئيسية', 'Main Navigation')}
            </span>
          )}
          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-1.5 rounded-xl neu-button text-slate-600 hover:text-blue-600 cursor-pointer"
            title={
              compactMode
                ? tr('توسيع القائمة الجانبية لإظهار الأسماء', 'Expand sidebar labels')
                : tr('تصغير القائمة الجانبية لتوسيع مساحة الشاشة', 'Collapse sidebar to maximize screen space')
            }
          >
            {dir === 'rtl' ? (
              compactMode ? (
                <PanelLeftClose className="w-4 h-4" />
              ) : (
                <PanelRightClose className="w-4 h-4" />
              )
            ) : compactMode ? (
              <PanelRightClose className="w-4 h-4" />
            ) : (
              <PanelLeftClose className="w-4 h-4" />
            )}
          </button>
        </div>
      )}

      <div
        className={`space-y-1.5 flex-1 overflow-y-auto no-scrollbar ${
          !compactMode ? (dir === 'rtl' ? 'pr-0.5' : 'pl-0.5') : ''
        }`}
      >
        {visibleMenuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const isLocked = item.superAdminOnly ? !isSuperAdminAccount : !hasPermission(item.permissionKey);

          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id, isLocked)}
              disabled={isLocked}
              title={
                isLocked
                  ? tr(
                      'هذه الشاشة غير مفعلة في صلاحيات حسابك',
                      'You do not have permission to open this screen'
                    )
                  : item.label
              }
              className={`w-full flex items-center ${
                compactMode ? 'justify-center p-2' : 'justify-between px-3 py-2'
              } rounded-2xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                isLocked
                  ? 'opacity-40 cursor-not-allowed text-slate-400 bg-transparent'
                  : isActive
                  ? 'neu-pressed text-blue-700 font-bold translate-y-[1px]'
                  : item.highlight
                  ? 'neu-button text-blue-600 font-bold border-blue-200/50'
                  : 'neu-button text-slate-700 hover:text-blue-600'
              }`}
            >
              <div className={`flex items-center ${compactMode ? 'justify-center' : 'gap-2.5 min-w-0'}`}>
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : item.highlight
                      ? 'bg-blue-100 text-blue-600'
                      : 'text-slate-500'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                {!compactMode && <span className="whitespace-nowrap truncate">{item.label}</span>}
              </div>

              {!compactMode && isLocked && (
                <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
            </button>
          );
        })}

        {/* Quick "أخذ ملف التحديث" + "خروج من البرنامج" Buttons at the end of the Sidebar */}
        <div className="pt-1.5 mt-1.5 border-t border-slate-200/60 space-y-1.5">
          <button
            type="button"
            onClick={async () => {
              showToast(
                tr('جاري تجهيز وتحميل ملف التحديث الشامل (.akupdate)...', 'Preparing and downloading update package (.akupdate)...'),
                'info'
              );
              await exportOfflineUpdatePackage();
              showToast(
                tr('تم أخذ وتحميل ملف التحديث بنجاح! يمكنك استخدامه لتحديث نسخة الموبايل واللابتوب (.EXE).', 'Update file downloaded successfully!'),
                'success'
              );
              if (onCloseMobile) onCloseMobile();
            }}
            title={tr('أخذ ملف التحديث (.akupdate)', 'Get Update File (.akupdate)')}
            className={`w-full flex items-center ${
              compactMode ? 'justify-center p-2' : 'justify-between px-3 py-2'
            } rounded-2xl text-xs font-bold transition-all duration-150 cursor-pointer neu-button text-emerald-700 hover:bg-emerald-50/80 hover:text-emerald-800 border border-emerald-200/70`}
          >
            <div className={`flex items-center ${compactMode ? 'justify-center' : 'gap-2.5 min-w-0'}`}>
              <div className="w-7 h-7 rounded-xl flex items-center justify-center shrink-0 bg-emerald-100/90 text-emerald-700">
                <Download className="w-4 h-4" />
              </div>
              {!compactMode && (
                <span className="whitespace-nowrap truncate">
                  {tr('أخذ ملف التحديث', 'Get Update File')}
                </span>
              )}
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onCloseMobile) onCloseMobile();
              logout();
              showToast(
                tr('تم تسجيل الخروج من البرنامج بنجاح', 'Logged out successfully'),
                'info'
              );
            }}
            title={tr('خروج من البرنامج', 'Exit Program / Logout')}
            className={`w-full flex items-center ${
              compactMode ? 'justify-center p-2' : 'justify-between px-3 py-2'
            } rounded-2xl text-xs font-bold transition-all duration-150 cursor-pointer neu-button text-red-600 hover:bg-red-50/80 hover:text-red-700 border border-red-200/60`}
          >
            <div className={`flex items-center ${compactMode ? 'justify-center' : 'gap-2.5 min-w-0'}`}>
              <div className="w-7 h-7 rounded-xl flex items-center justify-center shrink-0 bg-red-100/90 text-red-600">
                <LogOut className="w-4 h-4" />
              </div>
              {!compactMode && (
                <span className="whitespace-nowrap truncate">
                  {tr('خروج من البرنامج', 'Exit Program')}
                </span>
              )}
            </div>
          </button>
        </div>
      </div>

      {/* Bottom Version & Direction Tag */}
      <div
        className={`pt-2.5 border-t border-white/60 text-center text-[11px] text-slate-500 font-semibold flex items-center ${
          compactMode ? 'justify-center' : 'justify-between px-1.5'
        }`}
      >
        <div className="flex items-center gap-1.5">
          <AKStoreLogo logoUrl={settings.logoUrl} size="xs" />
          {!compactMode && <span className="font-bold text-slate-700">AK Store · POS</span>}
        </div>
        {!compactMode && (
          <span className="px-1.5 py-0.5 rounded bg-slate-200/60 text-slate-600 font-mono text-[9px] font-bold uppercase">
            {dir.toUpperCase()}
          </span>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar (visible on all PC monitors >= 768px) */}
      <aside className="hidden md:flex shrink-0 h-full">
        {renderSidebarBody(isCollapsed)}
      </aside>

      {/* Mobile Drawer Overlay (< 768px) */}
      {isOpenOnMobile && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={onCloseMobile}
          />
          <div
            className={`relative z-10 h-full shadow-2xl animate-in ${
              dir === 'rtl' ? 'slide-in-from-right' : 'slide-in-from-left'
            } duration-200`}
          >
            {renderSidebarBody(false)}
          </div>
        </div>
      )}
    </>
  );
};
