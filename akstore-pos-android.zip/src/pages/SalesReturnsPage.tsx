/**
 * @file pages/SalesReturnsPage.tsx
 * شاشة مرتجع المبيعات واسترجاع البضائع للمخزون مع الطباعة والحذف
 * Sales Returns & Restocking Terminal with Print and Delete Actions
 */

import React, { useState } from 'react';
import { RotateCcw, Search, Plus, Trash2, Printer, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import { SaleInvoice, ReturnInvoice } from '../types';
import { generateReturnInvoicePDF } from '../utils/exportUtils';
import { NumberStepperInput } from '../components/NumberStepperInput';

export const SalesReturnsPage: React.FC = () => {
  const { sales, returns, products, formatCurrency, refreshData, showToast, settings, t, tr, requestConfirm } = useApp();

  const [searchInvoice, setSearchInvoice] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<SaleInvoice | null>(null);
  const [returnItems, setReturnItems] = useState<{
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    refundTotal: number;
  }[]>([]);
  const [returnReason, setReturnReason] = useState('عيوب في المنتج أو رغبة العميل');

  const handleSearchInvoice = () => {
    if (!searchInvoice.trim()) return;
    const found = sales.find(s => s.invoiceNumber.toLowerCase() === searchInvoice.trim().toLowerCase());
    if (found) {
      setSelectedInvoice(found);
      setReturnItems([]);
    } else {
      showToast('لم يتم العثور على فاتورة بهذا الرقم', 'error');
    }
  };

  const handleToggleReturnItem = (prodId: string, maxQty: number, price: number, prodName: string) => {
    const existing = returnItems.find(i => i.productId === prodId);
    if (existing) {
      setReturnItems(prev => prev.filter(i => i.productId !== prodId));
    } else {
      setReturnItems(prev => [
        ...prev,
        {
          productId: prodId,
          productName: prodName,
          quantity: 1,
          price,
          refundTotal: price
        }
      ]);
    }
  };

  const handleUpdateItemQty = (prodId: string, newQty: number, maxQty: number, price: number) => {
    if (newQty < 1 || newQty > maxQty) return;
    setReturnItems(prev => prev.map(item => {
      if (item.productId === prodId) {
        return {
          ...item,
          quantity: newQty,
          refundTotal: newQty * price
        };
      }
      return item;
    }));
  };

  const totalRefund = returnItems.reduce((acc, item) => acc + item.refundTotal, 0);

  const handleConfirmReturn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice || returnItems.length === 0) {
      showToast('يرجى تحديد الأصناف المراد إرجاعها', 'error');
      return;
    }

    const createdReturn = db.createReturn({
      type: 'sale',
      originalInvoiceNumber: selectedInvoice.invoiceNumber,
      entityName: selectedInvoice.customerName || 'عميل نقدي',
      items: returnItems,
      totalRefund,
      reason: returnReason
    });

    showToast(`تم تأكيد مرتجع المبيعات واسترجاع ${formatCurrency(totalRefund)} للمخزون!`, 'success');
    refreshData();
    setSelectedInvoice(null);
    setReturnItems([]);
    setSearchInvoice('');

    // Print voucher automatically
    generateReturnInvoicePDF(createdReturn, settings);
  };

  const handleDeleteReturn = (id: string, num: string) => {
    requestConfirm({
      title: 'حذف سند المرتجع',
      message: `هل أنت متأكد من حذف سند المرتجع رقم: "${num}"؟`,
      confirmText: 'نعم، حذف السند',
      onConfirm: () => {
        db.deleteReturn(id);
        showToast('تم حذف سند المرتجع بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrintReturn = async (ret: ReturnInvoice) => {
    try {
      showToast(`جاري إنشاء سند المرتجع #${ret.returnNumber} باللغة العربية...`, 'info');
      await generateReturnInvoicePDF(ret, settings);
      showToast(`تم تحميل سند المرتجع #${ret.returnNumber} PDF بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل تصدير سند المرتجع', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="neu-card p-5 rounded-3xl">
        <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
          <RotateCcw className="w-5 h-5 text-blue-600" />
          <span>{tr('مرتجع المبيعات (Sales Return)', 'Sales Returns & Restocking')}</span>
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          {tr('البحث برقم فاتورة المبيعات لإرجاع أصناف وإعادتها للمخزون واسترداد المبالغ وطباعة السند', 'Search by sales invoice number to return items, restock inventory, refund amounts, and print voucher')}
        </p>

        {/* Invoice Search Bar */}
        <div className="mt-4 flex gap-2 max-w-lg">
          <input
            type="text"
            value={searchInvoice}
            onChange={(e) => setSearchInvoice(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearchInvoice()}
            placeholder={tr('أدخل رقم الفاتورة (مثال: INV-202610-0001)...', 'Enter Invoice Number (e.g. INV-202610-0001)...')}
            className="neu-input flex-1 px-4 py-2.5 rounded-xl text-xs font-mono"
          />
          <button
            type="button"
            onClick={handleSearchInvoice}
            className="neu-button-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <Search className="w-4 h-4" />
            <span>{tr('بحث', 'Search')}</span>
          </button>
        </div>
      </div>

      {/* Invoice Details & Return Selector */}
      {selectedInvoice && (
        <div className="neu-card p-5 rounded-3xl space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-3 border-b border-white/60">
            <div>
              <span className="font-mono font-bold text-blue-700 text-sm">
                فاتورة مبيعات: {selectedInvoice.invoiceNumber}
              </span>
              <span className="text-xs text-slate-500 block">
                العميل: {selectedInvoice.customerName || 'عميل نقدي'} · التاريخ: {new Date(selectedInvoice.date).toLocaleString('ar-SA')}
              </span>
            </div>
            <span className="font-black text-slate-800 text-sm">
              إجمالي الفاتورة: {formatCurrency(selectedInvoice.grandTotal)}
            </span>
          </div>

          <h4 className="text-xs font-bold text-slate-700">حدد الأصناف المراد إرجاعها:</h4>

          <div className="space-y-2">
            {selectedInvoice.items.map((item) => {
              const isSelected = returnItems.some(i => i.productId === item.product.id);
              const returnItem = returnItems.find(i => i.productId === item.product.id);

              return (
                <div
                  key={item.product.id}
                  className={`p-3 rounded-2xl flex items-center justify-between transition-all ${
                    isSelected ? 'neu-pressed border-blue-300' : 'neu-flat'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() =>
                        handleToggleReturnItem(
                          item.product.id,
                          item.quantity,
                          item.price,
                          item.product.name
                        )
                      }
                      className="w-4 h-4 text-blue-600 rounded"
                    />
                    <div>
                      <p className="font-bold text-xs text-slate-800">{item.product.name}</p>
                      <span className="text-[10px] text-slate-400">
                        الكمية الأصلية: {item.quantity} · السعر: {formatCurrency(item.price)}
                      </span>
                    </div>
                  </div>

                  {isSelected && returnItem && (
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-slate-500">الكمية المرتجعة:</span>
                        <NumberStepperInput
                          value={returnItem.quantity}
                          onChange={(val) =>
                            handleUpdateItemQty(
                              item.product.id,
                              Math.min(item.quantity, Math.max(1, val)),
                              item.quantity,
                              item.price
                            )
                          }
                          step={1}
                          min={1}
                          max={item.quantity}
                          fallbackOnBlur={1}
                          size="sm"
                          className="w-24"
                          inputClassName="text-center text-xs"
                        />
                      </div>
                      <span className="font-bold text-xs text-emerald-600 tabular-nums">
                        {formatCurrency(returnItem.refundTotal)}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {returnItems.length > 0 && (
            <div className="neu-pressed p-4 rounded-2xl space-y-3 mt-4">
              <div className="flex justify-between items-center text-sm font-black">
                <span>إجمالي المبلغ المسترد للعميل:</span>
                <span className="text-blue-700 tabular-nums">{formatCurrency(totalRefund)}</span>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  سبب الإرجاع:
                </label>
                <input
                  type="text"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs"
                />
              </div>

              <button
                type="button"
                onClick={handleConfirmReturn}
                className="neu-button-primary w-full py-2.5 rounded-xl text-xs font-bold cursor-pointer flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>تأكيد المرتجع وطباعة السند</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Historical Returns with Print & Delete */}
      <div className="neu-card p-5 rounded-3xl">
        <h3 className="font-bold text-slate-800 text-sm mb-3">
          سجل المرتجعات ({returns.filter(r => r.type === 'sale').length})
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-2">رقم المرتجع</th>
                <th className="pb-2">الفاتورة الأصلية</th>
                <th className="pb-2">العميل</th>
                <th className="pb-2">التاريخ</th>
                <th className="pb-2 text-left">مبلغ الاسترجاع</th>
                <th className="pb-2">السبب</th>
                <th className="pb-2 text-left">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {returns
                .filter(r => r.type === 'sale')
                .map(ret => (
                  <tr key={ret.id}>
                    <td className="py-2.5 font-mono font-bold text-blue-700">{ret.returnNumber}</td>
                    <td className="py-2.5 font-mono">{ret.originalInvoiceNumber}</td>
                    <td className="py-2.5 font-medium">{ret.entityName}</td>
                    <td className="py-2.5 tabular-nums text-slate-500">{new Date(ret.date).toLocaleDateString('ar-SA')}</td>
                    <td className="py-2.5 text-left font-bold text-red-600 tabular-nums">{formatCurrency(ret.totalRefund)}</td>
                    <td className="py-2.5 text-slate-500">{ret.reason}</td>
                    <td className="py-2.5 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          onClick={() => handlePrintReturn(ret)}
                          className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                          title="طباعة سند المرتجع"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteReturn(ret.id, ret.returnNumber)}
                          className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          title="حذف المرتجع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
