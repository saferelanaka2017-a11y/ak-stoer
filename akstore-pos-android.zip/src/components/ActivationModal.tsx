/**
 * @file components/ActivationModal.tsx
 * نافذة وقفل تفعيل البرنامج وعرض كود الجهاز والطلب عبر الواتساب (بدون أي اختصارات أو طرق تفعيل ظاهرة للعميل)
 * Strict Machine-Locked Activation Screen — Only accepts valid serial generated from the external Keygen
 */

import React, { useState, useEffect } from 'react';
import { 
  Key, 
  Copy, 
  Check, 
  MessageSquare, 
  Clock, 
  AlertTriangle, 
  ShieldCheck, 
  X,
  ExternalLink,
  ClipboardPaste,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { 
  activateLicense, 
  getWhatsAppActivationUrl,
  getWhatsAppActivationMessage,
  OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
  OFFICIAL_ACTIVATION_WHATSAPP_INTL,
  cleanInputSerial,
  verifyLicenseKey,
  downloadStandaloneKeygenHtml,
  LicenseState
} from '../utils/licenseManager';
import { openSmartWhatsAppModal } from '../utils/installmentAlerts';
import { syncDatabaseAndLicenseToSafeVault } from '../utils/updateManager';
import { copyTextFallback } from '../utils/win7Polyfills';
import { useApp } from '../contexts/AppContext';

interface ActivationModalProps {
  isOpen: boolean;
  onClose?: () => void;
  isMandatory?: boolean; // When true, trial is expired and cannot be closed without activation
  licenseState: LicenseState;
  onRefreshLicense: () => void;
}

export const ActivationModal: React.FC<ActivationModalProps> = ({
  isOpen,
  onClose,
  isMandatory = false,
  licenseState,
  onRefreshLicense
}) => {
  const { settings, showToast } = useApp();
  const [enteredKey, setEnteredKey] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [pastedSuccess, setPastedSuccess] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setStatusFeedback(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyDeviceCode = () => {
    copyTextFallback(licenseState.deviceCode);
    setCopiedCode(true);
    setStatusFeedback({
      type: 'info',
      text: `تم نسخ كود الجهاز (${licenseState.deviceCode}) بنجاح! يمكنك الآن توليد السيريل الخاص به.`
    });
    showToast('تم نسخ كود الجهاز بنجاح!', 'success');
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handlePasteFromClipboard = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (!text || !text.trim()) {
          setStatusFeedback({
            type: 'error',
            text: 'الحافظة فارغة! يرجى نسخ السيريل أولاً ثم المحاولة.'
          });
          showToast('الحافظة فارغة!', 'error');
          return;
        }
        const cleaned = cleanInputSerial(text);
        setEnteredKey(cleaned);
        setPastedSuccess(true);
        setStatusFeedback({
          type: 'info',
          text: 'تم لصق السيريل بنجاح، اضغط الآن على "تأكيد تفعيل البرنامج الآن".'
        });
        showToast('تم لصق السيريل تلقائياً!', 'success');
        setTimeout(() => setPastedSuccess(false), 2000);
      } else {
        throw new Error('Clipboard read not supported');
      }
    } catch {
      setStatusFeedback({
        type: 'info',
        text: 'اضغط داخل خانة السيريل ثم اضغط (Ctrl + V) من لوحة المفاتيح للصق السيريل.'
      });
      showToast('يرجى لصق السيريل يدوياً في الخانة (Ctrl+V)', 'info');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.toUpperCase();
    setEnteredKey(raw);
    if (statusFeedback) {
      setStatusFeedback(null);
    }
  };

  const handleInputPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const pasted = e.clipboardData.getData('text');
    if (pasted) {
      e.preventDefault();
      const cleaned = cleanInputSerial(pasted);
      setEnteredKey(cleaned);
      setStatusFeedback(null);
    }
  };

  const cleanedCurrentKey = enteredKey.trim() ? cleanInputSerial(enteredKey) : '';
  const isCurrentKeyValid = cleanedCurrentKey
    ? verifyLicenseKey(licenseState.deviceCode, cleanedCurrentKey)
    : false;

  const executeActivation = () => {
    const trimmed = enteredKey.trim().toUpperCase();

    // Secret Admin command to download standalone Keygen HTML file
    if (trimmed === 'AK-KEYGEN' || trimmed === 'KEYGEN-ADMIN') {
      downloadStandaloneKeygenHtml();
      setEnteredKey('');
      setStatusFeedback({
        type: 'success',
        text: 'تم تحميل برنامج توليد السيريلات المستقل (AK_Store_Keygen_Generator.html) بنجاح!'
      });
      showToast('تم تحميل برنامج توليد السيريلات المستقل بنجاح!', 'success');
      return;
    }

    const result = activateLicense(cleanedCurrentKey || enteredKey, licenseState.deviceCode);
    if (result.success) {
      setEnteredKey(cleanedCurrentKey || enteredKey);
      setStatusFeedback({
        type: 'success',
        text: `✅ ${result.message}`
      });
      showToast(result.message, 'success');
      syncDatabaseAndLicenseToSafeVault();
      onRefreshLicense();

      if (onClose) {
        setTimeout(() => {
          onClose();
        }, 900);
      }
    } else {
      setStatusFeedback({
        type: 'error',
        text: result.message
      });
      showToast(result.message, 'error');
    }
  };

  const handleActivateFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeActivation();
  };

  const activationMessageText = getWhatsAppActivationMessage(
    licenseState.deviceCode,
    settings.storeName
  );
  const encodedActivationMsg = encodeURIComponent(activationMessageText);
  const whatsappApiUrl = getWhatsAppActivationUrl(
    licenseState.deviceCode,
    OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
    settings.storeName
  );
  const whatsappAppProtocolUrl = `whatsapp://send?phone=${OFFICIAL_ACTIVATION_WHATSAPP_INTL}&text=${encodedActivationMsg}`;
  const whatsappWebUrl = `https://web.whatsapp.com/send?phone=${OFFICIAL_ACTIVATION_WHATSAPP_INTL}&text=${encodedActivationMsg}`;

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto ${
      isMandatory ? 'bg-slate-950/90 backdrop-blur-md' : 'bg-slate-900/60 backdrop-blur-sm'
    }`}>
      <div className="neu-card rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-white/40 my-6">
        {/* Header */}
        <div className={`px-6 py-4 flex items-center justify-between border-b ${
          isMandatory ? 'bg-red-500/10 border-red-500/20' : 'bg-blue-500/10 border-blue-500/20'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-inner ${
              isMandatory ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
            }`}>
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 text-sm">
                {isMandatory ? 'انتهت الفترة التجريبية - تفعيل النظام' : 'تفعيل ترخيص النظام الدائم'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isMandatory 
                  ? 'يرجى إدخال سيريل التفعيل الرسمي الخاص بهذا الجهاز لمتابعة العمل' 
                  : 'أدخل سيريل التفعيل المخصص لهذا الجهاز لتشغيل النظام بشكل دائم'}
              </p>
            </div>
          </div>

          {!isMandatory && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl neu-button text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-xs">
          {/* Trial Status Notice */}
          {licenseState.isActivated ? (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-800">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <p className="font-bold">البرنامج مفعل رسمياً وبشكل كامل مدى الحياة!</p>
                <p className="text-[11px] text-emerald-700/80 font-mono mt-0.5">
                  السيريل المفعل: {licenseState.licenseKey || 'مرخص دائم'}
                </p>
              </div>
            </div>
          ) : isMandatory ? (
            <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-red-800">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">انتهت الفترة التجريبية للنظام!</p>
                <p className="text-[11px] text-red-700/90 leading-relaxed mt-0.5">
                  لتفعيل النظام على هذا الكمبيوتر، انسخ كود جهازك أدناه وأرسله للحصول على سيريل التفعيل المخصص لجهازك.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-amber-800">
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">
                  فترة تجريبية نشطة (متبقي: {licenseState.remainingDays > 0 ? `${licenseState.remainingDays} يوم و ` : ''}
                  {licenseState.remainingHours} ساعة و {licenseState.remainingMinutes} دقيقة)
                </p>
                <p className="text-[11px] text-amber-700/80 mt-0.5">
                  يمكنك إدخال سيريل التفعيل الخاص بهذا الجهاز في أي وقت لتشغيل النسخة الدائمة.
                </p>
              </div>
            </div>
          )}

          {/* Device Code Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-800 block text-xs">
                كود هذا الجهاز (Device ID):
              </label>
              <span className="text-[10px] text-slate-500 font-semibold">
                مطلوب لإصدار سيريل التفعيل
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 p-3 bg-slate-100/90 border border-slate-300 rounded-2xl font-mono text-center text-sm font-black text-blue-800 tracking-wider select-all shadow-inner">
                {licenseState.deviceCode}
              </div>
              <button
                type="button"
                onClick={handleCopyDeviceCode}
                className="neu-button px-3.5 py-3 rounded-2xl flex items-center gap-1.5 font-bold text-slate-700 hover:text-blue-600 cursor-pointer shrink-0"
                title="نسخ كود الجهاز"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span className="text-emerald-700">تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>نسخ</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Official WhatsApp Activation Request Box (01006348851) */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-300/90 space-y-2.5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-600 fill-emerald-600 shrink-0" />
                <span className="font-extrabold text-emerald-950 text-xs">
                  لطلب تفعيل واتساب:
                </span>
              </div>
              <span
                dir="ltr"
                className="font-mono font-black text-sm text-emerald-800 bg-white px-3 py-1 rounded-xl border border-emerald-300 select-all shadow-2xs tabular-nums"
              >
                {OFFICIAL_ACTIVATION_WHATSAPP_LOCAL}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <a
                href={whatsappAppProtocolUrl}
                onClick={() => {
                  copyTextFallback(activationMessageText);
                  showToast(
                    `تم نسخ كود الجهاز! جاري فتح تطبيق واتساب لطلب التفعيل على الرقم ${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL}...`,
                    'success'
                  );
                }}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer no-underline text-center"
              >
                <MessageSquare className="w-4 h-4 fill-white shrink-0" />
                <span>فتح تطبيق واتساب ({OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})</span>
              </a>

              <a
                href={whatsappWebUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  copyTextFallback(activationMessageText);
                  showToast(
                    `تم نسخ رسالة التفعيل! جاري فتح واتساب ويب للرقم ${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL}...`,
                    'info'
                  );
                }}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer no-underline text-center"
              >
                <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                <span>فتح واتساب ويب (Web)</span>
              </a>
            </div>

            <div className="flex items-center gap-2 pt-0.5">
              <a
                href={whatsappApiUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  copyTextFallback(activationMessageText);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-white hover:bg-emerald-100/70 text-emerald-800 border border-emerald-300 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer no-underline text-center"
              >
                <span>رابط واتساب مباشر ({OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              <button
                type="button"
                onClick={() => {
                  openSmartWhatsAppModal({
                    customerName: 'إدارة تفعيل نظام AK Store',
                    phone: OFFICIAL_ACTIVATION_WHATSAPP_LOCAL,
                    message: activationMessageText,
                    title: `طلب تفعيل واتساب (${OFFICIAL_ACTIVATION_WHATSAPP_LOCAL})`
                  });
                }}
                className="py-2 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>مسح كود QR بالموبايل</span>
              </button>
            </div>
          </div>

          {/* Activation Key Form */}
          <form onSubmit={handleActivateFormSubmit} className="pt-2 space-y-3 border-t border-slate-200">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-slate-800 text-xs">
                  سيريل التفعيل المخصص لهذا الجهاز:
                </label>
                <button
                  type="button"
                  onClick={handlePasteFromClipboard}
                  className="text-[11px] text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <ClipboardPaste className="w-3.5 h-3.5" />
                  <span>{pastedSuccess ? 'تم اللصق!' : 'لصق من الحافظة'}</span>
                </button>
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={enteredKey}
                  onChange={handleInputChange}
                  onPaste={handleInputPaste}
                  placeholder="ACT-XXXX-XXXX-XXXX-XXXX"
                  dir="ltr"
                  className={`neu-input w-full px-3.5 py-2.5 rounded-xl font-mono text-center text-xs sm:text-sm font-bold tracking-wider placeholder:text-slate-400 ${
                    isCurrentKeyValid ? 'border-emerald-500 text-emerald-700 bg-emerald-50/40' : ''
                  }`}
                  autoFocus
                />
                {isCurrentKeyValid && (
                  <Check className="w-4 h-4 text-emerald-600 stroke-[3] absolute left-3 top-3" />
                )}
              </div>

              {isCurrentKeyValid && !statusFeedback && (
                <div className="mt-1.5 text-[11px] text-emerald-700 font-bold flex items-center gap-1 justify-center">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>كود السيريل صحيح ومطابق! اضغط على زر التأكيد أدناه للتفعيل.</span>
                </div>
              )}
            </div>

            {/* Direct Inline Feedback Banner inside Modal */}
            {statusFeedback && (
              <div
                className={`p-3 rounded-2xl border font-bold text-xs flex items-start gap-2 ${
                  statusFeedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                    : statusFeedback.type === 'error'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-blue-50 border-blue-300 text-blue-800'
                }`}
              >
                {statusFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                )}
                <span className="leading-relaxed">{statusFeedback.text}</span>
              </div>
            )}

            <button
              type="button"
              onClick={executeActivation}
              className="neu-button-primary w-full py-3 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer active:scale-98 transition-transform"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>تأكيد تفعيل البرنامج الآن</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
