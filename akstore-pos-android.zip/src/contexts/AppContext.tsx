/**
 * @file contexts/AppContext.tsx
 * السياق الشامل لإدارة بيانات المتجر، السلة، الإعدادات، واللغات
 * Global App Context for POS operations, Cart, Settings, and Notifications
 */

import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Product,
  CartItem,
  SaleInvoice,
  PurchaseInvoice,
  ReturnInvoice,
  Customer,
  Supplier,
  Expense,
  InstallmentPlan,
  StoreSettings,
  Warehouse,
  WarehouseTransfer,
  CurrencyRate,
  AppThemeId
} from '../types';
import { db, SyncStatusInfo } from '../db/database';
import { translations, Language, TranslationKey } from '../i18n';
import { getInitialLowSpecMode, applyLowSpecModeToDOM } from '../utils/win7Polyfills';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  // Localization
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  tr: (ar: string, en: string) => string;
  dir: 'rtl' | 'ltr';

  // Settings, Theme, Low-Spec Mode & Multi-Currency
  settings: StoreSettings;
  updateSettings: (newSettings: Partial<StoreSettings>) => void;
  appTheme: AppThemeId;
  setAppTheme: (theme: AppThemeId) => void;
  lowSpecMode: boolean;
  setLowSpecMode: (enabled: boolean) => void;
  formatCurrency: (amount: number) => string;
  currencies: CurrencyRate[];
  activeCurrency: CurrencyRate;
  baseCurrency: CurrencyRate;
  switchActiveCurrency: (code: string) => {
    success: boolean;
    message: string;
    currency?: CurrencyRate;
    affectedProductsCount: number;
  };
  updateCurrencyExchangeRate: (
    code: string,
    newRate: number,
    options?: {
      applyToProductPrices?: boolean;
      priceImpactMode?: 'auto' | 'scale_all' | 'convert_active';
    }
  ) => {
    success: boolean;
    message: string;
    oldRate: number;
    newRate: number;
    affectedProductsCount: number;
  };
  addCurrency: (currency: Omit<CurrencyRate, 'id' | 'updatedAt'>) => {
    success: boolean;
    message: string;
    currency?: CurrencyRate;
  };
  deleteCurrency: (code: string) => { success: boolean; message: string };
  setBaseCurrency: (newBaseCode: string) => { success: boolean; message: string };

  // Warehouses Management
  warehouses: Warehouse[];
  warehouseTransfers: WarehouseTransfer[];
  addWarehouse: (warehouse: Omit<Warehouse, 'id' | 'createdAt'>) => Warehouse;
  updateWarehouse: (id: string, updates: Partial<Warehouse>) => Warehouse | null;
  deleteWarehouse: (id: string) => { success: boolean; message?: string };
  setDefaultWarehouse: (id: string) => boolean;
  distributeProductStock: (productId: string, distribution: Record<string, number>) => boolean;
  transferStock: (params: {
    fromWarehouseId: string;
    toWarehouseId: string;
    productId: string;
    quantity: number;
    notes?: string;
    transferredBy?: string;
  }) => { success: boolean; message: string; transfer?: WarehouseTransfer };

  // Data lists
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: SaleInvoice[];
  purchases: PurchaseInvoice[];
  returns: ReturnInvoice[];
  expenses: Expense[];
  installmentPlans: InstallmentPlan[];
  refreshData: () => void;
  syncStatus: SyncStatusInfo;
  syncEmail: string;
  emailSyncLocked: boolean;
  setSyncEmail: (email: string) => Promise<boolean>;
  setEmailSyncFieldLocked: (locked: boolean) => void;
  syncNow: () => Promise<boolean>;

  // Cart Management
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQty: (productId: string, quantity: number) => void;
  updateCartPrice: (productId: string, price: number) => void;
  updateCartDiscount: (productId: string, discount: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartDiscount: number;
  cartTax: number;
  cartTotal: number;
  heldCarts: { id: string; name: string; date: string; items: CartItem[] }[];
  holdCurrentCart: (name?: string) => void;
  resumeHeldCart: (cartId: string) => void;
  deleteHeldCart: (cartId: string) => void;

  // Invoice Printing & Modal
  activeInvoice: SaleInvoice | null;
  openInvoiceModal: (invoice: SaleInvoice) => void;
  closeInvoiceModal: () => void;

  // Toast Notifications
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // Confirmation Modal
  confirmDialog: {
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  } | null;
  requestConfirm: (options: {
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  }) => void;
  closeConfirm: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<StoreSettings>(() => db.getSettings());
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLang = localStorage.getItem('pos_app_language') as Language | null;
    if (savedLang === 'ar' || savedLang === 'en') return savedLang;
    return settings.language || 'ar';
  });
  const [appTheme, setAppThemeState] = useState<AppThemeId>(() => {
    const saved = (localStorage.getItem('pos_app_theme') as AppThemeId) || settings.appTheme || 'ocean-blue';
    return saved;
  });
  const [lowSpecMode, setLowSpecModeState] = useState<boolean>(() =>
    getInitialLowSpecMode(settings.lowSpecMode)
  );
  const [products, setProducts] = useState<Product[]>(() => db.getProducts());
  const [customers, setCustomers] = useState<Customer[]>(() => db.getCustomers());
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => db.getSuppliers());
  const [sales, setSales] = useState<SaleInvoice[]>(() => db.getSales());
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>(() => db.getPurchases());
  const [returns, setReturns] = useState<ReturnInvoice[]>(() => db.getReturns());
  const [expenses, setExpenses] = useState<Expense[]>(() => db.getExpenses());
  const [installmentPlans, setInstallmentPlans] = useState<InstallmentPlan[]>(() => db.getInstallmentPlans());
  const [warehouses, setWarehouses] = useState<Warehouse[]>(() => db.getWarehouses());
  const [warehouseTransfers, setWarehouseTransfers] = useState<WarehouseTransfer[]>(() => db.getWarehouseTransfers());

  const [cart, setCart] = useState<CartItem[]>([]);
  const [heldCarts, setHeldCarts] = useState<{ id: string; name: string; date: string; items: CartItem[] }[]>([]);
  const [activeInvoice, setActiveInvoice] = useState<SaleInvoice | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dir: 'rtl' | 'ltr' = language === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = dir;
    document.documentElement.setAttribute('data-dir', dir);
    document.body.dir = dir;
    localStorage.setItem('pos_app_language', language);
  }, [language, dir]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', appTheme);
    localStorage.setItem('pos_app_theme', appTheme);
  }, [appTheme]);

  useEffect(() => {
    applyLowSpecModeToDOM(lowSpecMode);
    localStorage.setItem('pos_low_spec_mode', String(lowSpecMode));
  }, [lowSpecMode]);

  const [syncStatus, setSyncStatus] = useState<SyncStatusInfo>(() => db.getSyncStatus());

  const refreshData = useCallback(() => {
    setProducts([...db.getProducts()]);
    setCustomers([...db.getCustomers()]);
    setSuppliers([...db.getSuppliers()]);
    setSales([...db.getSales()]);
    setPurchases([...db.getPurchases()]);
    setReturns([...db.getReturns()]);
    setExpenses([...db.getExpenses()]);
    setInstallmentPlans([...db.getInstallmentPlans()]);
    setSettings({ ...db.getSettings() });
    setWarehouses([...db.getWarehouses()]);
    setWarehouseTransfers([...db.getWarehouseTransfers()]);
  }, []);

  // Subscribe to real-time updates from PC / Mobile / EXE sync engine
  useEffect(() => {
    const unsubRemote = db.onRemoteUpdate(() => {
      refreshData();
    });
    const unsubStatus = db.subscribeToSyncStatus((info) => {
      setSyncStatus({ ...info });
    });
    return () => {
      unsubRemote();
      unsubStatus();
    };
  }, [refreshData]);

  const syncNow = useCallback(async () => {
    const ok = await db.syncNow();
    refreshData();
    return ok;
  }, [refreshData]);

  const setSyncEmail = useCallback(async (email: string) => {
    const ok = await db.setSyncEmail(email);
    refreshData();
    return ok;
  }, [refreshData]);

  const setEmailSyncFieldLocked = useCallback((locked: boolean) => {
    db.setEmailSyncFieldLocked(locked);
  }, []);

  const addWarehouse = useCallback((warehouse: Omit<Warehouse, 'id' | 'createdAt'>) => {
    const newWh = db.addWarehouse(warehouse);
    refreshData();
    return newWh;
  }, [refreshData]);

  const updateWarehouse = useCallback((id: string, updates: Partial<Warehouse>) => {
    const updated = db.updateWarehouse(id, updates);
    refreshData();
    return updated;
  }, [refreshData]);

  const deleteWarehouse = useCallback((id: string) => {
    const res = db.deleteWarehouse(id);
    if (res.success) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const setDefaultWarehouse = useCallback((id: string) => {
    const res = db.setDefaultWarehouse(id);
    if (res) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const distributeProductStock = useCallback((productId: string, distribution: Record<string, number>) => {
    const res = db.distributeProductStock(productId, distribution);
    if (res) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const transferStock = useCallback((params: {
    fromWarehouseId: string;
    toWarehouseId: string;
    productId: string;
    quantity: number;
    notes?: string;
    transferredBy?: string;
  }) => {
    const res = db.transferStockBetweenWarehouses(params);
    if (res.success) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('pos_app_language', lang);
    const nextDir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
    document.documentElement.dir = nextDir;
    document.documentElement.setAttribute('data-dir', nextDir);
    document.body.dir = nextDir;
    db.updateSettings({ language: lang });
    setSettings(prev => ({ ...prev, language: lang }));
  }, []);

  const t = useCallback((key: TranslationKey): string => {
    const dict = translations[language] || translations.ar;
    return dict[key] || translations.ar[key] || key;
  }, [language]);

  const tr = useCallback((arText: string, enText: string): string => {
    return language === 'en' ? enText : arText;
  }, [language]);

  const setAppTheme = useCallback((theme: AppThemeId) => {
    setAppThemeState(theme);
    localStorage.setItem('pos_app_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    db.updateSettings({ appTheme: theme });
    setSettings(prev => ({ ...prev, appTheme: theme }));
  }, []);

  const setLowSpecMode = useCallback((enabled: boolean) => {
    setLowSpecModeState(enabled);
    localStorage.setItem('pos_low_spec_mode', String(enabled));
    applyLowSpecModeToDOM(enabled);
    db.updateSettings({ lowSpecMode: enabled });
    setSettings(prev => ({ ...prev, lowSpecMode: enabled }));
  }, []);

  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    const updated = db.updateSettings(newSettings);
    setSettings({ ...updated });
    if (newSettings.language && newSettings.language !== language) {
      setLanguageState(newSettings.language);
      localStorage.setItem('pos_app_language', newSettings.language);
    }
    if (newSettings.appTheme && newSettings.appTheme !== appTheme) {
      setAppThemeState(newSettings.appTheme);
    }
    if (typeof newSettings.lowSpecMode === 'boolean' && newSettings.lowSpecMode !== lowSpecMode) {
      setLowSpecModeState(newSettings.lowSpecMode);
      localStorage.setItem('pos_low_spec_mode', String(newSettings.lowSpecMode));
      applyLowSpecModeToDOM(newSettings.lowSpecMode);
    }
  };

  const formatCurrency = useCallback((amount: number): string => {
    const num = isNaN(amount) ? 0 : amount;
    let formatted: string;
    try {
      formatted = num.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    } catch {
      formatted = num.toFixed(2);
    }
    return `${formatted} ${settings.currencySymbol || (language === 'ar' ? 'ج.م' : 'EGP')}`;
  }, [language, settings.currencySymbol]);

  const currencies = useMemo(() => {
    return settings.currencies && settings.currencies.length > 0
      ? settings.currencies
      : db.getCurrencies();
  }, [settings.currencies]);

  const baseCurrency = useMemo(() => {
    return (
      currencies.find(c => c.isBase) ||
      currencies.find(c => c.code === (settings.baseCurrency || 'EGP')) ||
      currencies[0]
    );
  }, [currencies, settings.baseCurrency]);

  const activeCurrency = useMemo(() => {
    const activeCode = settings.activeCurrency || settings.currency || 'EGP';
    return currencies.find(c => c.code === activeCode) || baseCurrency;
  }, [currencies, settings.activeCurrency, settings.currency, baseCurrency]);

  const syncCartWithUpdatedProducts = useCallback(() => {
    const latestProducts = db.getProducts();
    const currentSettings = db.getSettings();
    const rawVat = Number(currentSettings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;

    setCart(prev =>
      prev.map(item => {
        const updatedProd = latestProducts.find(p => p.id === item.product.id);
        if (!updatedProd) return item;
        const newPrice = updatedProd.salePrice;
        const itemTotal = Math.max(0, newPrice * item.quantity - item.discount);
        const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
        return {
          ...item,
          product: updatedProd,
          price: newPrice,
          tax: taxVal,
          total: itemTotal
        };
      })
    );
  }, []);

  const switchActiveCurrency = useCallback((code: string) => {
    const res = db.switchActiveCurrency(code);
    if (res.success) {
      refreshData();
      syncCartWithUpdatedProducts();
    }
    return res;
  }, [refreshData, syncCartWithUpdatedProducts]);

  const updateCurrencyExchangeRate = useCallback((
    code: string,
    newRate: number,
    options?: {
      applyToProductPrices?: boolean;
      priceImpactMode?: 'auto' | 'scale_all' | 'convert_active';
    }
  ) => {
    const res = db.updateCurrencyExchangeRate(code, newRate, options);
    if (res.success) {
      refreshData();
      syncCartWithUpdatedProducts();
    }
    return res;
  }, [refreshData, syncCartWithUpdatedProducts]);

  const addCurrency = useCallback((currency: Omit<CurrencyRate, 'id' | 'updatedAt'>) => {
    const res = db.addCurrency(currency);
    if (res.success) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const deleteCurrency = useCallback((code: string) => {
    const res = db.deleteCurrency(code);
    if (res.success) {
      refreshData();
    }
    return res;
  }, [refreshData]);

  const setBaseCurrency = useCallback((newBaseCode: string) => {
    const res = db.setBaseCurrency(newBaseCode);
    if (res.success) {
      refreshData();
      syncCartWithUpdatedProducts();
    }
    return res;
  }, [refreshData, syncCartWithUpdatedProducts]);

  // Toast Notification handler
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) {
      showToast(language === 'ar' ? `تنبيه: هذا المنتج نافد من المخزون!` : `Alert: Item is out of stock!`, 'error');
      return;
    }

    const rawVat = Number(settings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;

    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.product.id === product.id);
      if (existingIndex > -1) {
        const existing = prev[existingIndex];
        const newQty = existing.quantity + quantity;
        if (newQty > product.stock) {
          showToast(language === 'ar' ? `الكمية المطلوبة تتجاوز المخزون المتوفر (${product.stock})` : `Quantity exceeds available stock (${product.stock})`, 'error');
          return prev;
        }
        const updated = [...prev];
        const itemTotal = (existing.price * newQty) - existing.discount;
        const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          tax: taxVal,
          total: itemTotal
        };
        return updated;
      } else {
        const itemTotal = (product.salePrice * quantity);
        const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
        return [
          ...prev,
          {
            product,
            quantity,
            price: product.salePrice,
            discount: 0,
            tax: taxVal,
            total: itemTotal
          }
        ];
      }
    });
  };

  const updateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    const rawVat = Number(settings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;

    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          if (quantity > item.product.stock) {
            showToast(language === 'ar' ? `المخزون المتوفر لا يكفي (${item.product.stock})` : `Insufficient stock (${item.product.stock})`, 'error');
            return item;
          }
          const itemTotal = (item.price * quantity) - item.discount;
          const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
          return {
            ...item,
            quantity,
            tax: taxVal,
            total: itemTotal
          };
        }
        return item;
      });
    });
  };

  const updateCartPrice = (productId: string, price: number) => {
    const cleanPrice = Math.max(0, price);
    const rawVat = Number(settings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;

    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const itemTotal = Math.max(0, (cleanPrice * item.quantity) - item.discount);
          const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
          return {
            ...item,
            price: cleanPrice,
            tax: taxVal,
            total: itemTotal
          };
        }
        return item;
      });
    });
  };

  const updateCartDiscount = (productId: string, discount: number) => {
    const rawVat = Number(settings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;

    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const discountVal = Math.max(0, discount);
          const itemTotal = Math.max(0, (item.price * item.quantity) - discountVal);
          const taxVal = taxRate > 0 ? Number((itemTotal * taxRate).toFixed(2)) : 0;
          return {
            ...item,
            discount: discountVal,
            tax: taxVal,
            total: itemTotal
          };
        }
        return item;
      });
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const holdCurrentCart = (name?: string) => {
    if (cart.length === 0) return;
    const holdName = name || (language === 'ar' ? `طلب معلق #${heldCarts.length + 1}` : `Held Order #${heldCarts.length + 1}`);
    setHeldCarts(prev => [
      ...prev,
      {
        id: `held-${Date.now()}`,
        name: holdName,
        date: new Date().toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
        items: [...cart]
      }
    ]);
    setCart([]);
    showToast(language === 'ar' ? 'تم تعليق الفاتورة بنجاح' : 'Order held successfully', 'info');
  };

  const resumeHeldCart = (cartId: string) => {
    const target = heldCarts.find(c => c.id === cartId);
    if (target) {
      setCart(target.items);
      setHeldCarts(prev => prev.filter(c => c.id !== cartId));
      showToast(language === 'ar' ? 'تم استرجاع الفاتورة المعلقة' : 'Held order resumed', 'success');
    }
  };

  const deleteHeldCart = (cartId: string) => {
    setHeldCarts(prev => prev.filter(c => c.id !== cartId));
  };

  // Cart Totals calculation: VAT is ONLY calculated when settings.vatPercentage > 0
  const { cartSubtotal, cartDiscount, cartTax, cartTotal } = useMemo(() => {
    let disc = 0;
    let netItemsTotal = 0;

    cart.forEach(item => {
      disc += item.discount;
      netItemsTotal += item.total;
    });

    const rawVat = Number(settings.vatPercentage);
    const taxRate = !isNaN(rawVat) && rawVat > 0 ? rawVat / 100 : 0;
    const tax = taxRate > 0 ? Number((netItemsTotal * taxRate).toFixed(2)) : 0;
    const grandTotal = Number((netItemsTotal + tax).toFixed(2));

    return {
      cartSubtotal: Number(netItemsTotal.toFixed(2)),
      cartDiscount: Number(disc.toFixed(2)),
      cartTax: tax,
      cartTotal: grandTotal
    };
  }, [cart, settings.vatPercentage]);

  // Invoice Modal handlers
  const openInvoiceModal = (invoice: SaleInvoice) => {
    setActiveInvoice(invoice);
  };

  const closeInvoiceModal = () => {
    setActiveInvoice(null);
  };

  // Confirmation Dialog
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  } | null>(null);

  const requestConfirm = useCallback((options: {
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  }) => {
    setConfirmDialog({
      isOpen: true,
      title: options.title,
      message: options.message,
      confirmText: options.confirmText,
      cancelText: options.cancelText,
      isDestructive: options.isDestructive !== undefined ? options.isDestructive : true,
      onConfirm: options.onConfirm
    });
  }, []);

  const closeConfirm = useCallback(() => {
    setConfirmDialog(null);
  }, []);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        tr,
        dir,
        settings,
        updateSettings,
        appTheme,
        setAppTheme,
        lowSpecMode,
        setLowSpecMode,
        formatCurrency,
        currencies,
        activeCurrency,
        baseCurrency,
        switchActiveCurrency,
        updateCurrencyExchangeRate,
        addCurrency,
        deleteCurrency,
        setBaseCurrency,
        warehouses,
        warehouseTransfers,
        addWarehouse,
        updateWarehouse,
        deleteWarehouse,
        setDefaultWarehouse,
        distributeProductStock,
        transferStock,
        products,
        customers,
        suppliers,
        sales,
        purchases,
        returns,
        expenses,
        installmentPlans,
        refreshData,
        syncStatus,
        syncEmail: syncStatus.syncEmail || db.getSyncEmail(),
        emailSyncLocked: Boolean(
          (syncStatus.syncEmail || db.getSyncEmail()) && syncStatus.emailSyncLocked
        ),
        setSyncEmail,
        setEmailSyncFieldLocked,
        syncNow,
        cart,
        addToCart,
        updateCartQty,
        updateCartPrice,
        updateCartDiscount,
        removeFromCart,
        clearCart,
        cartSubtotal,
        cartDiscount,
        cartTax,
        cartTotal,
        heldCarts,
        holdCurrentCart,
        resumeHeldCart,
        deleteHeldCart,
        activeInvoice,
        openInvoiceModal,
        closeInvoiceModal,
        toasts,
        showToast,
        removeToast,
        confirmDialog,
        requestConfirm,
        closeConfirm
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
