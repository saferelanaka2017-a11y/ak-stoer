/**
 * @file components/PrinterSelectionModal.tsx
 * نافذة اختيار وتعريف الطابعة للطباعة الفورية
 * تتيح تحديد نوع الطابعة (حرارية 80mm / 58mm / A4) وتخصيص الاسم والطباعة التلقائية
 */

import React, { useState } from 'react';
import { 
  Printer, 
  Check, 
  Settings, 
  X, 
  CheckCircle2, 
  FileText, 
  Laptop, 
  HelpCircle,
  Zap,
  Sparkles
} from 'lucide-react';
import { PrinterType, StoreSettings, SaleInvoice } from '../types';
import { useApp } from '../contexts/AppContext';
import { printInvoiceDirect, generateTestPrintPDF } from '../utils/exportUtils';

interface PrinterSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAndPrint?: (printerType: PrinterType) => void;
  currentInvoice?: SaleInvoice;
}

interface PrinterOption {
  id: PrinterType;
  title: string;
  badge: string;
  badgeColor: string;
  paperWidth: string;
  description: string;
  iconType: 'thermal' | 'portable' | 'office' | 'system' | 'pdf';
  recommendedFor: string;
}

const PRINTER_OPTIONS: PrinterOption[] = [
  {
    id: 'thermal-80',
    title: 'طابعة فواتير حرارية (80mm Thermal POS)',
    badge: 'الأكثر استخداماً في نقاط البيع',
    badgeColor: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    paperWidth: 'عرض الورق: 80 مم (بكرة حرارية)',
    description: 'متوافقة مع طابعات إبسون (Epson)، إكس برنتر (Xprinter)، بيسولون (Bixolon)، ستار، وسونمي.',
    iconType: 'thermal',
    recommendedFor: 'السوبرماركت، الكافيهات، والمحلات التجارية'
  },
  {
    id: 'thermal-58',
    title: 'طابعة إيصالات مدمجة / صغيرة (58mm Thermal)',
    badge: 'طابعات محمولة وبلوتوث',
    badgeColor: 'bg-amber-100 text-amber-700 border-amber-200',
    paperWidth: 'عرض الورق: 58 مم (بكرة صغيرة)',
    description: 'مناسبة للأجهزة الكفية المحمولة وطابعات البلوتوث الميدانية أو الطابعات الصغيرة الموفرة للمساحة.',
    iconType: 'portable',
    recommendedFor: 'المندوبين ومحلات الخدمات السريعة'
  },
  {
    id: 'a4-standard',
    title: 'طابعة مكتبية قياسية (Standard A4 / Laser)',
    badge: 'فواتير رسمية A4',
    badgeColor: 'bg-blue-100 text-blue-700 border-blue-200',
    paperWidth: 'مقاس الورق: A4 عادي',
    description: 'طباعة فاتورة ضريبية رسمية كاملة مع كود QR على ورق A4 عبر طابعات HP، Canon، Brother المكتبية.',
    iconType: 'office',
    recommendedFor: 'الشركات، مبيعات الجملة، والمؤسسات'
  },
  {
    id: 'system-dialog',
    title: 'قائمة طابعات نظام التشغيل (System Print Dialog)',
    badge: 'اختيار يدوي لكل عملية',
    badgeColor: 'bg-purple-100 text-purple-700 border-purple-200',
    paperWidth: 'حسب الطابعة المختارة',
    description: 'فتح نافذة اختيار الطابعة المدمجة في الويندوز أو الماك لاختيار الطابعة المعرفة في جهازك يدوياً.',
    iconType: 'system',
    recommendedFor: 'عند وجود عدة طابعات مختلفة متصلة بالجهاز'
  },
  {
    id: 'pdf-export',
    title: 'طابعة PDF الرقمية (Save / Print to PDF)',
    badge: 'حفظ إلكتروني',
    badgeColor: 'bg-slate-100 text-slate-700 border-slate-200',
    paperWidth: 'ملف رقمي إلكتروني',
    description: 'حفظ الفاتورة كملف رقمي عالي الجودة لإرسالها للعميل عبر الواتساب أو الإيميل.',
    iconType: 'pdf',
    recommendedFor: 'الأرشفة الإلكترونية وإرسال الفواتير عن بعد'
  }
];

export const PrinterSelectionModal: React.FC<PrinterSelectionModalProps> = ({
  isOpen,
  onClose,
  onSelectAndPrint,
  currentInvoice
}) => {
  const { settings, updateSettings, showToast } = useApp();

  const [selectedType, setSelectedType] = useState<PrinterType>(
    settings.selectedPrinter || 'thermal-80'
  );
  const [customName, setCustomName] = useState(
    settings.printerCustomName || ''
  );
  const [autoPrint, setAutoPrint] = useState(
    Boolean(settings.autoPrintOnSale)
  );
  const [alwaysShowDialog, setAlwaysShowDialog] = useState(
    Boolean(settings.showPrinterDialogBeforePrint)
  );
  const [isTesting, setIsTesting] = useState(false);

  if (!isOpen) return null;

  // Save selection to persistent StoreSettings
  const handleSaveSettings = () => {
    updateSettings({
      selectedPrinter: selectedType,
      printerCustomName: customName,
      autoPrintOnSale: autoPrint,
      showPrinterDialogBeforePrint: alwaysShowDialog,
      printLayout: selectedType === 'a4-standard' ? 'a4' : 'thermal'
    });
  };

  // Instant Test Print
  const handleTestPrint = () => {
    setIsTesting(true);
    showToast('جاري إرسال صفحة اختبار إلى الطابعة المحددة...', 'info');

    try {
      const mockInvoiceForTest: SaleInvoice = currentInvoice || {
        id: 'test-print-1',
        invoiceNumber: 'TEST-001',
        date: new Date().toISOString(),
        cashierId: 'admin',
        cashierName: 'مسؤول النظام',
        customerName: 'تجربة اتصال الطابعة',
        items: [
          {
            product: {
              id: 'p1',
              barcode: '12345678',
              name: 'صنف تجريبي لاختبار الطابعة',
              category: 'عام',
              costPrice: 10,
              salePrice: 15,
              stock: 100,
              minStockAlert: 5,
              unit: 'حبة',
              createdAt: new Date().toISOString()
            },
            quantity: 1,
            price: 15,
            discount: 0,
            tax: 2.25,
            total: 17.25
          }
        ],
        subtotal: 15,
        taxTotal: 2.25,
        discountTotal: 0,
        grandTotal: 17.25,
        paidAmount: 20,
        changeAmount: 2.75,
        paymentMethod: 'cash',
        notes: 'تمت الطباعة التجريبية بنجاح!'
      };

      printInvoiceDirect(mockInvoiceForTest, {
        ...settings,
        selectedPrinter: selectedType,
        printLayout: selectedType === 'a4-standard' ? 'a4' : 'thermal'
      });
      showToast('تم إرسال أمر الطباعة التجريبي!', 'success');
    } catch (e) {
      console.error(e);
      showToast('تعذر إرسال أمر الطباعة، يرجى التأكد من تشغيل الطابعة وتوصيل الكابل', 'error');
    } finally {
      setTimeout(() => setIsTesting(false), 800);
    }
  };

  // Confirm selection and execute immediate print if requested
  const handleConfirmAndPrint = () => {
    handleSaveSettings();
    showToast('تم حفظ إعدادات الطابعة الافتراضية بنجاح', 'success');

    if (onSelectAndPrint) {
      onSelectAndPrint(selectedType);
    } else if (currentInvoice) {
      printInvoiceDirect(currentInvoice, {
        ...settings,
        selectedPrinter: selectedType,
        printLayout: selectedType === 'a4-standard' ? 'a4' : 'thermal'
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm overflow-y-auto">
      <div className="neu-card rounded-3xl w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center shadow-inner">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <span>اختيار وتجهيز طابعة الفواتير الفورية</span>
                <span className="px-2 py-0.5 text-[10px] bg-blue-50 text-blue-600 border border-blue-200 rounded-full font-normal">
                  إعدادات سريعة
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                حدد نوع الطابعة المتصلة بجهازك لضبط مقاس الورق والأمر الفوري بدقة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl neu-button flex items-center justify-center text-slate-500 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs flex-1">
          {/* Instructions Banner */}
          <div className="p-3.5 bg-blue-50/70 border border-blue-200/60 rounded-2xl flex items-start gap-3">
            <Zap className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold text-blue-900">
                الطباعة الفورية في ثوانٍ:
              </p>
              <p className="text-blue-800/80 leading-relaxed text-[11px]">
                اختر الطابعة المناسبة لجهازك أدناه وسيتم ضبط قياس الفاتورة (حراري 80mm أو 58mm أو A4) تلقائياً ليتم إرسال الأمر فوراً عند النقر بدون خطوات إضافية.
              </p>
            </div>
          </div>

          {/* Printer Options List */}
          <div className="space-y-2.5">
            <label className="font-bold text-slate-800 block text-xs">
              اختر نوع الطابعة المتوفرة لديك:
            </label>

            {PRINTER_OPTIONS.map((opt) => {
              const isSelected = selectedType === opt.id;
              return (
                <div
                  key={opt.id}
                  onClick={() => setSelectedType(opt.id)}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3.5 ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50/40 shadow-sm ring-2 ring-blue-500/20'
                      : 'border-slate-200/80 hover:border-slate-300 bg-white/60'
                  }`}
                >
                  <div className="pt-0.5">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                        isSelected ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </div>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="font-bold text-slate-800 text-xs">{opt.title}</span>
                      <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full border ${opt.badgeColor}`}>
                        {opt.badge}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 font-medium">
                      {opt.paperWidth} — <span className="text-slate-400 font-normal">{opt.recommendedFor}</span>
                    </p>

                    <p className="text-[10px] text-slate-500 leading-normal">
                      {opt.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Custom Printer Name (Optional) */}
          <div className="p-4 bg-slate-50/80 border border-slate-200 rounded-2xl space-y-2">
            <label className="font-bold text-slate-800 block text-xs">
              اسم الطابعة أو الموديل (اختياري لتسهيل التمييز):
            </label>
            <input
              type="text"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder="مثال: Epson TM-T20III أو Xprinter XP-420B أو HP LaserJet"
              className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold"
            />
            <p className="text-[10px] text-slate-400">
              يساعدك في تذكر الطابعة التي تم ربطها بهذا الجهاز.
            </p>
          </div>

          {/* Quick Preferences */}
          <div className="space-y-2 pt-1 border-t border-slate-200">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoPrint}
                onChange={(e) => setAutoPrint(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300"
              />
              <span className="font-bold text-slate-700">
                طباعة فورية تلقائية بمجرد حفظ الفاتورة بنقطة البيع (Auto-Print)
              </span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={alwaysShowDialog}
                onChange={(e) => setAlwaysShowDialog(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300"
              />
              <span className="text-slate-600 font-medium">
                إظهار نافذة اختيار الطابعة قبل كل عملية طباعة
              </span>
            </label>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-white/60 flex items-center justify-between neu-card bg-slate-50/50">
          <button
            type="button"
            onClick={handleTestPrint}
            disabled={isTesting}
            className="neu-button px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-semibold text-blue-600 cursor-pointer disabled:opacity-50"
          >
            <Printer className={`w-4 h-4 ${isTesting ? 'animate-pulse' : ''}`} />
            <span>{isTesting ? 'جاري الاختبار...' : 'طباعة تجريبية الآن'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="neu-button px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleConfirmAndPrint}
              className="neu-button-primary px-5 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>تأكيد والطباعة فوراً</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
