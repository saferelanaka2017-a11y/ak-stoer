/**
 * @file App.tsx
 * تطبيق نقاط البيع وإدارة المبيعات المتكامل
 * Soft Glass Neumorphic POS Main Application Component with Auto-Fit Screen Scaling for All PC Monitors
 */

import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AppProvider, useApp } from './contexts/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { ToastContainer } from './components/ToastContainer';
import { ConfirmModal } from './components/ConfirmModal';
import { ActivationModal } from './components/ActivationModal';
import { TrialBanner } from './components/TrialBanner';
import { WindowsDesktopModal } from './components/WindowsDesktopModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { MobileRemoteScannerView } from './components/MobileRemoteScannerView';
import { SmartWhatsAppModal } from './components/SmartWhatsAppModal';

// Pages
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { POSPage } from './pages/POSPage';
import { SalesInvoicesPage } from './pages/SalesInvoicesPage';
import { ProductsPage } from './pages/ProductsPage';
import { PurchasesPage } from './pages/PurchasesPage';
import { SalesReturnsPage } from './pages/SalesReturnsPage';
import { PurchaseReturnsPage } from './pages/PurchaseReturnsPage';
import { CustomersPage } from './pages/CustomersPage';
import { InstallmentsPage } from './pages/InstallmentsPage';
import { ExpensesPage } from './pages/ExpensesPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { UsersPage } from './pages/UsersPage';
import { DeveloperKeygenPage } from './pages/DeveloperKeygenPage';
import { UserPermissions } from './types';
import { ShieldAlert } from 'lucide-react';

// License & Trial Manager
import { getLicenseState, LicenseState } from './utils/licenseManager';
import {
  restoreDatabaseAndLicenseFromSafeVaultIfNeeded,
  syncDatabaseAndLicenseToSafeVault,
  startAutoLiveUpdateWatcher
} from './utils/updateManager';
import {
  ScreenScalePreset,
  ScreenResolutionInfo,
  getSavedScreenScalePreset,
  saveScreenScalePreset,
  applyScreenScaleToDOM,
  getSavedSidebarCollapsed,
  saveSidebarCollapsed
} from './utils/screenAdapter';

const TAB_PERMISSION_MAP: Record<string, keyof UserPermissions> = {
  dashboard: 'viewDashboard',
  pos: 'accessPOS',
  'sales-invoices': 'viewSalesInvoices',
  products: 'viewProducts',
  purchases: 'viewPurchases',
  'sales-returns': 'viewSalesReturns',
  'purchase-returns': 'viewPurchaseReturns',
  customers: 'viewCustomers',
  installments: 'viewInstallments',
  expenses: 'viewExpenses',
  reports: 'viewReports',
  users: 'manageUsers',
  settings: 'viewSettings'
};

function AppContent() {
  const { user, isAdmin, hasPermission } = useAuth();
  const { activeInvoice, closeInvoiceModal, confirmDialog, closeConfirm, refreshData, showToast, tr } = useApp();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [remoteScannerSession, setRemoteScannerSession] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    const params = new URLSearchParams(window.location.search);
    return params.get('scannerSession') || null;
  });

  // Adaptive Screen Size & Sidebar Collapse State
  const [screenScalePreset, setScreenScalePreset] = useState<ScreenScalePreset>(() =>
    getSavedScreenScalePreset()
  );
  const [screenInfo, setScreenInfo] = useState<ScreenResolutionInfo>(() =>
    applyScreenScaleToDOM(getSavedScreenScalePreset())
  );
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() =>
    getSavedSidebarCollapsed()
  );

  const handleChangeScreenScale = useCallback((preset: ScreenScalePreset) => {
    setScreenScalePreset(preset);
    saveScreenScalePreset(preset);
    setScreenInfo(applyScreenScaleToDOM(preset));
  }, []);

  const handleToggleSidebarCollapse = useCallback(() => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      saveSidebarCollapsed(next);
      return next;
    });
  }, []);

  // Re-calculate screen scale on window resize so any monitor resolution change adapts live
  useEffect(() => {
    const updateOnResize = () => {
      setScreenInfo(applyScreenScaleToDOM(screenScalePreset));
    };
    updateOnResize();
    window.addEventListener('resize', updateOnResize);
    return () => window.removeEventListener('resize', updateOnResize);
  }, [screenScalePreset]);

  // License and trial tracking
  const [licenseState, setLicenseState] = useState<LicenseState>(getLicenseState());
  const [isActivationModalOpen, setIsActivationModalOpen] = useState(false);
  const [isWindowsModalOpen, setIsWindowsModalOpen] = useState(false);

  const refreshLicense = () => {
    setLicenseState(getLicenseState());
    syncDatabaseAndLicenseToSafeVault();
  };

  // Restore from persistent EXE vault if needed on startup & sync periodically
  useEffect(() => {
    restoreDatabaseAndLicenseFromSafeVaultIfNeeded().then((restored) => {
      if (restored) {
        refreshData();
        setLicenseState(getLicenseState());
      } else {
        syncDatabaseAndLicenseToSafeVault();
      }
    });
  }, [refreshData]);

  // Live OTA Auto-Update Watcher for Mobile PWA & Laptop .EXE
  useEffect(() => {
    const stopWatcher = startAutoLiveUpdateWatcher(() => {
      showToast(
        tr(
          'تم تحميل أحدث تعديلات النظام تلقائياً! جاري تحديث النسخة المحملة...',
          'Latest system modifications downloaded! Updating installed app...'
        ),
        'info'
      );
      setTimeout(() => {
        const url = new URL(window.location.href);
        url.searchParams.set('updated', String(Date.now()));
        window.location.replace(url.toString());
      }, 900);
    });
    return stopWatcher;
  }, [showToast, tr]);

  // Keep countdown updated periodically & check for developer secret param (Admin only)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if ((params.get('developer') === '1' || params.get('dev') === '1') && isAdmin) {
      setActiveTab('developer-keygen');
    }

    const handleLicenseEvent = () => {
      setLicenseState(getLicenseState());
      syncDatabaseAndLicenseToSafeVault();
    };
    window.addEventListener('akstore-license-updated', handleLicenseEvent);

    const timer = setInterval(() => {
      setLicenseState(getLicenseState());
      syncDatabaseAndLicenseToSafeVault();
    }, 30000);
    return () => {
      window.removeEventListener('akstore-license-updated', handleLicenseEvent);
      clearInterval(timer);
    };
  }, [isAdmin]);

  // When a user logs in, ensure their activeTab is one they have permission to view
  // and clean any ?install=1 parameter so setup never pops up for non-admin users
  useEffect(() => {
    if (!user) return;
    const isSuperAdmin = user.username.toLowerCase() === 'admin';
    if (typeof window !== 'undefined' && window.location.search.includes('install=')) {
      const url = new URL(window.location.href);
      url.searchParams.delete('install');
      window.history.replaceState({}, '', url.toString());
      if (isSuperAdmin) {
        setActiveTab('admin-setup');
        return;
      }
    }
    if (!isSuperAdmin && isWindowsModalOpen) {
      setIsWindowsModalOpen(false);
    }
    if (activeTab === 'admin-setup') {
      if (!isSuperAdmin) {
        setActiveTab('dashboard');
      }
      return;
    }
    if (activeTab === 'developer-keygen') {
      if (!isAdmin) {
        setActiveTab('pos');
      }
      return;
    }
    const reqPerm = TAB_PERMISSION_MAP[activeTab];
    if (reqPerm && !hasPermission(reqPerm)) {
      const firstAllowedTab = Object.entries(TAB_PERMISSION_MAP).find(([, permKey]) =>
        hasPermission(permKey)
      )?.[0];
      if (firstAllowedTab) {
        setActiveTab(firstAllowedTab);
      }
    }
  }, [user, isAdmin, activeTab, hasPermission]);

  // If opened on a mobile phone via QR code (?scannerSession=...), render the Wireless Mobile Barcode Scanner directly
  if (remoteScannerSession) {
    return (
      <>
        <MobileRemoteScannerView
          sessionId={remoteScannerSession}
          onExitRemoteMode={() => {
            setRemoteScannerSession(null);
            if (typeof window !== 'undefined') {
              const url = new URL(window.location.href);
              url.searchParams.delete('scannerSession');
              window.history.replaceState({}, '', url.toString());
            }
          }}
        />
        <ToastContainer />
      </>
    );
  }

  // When user is not logged in, render the login page first
  if (!user) {
    return (
      <>
        <LoginPage />
        <SmartWhatsAppModal />
        <ToastContainer />
      </>
    );
  }

  // Determine if application is locked due to expired trial
  const isTrialLocked = licenseState.isTrialExpired && !licenseState.isActivated;

  const renderActivePage = () => {
    if (activeTab === 'admin-setup') {
      if (user.username.toLowerCase() !== 'admin') {
        return <DashboardPage onNavigate={setActiveTab} />;
      }
      return (
        <WindowsDesktopModal
          isOpen={true}
          asPage={true}
          onClose={() => setActiveTab('dashboard')}
        />
      );
    }

    if (activeTab === 'developer-keygen' && !isAdmin) {
      return <POSPage />;
    }

    if (activeTab !== 'developer-keygen' && activeTab !== 'admin-setup') {
      const reqPerm = TAB_PERMISSION_MAP[activeTab];
      if (reqPerm && !hasPermission(reqPerm)) {
        const fallbackTab =
          Object.entries(TAB_PERMISSION_MAP).find(([, permKey]) => hasPermission(permKey))?.[0] ||
          'pos';
        return (
          <div className="neu-card rounded-3xl p-8 max-w-lg mx-auto my-12 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
              <ShieldAlert className="w-7 h-7" />
            </div>
            <h2 className="text-lg font-black text-slate-800">
              {tr('عفواً، ليس لديك صلاحية لفتح هذه الشاشة', 'Access Denied to This Screen')}
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              {tr(
                'تم تقييد الوصول لهذه الشاشة حسب الصلاحيات المحددة لحسابك من قِبل مدير النظام.',
                'Your account permissions do not include access to this module. Please contact your system administrator.'
              )}
            </p>
            <button
              onClick={() => setActiveTab(fallbackTab)}
              className="neu-button-primary px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer"
            >
              {tr('الانتقال للشاشة المتاحة', 'Go to Allowed Screen')}
            </button>
          </div>
        );
      }
    }

    switch (activeTab) {
      case 'dashboard':
        return <DashboardPage onNavigate={setActiveTab} />;
      case 'pos':
        return <POSPage />;
      case 'sales-invoices':
        return <SalesInvoicesPage />;
      case 'products':
        return <ProductsPage />;
      case 'purchases':
        return <PurchasesPage />;
      case 'sales-returns':
        return <SalesReturnsPage />;
      case 'purchase-returns':
        return <PurchaseReturnsPage />;
      case 'customers':
        return <CustomersPage />;
      case 'installments':
        return <InstallmentsPage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'reports':
        return <ReportsPage />;
      case 'users':
        return <UsersPage />;
      case 'settings':
        return <SettingsPage />;
      case 'developer-keygen':
        return (
          <DeveloperKeygenPage
            onBackToApp={() => setActiveTab('pos')}
            onRefreshLicense={refreshLicense}
          />
        );
      default:
        return <POSPage />;
    }
  };

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-[#e9eff5]">
      {/* 2-Day Trial Top Alert Banner */}
      <TrialBanner
        licenseState={licenseState}
        onOpenActivation={() => setIsActivationModalOpen(true)}
      />

      {/* Top Navbar */}
      <Navbar
        onNavigate={setActiveTab}
        activeTab={activeTab}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        licenseState={licenseState}
        onOpenActivation={() => setIsActivationModalOpen(true)}
        screenScalePreset={screenScalePreset}
        screenInfo={screenInfo}
        onChangeScreenScale={handleChangeScreenScale}
        isSidebarCollapsed={isSidebarCollapsed}
        onToggleSidebarCollapse={handleToggleSidebarCollapse}
      />

      {/* Main Body with Adaptive Sidebar + Viewport */}
      <div className="flex-1 min-h-0 flex overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          isOpenOnMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleToggleSidebarCollapse}
        />
        <main className="flex-1 min-w-0 min-h-0 p-2.5 sm:p-4 lg:p-5 overflow-y-auto">
          {renderActivePage()}
        </main>
      </div>

      {/* Invoice Print & PDF Modal */}
      {activeInvoice && (
        <InvoicePrintModal invoice={activeInvoice} onClose={closeInvoiceModal} />
      )}

      {/* Confirmation Modal */}
      {confirmDialog && (
        <ConfirmModal
          isOpen={confirmDialog.isOpen}
          title={confirmDialog.title}
          message={confirmDialog.message}
          confirmText={confirmDialog.confirmText}
          cancelText={confirmDialog.cancelText}
          isDestructive={confirmDialog.isDestructive}
          onConfirm={confirmDialog.onConfirm}
          onCancel={closeConfirm}
        />
      )}

      {/* Activation Modal / Trial Lock Screen */}
      <ActivationModal
        isOpen={isTrialLocked || isActivationModalOpen}
        isMandatory={isTrialLocked}
        onClose={() => setIsActivationModalOpen(false)}
        licenseState={licenseState}
        onRefreshLicense={refreshLicense}
      />

      {/* Windows 7 / 8 / 10 / 11 Desktop Installer Modal — Strictly for primary @admin only */}
      {user.username.toLowerCase() === 'admin' && isWindowsModalOpen && (
        <WindowsDesktopModal
          isOpen={isWindowsModalOpen}
          onClose={() => setIsWindowsModalOpen(false)}
        />
      )}

      {/* Global Smart Multi-Channel WhatsApp Sender Modal */}
      <SmartWhatsAppModal />

      {/* Offline Connectivity Banner */}
      <OfflineIndicator />

      {/* Global Notifications */}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
}
