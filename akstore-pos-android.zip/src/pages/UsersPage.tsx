/**
 * @file pages/UsersPage.tsx
 * شاشة تسجيل المستخدمين وإدارة الصلاحيات المخصصة لأي مستخدم غير الأدمن
 * Users Registration & Granular Permissions Management Screen
 */

import React, { useState, useMemo } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  Shield,
  KeyRound,
  Edit,
  Trash2,
  Search,
  Check,
  X,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Phone,
  Briefcase,
  SlidersHorizontal,
  LayoutDashboard,
  ShoppingCart,
  Package,
  ShoppingBag,
  RotateCcw,
  Undo2,
  CalendarClock,
  ReceiptText,
  BarChart3,
  Settings as SettingsIcon,
  CheckSquare,
  Square
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import { User, UserRole, UserPermissions } from '../types';
import {
  DEFAULT_ADMIN_PERMISSIONS,
  DEFAULT_CASHIER_PERMISSIONS,
  getEffectivePermissions
} from '../db/database';
import {
  normalizeEnglishPasswordInput,
  handleEnglishPasswordKeyDown
} from '../utils/keyboardNormalizer';

interface PermissionMeta {
  key: keyof UserPermissions;
  category: 'screens' | 'actions';
  labelAr: string;
  labelEn: string;
  descAr: string;
  descEn: string;
  icon: React.ComponentType<{ className?: string }>;
}

const PERMISSIONS_CATALOG: PermissionMeta[] = [
  // 1. صلاحيات فتح الشاشات والأقسام (Screen Access)
  {
    key: 'viewDashboard',
    category: 'screens',
    labelAr: 'لوحة التحكم والإحصائيات السريعة',
    labelEn: 'Dashboard Overview',
    descAr: 'عرض ملخص المبيعات اليومية والتنبيهات في الصفحة الرئيسية',
    descEn: 'View daily summary cards and alerts on the home dashboard',
    icon: LayoutDashboard
  },
  {
    key: 'accessPOS',
    category: 'screens',
    labelAr: 'شاشة نقطة البيع (الكاشير)',
    labelEn: 'Point of Sale (POS)',
    descAr: 'إصدار فواتير البيع وطباعة الإيصالات للعملاء',
    descEn: 'Create sales invoices and print customer receipts',
    icon: ShoppingCart
  },
  {
    key: 'viewSalesInvoices',
    category: 'screens',
    labelAr: 'شاشة فواتير المبيعات (بيع مباشر غير كاشير)',
    labelEn: 'Standard Sales Invoices (Non-Cashier)',
    descAr: 'إصدار وإدارة فواتير المبيعات الجدولية والآجلة للعملاء والتجار',
    descEn: 'Create and manage tabular B2B/direct sales invoices and credit sales',
    icon: ReceiptText
  },
  {
    key: 'viewProducts',
    category: 'screens',
    labelAr: 'شاشة المنتجات والمخزون',
    labelEn: 'Products & Inventory',
    descAr: 'استعراض الأصناف والباركود وكميات المخزون والمستودعات',
    descEn: 'View products catalog, barcodes, and warehouse stock levels',
    icon: Package
  },
  {
    key: 'viewPurchases',
    category: 'screens',
    labelAr: 'شاشة فواتير المشتريات',
    labelEn: 'Purchases Module',
    descAr: 'تسجيل فواتير الشراء وتوريد البضاعة للمخازن',
    descEn: 'Record purchase invoices and stock receiving',
    icon: ShoppingBag
  },
  {
    key: 'viewSalesReturns',
    category: 'screens',
    labelAr: 'شاشة مرتجع المبيعات',
    labelEn: 'Sales Returns',
    descAr: 'إرجاع أصناف من فواتير البيع للعملاء',
    descEn: 'Process customer sales returns and refunds',
    icon: RotateCcw
  },
  {
    key: 'viewPurchaseReturns',
    category: 'screens',
    labelAr: 'شاشة مرتجع المشتريات',
    labelEn: 'Purchase Returns',
    descAr: 'إرجاع بضاعة للموردين وخصمها من المخزون',
    descEn: 'Process returns to suppliers',
    icon: Undo2
  },
  {
    key: 'viewCustomers',
    category: 'screens',
    labelAr: 'شاشة العملاء والموردين',
    labelEn: 'Customers & Suppliers',
    descAr: 'إدارة بيانات العملاء والموردين وكشوف الحسابات والمديونيات',
    descEn: 'View and manage customers, suppliers, and account balances',
    icon: Users
  },
  {
    key: 'viewInstallments',
    category: 'screens',
    labelAr: 'شاشة إدارة الأقساط',
    labelEn: 'Installments Management',
    descAr: 'متابعة جداول الأقساط وتحصيل الدفعات المستحقة',
    descEn: 'Track installment plans and collect scheduled payments',
    icon: CalendarClock
  },
  {
    key: 'viewExpenses',
    category: 'screens',
    labelAr: 'شاشة المصروفات اليومية',
    labelEn: 'Daily Expenses',
    descAr: 'تسجيل ومتابعة مصروفات المتجر والتشغيل',
    descEn: 'Record and review daily store operational expenses',
    icon: ReceiptText
  },
  {
    key: 'viewReports',
    category: 'screens',
    labelAr: 'شاشة التقارير والأرباح التفصيلية',
    labelEn: 'Reports & Profit Analytics',
    descAr: 'الاطلاع على تقارير صافي الربح والمبيعات وحركة الصندوق',
    descEn: 'Access financial reports, net profit, and analytics',
    icon: BarChart3
  },
  {
    key: 'viewSettings',
    category: 'screens',
    labelAr: 'شاشة إعدادات النظام والعملات',
    labelEn: 'System & Currency Settings',
    descAr: 'تعديل إعدادات المتجر والضرائب والعملات والنسخ الاحتياطي',
    descEn: 'Modify store configuration, currencies, VAT, and backups',
    icon: SettingsIcon
  },
  {
    key: 'manageUsers',
    category: 'screens',
    labelAr: 'شاشة إدارة المستخدمين والصلاحيات',
    labelEn: 'Users & Permissions Management',
    descAr: 'إضافة وتعديل حسابات الموظفين وتخصيص صلاحياتهم',
    descEn: 'Register staff accounts and customize user permissions',
    icon: ShieldCheck
  },

  // 2. صلاحيات العمليات الحساسة والإجراءات (Operational Actions)
  {
    key: 'canAddProduct',
    category: 'actions',
    labelAr: 'إضافة أصناف ومنتجات جديدة',
    labelEn: 'Add New Products',
    descAr: 'السماح بإضافة منتجات جديدة واستيراد الأصناف للمخزون',
    descEn: 'Allow creating new products and importing items',
    icon: Package
  },
  {
    key: 'canEditProduct',
    category: 'actions',
    labelAr: 'تعديل بيانات وأسعار المنتجات والمخازن',
    labelEn: 'Edit Products & Stock',
    descAr: 'السماح بتعديل أسعار البيع والتكلفة وتوزيع كميات المستودعات',
    descEn: 'Allow editing product prices, details, and warehouse stock',
    icon: Edit
  },
  {
    key: 'canDelete',
    category: 'actions',
    labelAr: 'صلاحية الحذف (أصناف / فواتير / سجلات)',
    labelEn: 'Delete Records & Invoices',
    descAr: 'السماح بحذف الأصناف أو الفواتير أو السجلات المالية من النظام',
    descEn: 'Allow deleting products, invoices, customers, or expenses',
    icon: Trash2
  },
  {
    key: 'canDiscountPOS',
    category: 'actions',
    labelAr: 'منح خصومات في شاشة نقطة البيع',
    labelEn: 'Apply Discounts in POS',
    descAr: 'السماح للكاشير بإضافة خصم مالي على الأصناف داخل سلة المبيعات',
    descEn: 'Allow applying item discounts inside the POS cart',
    icon: ShoppingCart
  },
  {
    key: 'canEditPricePOS',
    category: 'actions',
    labelAr: 'تغيير سعر البيع المباشر في الكاشير',
    labelEn: 'Override Sale Price in POS',
    descAr: 'السماح بتعديل سعر بيع الصنف يدوياً أثناء إصدار الفاتورة',
    descEn: 'Allow changing unit sale price during checkout',
    icon: SlidersHorizontal
  },
  {
    key: 'canExportData',
    category: 'actions',
    labelAr: 'تصدير البيانات والتقارير (Excel / PDF / DB)',
    labelEn: 'Export Data & Reports',
    descAr: 'السماح بتحميل ملفات إكسل ونسخ قواعد البيانات',
    descEn: 'Allow exporting spreadsheets, PDFs, and database backups',
    icon: BarChart3
  }
];

export const UsersPage: React.FC = () => {
  const {
    user: currentUser,
    users,
    addUser,
    updateUser,
    deleteUser
  } = useAuth();
  const { tr, showToast, requestConfirm } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admin' | 'cashier'>('all');

  // Create / Edit User Modal State
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Dedicated Permissions Modal State (for quick permission editing on any non-admin user)
  const [permissionsModalUser, setPermissionsModalUser] = useState<User | null>(null);
  const [tempPermissions, setTempPermissions] = useState<UserPermissions>({
    ...DEFAULT_CASHIER_PERMISSIONS
  });

  // Dedicated Quick Password Change Modal State
  const [passwordModalUser, setPasswordModalUser] = useState<User | null>(null);
  const [quickNewPassword, setQuickNewPassword] = useState('');
  const [showQuickPassword, setShowQuickPassword] = useState(false);

  // Form fields for Add/Edit User
  const [formData, setFormData] = useState<{
    name: string;
    username: string;
    password: string;
    role: UserRole;
    jobTitle: string;
    phone: string;
    isActive: boolean;
    permissions: UserPermissions;
  }>({
    name: '',
    username: '',
    password: '',
    role: 'cashier',
    jobTitle: '',
    phone: '',
    isActive: true,
    permissions: { ...DEFAULT_CASHIER_PERMISSIONS }
  });

  const [showPassword, setShowPassword] = useState(false);

  const screenPermissionsList = useMemo(
    () => PERMISSIONS_CATALOG.filter(p => p.category === 'screens'),
    []
  );
  const actionPermissionsList = useMemo(
    () => PERMISSIONS_CATALOG.filter(p => p.category === 'actions'),
    []
  );

  const isSuperAdminLoggedIn = currentUser?.username?.toLowerCase() === 'admin';

  // Hide the primary 'admin' account from all other users; only 'admin' himself can see/edit it
  const visibleUsers = useMemo(() => {
    if (isSuperAdminLoggedIn) return users;
    return users.filter(u => u.username.toLowerCase() !== 'admin');
  }, [users, isSuperAdminLoggedIn]);

  // Filtered users
  const filteredUsers = useMemo(() => {
    return visibleUsers.filter(u => {
      const matchesRole = roleFilter === 'all' || u.role === roleFilter;
      if (!matchesRole) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        u.name.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        (u.jobTitle || '').toLowerCase().includes(q) ||
        (u.phone || '').includes(q)
      );
    });
  }, [visibleUsers, roleFilter, searchQuery]);

  // Stats
  const stats = useMemo(() => {
    const total = visibleUsers.length;
    const admins = visibleUsers.filter(u => u.role === 'admin').length;
    const staff = visibleUsers.filter(u => u.role !== 'admin').length;
    const active = visibleUsers.filter(u => u.isActive !== false).length;
    return { total, admins, staff, active };
  }, [visibleUsers]);

  const countEnabledPermissions = (u: User): { enabled: number; total: number } => {
    const eff = getEffectivePermissions(u);
    const keys = Object.keys(DEFAULT_ADMIN_PERMISSIONS) as (keyof UserPermissions)[];
    const enabled = keys.filter(k => !!eff[k]).length;
    return { enabled, total: keys.length };
  };

  // Preset generators for non-admin roles
  const applyPermissionPreset = (
    preset: 'cashier_pos' | 'warehouse_purchases' | 'accountant' | 'supervisor' | 'all' | 'minimal',
    targetSetter: (perms: UserPermissions) => void
  ) => {
    switch (preset) {
      case 'cashier_pos':
        targetSetter({
          viewDashboard: true,
          accessPOS: true,
          viewProducts: true,
          viewPurchases: false,
          viewSalesReturns: true,
          viewPurchaseReturns: false,
          viewCustomers: true,
          viewInstallments: true,
          viewExpenses: false,
          viewReports: false,
          viewSettings: false,
          manageUsers: false,
          canAddProduct: false,
          canEditProduct: false,
          canDelete: false,
          canDiscountPOS: true,
          canEditPricePOS: false,
          canExportData: false
        });
        break;
      case 'warehouse_purchases':
        targetSetter({
          viewDashboard: true,
          accessPOS: false,
          viewProducts: true,
          viewPurchases: true,
          viewSalesReturns: false,
          viewPurchaseReturns: true,
          viewCustomers: true,
          viewInstallments: false,
          viewExpenses: false,
          viewReports: false,
          viewSettings: false,
          manageUsers: false,
          canAddProduct: true,
          canEditProduct: true,
          canDelete: false,
          canDiscountPOS: false,
          canEditPricePOS: false,
          canExportData: true
        });
        break;
      case 'accountant':
        targetSetter({
          viewDashboard: true,
          accessPOS: true,
          viewProducts: true,
          viewPurchases: true,
          viewSalesReturns: true,
          viewPurchaseReturns: true,
          viewCustomers: true,
          viewInstallments: true,
          viewExpenses: true,
          viewReports: true,
          viewSettings: false,
          manageUsers: false,
          canAddProduct: false,
          canEditProduct: false,
          canDelete: false,
          canDiscountPOS: true,
          canEditPricePOS: false,
          canExportData: true
        });
        break;
      case 'supervisor':
        targetSetter({
          viewDashboard: true,
          accessPOS: true,
          viewProducts: true,
          viewPurchases: true,
          viewSalesReturns: true,
          viewPurchaseReturns: true,
          viewCustomers: true,
          viewInstallments: true,
          viewExpenses: true,
          viewReports: true,
          viewSettings: false,
          manageUsers: false,
          canAddProduct: true,
          canEditProduct: true,
          canDelete: true,
          canDiscountPOS: true,
          canEditPricePOS: true,
          canExportData: true
        });
        break;
      case 'all':
        targetSetter({ ...DEFAULT_ADMIN_PERMISSIONS });
        break;
      case 'minimal':
        targetSetter({
          viewDashboard: false,
          accessPOS: true,
          viewProducts: false,
          viewPurchases: false,
          viewSalesReturns: false,
          viewPurchaseReturns: false,
          viewCustomers: false,
          viewInstallments: false,
          viewExpenses: false,
          viewReports: false,
          viewSettings: false,
          manageUsers: false,
          canAddProduct: false,
          canEditProduct: false,
          canDelete: false,
          canDiscountPOS: false,
          canEditPricePOS: false,
          canExportData: false
        });
        break;
    }
  };

  // Open Create User Modal
  const handleOpenCreateModal = () => {
    setEditingUser(null);
    setShowPassword(false);
    setFormData({
      name: '',
      username: '',
      password: '',
      role: 'cashier',
      jobTitle: tr('كاشير مبيعات', 'Sales Cashier'),
      phone: '',
      isActive: true,
      permissions: { ...DEFAULT_CASHIER_PERMISSIONS }
    });
    setIsUserModalOpen(true);
  };

  // Open Edit User Modal
  const handleOpenEditModal = (u: User) => {
    if (u.username.toLowerCase() === 'admin' && !isSuperAdminLoggedIn) {
      showToast(
        tr('حساب الأدمن الرئيسي خاص بالأدمن فقط ولا يمكن تعديله من حساب آخر', 'Primary Admin account can only be edited by Admin'),
        'error'
      );
      return;
    }
    setEditingUser(u);
    setShowPassword(false);
    setFormData({
      name: u.name,
      username: u.username,
      password: '',
      role: u.role,
      jobTitle: u.jobTitle || (u.role === 'admin' ? tr('مدير النظام', 'System Admin') : tr('كاشير مبيعات', 'Sales Cashier')),
      phone: u.phone || '',
      isActive: u.isActive !== false,
      permissions: getEffectivePermissions(u)
    });
    setIsUserModalOpen(true);
  };

  // Open Quick Permissions Modal
  const handleOpenPermissionsModal = (u: User) => {
    if (u.username.toLowerCase() === 'admin' && !isSuperAdminLoggedIn) {
      return;
    }
    setPermissionsModalUser(u);
    setTempPermissions(getEffectivePermissions(u));
  };

  const handleSaveQuickPermissions = () => {
    if (!permissionsModalUser) return;

    // Ensure at least one screen is accessible so the user is not locked out of all views
    const hasAnyScreen = screenPermissionsList.some(s => tempPermissions[s.key]);
    if (!hasAnyScreen) {
      showToast(
        tr('يجب تفعيل شاشة واحدة على الأقل للمستخدم ليتمكن من العمل على النظام', 'Please enable at least one screen for the user'),
        'error'
      );
      return;
    }

    const res = updateUser(permissionsModalUser.id, {
      permissions: tempPermissions
    });

    if (res.success) {
      showToast(res.message, 'success');
      setPermissionsModalUser(null);
    } else {
      showToast(res.message, 'error');
    }
  };

  // Open Quick Password Change Modal
  const handleOpenPasswordModal = (u: User) => {
    if (u.username.toLowerCase() === 'admin' && !isSuperAdminLoggedIn) {
      showToast(
        tr('حساب الأدمن الرئيسي خاص بالأدمن فقط ولا يمكن تعديله من حساب آخر', 'Primary Admin account can only be edited by Admin'),
        'error'
      );
      return;
    }
    setPasswordModalUser(u);
    setQuickNewPassword('');
    setShowQuickPassword(true);
  };

  const handleSaveQuickPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordModalUser) return;
    const cleanPw = quickNewPassword.trim();
    if (!cleanPw) {
      showToast(
        tr('يرجى كتابة كلمة المرور الجديدة أولاً', 'Please enter the new password first'),
        'error'
      );
      return;
    }

    const res = updateUser(passwordModalUser.id, {
      newPassword: cleanPw
    });

    if (res.success) {
      showToast(
        tr(
          `تم تغيير الباسورد لحساب "${passwordModalUser.name}" (@${passwordModalUser.username}) بنجاح!`,
          `Password updated for "${passwordModalUser.name}" (@${passwordModalUser.username})!`
        ),
        'success'
      );
      setPasswordModalUser(null);
      setQuickNewPassword('');
    } else {
      showToast(res.message, 'error');
    }
  };

  const handleSaveUserForm = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.username.trim()) {
      showToast(
        tr('يرجى إدخال الاسم الكامل واسم المستخدم للدخول', 'Please enter full name and username'),
        'error'
      );
      return;
    }

    if (!editingUser && !formData.password.trim()) {
      showToast(
        tr('يرجى كتابة كلمة المرور للمستخدم الجديد', 'Please enter a password for the new user'),
        'error'
      );
      return;
    }

    if (formData.role !== 'admin') {
      const hasAnyScreen = screenPermissionsList.some(s => formData.permissions[s.key]);
      if (!hasAnyScreen) {
        showToast(
          tr('يرجى منح المستخدم صلاحية الدخول لشاشة واحدة على الأقل (مثل نقطة البيع)', 'Please grant access to at least one screen (e.g. POS)'),
          'error'
        );
        return;
      }
    }

    if (editingUser) {
      const res = updateUser(editingUser.id, {
        name: formData.name,
        username: formData.username,
        newPassword: formData.password.trim() ? formData.password.trim() : undefined,
        role: formData.role,
        jobTitle: formData.jobTitle,
        phone: formData.phone,
        isActive: formData.isActive,
        permissions: formData.role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : formData.permissions
      });
      if (res.success) {
        showToast(res.message, 'success');
        setIsUserModalOpen(false);
      } else {
        showToast(res.message, 'error');
      }
    } else {
      const res = addUser({
        name: formData.name,
        username: formData.username,
        password: formData.password,
        role: formData.role,
        jobTitle: formData.jobTitle,
        phone: formData.phone,
        isActive: formData.isActive,
        permissions: formData.role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : formData.permissions
      });
      if (res.success) {
        showToast(res.message, 'success');
        setIsUserModalOpen(false);
      } else {
        showToast(res.message, 'error');
      }
    }
  };

  const handleToggleUserActive = (u: User) => {
    if (u.username.toLowerCase() === 'admin') {
      showToast(tr('لا يمكن إيقاف حساب المدير العام الرئيسي', 'Cannot deactivate primary admin account'), 'error');
      return;
    }
    if (currentUser?.id === u.id) {
      showToast(tr('لا يمكنك إيقاف حسابك الحالي أثناء تسجيل الدخول', 'You cannot deactivate your own active account'), 'error');
      return;
    }
    const nextState = u.isActive === false ? true : false;
    const res = updateUser(u.id, { isActive: nextState });
    if (res.success) {
      showToast(
        nextState
          ? tr(`تم تفعيل حساب "${u.name}" بنجاح`, `Account "${u.name}" activated`)
          : tr(`تم إيقاف حساب "${u.name}" ومنعه من الدخول مؤقتاً`, `Account "${u.name}" suspended`),
        nextState ? 'success' : 'info'
      );
    } else {
      showToast(res.message, 'error');
    }
  };

  const handleDeleteUser = (u: User) => {
    if (u.username.toLowerCase() === 'admin') {
      showToast(tr('لا يمكن حذف حساب المدير العام الأساسي', 'Cannot delete primary admin account'), 'error');
      return;
    }
    if (currentUser?.id === u.id) {
      showToast(tr('لا يمكنك حذف حسابك الشخصي الحالي', 'Cannot delete your currently logged-in account'), 'error');
      return;
    }

    requestConfirm({
      title: tr('حذف حساب المستخدم', 'Delete User Account'),
      message: tr(
        `هل أنت متأكد من حذف حساب المستخدم "${u.name}" (@${u.username}) نهائياً؟ لن يتمكن من تسجيل الدخول للنظام بعد الحذف.`,
        `Are you sure you want to permanently delete user "${u.name}" (@${u.username})?`
      ),
      confirmText: tr('نعم، حذف المستخدم', 'Yes, Delete User'),
      isDestructive: true,
      onConfirm: () => {
        const res = deleteUser(u.id);
        if (res.success) {
          showToast(res.message, 'info');
        } else {
          showToast(res.message, 'error');
        }
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Primary Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-800 flex items-center gap-2.5">
            <ShieldCheck className="w-7 h-7 text-blue-600" />
            <span>{tr('إدارة المستخدمين والصلاحيات', 'Users & Permissions Management')}</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            {tr(
              'تسجيل حسابات الموظفين والكاشير وتخصيص صلاحيات الشاشات والعمليات لأي مستخدم غير الأدمن',
              'Register staff accounts, set login passwords, and configure granular screen & action permissions for any non-admin user'
            )}
          </p>
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="neu-button-primary px-5 py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-md cursor-pointer whitespace-nowrap shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>{tr('تسجيل مستخدم جديد', 'Register New User')}</span>
        </button>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="neu-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              {tr('إجمالي المستخدمين', 'Total Users')}
            </p>
            <p className="text-2xl font-black text-slate-800 mt-1 font-mono tabular-nums">
              {stats.total}
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-blue-100/80 text-blue-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              {tr('حسابات المديرين (Admin)', 'System Admins')}
            </p>
            <p className="text-2xl font-black text-indigo-700 mt-1 font-mono tabular-nums">
              {stats.admins}
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-indigo-100/80 text-indigo-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              {tr('مستخدمون بصلاحيات مخصصة', 'Custom Permission Staff')}
            </p>
            <p className="text-2xl font-black text-emerald-700 mt-1 font-mono tabular-nums">
              {stats.staff}
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-emerald-100/80 text-emerald-600 flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
        </div>

        <div className="neu-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              {tr('الحسابات النشطة حالياً', 'Active Accounts')}
            </p>
            <p className="text-2xl font-black text-teal-700 mt-1 font-mono tabular-nums">
              {stats.active}
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-teal-100/80 text-teal-600 flex items-center justify-center">
            <Unlock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="neu-card rounded-3xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute top-3.5 right-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={tr(
              'بحث بالاسم، اسم المستخدم (@username)، المسمى الوظيفي أو رقم الهاتف...',
              'Search by name, @username, job title, or phone...'
            )}
            className="w-full pr-10 pl-4 py-2.5 rounded-2xl neu-inset text-xs font-semibold text-slate-700 outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-2xl neu-inset shrink-0">
          <button
            type="button"
            onClick={() => setRoleFilter('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              roleFilter === 'all'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('الكل', 'All')} ({visibleUsers.length})
          </button>
          <button
            type="button"
            onClick={() => setRoleFilter('admin')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              roleFilter === 'admin'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('المديرون (Admin)', 'Admins')} ({stats.admins})
          </button>
          <button
            type="button"
            onClick={() => setRoleFilter('cashier')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              roleFilter === 'cashier'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('الموظفون (غير الأدمن)', 'Non-Admin Staff')} ({stats.staff})
          </button>
        </div>
      </div>

      {/* Users Directory Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredUsers.map(u => {
          const isPrimaryAdmin = u.username.toLowerCase() === 'admin';
          const isSelf = currentUser?.id === u.id;
          const permSummary = countEnabledPermissions(u);
          const effPerms = getEffectivePermissions(u);

          // Sample top enabled screens to display cleanly as unboxed text
          const enabledScreenNames = screenPermissionsList
            .filter(s => effPerms[s.key])
            .map(s => tr(s.labelAr.replace('شاشة ', ''), s.labelEn));

          return (
            <div
              key={u.id}
              className={`neu-card rounded-3xl p-5 flex flex-col justify-between gap-4 border transition-all ${
                u.isActive === false
                  ? 'opacity-70 border-red-200/70'
                  : u.role === 'admin'
                  ? 'border-blue-200/70'
                  : 'border-white/70'
              }`}
            >
              {/* Top Row: User Identity + Role & Status */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white text-base font-black shadow-md shrink-0 ${
                      u.isActive === false
                        ? 'bg-slate-400'
                        : u.role === 'admin'
                        ? 'bg-gradient-to-tr from-blue-600 to-indigo-600'
                        : 'bg-gradient-to-tr from-emerald-600 to-teal-600'
                    }`}
                  >
                    {u.name.charAt(0)}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-black text-slate-800 truncate">{u.name}</h3>
                      {isSelf && (
                        <span className="text-[11px] font-bold text-blue-600">
                          · {tr('حسابك الحالي', 'You')}
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-500 flex items-center gap-2 flex-wrap mt-0.5">
                      <span className="font-mono font-bold text-slate-600">@{u.username}</span>
                      <span>·</span>
                      <span className="font-semibold text-slate-600">
                        {u.jobTitle || (u.role === 'admin' ? tr('مدير النظام', 'System Admin') : tr('كاشير / موظف', 'Staff / Cashier'))}
                      </span>
                      {u.phone && (
                        <>
                          <span>·</span>
                          <span className="font-mono tabular-nums text-slate-500">{u.phone}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Role & Active Status Indicator */}
                <div className="text-left shrink-0 flex flex-col items-end gap-1">
                  <span
                    className={`text-xs font-extrabold flex items-center gap-1 ${
                      u.role === 'admin' ? 'text-blue-700' : 'text-emerald-700'
                    }`}
                  >
                    {u.role === 'admin' ? (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{tr('مدير كامل الصلاحيات', 'Full Admin')}</span>
                      </>
                    ) : (
                      <>
                        <Shield className="w-3.5 h-3.5" />
                        <span>{tr('صلاحيات مخصصة', 'Custom Role')}</span>
                      </>
                    )}
                  </span>

                  <span
                    className={`text-[11px] font-bold ${
                      u.isActive === false ? 'text-red-600' : 'text-slate-500'
                    }`}
                  >
                    {u.isActive === false
                      ? tr('الحساب موقوف مؤقتاً', 'Account Suspended')
                      : tr('الحساب نشط', 'Active Account')}
                  </span>
                </div>
              </div>

              {/* Middle Row: Permissions Summary */}
              <div className="p-3.5 rounded-2xl neu-inset space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700">
                    {tr('نطاق الصلاحيات الممنوحة:', 'Granted Permissions Scope:')}
                  </span>
                  <span className="font-mono font-black text-blue-700 tabular-nums">
                    {permSummary.enabled} / {permSummary.total}{' '}
                    {tr('صلاحية مفعلة', 'enabled')}
                  </span>
                </div>

                {u.role === 'admin' ? (
                  <p className="text-[11px] text-slate-500 font-medium">
                    {tr(
                      'يمتلك صلاحية الوصول الكامل لجميع شاشات النظام والتقارير والإعدادات والعمليات الحساسة.',
                      'Has unrestricted access to all system screens, financial reports, settings, and administrative actions.'
                    )}
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    <p className="text-[11px] text-slate-600 font-medium leading-relaxed line-clamp-2">
                      <span className="font-bold text-slate-700">
                        {tr('الشاشات المتاحة: ', 'Allowed Screens: ')}
                      </span>
                      {enabledScreenNames.length > 0
                        ? enabledScreenNames.join(' · ')
                        : tr('لا توجد شاشات مفعلة', 'No screens enabled')}
                    </p>
                    <div className="flex items-center gap-3 flex-wrap text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                      <span className={effPerms.canDelete ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                        {effPerms.canDelete ? '✓' : '✕'} {tr('الحذف', 'Delete')}
                      </span>
                      <span>·</span>
                      <span className={effPerms.viewReports ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                        {effPerms.viewReports ? '✓' : '✕'} {tr('التقارير والأرباح', 'Reports')}
                      </span>
                      <span>·</span>
                      <span className={effPerms.canAddProduct ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                        {effPerms.canAddProduct ? '✓' : '✕'} {tr('إضافة أصناف', 'Add Items')}
                      </span>
                      <span>·</span>
                      <span className={effPerms.canDiscountPOS ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                        {effPerms.canDiscountPOS ? '✓' : '✕'} {tr('خصومات الكاشير', 'POS Discount')}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Actions Bar */}
              <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                <div className="flex items-center gap-2 flex-wrap">
                  {u.role !== 'admin' && (
                    <button
                      type="button"
                      onClick={() => handleOpenPermissionsModal(u)}
                      className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>{tr('تخصيص الصلاحيات', 'Customize Permissions')}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleOpenPasswordModal(u)}
                    className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>{tr('تغيير الباسورد', 'Change Password')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenEditModal(u)}
                    className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 hover:text-blue-600 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span>{tr('تعديل البيانات', 'Edit Info')}</span>
                  </button>
                </div>

                {!isPrimaryAdmin && (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleToggleUserActive(u)}
                      title={
                        u.isActive === false
                          ? tr('تفعيل الحساب', 'Activate Account')
                          : tr('إيقاف الحساب مؤقتاً', 'Suspend Account')
                      }
                      className={`neu-button p-2 rounded-xl text-xs font-bold cursor-pointer ${
                        u.isActive === false
                          ? 'text-emerald-600 hover:text-emerald-700'
                          : 'text-amber-600 hover:text-amber-700'
                      }`}
                    >
                      {u.isActive === false ? (
                        <Unlock className="w-4 h-4" />
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteUser(u)}
                      disabled={isSelf}
                      title={tr('حذف المستخدم', 'Delete User')}
                      className="neu-button p-2 rounded-xl text-red-500 hover:text-red-700 disabled:opacity-40 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* =====================================================================
          MODAL 1: CREATE / EDIT USER & FULL PERMISSIONS MATRIX
         ===================================================================== */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col border border-white/80 shadow-2xl overflow-hidden my-auto">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200/70 flex items-center justify-between bg-white/40 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm">
                  {editingUser ? <Edit className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                </div>
                <div>
                  <h2 className="text-base font-black text-slate-800">
                    {editingUser
                      ? tr(`تعديل بيانات وصلاحيات: ${editingUser.name}`, `Edit User & Permissions: ${editingUser.name}`)
                      : tr('تسجيل مستخدم جديد وتحديد صلاحياته', 'Register New User & Configure Permissions')}
                  </h2>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {tr(
                      'حدد اسم المستخدم وكلمة المرور ونوع الحساب والصلاحيات المسموحة له بدقة',
                      'Set username, login password, role type, and granular access permissions'
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsUserModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSaveUserForm} className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Section 1: Basic Account Credentials */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {tr('الاسم الكامل للموظف / المستخدم *', 'Full Name *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder={tr('مثال: محمد حسن (كاشير مسائي)', 'e.g. Mohamed Hassan')}
                    className="w-full px-3.5 py-2.5 rounded-xl neu-inset text-xs font-bold text-slate-800 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {tr('اسم المستخدم للدخول (Username) *', 'Login Username *')}
                  </label>
                  <input
                    type="text"
                    required
                    disabled={editingUser?.username.toLowerCase() === 'admin'}
                    value={formData.username}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        username: e.target.value.replace(/\s+/g, '').toLowerCase()
                      })
                    }
                    placeholder={tr('مثال: mohamed', 'e.g. mohamed')}
                    className="w-full px-3.5 py-2.5 rounded-xl neu-inset text-xs font-mono font-bold text-slate-800 outline-none disabled:opacity-60"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                    <span>
                      {editingUser
                        ? tr('كلمة المرور الجديدة (اتركها فارغة لعدم التغيير)', 'New Password (leave blank to keep)')
                        : tr('كلمة المرور للدخول (Password) *', 'Login Password *')}
                    </span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      dir="ltr"
                      lang="en"
                      inputMode="text"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      required={!editingUser}
                      value={formData.password}
                      onKeyDown={e =>
                        handleEnglishPasswordKeyDown(e, formData.password, nextVal =>
                          setFormData({ ...formData, password: nextVal })
                        )
                      }
                      onChange={e =>
                        setFormData({
                          ...formData,
                          password: normalizeEnglishPasswordInput(e.target.value)
                        })
                      }
                      placeholder={
                        editingUser
                          ? tr('اكتب باسورد جديد لتغييره...', 'Enter new password to change...')
                          : tr('اكتب كلمة المرور...', 'Enter password...')
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl neu-inset text-xs font-mono font-bold text-slate-800 outline-none text-left"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute top-2.5 left-3 text-slate-400 hover:text-blue-600 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1">
                    <Briefcase className="w-3.5 h-3.5 text-blue-600" />
                    <span>{tr('المسمى الوظيفي', 'Job Title')}</span>
                  </label>
                  <input
                    type="text"
                    value={formData.jobTitle}
                    onChange={e => setFormData({ ...formData, jobTitle: e.target.value })}
                    placeholder={tr('مثال: كاشير مبيعات / محاسب / أمين مخزن', 'e.g. Sales Cashier / Accountant')}
                    className="w-full px-3.5 py-2.5 rounded-xl neu-inset text-xs font-semibold text-slate-800 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-blue-600" />
                    <span>{tr('رقم الهاتف', 'Phone Number')}</span>
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="010xxxxxxxx"
                    className="w-full px-3.5 py-2.5 rounded-xl neu-inset text-xs font-mono tabular-nums text-slate-800 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {tr('حالة الحساب', 'Account Status')}
                  </label>
                  <button
                    type="button"
                    disabled={editingUser?.username.toLowerCase() === 'admin'}
                    onClick={() => setFormData({ ...formData, isActive: !formData.isActive })}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center justify-between border transition-all cursor-pointer ${
                      formData.isActive
                        ? 'bg-emerald-50/80 border-emerald-300 text-emerald-800'
                        : 'bg-red-50/80 border-red-300 text-red-700'
                    }`}
                  >
                    <span>
                      {formData.isActive
                        ? tr('حساب نشط (مسموح له بالدخول)', 'Active (Allowed to sign in)')
                        : tr('حساب موقوف (ممنوع من الدخول)', 'Suspended (Sign-in blocked)')}
                    </span>
                    {formData.isActive ? <Check className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Section 2: Role Type Selector (Admin vs Non-Admin Custom Permissions) */}
              <div className="p-4 rounded-2xl neu-inset space-y-3">
                <label className="block text-xs font-black text-slate-800">
                  {tr('نوع الحساب ومستوى الصلاحية الأساسي:', 'Account Role & Authority Level:')}
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({
                        ...formData,
                        role: 'cashier',
                        jobTitle:
                          formData.jobTitle === tr('مدير النظام', 'System Admin')
                            ? tr('كاشير مبيعات', 'Sales Cashier')
                            : formData.jobTitle
                      })
                    }
                    disabled={editingUser?.username.toLowerCase() === 'admin'}
                    className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-3 ${
                      formData.role === 'cashier'
                        ? 'bg-emerald-50/90 border-emerald-400 shadow-sm'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        formData.role === 'cashier'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-800">
                        {tr('مستخدم بصلاحيات مخصصة (غير أدمن)', 'Non-Admin User (Custom Permissions)')}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {tr(
                          'كاشير، بائع، محاسب، أو أمين مخزن — يمكنك تحديد الشاشات والعمليات المسموحة له بالأسفل',
                          'Cashier, salesperson, accountant, or warehouse clerk — customize exact allowed screens & actions below'
                        )}
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setFormData({
                        ...formData,
                        role: 'admin',
                        permissions: { ...DEFAULT_ADMIN_PERMISSIONS }
                      })
                    }
                    className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-3 ${
                      formData.role === 'admin'
                        ? 'bg-blue-50/90 border-blue-400 shadow-sm'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        formData.role === 'admin'
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-800">
                        {tr('مدير النظام (Admin - كامل الصلاحيات)', 'System Administrator (Full Access)')}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {tr(
                          'صلاحية كاملة لفتح كافة الشاشات، التقارير، الإعدادات، الحذف وإدارة المستخدمين',
                          'Full access to all screens, reports, settings, deletion, and user management'
                        )}
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Section 3: Granular Permissions Matrix (Shown when role !== 'admin') */}
              {formData.role !== 'admin' ? (
                <div className="space-y-5">
                  {/* Quick Role Presets Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
                    <div>
                      <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                        <KeyRound className="w-4 h-4 text-blue-600" />
                        <span>
                          {tr('تخصيص صلاحيات المستخدم (اختر قالب جاهز أو خصص يدوياً):', 'Customize User Permissions (Pick a preset or toggle manually):')}
                        </span>
                      </h3>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('cashier_pos', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms, jobTitle: tr('كاشير مبيعات', 'Sales Cashier') }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer whitespace-nowrap"
                      >
                        {tr('قالب: كاشير مبيعات فقط', 'Preset: POS Cashier')}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('warehouse_purchases', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms, jobTitle: tr('أمين مخزن ومشتريات', 'Inventory & Purchases') }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer whitespace-nowrap"
                      >
                        {tr('قالب: أمين مخزن ومشتريات', 'Preset: Warehouse')}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('accountant', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms, jobTitle: tr('محاسب مالي', 'Accountant') }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer whitespace-nowrap"
                      >
                        {tr('قالب: محاسب وتقارير', 'Preset: Accountant')}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('supervisor', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms, jobTitle: tr('مشرف مبيعات وفرع', 'Branch Supervisor') }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer whitespace-nowrap"
                      >
                        {tr('قالب: مشرف فرع', 'Preset: Supervisor')}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('all', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-emerald-700 cursor-pointer whitespace-nowrap"
                      >
                        {tr('تحديد الكل', 'Select All')}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          applyPermissionPreset('minimal', perms =>
                            setFormData(prev => ({ ...prev, permissions: perms }))
                          )
                        }
                        className="neu-button px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-red-600 cursor-pointer whitespace-nowrap"
                      >
                        {tr('الكاشير فقط', 'POS Only')}
                      </button>
                    </div>
                  </div>

                  {/* Group A: Screen Access Permissions */}
                  <div>
                    <h4 className="text-xs font-black text-blue-700 mb-2.5">
                      {tr('1. صلاحيات فتح الشاشات والأقسام في القائمة الجانبية:', '1. Allowed Screens & Sidebar Modules:')}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                      {screenPermissionsList.map(item => {
                        const Icon = item.icon;
                        const checked = !!formData.permissions[item.key];
                        return (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() =>
                              setFormData(prev => ({
                                ...prev,
                                permissions: {
                                  ...prev.permissions,
                                  [item.key]: !checked
                                }
                              }))
                            }
                            className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                              checked
                                ? 'bg-blue-50/90 border-blue-400 text-slate-900 shadow-sm'
                                : 'bg-white/50 border-slate-200/80 text-slate-500 hover:bg-white'
                            }`}
                          >
                            <div
                              className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                                checked ? 'bg-blue-600 text-white' : 'bg-slate-200 text-transparent'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-bold flex items-center gap-1.5">
                                <Icon className="w-3.5 h-3.5 shrink-0 text-blue-600" />
                                <span className="truncate">{tr(item.labelAr, item.labelEn)}</span>
                              </div>
                              <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                                {tr(item.descAr, item.descEn)}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Group B: Action & Operational Permissions */}
                  <div>
                    <h4 className="text-xs font-black text-emerald-700 mb-2.5">
                      {tr('2. صلاحيات العمليات الحساسة والإجراءات داخل الشاشات:', '2. Operational Actions & Sensitive Permissions:')}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                      {actionPermissionsList.map(item => {
                        const Icon = item.icon;
                        const checked = !!formData.permissions[item.key];
                        return (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() =>
                              setFormData(prev => ({
                                ...prev,
                                permissions: {
                                  ...prev.permissions,
                                  [item.key]: !checked
                                }
                              }))
                            }
                            className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                              checked
                                ? 'bg-emerald-50/90 border-emerald-400 text-slate-900 shadow-sm'
                                : 'bg-white/50 border-slate-200/80 text-slate-500 hover:bg-white'
                            }`}
                          >
                            <div
                              className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                                checked ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-transparent'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-bold flex items-center gap-1.5">
                                <Icon className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                                <span className="truncate">{tr(item.labelAr, item.labelEn)}</span>
                              </div>
                              <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                                {tr(item.descAr, item.descEn)}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 text-xs text-blue-800 font-bold flex items-center gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
                  <span>
                    {tr(
                      'هذا الحساب من نوع (مدير النظام Admin) ولذلك يتمتع تلقائياً بكافة صلاحيات الشاشات والتقارير والإعدادات والحذف.',
                      'This account is set as System Administrator (Admin) and automatically holds all screen and operational permissions.'
                    )}
                  </span>
                </div>
              )}

              {/* Modal Footer */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="neu-button px-5 py-2.5 rounded-xl text-xs font-bold text-slate-600 cursor-pointer"
                >
                  {tr('إلغاء', 'Cancel')}
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>
                    {editingUser
                      ? tr('حفظ التعديلات والصلاحيات', 'Save Changes & Permissions')
                      : tr('تسجيل المستخدم وحفظ الصلاحيات', 'Register User & Save Permissions')}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL 2: QUICK PERMISSIONS CUSTOMIZER FOR NON-ADMIN USER
         ===================================================================== */}
      {permissionsModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-white/80 shadow-2xl overflow-hidden my-auto">
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-200/70 flex items-center justify-between bg-white/40 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center font-black">
                  {permissionsModalUser.name.charAt(0)}
                </div>
                <div>
                  <h2 className="text-base font-black text-slate-800">
                    {tr(
                      `تخصيص صلاحيات المستخدم: ${permissionsModalUser.name} (@${permissionsModalUser.username})`,
                      `Customize Permissions: ${permissionsModalUser.name} (@${permissionsModalUser.username})`
                    )}
                  </h2>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {tr(
                      'قم بتفعيل أو إلغاء الشاشات والعمليات المسموحة لهذا المستخدم وستُطبق فوراً',
                      'Toggle allowed screens and actions for this user — changes take effect immediately'
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPermissionsModalUser(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* Quick Presets */}
              <div className="flex items-center justify-between flex-wrap gap-2 p-3 rounded-2xl neu-inset">
                <span className="text-xs font-bold text-slate-700">
                  {tr('قوالب الصلاحيات السريعة:', 'Quick Permission Presets:')}
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('cashier_pos', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer"
                  >
                    {tr('كاشير مبيعات', 'POS Cashier')}
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('warehouse_purchases', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer"
                  >
                    {tr('أمين مخزن ومشتريات', 'Warehouse & Purchases')}
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('accountant', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer"
                  >
                    {tr('محاسب وتقارير', 'Accountant')}
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('supervisor', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 cursor-pointer"
                  >
                    {tr('مشرف فرع', 'Supervisor')}
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('all', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-emerald-700 flex items-center gap-1 cursor-pointer"
                  >
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>{tr('تفعيل الكل', 'Enable All')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPermissionPreset('minimal', setTempPermissions)}
                    className="neu-button px-3 py-1.5 rounded-xl text-[11px] font-bold text-red-600 flex items-center gap-1 cursor-pointer"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>{tr('الكاشير فقط', 'POS Only')}</span>
                  </button>
                </div>
              </div>

              {/* Screens Grid */}
              <div>
                <h4 className="text-xs font-black text-blue-700 mb-2.5">
                  {tr('أولاً: الشاشات المسموح للمستخدم بفتحها:', '1. Allowed Screens & Modules:')}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {screenPermissionsList.map(item => {
                    const Icon = item.icon;
                    const checked = !!tempPermissions[item.key];
                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() =>
                          setTempPermissions(prev => ({
                            ...prev,
                            [item.key]: !checked
                          }))
                        }
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                          checked
                            ? 'bg-blue-50/90 border-blue-400 text-slate-900 shadow-sm'
                            : 'bg-white/50 border-slate-200/80 text-slate-500 hover:bg-white'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                            checked ? 'bg-blue-600 text-white' : 'bg-slate-200 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold flex items-center gap-1.5">
                            <Icon className="w-3.5 h-3.5 shrink-0 text-blue-600" />
                            <span className="truncate">{tr(item.labelAr, item.labelEn)}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                            {tr(item.descAr, item.descEn)}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Actions Grid */}
              <div>
                <h4 className="text-xs font-black text-emerald-700 mb-2.5">
                  {tr('ثانياً: صلاحيات الإجراءات والعمليات الحساسة:', '2. Operational Actions & Permissions:')}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {actionPermissionsList.map(item => {
                    const Icon = item.icon;
                    const checked = !!tempPermissions[item.key];
                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() =>
                          setTempPermissions(prev => ({
                            ...prev,
                            [item.key]: !checked
                          }))
                        }
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                          checked
                            ? 'bg-emerald-50/90 border-emerald-400 text-slate-900 shadow-sm'
                            : 'bg-white/50 border-slate-200/80 text-slate-500 hover:bg-white'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                            checked ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold flex items-center gap-1.5">
                            <Icon className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                            <span className="truncate">{tr(item.labelAr, item.labelEn)}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                            {tr(item.descAr, item.descEn)}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-200/70 bg-white/40 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setPermissionsModalUser(null)}
                className="neu-button px-5 py-2.5 rounded-xl text-xs font-bold text-slate-600 cursor-pointer"
              >
                {tr('إلغاء', 'Cancel')}
              </button>
              <button
                type="button"
                onClick={handleSaveQuickPermissions}
                className="neu-button-primary px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{tr('حفظ وتطبيق الصلاحيات', 'Save & Apply Permissions')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL 3: QUICK CHANGE PASSWORD MODAL
         ===================================================================== */}
      {passwordModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="neu-card rounded-3xl w-full max-w-md flex flex-col border border-white/80 shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200/70 flex items-center justify-between bg-white/40">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-slate-800">
                    {tr(`تغيير الباسورد: ${passwordModalUser.name}`, `Change Password: ${passwordModalUser.name}`)}
                  </h2>
                  <p className="text-[11px] text-slate-500 font-mono font-bold">
                    @{passwordModalUser.username}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPasswordModalUser(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickPassword} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  {tr('كلمة المرور الجديدة للدخول *', 'New Login Password *')}
                </label>
                <div className="relative">
                  <input
                    type={showQuickPassword ? 'text' : 'password'}
                    dir="ltr"
                    lang="en"
                    inputMode="text"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    required
                    autoFocus
                    value={quickNewPassword}
                    onKeyDown={e =>
                      handleEnglishPasswordKeyDown(e, quickNewPassword, nextVal =>
                        setQuickNewPassword(nextVal)
                      )
                    }
                    onChange={e => setQuickNewPassword(normalizeEnglishPasswordInput(e.target.value))}
                    placeholder={tr('اكتب كلمة المرور الجديدة هنا...', 'Type new password here...')}
                    className="w-full px-4 py-3 rounded-xl neu-inset text-sm font-mono font-bold text-slate-800 outline-none text-left"
                  />
                  <button
                    type="button"
                    onClick={() => setShowQuickPassword(!showQuickPassword)}
                    className="absolute top-3 left-3 text-slate-400 hover:text-indigo-600 cursor-pointer"
                  >
                    {showQuickPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 font-medium">
                  {tr(
                    'سيتم تفعيل الباسورد الجديد فوراً في شاشة تسجيل الدخول وعلى جميع الأجهزة المتصلة.',
                    'The new password will take effect immediately on the login screen and across all connected devices.'
                  )}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200/70 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setPasswordModalUser(null)}
                  className="neu-button px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 cursor-pointer"
                >
                  {tr('إلغاء', 'Cancel')}
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{tr('حفظ الباسورد الجديد', 'Save New Password')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
