/**
 * @file components/InstallmentReminderModal.tsx
 * نافذة إرسال تذكير بميعاد القسط (واتساب / رسالة نصية) وسداد الأقساط
 * Installment Reminder & Payment Modal with Automated Templates & WhatsApp Direct Link
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  MessageCircle,
  Copy,
  Check,
  DollarSign,
  Calendar,
  AlertTriangle,
  Clock,
  Sparkles,
  Smartphone,
  Send,
  RotateCcw
} from 'lucide-react';
import { InstallmentPlan } from '../types';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import {
  getDaysDifference,
  generateReminderMessage,
  createWhatsAppUrl,
  ReminderTemplateType,
  formatWhatsAppPhone,
  openSmartWhatsAppModal
} from '../utils/installmentAlerts';

interface InstallmentReminderModalProps {
  plan: InstallmentPlan;
  selectedInstallmentId?: string;
  onClose: () => void;
  onSuccess: () => void;
}

export const InstallmentReminderModal: React.FC<InstallmentReminderModalProps> = ({
  plan,
  selectedInstallmentId,
  onClose,
  onSuccess
}) => {
  const { settings, formatCurrency, showToast } = useApp();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'reminder' | 'payment'>('reminder');

  // Selected installment
  const targetInst = plan.installments.find(i => i.id === selectedInstallmentId) || plan.installments[0];
  const daysDiff = targetInst ? getDaysDifference(targetInst.dueDate) : 0;

  // Initial template type based on urgency
  const initialTemplate: ReminderTemplateType =
    daysDiff < 0 ? 'overdue' : daysDiff === 0 ? 'due_today' : 'gentle';

  const [templateType, setTemplateType] = useState<ReminderTemplateType>(initialTemplate);
  const [customPhone, setCustomPhone] = useState(plan.customerPhone);
  const [messageText, setMessageText] = useState('');

  // Payment form state
  const [payAmount, setPayAmount] = useState<number>(targetInst ? targetInst.amount : 0);
  const [payNotes, setPayNotes] = useState('');

  // Update generated text whenever template changes or targetInst changes
  useEffect(() => {
    if (!targetInst) return;
    const text = generateReminderMessage({
      customerName: plan.customerName,
      installmentNumber: targetInst.installmentNumber,
      amount: targetInst.amount,
      dueDate: targetInst.dueDate,
      currencySymbol: settings.currencySymbol || 'ر.س',
      storeName: settings.storeName || 'المتجر',
      storePhone: settings.storePhone,
      daysDiff,
      templateType
    });
    setMessageText(text);
  }, [templateType, targetInst, plan, settings, daysDiff]);

  const handleResetMessage = () => {
    if (!targetInst) return;
    const text = generateReminderMessage({
      customerName: plan.customerName,
      installmentNumber: targetInst.installmentNumber,
      amount: targetInst.amount,
      dueDate: targetInst.dueDate,
      currencySymbol: settings.currencySymbol || 'ر.س',
      storeName: settings.storeName || 'المتجر',
      storePhone: settings.storePhone,
      daysDiff,
      templateType
    });
    setMessageText(text);
    showToast('تمت استعادة النص التلقائي للنموذج', 'info');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    showToast('تم نسخ نص التذكير بنجاح!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleWhatsApp = () => {
    const clean = formatWhatsAppPhone(customPhone);
    if (!clean) {
      showToast('يرجى التأكد من رقم هاتف العميل', 'error');
      return;
    }
    openSmartWhatsAppModal({
      recipientName: plan.customerName,
      phone: customPhone,
      message: messageText,
      title: 'إرسال تذكير القسط عبر واتساب',
      subtitle: `فاتورة #${plan.invoiceNumber} · القسط #${targetInst?.installmentNumber || 1}`
    });
  };

  const handleSMS = () => {
    const clean = customPhone.replace(/\D/g, '');
    const smsUrl = `sms:${clean}?body=${encodeURIComponent(messageText)}`;
    window.location.href = smsUrl;
  };

  const handleSettlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetInst) return;

    if (payAmount <= 0) {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
      return;
    }

    const success = db.payInstallmentItem(plan.id, targetInst.id, payAmount, payNotes);
    if (success) {
      showToast('تم تسجيل سداد القسط بنجاح وتحديث الرصيد!', 'success');
      onSuccess();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
      <div className="neu-card rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/60 bg-white/40">
          <div>
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>متابعة القسط والتنبيهات · {plan.customerName}</span>
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              فاتورة #{plan.invoiceNumber} · هاتف: {plan.customerPhone}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-4 flex gap-2">
          <button
            onClick={() => setActiveTab('reminder')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'reminder' ? 'neu-pressed text-emerald-600' : 'neu-button text-slate-600'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>إرسال تذكير واتساب / رسالة</span>
          </button>
          <button
            onClick={() => setActiveTab('payment')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'payment' ? 'neu-pressed text-blue-600' : 'neu-button text-slate-600'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>تسجيل سداد القسط</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'reminder' ? (
            <div className="space-y-4">
              {/* Installment Summary Banner */}
              <div
                className={`p-3.5 rounded-2xl flex items-center justify-between text-xs border ${
                  daysDiff < 0
                    ? 'bg-red-50/70 border-red-200 text-red-900'
                    : daysDiff === 0
                    ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                    : 'bg-blue-50/70 border-blue-200 text-blue-900'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">
                      قسط #{targetInst?.installmentNumber}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        daysDiff < 0
                          ? 'bg-red-200 text-red-800'
                          : daysDiff === 0
                          ? 'bg-amber-200 text-amber-800'
                          : 'bg-blue-200 text-blue-800'
                      }`}
                    >
                      {daysDiff < 0
                        ? `متأخر بـ ${Math.abs(daysDiff)} يوم`
                        : daysDiff === 0
                        ? 'مستحق اليوم'
                        : `يستحق بعد ${daysDiff} يوم`}
                    </span>
                  </div>
                  <span className="text-[11px] block mt-0.5">
                    تاريخ الاستحقاق: <strong className="font-mono">{targetInst?.dueDate}</strong>
                  </span>
                </div>
                <div className="text-left">
                  <span className="text-[10px] block opacity-80">المبلغ المطلوب:</span>
                  <span className="font-black text-base tabular-nums">
                    {formatCurrency(targetInst?.amount || 0)}
                  </span>
                </div>
              </div>

              {/* Template Selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>اختر نموذج رسالة التذكير:</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleResetMessage}
                    className="text-[10px] text-blue-600 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer"
                    title="إعادة تعيين النص الأصلي"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>إعادة ضبط النص</span>
                  </button>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setTemplateType('gentle')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      templateType === 'gentle'
                        ? 'neu-pressed text-blue-600'
                        : 'neu-button text-slate-600'
                    }`}
                  >
                    تذكير ودّي قادم
                  </button>
                  <button
                    type="button"
                    onClick={() => setTemplateType('due_today')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      templateType === 'due_today'
                        ? 'neu-pressed text-amber-600'
                        : 'neu-button text-slate-600'
                    }`}
                  >
                    مستحق اليوم
                  </button>
                  <button
                    type="button"
                    onClick={() => setTemplateType('overdue')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      templateType === 'overdue'
                        ? 'neu-pressed text-red-600'
                        : 'neu-button text-slate-600'
                    }`}
                  >
                    إشعار تأخير
                  </button>
                  <button
                    type="button"
                    onClick={() => setTemplateType('formal')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      templateType === 'formal'
                        ? 'neu-pressed text-slate-800'
                        : 'neu-button text-slate-600'
                    }`}
                  >
                    إشعار رسمي موجز
                  </button>
                </div>
              </div>

              {/* Destination Phone field */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  رقم هاتف الواتساب:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={customPhone}
                    onChange={(e) => setCustomPhone(e.target.value)}
                    dir="ltr"
                    className="neu-input w-full px-3 py-2 pl-9 rounded-xl text-xs font-mono font-bold text-slate-800"
                    placeholder="010XXXXXXXX / 2010XXXXXXXX"
                  />
                  <Smartphone className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  يتم ضبط كود الدولة تلقائياً (+20 مصر أو +966 السعودية) ونسخ الرسالة عند الإرسال.
                </span>
              </div>

              {/* Message Content */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  نص الرسالة (يمكنك التعديل عليها مباشرة قبل الإرسال):
                </label>
                <textarea
                  rows={6}
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  className="neu-input w-full p-3 text-xs text-slate-800 rounded-2xl resize-y font-medium leading-relaxed"
                  placeholder="نص رسالة التذكير..."
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={handleWhatsApp}
                  className="neu-button-emerald flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>فتح وإرسال عبر واتساب</span>
                </button>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="neu-button py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
                  <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleSMS}
                  className="neu-button py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer"
                  title="إرسال كرسالة SMS عادية"
                >
                  <Send className="w-3.5 h-3.5 text-blue-600" />
                  <span>رسالة SMS</span>
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSettlePayment} className="space-y-4">
              <div className="neu-card p-3 rounded-2xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 block">القسط المراد سداده:</span>
                  <span className="font-bold text-slate-800">
                    رقم {targetInst?.installmentNumber}
                  </span>
                </div>
                <div className="text-left">
                  <span className="text-slate-500 block">المبلغ الأصلي للقسط:</span>
                  <span className="font-bold text-emerald-600">{formatCurrency(targetInst?.amount || 0)}</span>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                  المبلغ المدفوع ({settings.currencySymbol}):
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="neu-input w-full px-4 py-2.5 rounded-xl text-sm font-bold text-slate-800 tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                  ملاحظات أو طريقة التحويل:
                </label>
                <input
                  type="text"
                  placeholder="مثال: نقداً في الفرع، تحويل بنكي على الراجحي..."
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="neu-input w-full px-4 py-2.5 rounded-xl text-xs text-slate-700"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="neu-button-emerald w-full py-2.5 rounded-xl flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>تأكيد السداد وتحديث الحساب</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
