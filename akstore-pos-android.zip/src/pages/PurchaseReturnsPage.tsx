/**
 * @file pages/PurchaseReturnsPage.tsx
 * شاشة مرتجع المشتريات وإرجاع البضائع للموردين مع الطباعة والحذف
 * Purchase Returns to Suppliers Page with Print and Delete Actions
 */

import React, { useState } from 'react';
import { Undo2, Search, Trash2, Printer, ArrowLeft, Plus } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import { PurchaseInvoice, ReturnInvoice } from '../types';
import { generateReturnInvoicePDF } from '../utils/exportUtils';
import { NumberStepperInput } from '../components/NumberStepperInput';

export const PurchaseReturnsPage: React.FC = () => {
  const { purchases, returns, formatCurrency, refreshData, showToast, settings, tr, requestConfirm } = useApp();

  const [searchPurchase, setSearchPurchase] = useState('');
  const [selectedPurchase, setSelectedPurchase] = useState<PurchaseInvoice | null>(null);
  const [returnItems, setReturnItems] = useState<{
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    refundTotal: number;
  }[]>([]);
  const [returnReason, setReturnReason] = useState('بضاعة معيبة أو منتهية الصلاحية');

  const handleSearchPurchase = () => {
    if (!searchPurchase.trim()) return;
    const found = purchases.find(p => p.invoiceNumber.toLowerCase() === searchPurchase.trim().toLowerCase());
    if (found) {
      setSelectedPurchase(found);
      setReturnItems([]);
    } else {
      showToast('لم يتم العثور على فاتورة شراء بهذا الرقم', 'error');
    }
  };

  const handleToggleReturnItem = (prodId: string, maxQty: number, cost: number, prodName: string) => {
    const existing = returnItems.find(i => i.productId === prodId);
    if (existing) {
      setReturnItems(prev => prev.filter(i => i.productId !== prodId));
    } else {
      setReturnItems(prev => [
        ...prev,
        {
          productId: prodId,
          productName: prodName,
          quantity: 1,
          price: cost,
          refundTotal: cost
        }
      ]);
    }
  };

  const totalRefund = returnItems.reduce((acc, item) => acc + item.refundTotal, 0);

  const handleConfirmReturn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPurchase || returnItems.length === 0) {
      showToast('يرجى تحديد الأصناف المراد إرجاعها', 'error');
      return;
    }

    const createdReturn = db.createReturn({
      type: 'purchase',
      originalInvoiceNumber: selectedPurchase.invoiceNumber,
      entityName: selectedPurchase.supplierName,
      items: returnItems,
      totalRefund,
      reason: returnReason
    });

    // Reduce supplier balance
    db.adjustSupplierBalance(selectedPurchase.supplierId, -totalRefund);

    showToast(`تم تسجيل مرتجع الشراء للمورد وتخفيض حسابه بمقدار ${formatCurrency(totalRefund)}!`, 'success');
    refreshData();
    setSelectedPurchase(null);
    setReturnItems([]);
    setSearchPurchase('');

    // Print voucher
    generateReturnInvoicePDF(createdReturn, settings);
  };

  const handleDeleteReturn = (id: string, num: string) => {
    requestConfirm({
      title: 'حذف سند مرتجع الشراء',
      message: `هل أنت متأكد من حذف سند مرتجع الشراء رقم: "${num}"؟`,
      confirmText: 'نعم، حذف السند',
      onConfirm: () => {
        db.deleteReturn(id);
        showToast('تم حذف سند مرتجع الشراء بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrintReturn = async (ret: ReturnInvoice) => {
    try {
      showToast(`جاري إنشاء سند مرتجع المورد #${ret.returnNumber} باللغة العربية...`, 'info');
      await generateReturnInvoicePDF(ret, settings);
      showToast(`تم تحميل سند مرتجع المورد #${ret.returnNumber} PDF بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء ملف PDF لمرتجع المورد', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="neu-card p-5 rounded-3xl">
        <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
          <Undo2 className="w-5 h-5 text-indigo-600" />
          <span>{tr('مرتجع المشتريات إلى الموردين (Purchase Return)', 'Purchase Returns to Suppliers')}</span>
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          {tr('إرجاع بضاعة تالفة أو غير مطابقة للمواصفات إلى الموردين وتخفيض مديونية المورد وطباعة السند', 'Return defective or mismatched goods to suppliers, reduce supplier balance, and print voucher')}
        </p>

        <div className="mt-4 flex gap-2 max-w-lg">
          <input
            type="text"
            value={searchPurchase}
            onChange={(e) => setSearchPurchase(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearchPurchase()}
            placeholder={tr('أدخل رقم فاتورة الشراء (مثال: PUR-202610-0001)...', 'Enter Purchase Invoice Number (e.g. PUR-202610-0001)...')}
            className="neu-input flex-1 px-4 py-2.5 rounded-xl text-xs font-mono"
          />
          <button
            type="button"
            onClick={handleSearchPurchase}
            className="neu-button-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <Search className="w-4 h-4" />
            <span>{tr('بحث', 'Search')}</span>
          </button>
        </div>
      </div>

      {/* Selected Purchase Invoice Content */}
      {selectedPurchase && (
        <div className="neu-card p-5 rounded-3xl space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-3 border-b border-white/60">
            <div>
              <span className="font-mono font-bold text-indigo-700 text-sm">
                فاتورة شراء: {selectedPurchase.invoiceNumber}
              </span>
              <span className="text-xs text-slate-500 block">
                المورد: {selectedPurchase.supplierName} · التاريخ: {new Date(selectedPurchase.date).toLocaleString('ar-SA')}
              </span>
            </div>
            <span className="font-black text-slate-800 text-sm">
              إجمالي الشراء: {formatCurrency(selectedPurchase.grandTotal)}
            </span>
          </div>

          <h4 className="text-xs font-bold text-slate-700">حدد الأصناف المراد إرجاعها للمورد:</h4>

          <div className="space-y-2">
            {selectedPurchase.items.map((item) => {
              const isSelected = returnItems.some(i => i.productId === item.productId);
              const returnItem = returnItems.find(i => i.productId === item.productId);

              return (
                <div
                  key={item.productId}
                  className={`p-3 rounded-2xl flex items-center justify-between transition-all ${
                    isSelected ? 'neu-pressed border-indigo-300' : 'neu-flat'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() =>
                        handleToggleReturnItem(
                          item.productId,
                          item.quantity,
                          item.costPrice,
                          item.productName
                        )
                      }
                      className="w-4 h-4 text-indigo-600 rounded"
                    />
                    <div>
                      <p className="font-bold text-xs text-slate-800">{item.productName}</p>
                      <span className="text-[10px] text-slate-400">
                        الكمية المشتراة: {item.quantity} · التكلفة: {formatCurrency(item.costPrice)}
                      </span>
                    </div>
                  </div>

                  {isSelected && returnItem && (
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-slate-500">الكمية المرتجعة:</span>
                        <NumberStepperInput
                          value={returnItem.quantity}
                          onChange={(val) => {
                            const safeVal = Math.min(item.quantity, Math.max(1, val));
                            setReturnItems(prev => prev.map(ri => ri.productId === item.productId ? { ...ri, quantity: safeVal, refundTotal: safeVal * item.costPrice } : ri));
                          }}
                          step={1}
                          min={1}
                          max={item.quantity}
                          fallbackOnBlur={1}
                          size="sm"
                          className="w-24"
                          inputClassName="text-center text-xs"
                        />
                      </div>
                      <span className="font-bold text-xs text-indigo-700 tabular-nums">
                        {formatCurrency(returnItem.refundTotal)}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {returnItems.length > 0 && (
            <div className="neu-pressed p-4 rounded-2xl space-y-3 mt-4">
              <div className="flex justify-between items-center text-sm font-black">
                <span>إجمالي الخصم من حساب المورد:</span>
                <span className="text-indigo-700 tabular-nums">{formatCurrency(totalRefund)}</span>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  سبب إرجاع البضاعة للمورد:
                </label>
                <input
                  type="text"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl text-xs"
                />
              </div>

              <button
                type="button"
                onClick={handleConfirmReturn}
                className="neu-button-primary w-full py-2.5 rounded-xl text-xs font-bold cursor-pointer flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>تأكيد مرتجع الشراء وطباعة السند</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Historical Purchase Returns */}
      <div className="neu-card p-5 rounded-3xl">
        <h3 className="font-bold text-slate-800 text-sm mb-3">
          سجل مرتجعات المشتريات للموردين ({returns.filter(r => r.type === 'purchase').length})
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-2">رقم المرتجع</th>
                <th className="pb-2">فاتورة الشراء</th>
                <th className="pb-2">المورد</th>
                <th className="pb-2">التاريخ</th>
                <th className="pb-2 text-left">المبلغ المخصوم</th>
                <th className="pb-2">السبب</th>
                <th className="pb-2 text-left">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {returns
                .filter(r => r.type === 'purchase')
                .map(ret => (
                  <tr key={ret.id}>
                    <td className="py-2.5 font-mono font-bold text-indigo-700">{ret.returnNumber}</td>
                    <td className="py-2.5 font-mono">{ret.originalInvoiceNumber}</td>
                    <td className="py-2.5 font-medium">{ret.entityName}</td>
                    <td className="py-2.5 tabular-nums text-slate-500">{new Date(ret.date).toLocaleDateString('ar-SA')}</td>
                    <td className="py-2.5 text-left font-bold text-emerald-600 tabular-nums">{formatCurrency(ret.totalRefund)}</td>
                    <td className="py-2.5 text-slate-500">{ret.reason}</td>
                    <td className="py-2.5 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          onClick={() => handlePrintReturn(ret)}
                          className="neu-button p-1.5 rounded-lg text-indigo-600 hover:text-indigo-700 cursor-pointer"
                          title="طباعة سند المرتجع"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteReturn(ret.id, ret.returnNumber)}
                          className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          title="حذف المرتجع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
