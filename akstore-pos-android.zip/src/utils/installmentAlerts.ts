/**
 * @file utils/installmentAlerts.ts
 * محرك التنبيهات التلقائية للأقساط ورسائل الواتساب الذكي
 * Automated Installment Notification Engine & Multi-Channel WhatsApp Messaging Utilities
 */

import { InstallmentPlan, InstallmentItem } from '../types';

export type AlertUrgency = 'overdue' | 'today' | 'upcoming';

export interface ApproachingInstallment {
  planId: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  installment: InstallmentItem;
  dueDate: string;
  amount: number;
  daysDiff: number; // Negative = overdue, 0 = today, positive = days left
  urgency: AlertUrgency;
}

export type ReminderTemplateType = 'gentle' | 'due_today' | 'overdue' | 'formal';

/**
 * تحويل الأرقام العربية الشرقية (٠١٢٣٤٥٦٧٨٩) أو الفارسية إلى أرقام إنجليزية قياسية (0123456789)
 */
export function normalizeDigits(input: string): string {
  if (!input) return '';
  return String(input)
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776));
}

/**
 * تنسيق رقم الهاتف تلقائياً ليتوافق 100% مع روابط واتساب الدولية
 * يدعم مصر (+20)، السعودية (+966)، الإمارات (+971)، الكويت (+965)، الأردن (+962)، وغيرها
 */
export function formatWhatsAppPhone(phone: string, preferredCountryCode: string = '20'): string {
  const normalized = normalizeDigits(phone || '');
  let cleaned = normalized.replace(/\D/g, '');
  if (!cleaned) return '';

  // إزالة الأصفار الدولية المزدوجة في البداية (مثل 0020 أو 00966)
  if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }

  // معالجة خطأ شائع: كتابة كود الدولة متبوعاً بصفر محلي (مثل 20010... أو 96605...)
  if (cleaned.startsWith('2001') && cleaned.length === 13) {
    return '20' + cleaned.substring(3);
  }
  if (cleaned.startsWith('96605') && cleaned.length === 13) {
    return '966' + cleaned.substring(4);
  }
  if (cleaned.startsWith('97105') && cleaned.length === 13) {
    return '971' + cleaned.substring(4);
  }

  // أرقام الموبايل المصرية (تبدأ بـ 010 أو 011 أو 012 أو 015 ومكونة من 11 رقم)
  if (
    (cleaned.startsWith('010') ||
      cleaned.startsWith('011') ||
      cleaned.startsWith('012') ||
      cleaned.startsWith('015')) &&
    cleaned.length === 11
  ) {
    return '20' + cleaned.substring(1);
  }

  // أرقام الموبايل المصرية المكتوبة بدون صفر البداية (10، 11، 12، 15 ومكونة من 10 أرقام)
  if (
    (cleaned.startsWith('10') ||
      cleaned.startsWith('11') ||
      cleaned.startsWith('12') ||
      cleaned.startsWith('15')) &&
    cleaned.length === 10
  ) {
    return '20' + cleaned;
  }

  // أرقام الجوال السعودية (تبدأ بـ 05 ومكونة من 10 أرقام)
  if (cleaned.startsWith('05') && cleaned.length === 10) {
    return '966' + cleaned.substring(1);
  }
  // أرقام الجوال السعودية بدون صفر (تبدأ بـ 5 ومكونة من 9 أرقام)
  if (cleaned.startsWith('5') && cleaned.length === 9) {
    return '966' + cleaned;
  }

  // إذا كان الرقم يحتوي بالفعل على مفتاح دولة دولي صحيح
  if (
    cleaned.length >= 11 &&
    (cleaned.startsWith('20') ||
      cleaned.startsWith('966') ||
      cleaned.startsWith('971') ||
      cleaned.startsWith('965') ||
      cleaned.startsWith('968') ||
      cleaned.startsWith('974') ||
      cleaned.startsWith('973') ||
      cleaned.startsWith('962') ||
      cleaned.startsWith('964') ||
      cleaned.startsWith('218') ||
      cleaned.startsWith('249'))
  ) {
    return cleaned;
  }

  // أي رقم يبدأ بصفر محلي (افتراضياً مصر 20 أو كود الدولة المفضل)
  if (cleaned.startsWith('0') && cleaned.length >= 9) {
    return preferredCountryCode + cleaned.substring(1);
  }

  // إذا كان الرقم من 9 أو 10 أرقام بدون كود دولة، نضيف كود الدولة الافتراضي (مصر 20)
  if (cleaned.length >= 9 && cleaned.length <= 10) {
    return preferredCountryCode + cleaned;
  }

  return cleaned;
}

/**
 * Calculates days difference between target date and today (in local timezone)
 */
export function getDaysDifference(targetDateStr: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [year, month, day] = targetDateStr.split('-').map(Number);
  const target = new Date(year, month - 1, day);
  target.setHours(0, 0, 0, 0);

  const diffTime = target.getTime() - today.getTime();
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Scans all installment plans and filters approaching, due today, or overdue installments
 */
export function getApproachingInstallments(
  plans: InstallmentPlan[],
  daysThreshold: number = 7
): ApproachingInstallment[] {
  const result: ApproachingInstallment[] = [];

  plans.forEach((plan) => {
    plan.installments.forEach((inst) => {
      if (inst.status !== 'paid') {
        const daysDiff = getDaysDifference(inst.dueDate);

        let urgency: AlertUrgency | null = null;
        if (daysDiff < 0) {
          urgency = 'overdue';
        } else if (daysDiff === 0) {
          urgency = 'today';
        } else if (daysDiff <= daysThreshold) {
          urgency = 'upcoming';
        }

        if (urgency) {
          result.push({
            planId: plan.id,
            invoiceNumber: plan.invoiceNumber,
            customerId: plan.customerId,
            customerName: plan.customerName,
            customerPhone: plan.customerPhone,
            installment: inst,
            dueDate: inst.dueDate,
            amount: inst.amount,
            daysDiff,
            urgency
          });
        }
      }
    });
  });

  // Sort: Overdue first (most overdue top), then today, then nearest upcoming
  return result.sort((a, b) => a.daysDiff - b.daysDiff);
}

/**
 * Generates ready-to-send reminder message based on urgency & template
 */
export function generateReminderMessage(params: {
  customerName: string;
  installmentNumber: number;
  amount: number;
  dueDate: string;
  currencySymbol: string;
  storeName: string;
  storePhone?: string;
  daysDiff: number;
  templateType?: ReminderTemplateType;
}): string {
  const {
    customerName,
    installmentNumber,
    amount,
    dueDate,
    currencySymbol,
    storeName,
    storePhone,
    daysDiff,
    templateType = 'gentle'
  } = params;

  const formattedAmt = Number(amount || 0).toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  });
  const phoneLine = storePhone ? `\nللتواصل والاستفسار: ${storePhone}` : '';

  if (templateType === 'overdue' || daysDiff < 0) {
    const overdueDays = Math.abs(daysDiff);
    return `السلام عليكم ورحمة الله وبركاته
عزيزنا العميل: ${customerName} المحترم

نود تذكيركم بوجود قسط مستحق السداد:
- رقم القسط: (${installmentNumber})
- المبلغ المطلوب: ${formattedAmt} ${currencySymbol}
- تاريخ الاستحقاق: ${dueDate}${overdueDays > 0 ? ` (متأخر منذ ${overdueDays} يوم)` : ''}

نرجو التكرم بسداد القسط في أقرب وقت، شاكرين حسن تعاونكم.

مع تحيات: ${storeName}${phoneLine}`;
  }

  if (templateType === 'due_today' || daysDiff === 0) {
    return `السلام عليكم ورحمة الله وبركاته
عزيزنا العميل: ${customerName} المحترم

نود تذكيركم بأن اليوم هو موعد سداد القسط:
- رقم القسط: (${installmentNumber})
- المبلغ المطلوب: ${formattedAmt} ${currencySymbol}
- تاريخ الاستحقاق: اليوم (${dueDate})

شاكرين ومقدرين التزامكم وتعاونكم الدائم.

مع تحيات: ${storeName}${phoneLine}`;
  }

  if (templateType === 'formal') {
    return `إشعار استحقاق قسط - ${storeName}
السيد/ة: ${customerName}
نلفت عنايتكم إلى استحقاق القسط رقم (${installmentNumber}) بقيمة ${formattedAmt} ${currencySymbol} بتاريخ ${dueDate}.
يرجى التنسيق لإتمام السداد في الموعد المحدد.${phoneLine}`;
  }

  // Gentle default reminder (upcoming in X days)
  const daysText =
    daysDiff === 1 ? 'غداً' : daysDiff === 2 ? 'بعد يومين' : `خلال ${daysDiff} أيام`;
  return `السلام عليكم ورحمة الله وبركاته
عزيزنا العميل: ${customerName} المحترم

تذكير ودي بقرب موعد استحقاق القسط الخاص بكم (${daysText}):
- رقم القسط: (${installmentNumber})
- المبلغ المستحق: ${formattedAmt} ${currencySymbol}
- تاريخ الاستحقاق: ${dueDate}

شاكرين لكم التزامكم وحسن تعاملكم، ويسعدنا خدمتكم دائماً.

مع تحيات: ${storeName}${phoneLine}`;
}

/**
 * رابط واتساب الرسمي العام (يعمل على الموبايل والكمبيوتر بدون مشاكل تشفير النص العربي)
 */
export function createWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatWhatsAppPhone(phone);
  const encodedText = encodeURIComponent(message || '');
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * رابط واتساب ويب المباشر للمتصفح على الكمبيوتر (يتخطى صفحة التحويل الوسيطة)
 */
export function createWhatsAppWebUrl(phone: string, message: string): string {
  const formattedPhone = formatWhatsAppPhone(phone);
  const encodedText = encodeURIComponent(message || '');
  return `https://web.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * بروتوكول تطبيق واتساب المباشر (يفتح برنامج واتساب المثبت على الويندوز أو الموبايل فوراً)
 */
export function createWhatsAppAppProtocolUrl(phone: string, message: string): string {
  const formattedPhone = formatWhatsAppPhone(phone);
  const encodedText = encodeURIComponent(message || '');
  return `whatsapp://send?phone=${formattedPhone}&text=${encodedText}`;
}

export interface WhatsAppDispatchPayload {
  customerName?: string;
  recipientName?: string;
  phone: string;
  message: string;
  title?: string;
  subtitle?: string;
}

export const WHATSAPP_DISPATCH_EVENT = 'ak_store_open_whatsapp_modal';

/**
 * فتح نافذة الإرسال الذكية للواتساب (تنسخ الرسالة تلقائياً وتتيح الفتح عبر تطبيق الويندوز أو واتساب ويب أو مسح QR بالموبايل)
 */
export function openSmartWhatsAppModal(payload: WhatsAppDispatchPayload): void {
  if (typeof window === 'undefined') return;
  try {
    if (payload.message && navigator.clipboard) {
      navigator.clipboard.writeText(payload.message).catch(() => {});
    }
  } catch {
    // Ignore clipboard error
  }
  window.dispatchEvent(
    new CustomEvent<WhatsAppDispatchPayload>(WHATSAPP_DISPATCH_EVENT, {
      detail: payload
    })
  );
}
