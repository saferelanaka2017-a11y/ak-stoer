/**
 * @file db/database.ts
 * طبقة إدارة قاعدة البيانات المحلية SQLite
 * Local Database Layer with SQLite table schemas, automatic seeding, and offline persistence
 */

import {
  Product,
  Customer,
  Supplier,
  SaleInvoice,
  PurchaseInvoice,
  ReturnInvoice,
  Expense,
  InstallmentPlan,
  StoreSettings,
  User,
  UserRole,
  UserPermissions,
  Warehouse,
  WarehouseTransfer,
  CurrencyRate
} from '../types';
import {
  initialProducts,
  initialCustomers,
  initialSuppliers,
  initialExpenses,
  initialSales,
  initialInstallmentPlans,
  initialSettings,
  initialWarehouses,
  defaultCurrencies
} from './initialData';
import { getUpdateServerUrl, syncDatabaseAndLicenseToSafeVault } from '../utils/updateManager';
import { normalizeEnglishPasswordInput } from '../utils/keyboardNormalizer';
import { normalizeLogoForPrint } from '../components/AKStoreLogo';
import {
  verifyAndHydrateLocalDb,
  persistStateToLocalIndexedDB,
  markOfflineOutboxPending,
  verifyNetworkAfterLocalDbReady,
  getLocalDbHealthStatus,
  subscribeToLocalDbHealth,
  LocalDbHealthStatus
} from './localDbEngine';

export { getLocalDbHealthStatus, subscribeToLocalDbHealth };
export type { LocalDbHealthStatus };

const DB_STORAGE_KEY = 'soft_glass_pos_db_v1';
const DB_DELETED_IDS_KEY = 'soft_glass_pos_deleted_ids_v1';
const DB_SYNC_DEVICE_ID_KEY = 'soft_glass_pos_sync_device_id_v1';
const DB_USER_MODIFIED_KEY = 'soft_glass_pos_user_modified_v1';
const DB_SYNC_EMAIL_KEY = 'soft_glass_pos_sync_email_v1';
const DB_EMAIL_SYNC_LOCKED_KEY = 'soft_glass_pos_email_sync_locked_v1';

export function normalizeSyncEmailClient(raw?: string | null): string {
  if (!raw || typeof raw !== 'string') return '';
  const cleaned = raw.trim().toLowerCase();
  if (!cleaned || cleaned.length > 160) return '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleaned)) return '';
  return cleaned;
}

export interface SyncStatusInfo {
  status: 'connected' | 'syncing' | 'offline' | 'unconfigured';
  syncEmail: string;
  emailSyncLocked: boolean;
  lastSyncAt: string | null;
  lastUpdatedByName: string;
  revision: number;
  connectedDevices: number;
}

export const DEFAULT_ADMIN_PERMISSIONS: UserPermissions = {
  viewDashboard: true,
  accessPOS: true,
  viewSalesInvoices: true,
  viewProducts: true,
  viewPurchases: true,
  viewSalesReturns: true,
  viewPurchaseReturns: true,
  viewCustomers: true,
  viewInstallments: true,
  viewExpenses: true,
  viewReports: true,
  viewSettings: true,
  manageUsers: true,
  canAddProduct: true,
  canEditProduct: true,
  canDelete: true,
  canDiscountPOS: true,
  canEditPricePOS: true,
  canExportData: true
};

export const DEFAULT_CASHIER_PERMISSIONS: UserPermissions = {
  viewDashboard: true,
  accessPOS: true,
  viewSalesInvoices: true,
  viewProducts: true,
  viewPurchases: true,
  viewSalesReturns: true,
  viewPurchaseReturns: true,
  viewCustomers: true,
  viewInstallments: true,
  viewExpenses: true,
  viewReports: false,
  viewSettings: false,
  manageUsers: false,
  canAddProduct: true,
  canEditProduct: true,
  canDelete: false,
  canDiscountPOS: true,
  canEditPricePOS: false,
  canExportData: false
};

export function getEffectivePermissions(user?: User | null): UserPermissions {
  if (!user) {
    return { ...DEFAULT_CASHIER_PERMISSIONS };
  }
  if (user.role === 'admin') {
    return { ...DEFAULT_ADMIN_PERMISSIONS };
  }
  return {
    ...DEFAULT_CASHIER_PERMISSIONS,
    ...(user.permissions || {})
  };
}

export interface DatabaseState {
  users: User[];
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: SaleInvoice[];
  purchases: PurchaseInvoice[];
  returns: ReturnInvoice[];
  expenses: Expense[];
  installmentPlans: InstallmentPlan[];
  settings: StoreSettings;
  warehouses: Warehouse[];
  warehouseTransfers: WarehouseTransfer[];
}

// Simple deterministic hash for demo passwords (bcrypt-compatible interface)
export function hashPassword(plainText: string): string {
  let hash = 0;
  for (let i = 0; i < plainText.length; i++) {
    const char = plainText.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return `hash_${Math.abs(hash).toString(16)}_${plainText.length}`;
}

export function verifyPassword(plainText: string, storedHash?: string): boolean {
  if (!storedHash) return false;
  return hashPassword(plainText) === storedHash;
}

const defaultUsers: User[] = [
  {
    id: 'user-manager',
    username: 'manager',
    name: 'المدير العام',
    role: 'admin',
    jobTitle: 'المدير العام للمتجر',
    phone: '01000000001',
    isActive: true,
    permissions: { ...DEFAULT_ADMIN_PERMISSIONS },
    passwordHash: hashPassword('123'),
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-cashier',
    username: 'cashier',
    name: 'كاشير الفرع الرئيسي',
    role: 'cashier',
    jobTitle: 'كاشير مبيعات',
    phone: '01000000002',
    isActive: true,
    permissions: { ...DEFAULT_CASHIER_PERMISSIONS },
    passwordHash: hashPassword('123'),
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-ahmed',
    username: 'ahmed',
    name: 'أحمد رضوان (كاشير - الوردية الصباحية)',
    role: 'cashier',
    jobTitle: 'كاشير مبيعات - وردية صباحية',
    phone: '01012345678',
    isActive: true,
    permissions: {
      ...DEFAULT_CASHIER_PERMISSIONS,
      viewPurchases: false,
      viewPurchaseReturns: false,
      canAddProduct: false,
      canEditProduct: false
    },
    passwordHash: hashPassword('123'),
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-sara',
    username: 'sara',
    name: 'سارة عبد الله (محاسبة وكاشير)',
    role: 'cashier',
    jobTitle: 'محاسبة فرع وكاشير',
    phone: '01123456789',
    isActive: true,
    permissions: {
      ...DEFAULT_CASHIER_PERMISSIONS,
      viewReports: true,
      canExportData: true
    },
    passwordHash: hashPassword('123'),
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-supervisor',
    username: 'supervisor',
    name: 'محمود خليل (مشرف المبيعات والفرع)',
    role: 'admin',
    jobTitle: 'مشرف المبيعات والفرع',
    phone: '01234567890',
    isActive: true,
    permissions: { ...DEFAULT_ADMIN_PERMISSIONS },
    passwordHash: hashPassword('123'),
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-admin',
    username: 'admin',
    name: 'الأدمن (مسؤول النظام)',
    role: 'admin',
    jobTitle: 'الأدمن ومسؤول النظام الرئيسي',
    phone: '01000000000',
    isActive: true,
    permissions: { ...DEFAULT_ADMIN_PERMISSIONS },
    passwordHash: hashPassword('admin'),
    createdAt: new Date().toISOString()
  }
];

function orderUsersWithManagerFirstAndAdminLast(usersList: User[]): User[] {
  const defaultManagerHash = hashPassword('123');
  const dedupedById = new Map<string, User>();

  for (const u of usersList) {
    if (!u || typeof u !== 'object') continue;
    const key = u.id || u.username;
    if (!key) continue;
    const existing = dedupedById.get(key);
    if (!existing) {
      dedupedById.set(key, u);
    } else {
      const existingTime = existing.updatedAt ? new Date(existing.updatedAt).getTime() : 0;
      const candidateTime = u.updatedAt ? new Date(u.updatedAt).getTime() : 0;
      if (candidateTime > existingTime) {
        dedupedById.set(key, u);
      } else if (candidateTime === existingTime) {
        // If one of them is an unmodified default 'manager' with '123' password and the other is customized, keep the customized one
        const existingIsDefaultManager =
          existing.id === 'user-manager' &&
          existing.username?.toLowerCase() === 'manager' &&
          existing.passwordHash === defaultManagerHash;
        const candidateIsCustomized =
          u.username?.toLowerCase() !== 'manager' || u.passwordHash !== defaultManagerHash;
        if (existingIsDefaultManager && candidateIsCustomized) {
          dedupedById.set(key, u);
        }
      }
    }
  }

  const managerAccounts: User[] = [];
  const otherAccounts: User[] = [];
  const adminAccounts: User[] = [];

  for (const u of dedupedById.values()) {
    const uname = (u.username || '').toLowerCase();
    if (uname === 'admin' || u.id === 'user-admin') {
      adminAccounts.push(u);
    } else if (u.id === 'user-manager' || uname === 'manager') {
      managerAccounts.push(u);
    } else {
      otherAccounts.push(u);
    }
  }

  return [...managerAccounts, ...otherAccounts, ...adminAccounts];
}

class LocalDatabase {
  private state: DatabaseState;
  private isInitialized = false;
  private deletedIds: Set<string> = new Set();
  private deviceId: string = '';
  private deviceName: string = '';
  private syncEmail: string = '';
  private lastSyncRevision = 0;
  private lastSyncTimestamp = 0;
  private pushDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private isApplyingRemote = false;
  private syncStatus: SyncStatusInfo = {
    status: 'unconfigured',
    syncEmail: '',
    emailSyncLocked: false,
    lastSyncAt: null,
    lastUpdatedByName: '',
    revision: 0,
    connectedDevices: 1
  };
  private remoteListeners: Set<() => void> = new Set();
  private syncStatusListeners: Set<(info: SyncStatusInfo) => void> = new Set();
  private broadcastChannel: BroadcastChannel | null = null;
  private sseSource: EventSource | null = null;
  private localDbVerified = false;
  private pendingOfflineReplaceAll = false;

  constructor() {
    this.initDeviceMetadata();
    this.state = this.loadDatabase();
    this.isInitialized = true;
    this.initOfflineFirstBootAndSync();
  }

  /**
   * التحقق من جاهزية وسلامة قاعدة البيانات المحلية (IndexedDB + SQLite) أولاً قبل أي اتصال بالشبكة
   */
  async verifyLocalEngineBeforeNetwork(): Promise<LocalDbHealthStatus> {
    const storageKey = this.getEmailStorageKey();
    const { status, hydratedState } = await verifyAndHydrateLocalDb(storageKey);
    this.localDbVerified = true;

    if (hydratedState && typeof hydratedState === 'object') {
      // Hydrate state from IndexedDB if localStorage was empty or reset
      this.applyRemoteState(hydratedState);
    } else {
      // Ensure current SQLite tables are mirrored in IndexedDB
      persistStateToLocalIndexedDB(this.state, storageKey, Array.from(this.deletedIds));
    }
    return status;
  }


  private getEmailStorageKey(email?: string): string {
    const clean = normalizeSyncEmailClient(email ?? this.syncEmail);
    return clean ? `${DB_STORAGE_KEY}_email_${clean}` : DB_STORAGE_KEY;
  }

  private getEmailDeletedKey(email?: string): string {
    const clean = normalizeSyncEmailClient(email ?? this.syncEmail);
    return clean ? `${DB_DELETED_IDS_KEY}_email_${clean}` : DB_DELETED_IDS_KEY;
  }

  private initDeviceMetadata() {
    try {
      let savedDeviceId = localStorage.getItem(DB_SYNC_DEVICE_ID_KEY);
      if (!savedDeviceId) {
        savedDeviceId = `dev-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        localStorage.setItem(DB_SYNC_DEVICE_ID_KEY, savedDeviceId);
      }
      this.deviceId = savedDeviceId;

      // Check URL for ?syncEmail=... first (for 1-click phone link pairing)
      let initialEmail = '';
      if (typeof window !== 'undefined' && window.location?.search) {
        const params = new URLSearchParams(window.location.search);
        const urlEmail = normalizeSyncEmailClient(params.get('syncEmail'));
        if (urlEmail) {
          initialEmail = urlEmail;
          localStorage.setItem(DB_SYNC_EMAIL_KEY, urlEmail);
          localStorage.setItem(DB_EMAIL_SYNC_LOCKED_KEY, 'true');
          const cleanUrl = new URL(window.location.href);
          cleanUrl.searchParams.delete('syncEmail');
          window.history.replaceState({}, '', cleanUrl.toString());
        }
      }
      if (!initialEmail) {
        initialEmail = normalizeSyncEmailClient(localStorage.getItem(DB_SYNC_EMAIL_KEY));
      }
      const isEmailLocked = initialEmail
        ? localStorage.getItem(DB_EMAIL_SYNC_LOCKED_KEY) !== 'false'
        : false;
      this.syncEmail = initialEmail;
      this.syncStatus = {
        ...this.syncStatus,
        status: initialEmail ? 'connected' : 'unconfigured',
        syncEmail: initialEmail,
        emailSyncLocked: isEmailLocked
      };

      const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
      const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
      const isExe = ua.includes('Electron') || (typeof window !== 'undefined' && window.location?.protocol === 'file:');
      this.deviceName = isExe
        ? 'كمبيوتر (نسخة EXE)'
        : isMobile
        ? 'موبايل (هاتف ذكي)'
        : 'كمبيوتر (متصفح الويب)';

      const rawDeleted =
        localStorage.getItem(this.getEmailDeletedKey()) ||
        localStorage.getItem(DB_DELETED_IDS_KEY);
      if (rawDeleted) {
        const parsed = JSON.parse(rawDeleted);
        if (Array.isArray(parsed)) {
          this.deletedIds = new Set(parsed.map(String));
        }
      }
    } catch {
      this.deviceId = 'dev-fallback';
      this.deviceName = 'جهاز متصل';
    }
  }

  getSyncEmail(): string {
    return this.syncEmail;
  }

  isEmailSyncFieldLocked(): boolean {
    return Boolean(this.syncEmail && this.syncStatus.emailSyncLocked);
  }

  setEmailSyncFieldLocked(locked: boolean): void {
    try {
      localStorage.setItem(DB_EMAIL_SYNC_LOCKED_KEY, locked ? 'true' : 'false');
    } catch {
      // ignore
    }
    this.updateSyncStatus({
      emailSyncLocked: locked
    });
  }

  async setSyncEmail(newRawEmail: string): Promise<boolean> {
    const nextEmail = normalizeSyncEmailClient(newRawEmail);
    const prevEmail = this.syncEmail;

    if (!nextEmail) {
      this.syncEmail = '';
      this.lastSyncRevision = 0;
      try {
        localStorage.removeItem(DB_SYNC_EMAIL_KEY);
        localStorage.setItem(DB_EMAIL_SYNC_LOCKED_KEY, 'false');
      } catch {
        // ignore
      }
      if (this.sseSource) {
        this.sseSource.close();
        this.sseSource = null;
      }
      this.updateSyncStatus({
        status: 'unconfigured',
        syncEmail: '',
        emailSyncLocked: false,
        revision: 0,
        connectedDevices: 1
      });
      return false;
    }

    // Save current state to previous email slot if switching between two different emails
    if (prevEmail && prevEmail !== nextEmail) {
      try {
        localStorage.setItem(this.getEmailStorageKey(prevEmail), JSON.stringify(this.state));
        localStorage.setItem(
          this.getEmailDeletedKey(prevEmail),
          JSON.stringify(Array.from(this.deletedIds).slice(-1000))
        );
      } catch {
        // ignore
      }
    }

    this.syncEmail = nextEmail;
    this.lastSyncRevision = 0;
    this.lastSyncTimestamp = 0;

    try {
      localStorage.setItem(DB_SYNC_EMAIL_KEY, nextEmail);
      localStorage.setItem(DB_EMAIL_SYNC_LOCKED_KEY, 'true');
    } catch {
      // ignore
    }

    // If switching from a different email, load the target email's local snapshot (or clean default seed) so data never leaks between two emails on the same browser
    if (prevEmail && prevEmail !== nextEmail) {
      const existingTargetRaw = localStorage.getItem(this.getEmailStorageKey(nextEmail));
      const existingTargetDeleted = localStorage.getItem(this.getEmailDeletedKey(nextEmail));
      this.deletedIds = new Set(
        existingTargetDeleted ? JSON.parse(existingTargetDeleted).map(String) : []
      );
      if (existingTargetRaw) {
        try {
          localStorage.setItem(DB_STORAGE_KEY, existingTargetRaw);
          this.state = this.loadDatabase();
        } catch {
          // ignore
        }
      } else {
        // Start clean for the new email before pulling its cloud state
        const freshState: DatabaseState = {
          users: [...defaultUsers],
          products: [...initialProducts],
          customers: [...initialCustomers],
          suppliers: [...initialSuppliers],
          sales: [...initialSales],
          purchases: [],
          returns: [],
          expenses: [...initialExpenses],
          installmentPlans: [...initialInstallmentPlans],
          settings: { ...initialSettings, warehouses: [...initialWarehouses] },
          warehouses: [...initialWarehouses],
          warehouseTransfers: []
        };
        this.state = freshState;
        this.persist(this.state);
      }
      this.notifyRemoteListeners();
    } else {
      // First time linking an email on this device: persist current state into this email's slot as well
      this.persist(this.state);
    }

    this.updateSyncStatus({
      status: 'syncing',
      syncEmail: nextEmail,
      emailSyncLocked: true
    });

    this.reconnectSseStream();
    const ok = await this.pullFromServer(true);
    return ok;
  }

  private recordDeletedId(id: string) {
    if (!id) return;
    this.deletedIds.add(String(id));
    try {
      const arr = Array.from(this.deletedIds).slice(-1000);
      const serialized = JSON.stringify(arr);
      localStorage.setItem(DB_DELETED_IDS_KEY, serialized);
      if (this.syncEmail) {
        localStorage.setItem(this.getEmailDeletedKey(), serialized);
      }
    } catch {
      // ignore
    }
  }

  /**
   * تحميل قاعدة البيانات أو إنشاؤها تلقائياً عند التشغيل الأول
   */
  private loadDatabase(): DatabaseState {
    try {
      const stored =
        (this.syncEmail ? localStorage.getItem(this.getEmailStorageKey()) : null) ||
        localStorage.getItem(DB_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        let loadedUsers: User[] = parsed.users && Array.isArray(parsed.users) ? parsed.users : [];
        if (loadedUsers.length === 0) {
          loadedUsers = [...defaultUsers];
        } else {
          // Ensure every loaded user has passwordHash, isActive, and well-formed permissions
          loadedUsers = loadedUsers.map(u => {
            const isSuperAdmin = u.username.toLowerCase() === 'admin';
            return {
              ...u,
              name: isSuperAdmin ? 'الأدمن (مسؤول النظام)' : u.name,
              isActive: u.isActive !== false,
              jobTitle: u.jobTitle || (u.role === 'admin' ? 'مدير النظام' : 'كاشير مبيعات'),
              permissions: getEffectivePermissions(u),
              passwordHash: isSuperAdmin
                ? (u.passwordHash === hashPassword('123') || !u.passwordHash
                    ? hashPassword('admin')
                    : u.passwordHash)
                : (u.passwordHash || hashPassword('123'))
            };
          });
          // Ensure primary manager account exists first (check by id 'user-manager' or username 'manager')
          if (
            !loadedUsers.some(
              u => u.id === 'user-manager' || u.username.toLowerCase() === 'manager'
            )
          ) {
            loadedUsers.unshift(defaultUsers[0]);
          }
          // Always ensure primary admin account exists at the end
          if (
            !loadedUsers.some(
              u => u.id === 'user-admin' || u.username.toLowerCase() === 'admin'
            )
          ) {
            loadedUsers.push(defaultUsers[defaultUsers.length - 1]);
          }
          // One-time seed of initial staff if not migrated yet
          const usersSeeded = localStorage.getItem('soft_glass_pos_users_seeded_v2');
          if (!usersSeeded) {
            for (const defUser of defaultUsers) {
              if (
                !loadedUsers.some(
                  u =>
                    u.id === defUser.id ||
                    u.username.toLowerCase() === defUser.username.toLowerCase()
                )
              ) {
                loadedUsers.push(defUser);
              }
            }
            localStorage.setItem('soft_glass_pos_users_seeded_v2', 'true');
          }
          loadedUsers = orderUsersWithManagerFirstAndAdminLast(loadedUsers);
        }

        // One-time migration to ensure Admin password is 'admin' and Manager is first
        const adminPwMigrated = localStorage.getItem('soft_glass_pos_admin_pw_order_v1');
        let needsPersistFromAdminMigration = false;
        if (!adminPwMigrated) {
          loadedUsers = loadedUsers.map(u =>
            u.username.toLowerCase() === 'admin'
              ? {
                  ...u,
                  name: 'الأدمن (مسؤول النظام)',
                  jobTitle: 'الأدمن ومسؤول النظام الرئيسي',
                  passwordHash: hashPassword('admin')
                }
              : u
          );
          loadedUsers = orderUsersWithManagerFirstAndAdminLast(loadedUsers);
          localStorage.setItem('soft_glass_pos_admin_pw_order_v1', 'true');
          needsPersistFromAdminMigration = true;
        }

        const loadedSettings: StoreSettings = {
          ...initialSettings,
          ...(parsed.settings || {})
        };
        loadedSettings.logoUrl = normalizeLogoForPrint(loadedSettings.logoUrl);
        if (!loadedSettings.currencies || loadedSettings.currencies.length === 0) {
          loadedSettings.currencies = [...defaultCurrencies];
        }
        if (loadedSettings.autoUpdatePricesOnRateChange === undefined) {
          loadedSettings.autoUpdatePricesOnRateChange = true;
        }
        if (!loadedSettings.exchangeRateLogs) {
          loadedSettings.exchangeRateLogs = [];
        }

        // One-time automatic migration to set EGP (الجنيه المصري) as the base & default currency
        const egpMigrated = localStorage.getItem('soft_glass_pos_egp_base_migrated_v1');
        let needsPersistAfterMigration = needsPersistFromAdminMigration;
        if (!egpMigrated) {
          loadedSettings.baseCurrency = 'EGP';
          loadedSettings.activeCurrency = 'EGP';
          loadedSettings.currency = 'EGP';
          loadedSettings.currencySymbol = 'ج.م';

          const oldCurrMap = new Map<string, CurrencyRate>();
          (loadedSettings.currencies || []).forEach(c => oldCurrMap.set(c.code.toUpperCase(), c));
          const mergedCurrencies: CurrencyRate[] = defaultCurrencies.map(defCurr => ({ ...defCurr }));
          oldCurrMap.forEach((c, code) => {
            if (!mergedCurrencies.some(mc => mc.code === code)) {
              mergedCurrencies.push({
                ...c,
                isBase: false,
                exchangeRate: Number(((c.exchangeRate || 1) * 13.15).toFixed(4))
              });
            }
          });
          loadedSettings.currencies = mergedCurrencies;
          localStorage.setItem('soft_glass_pos_egp_base_migrated_v1', 'true');
          needsPersistAfterMigration = true;
        }

        // One-time automatic migration to apply AK Store brand name & professional logo
        const akBrandMigrated = localStorage.getItem('soft_glass_pos_ak_store_brand_v1');
        if (!akBrandMigrated) {
          loadedSettings.storeName = 'AK Store';
          if (!loadedSettings.logoUrl || loadedSettings.logoUrl.trim() === '') {
            loadedSettings.logoUrl = initialSettings.logoUrl;
          }
          localStorage.setItem('soft_glass_pos_ak_store_brand_v1', 'true');
          needsPersistAfterMigration = true;
        } else if (!loadedSettings.logoUrl || loadedSettings.logoUrl.trim() === '') {
          loadedSettings.logoUrl = initialSettings.logoUrl;
        }

        // One-time migration: Set default VAT percentage to 0 so no tax is calculated unless user explicitly enters a number > 0
        const vatZeroMigrated = localStorage.getItem('soft_glass_pos_vat_zero_default_v1');
        if (!vatZeroMigrated) {
          loadedSettings.vatPercentage = 0;
          localStorage.setItem('soft_glass_pos_vat_zero_default_v1', 'true');
          needsPersistAfterMigration = true;
        } else {
          const parsedVat = Number(loadedSettings.vatPercentage);
          loadedSettings.vatPercentage = !isNaN(parsedVat) && parsedVat > 0 ? parsedVat : 0;
        }

        const activeCurrCode = loadedSettings.activeCurrency || loadedSettings.currency || 'EGP';
        const activeCurrObj = loadedSettings.currencies.find(c => c.code === activeCurrCode) || loadedSettings.currencies[0];
        const activeRate = activeCurrObj && activeCurrObj.exchangeRate > 0 ? activeCurrObj.exchangeRate : 1;

        // Ensure products have warehouseStock and baseCostPrice / baseSalePrice
        const loadedProducts: Product[] = (parsed.products || initialProducts).map((p: Product) => {
          const baseCost = needsPersistAfterMigration
            ? Number((p.costPrice * activeRate).toFixed(4))
            : (p.baseCostPrice !== undefined ? p.baseCostPrice : Number((p.costPrice * activeRate).toFixed(4)));
          const baseSale = needsPersistAfterMigration
            ? Number((p.salePrice * activeRate).toFixed(4))
            : (p.baseSalePrice !== undefined ? p.baseSalePrice : Number((p.salePrice * activeRate).toFixed(4)));
          const whStock = (!p.warehouseStock || Object.keys(p.warehouseStock).length === 0)
            ? {
                'wh-main': Math.round(p.stock * 0.7),
                'wh-pos': p.stock - Math.round(p.stock * 0.7),
                'wh-backup': 0
              }
            : p.warehouseStock;

          return {
            ...p,
            baseCostPrice: baseCost,
            baseSalePrice: baseSale,
            warehouseStock: whStock
          };
        });

        const loadedWarehouses: Warehouse[] =
          parsed.warehouses && Array.isArray(parsed.warehouses) && parsed.warehouses.length > 0
            ? parsed.warehouses
            : (loadedSettings.warehouses || initialWarehouses);

        loadedSettings.warehouses = loadedWarehouses;

        let loadedSales: SaleInvoice[] = parsed.sales || initialSales;
        const weeklySalesSeeded = localStorage.getItem('soft_glass_pos_weekly_sales_seeded_v1');
        if (!weeklySalesSeeded) {
          const customSales = loadedSales.filter(
            (s: SaleInvoice) => !initialSales.some(initS => initS.id === s.id)
          );
          loadedSales = [...initialSales, ...customSales];
          localStorage.setItem('soft_glass_pos_weekly_sales_seeded_v1', 'true');
          needsPersistAfterMigration = true;
        }

        let loadedCustomers: Customer[] = parsed.customers || initialCustomers;
        let loadedInstallmentPlans: InstallmentPlan[] = parsed.installmentPlans || initialInstallmentPlans;
        const weeklyInstallmentsSeeded = localStorage.getItem('soft_glass_pos_weekly_installments_seeded_v1');
        if (!weeklyInstallmentsSeeded) {
          const customCustomers = loadedCustomers.filter(
            (c: Customer) => !initialCustomers.some(initC => initC.id === c.id)
          );
          loadedCustomers = [...initialCustomers, ...customCustomers];

          const customPlans = loadedInstallmentPlans.filter(
            (p: InstallmentPlan) => !initialInstallmentPlans.some(initP => initP.id === p.id)
          );
          loadedInstallmentPlans = [...initialInstallmentPlans, ...customPlans];
          localStorage.setItem('soft_glass_pos_weekly_installments_seeded_v1', 'true');
          needsPersistAfterMigration = true;
        }

        const loadedState: DatabaseState = {
          users: loadedUsers,
          products: loadedProducts,
          customers: loadedCustomers,
          suppliers: parsed.suppliers || initialSuppliers,
          sales: loadedSales,
          purchases: parsed.purchases || [],
          returns: parsed.returns || [],
          expenses: parsed.expenses || initialExpenses,
          installmentPlans: loadedInstallmentPlans,
          settings: loadedSettings,
          warehouses: loadedWarehouses,
          warehouseTransfers: parsed.warehouseTransfers || []
        };
        if (needsPersistAfterMigration) {
          this.persist(loadedState);
        }
        return loadedState;
      }
    } catch (e) {
      console.warn('Could not load from localStorage, initializing fresh DB state:', e);
    }

    // Default Seed
    localStorage.setItem('soft_glass_pos_users_seeded_v2', 'true');
    const freshState: DatabaseState = {
      users: defaultUsers,
      products: initialProducts,
      customers: initialCustomers,
      suppliers: initialSuppliers,
      sales: initialSales,
      purchases: [],
      returns: [],
      expenses: initialExpenses,
      installmentPlans: initialInstallmentPlans,
      settings: initialSettings,
      warehouses: initialWarehouses,
      warehouseTransfers: []
    };
    this.persist(freshState);
    return freshState;
  }

  private persist(state: DatabaseState) {
    try {
      const serialized = JSON.stringify(state);
      localStorage.setItem(DB_STORAGE_KEY, serialized);
      const emailKey = this.getEmailStorageKey();
      if (this.syncEmail) {
        localStorage.setItem(emailKey, serialized);
      }
      // Mirror all SQLite tables into local IndexedDB asynchronously for permanent Offline-First resilience
      persistStateToLocalIndexedDB(state, emailKey, Array.from(this.deletedIds));
    } catch (e) {
      console.error('Failed to persist database state:', e);
    }
  }

  private save(replaceAllOnServer = false) {
    try {
      localStorage.setItem(DB_USER_MODIFIED_KEY, 'true');
    } catch {
      // ignore
    }
    this.persist(this.state);
    syncDatabaseAndLicenseToSafeVault();

    if (!this.isApplyingRemote) {
      this.broadcastLocalTabUpdate();
      this.schedulePushToServer(replaceAllOnServer);
    }
  }

  // ---- Real-Time Bidirectional Sync (PC <-> Mobile <-> EXE) ----
  private getSyncBaseUrl(): string {
    if (
      typeof window !== 'undefined' &&
      window.location &&
      window.location.origin &&
      window.location.origin.startsWith('http')
    ) {
      return window.location.origin.replace(/\/$/, '');
    }
    return getUpdateServerUrl();
  }

  onRemoteUpdate(listener: () => void): () => void {
    this.remoteListeners.add(listener);
    return () => {
      this.remoteListeners.delete(listener);
    };
  }

  subscribeToSyncStatus(listener: (info: SyncStatusInfo) => void): () => void {
    this.syncStatusListeners.add(listener);
    listener(this.syncStatus);
    return () => {
      this.syncStatusListeners.delete(listener);
    };
  }

  getSyncStatus(): SyncStatusInfo {
    return this.syncStatus;
  }

  private updateSyncStatus(partial: Partial<SyncStatusInfo>) {
    this.syncStatus = { ...this.syncStatus, ...partial };
    this.syncStatusListeners.forEach((cb) => {
      try {
        cb(this.syncStatus);
      } catch {
        // ignore
      }
    });
  }

  private notifyRemoteListeners() {
    this.remoteListeners.forEach((cb) => {
      try {
        cb();
      } catch {
        // ignore
      }
    });
  }

  private broadcastLocalTabUpdate() {
    try {
      if (this.broadcastChannel) {
        this.broadcastChannel.postMessage({
          type: 'local_db_updated',
          deviceId: this.deviceId,
          timestamp: Date.now()
        });
      }
    } catch {
      // ignore
    }
  }

  private schedulePushToServer(replaceAll = false) {
    if (this.pushDebounceTimer) {
      clearTimeout(this.pushDebounceTimer);
    }
    this.pushDebounceTimer = setTimeout(() => {
      this.pushToServer(replaceAll);
    }, 120);
  }

  async pushToServer(replaceAll = false): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    // 1. Always verify local IndexedDB/SQLite connection first (Offline-First guarantee)
    if (!this.localDbVerified) {
      await this.verifyLocalEngineBeforeNetwork();
    }

    if (!this.syncEmail) {
      this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
      return false;
    }

    const baseUrl = this.getSyncBaseUrl();
    const isReachable = await verifyNetworkAfterLocalDbReady(baseUrl, false);
    if (!isReachable) {
      this.pendingOfflineReplaceAll = this.pendingOfflineReplaceAll || replaceAll;
      await markOfflineOutboxPending(true, this.pendingOfflineReplaceAll);
      this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
      return false;
    }

    this.updateSyncStatus({ status: 'syncing', syncEmail: this.syncEmail });

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const response = await fetch(`${baseUrl}/api/sync/push`, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          'X-Sync-Email': this.syncEmail
        },
        body: JSON.stringify({
          email: this.syncEmail,
          deviceId: this.deviceId,
          deviceName: this.deviceName,
          replaceAll: replaceAll || this.pendingOfflineReplaceAll,
          deletedIds: Array.from(this.deletedIds),
          state: this.state
        })
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      if (data && data.offline) {
        this.pendingOfflineReplaceAll = this.pendingOfflineReplaceAll || replaceAll;
        await markOfflineOutboxPending(true, this.pendingOfflineReplaceAll);
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        return false;
      }
      if (data && data.requiresEmail) {
        this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
        return false;
      }
      if (data && data.success) {
        this.pendingOfflineReplaceAll = false;
        await markOfflineOutboxPending(false, false);
        this.lastSyncRevision = Number(data.revision) || this.lastSyncRevision;
        this.lastSyncTimestamp = Number(data.lastModified) || Date.now();
        if (Array.isArray(data.deletedIds)) {
          data.deletedIds.forEach((id: string) => this.deletedIds.add(String(id)));
        }
        if (data.state && typeof data.state === 'object') {
          this.applyRemoteState(data.state, data.deletedIds);
        }
        this.updateSyncStatus({
          status: 'connected',
          syncEmail: this.syncEmail,
          lastSyncAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          lastUpdatedByName: this.deviceName,
          revision: this.lastSyncRevision,
          connectedDevices: Number(data.connectedDevices) || 1
        });
        return true;
      }
    } catch {
      this.pendingOfflineReplaceAll = this.pendingOfflineReplaceAll || replaceAll;
      await markOfflineOutboxPending(true, this.pendingOfflineReplaceAll);
      this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
    }
    return false;
  }

  async pullFromServer(isInitialBoot = false): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    // 1. Always verify local IndexedDB/SQLite connection first (Offline-First guarantee)
    if (!this.localDbVerified) {
      await this.verifyLocalEngineBeforeNetwork();
    }

    if (!this.syncEmail) {
      this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
      return false;
    }

    // Do not overwrite local state with a background pull while a local push is pending
    if (!isInitialBoot && this.pushDebounceTimer !== null) return false;

    const baseUrl = this.getSyncBaseUrl();
    const isReachable = await verifyNetworkAfterLocalDbReady(baseUrl, false);
    if (!isReachable) {
      this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
      return false;
    }

    try {
      const emailParam = `email=${encodeURIComponent(this.syncEmail)}`;
      const query = isInitialBoot
        ? `?${emailParam}&t=${Date.now()}`
        : `?${emailParam}&sinceRevision=${this.lastSyncRevision}&t=${Date.now()}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const response = await fetch(`${baseUrl}/api/sync/state${query}`, {
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'X-Sync-Email': this.syncEmail
        }
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      if (data && data.offline) {
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        return false;
      }
      if (!data || data.requiresEmail) {
        this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
        return false;
      }
      if (!data.success) return false;

      // If server has no state yet for this email, push our local state to initialize this email's cloud vault
      if (!data.hasState || !data.state) {
        await this.pushToServer(false);
        return true;
      }

      if (data.upToDate) {
        this.updateSyncStatus({
          status: 'connected',
          syncEmail: this.syncEmail,
          revision: Number(data.revision) || this.lastSyncRevision,
          connectedDevices: Number(data.connectedDevices) || 1
        });
        return true;
      }

      const serverRevision = Number(data.revision) || 0;
      if (serverRevision > this.lastSyncRevision || isInitialBoot) {
        this.lastSyncRevision = serverRevision;
        this.lastSyncTimestamp = Number(data.lastModified) || Date.now();
        this.applyRemoteState(data.state, data.deletedIds);

        this.updateSyncStatus({
          status: 'connected',
          syncEmail: this.syncEmail,
          lastSyncAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          lastUpdatedByName: data.lastUpdatedByName || 'جهاز متصل',
          revision: this.lastSyncRevision,
          connectedDevices: Number(data.connectedDevices) || 1
        });

        // If this device had local user modifications before initial boot, push back merged state so both sides match 100%
        if (isInitialBoot && localStorage.getItem(DB_USER_MODIFIED_KEY) === 'true') {
          this.schedulePushToServer(false);
        }
        return true;
      }
    } catch {
      this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
    }
    return false;
  }

  private mergeClientArraysById<T extends { id?: string; code?: string; updatedAt?: string }>(
    localArr: T[] | undefined,
    remoteArr: T[] | undefined,
    deletedSet: Set<string>,
    preferRemote: boolean
  ): T[] {
    const primary = preferRemote ? remoteArr || [] : localArr || [];
    const secondary = preferRemote ? localArr || [] : remoteArr || [];

    const map = new Map<string, T>();
    const orderedIds: string[] = [];

    for (const item of primary) {
      if (!item || typeof item !== 'object') continue;
      const key = String(item.id || item.code || '');
      if (!key || deletedSet.has(key)) continue;
      if (!map.has(key)) {
        map.set(key, item);
        orderedIds.push(key);
      } else {
        const existing = map.get(key)!;
        const existingTime = existing.updatedAt ? new Date(existing.updatedAt).getTime() : 0;
        const candidateTime = item.updatedAt ? new Date(item.updatedAt).getTime() : 0;
        if (candidateTime > existingTime) {
          map.set(key, item);
        }
      }
    }

    for (const item of secondary) {
      if (!item || typeof item !== 'object') continue;
      const key = String(item.id || item.code || '');
      if (!key || deletedSet.has(key)) continue;
      if (!map.has(key)) {
        map.set(key, item);
        orderedIds.push(key);
      } else {
        // If secondary item has a strictly newer updatedAt timestamp, keep the newer version
        const existing = map.get(key)!;
        const existingTime = existing.updatedAt ? new Date(existing.updatedAt).getTime() : 0;
        const candidateTime = item.updatedAt ? new Date(item.updatedAt).getTime() : 0;
        if (candidateTime > existingTime) {
          map.set(key, item);
        }
      }
    }

    return orderedIds.map((k) => map.get(k)!);
  }

  private applyRemoteState(remoteState: Partial<DatabaseState>, remoteDeletedIds?: string[]) {
    if (!remoteState || typeof remoteState !== 'object') return;
    this.isApplyingRemote = true;
    try {
      if (Array.isArray(remoteDeletedIds)) {
        remoteDeletedIds.forEach((id) => this.deletedIds.add(String(id)));
        try {
          localStorage.setItem(
            DB_DELETED_IDS_KEY,
            JSON.stringify(Array.from(this.deletedIds).slice(-1000))
          );
        } catch {
          // ignore
        }
      }

      const nextSettings: StoreSettings = {
        ...this.state.settings,
        ...(remoteState.settings || {})
      };

      const nextWarehouses = this.mergeClientArraysById(
        this.state.warehouses,
        remoteState.warehouses,
        this.deletedIds,
        true
      );
      nextSettings.warehouses = nextWarehouses;

      const mergedUsers = orderUsersWithManagerFirstAndAdminLast(
        this.mergeClientArraysById(this.state.users, remoteState.users, this.deletedIds, true).map(u =>
          u.username?.toLowerCase() === 'admin' && u.passwordHash === hashPassword('123')
            ? { ...u, name: 'الأدمن (مسؤول النظام)', passwordHash: hashPassword('admin') }
            : u
        )
      );

      this.state = {
        users: mergedUsers,
        products: this.mergeClientArraysById(
          this.state.products,
          remoteState.products,
          this.deletedIds,
          true
        ),
        customers: this.mergeClientArraysById(
          this.state.customers,
          remoteState.customers,
          this.deletedIds,
          true
        ),
        suppliers: this.mergeClientArraysById(
          this.state.suppliers,
          remoteState.suppliers,
          this.deletedIds,
          true
        ),
        sales: this.mergeClientArraysById(this.state.sales, remoteState.sales, this.deletedIds, true),
        purchases: this.mergeClientArraysById(
          this.state.purchases,
          remoteState.purchases,
          this.deletedIds,
          true
        ),
        returns: this.mergeClientArraysById(
          this.state.returns,
          remoteState.returns,
          this.deletedIds,
          true
        ),
        expenses: this.mergeClientArraysById(
          this.state.expenses,
          remoteState.expenses,
          this.deletedIds,
          true
        ),
        installmentPlans: this.mergeClientArraysById(
          this.state.installmentPlans,
          remoteState.installmentPlans,
          this.deletedIds,
          true
        ),
        settings: nextSettings,
        warehouses: nextWarehouses,
        warehouseTransfers: this.mergeClientArraysById(
          this.state.warehouseTransfers,
          remoteState.warehouseTransfers,
          this.deletedIds,
          true
        )
      };

      this.persist(this.state);
      syncDatabaseAndLicenseToSafeVault();
      this.notifyRemoteListeners();
    } finally {
      this.isApplyingRemote = false;
    }
  }

  async syncNow(): Promise<boolean> {
    if (!this.syncEmail) {
      this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
      return false;
    }
    await this.pushToServer(false);
    return await this.pullFromServer(false);
  }

  private async reconnectSseStream() {
    if (typeof window === 'undefined') return;
    try {
      if (this.sseSource) {
        this.sseSource.close();
        this.sseSource = null;
      }
      if (!this.syncEmail) return;

      // Verify local IndexedDB/SQLite first and then check real network reachability before opening EventSource
      if (!this.localDbVerified) {
        await this.verifyLocalEngineBeforeNetwork();
      }
      const baseUrl = this.getSyncBaseUrl();
      const isReachable = await verifyNetworkAfterLocalDbReady(baseUrl, false);
      if (!isReachable) {
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        return;
      }

      const es = new EventSource(
        `${baseUrl}/api/sync/stream?email=${encodeURIComponent(this.syncEmail)}`
      );
      this.sseSource = es;

      es.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'sync_init') {
            if (payload.revision > this.lastSyncRevision) {
              this.pullFromServer(false);
            }
          } else if (payload.type === 'sync_update') {
            if (
              payload.lastUpdatedByDevice !== this.deviceId ||
              payload.revision > this.lastSyncRevision
            ) {
              this.pullFromServer(false);
            }
          }
        } catch {
          // ignore
        }
      };

      es.onerror = () => {
        es.close();
        this.sseSource = null;
        if (this.syncEmail && typeof navigator !== 'undefined' && navigator.onLine !== false) {
          setTimeout(() => this.reconnectSseStream(), 8000);
        } else if (this.syncEmail) {
          this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        }
      };
    } catch {
      // Fallback to polling when online
    }
  }

  private initOfflineFirstBootAndSync() {
    if (typeof window === 'undefined') return;

    // 1. Local multi-tab instant BroadcastChannel + storage event listener (100% local, zero network)
    try {
      if ('BroadcastChannel' in window) {
        this.broadcastChannel = new BroadcastChannel('akstore_pos_realtime_sync');
        this.broadcastChannel.onmessage = (event) => {
          if (event.data?.deviceId !== this.deviceId) {
            const raw = localStorage.getItem(this.getEmailStorageKey());
            if (raw) {
              try {
                this.applyRemoteState(JSON.parse(raw));
              } catch {
                // ignore
              }
            }
          }
        };
      }
      window.addEventListener('storage', (ev) => {
        if (ev.key === DB_SYNC_EMAIL_KEY) {
          const updatedEmail = normalizeSyncEmailClient(ev.newValue);
          if (updatedEmail !== this.syncEmail) {
            this.syncEmail = updatedEmail;
            this.reconnectSseStream();
            this.pullFromServer(true);
          }
        } else if (ev.key === DB_STORAGE_KEY && ev.newValue) {
          try {
            this.applyRemoteState(JSON.parse(ev.newValue));
          } catch {
            // ignore
          }
        }
      });
    } catch {
      // ignore
    }

    // 2. STRICT OFFLINE-FIRST SEQUENCE:
    // Verify local IndexedDB & SQLite tables FIRST before attempting ANY network connection!
    this.verifyLocalEngineBeforeNetwork().then(async (localHealth) => {
      if (!this.syncEmail) {
        this.updateSyncStatus({ status: 'unconfigured', syncEmail: '' });
        return;
      }

      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        return;
      }

      const baseUrl = this.getSyncBaseUrl();
      const reachable = await verifyNetworkAfterLocalDbReady(baseUrl, true);
      if (!reachable) {
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
        return;
      }

      // Flush any offline outbox changes queued while disconnected
      if (localHealth.pendingOutboxCount > 0) {
        await this.pushToServer(this.pendingOfflineReplaceAll);
      }

      await this.pullFromServer(true);
      this.reconnectSseStream();
    });

    // 3. Background sync check (only when tab is visible, email is configured, and browser is online)
    setInterval(async () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
      if (!this.syncEmail) return;
      if (typeof navigator !== 'undefined' && navigator.onLine === false) return;

      const baseUrl = this.getSyncBaseUrl();
      const reachable = await verifyNetworkAfterLocalDbReady(baseUrl, false);
      if (!reachable) return;

      const health = getLocalDbHealthStatus();
      if (health.pendingOutboxCount > 0) {
        await this.pushToServer(this.pendingOfflineReplaceAll);
      }
      await this.pullFromServer(false);
    }, 5000);

    // 4. Immediately close SSE & cancel network attempts when device goes offline
    window.addEventListener('offline', () => {
      if (this.sseSource) {
        this.sseSource.close();
        this.sseSource = null;
      }
      if (this.syncEmail) {
        this.updateSyncStatus({ status: 'offline', syncEmail: this.syncEmail });
      }
    });

    window.addEventListener('focus', () => {
      if (this.syncEmail && typeof navigator !== 'undefined' && navigator.onLine !== false) {
        this.pullFromServer(false);
      }
    });

    window.addEventListener('online', async () => {
      if (!this.syncEmail) return;
      const baseUrl = this.getSyncBaseUrl();
      const reachable = await verifyNetworkAfterLocalDbReady(baseUrl, true);
      if (reachable) {
        await this.syncNow();
        this.reconnectSseStream();
      }
    });
  }

  // ---- Users & Permissions Management ----
  getUsers(): User[] {
    const mapped = this.state.users.map(u => ({
      ...u,
      isActive: u.isActive !== false,
      permissions: getEffectivePermissions(u)
    }));
    return orderUsersWithManagerFirstAndAdminLast(mapped);
  }

  getUserByUsername(username: string): User | undefined {
    const clean = username.trim().toLowerCase();
    const byUsername = this.state.users.find(u => u.username.toLowerCase() === clean);
    if (byUsername) return byUsername;
    const byId = this.state.users.find(u => u.id.toLowerCase() === clean);
    if (byId) return byId;
    if (clean === 'manager') {
      return this.state.users.find(u => u.id === 'user-manager');
    }
    return this.state.users.find(u => u.name.trim().toLowerCase() === clean);
  }

  authenticate(username: string, password: string): User | null {
    if (!username || !username.trim() || !password || !password.trim()) {
      return null;
    }
    const user = this.getUserByUsername(username);
    if (!user) return null;
    if (user.isActive === false) return null;
    const rawPw = password.trim();
    const normalizedPw = normalizeEnglishPasswordInput(rawPw);
    if (
      verifyPassword(normalizedPw, user.passwordHash) ||
      verifyPassword(rawPw, user.passwordHash)
    ) {
      return {
        ...user,
        isActive: true,
        permissions: getEffectivePermissions(user)
      };
    }
    return null;
  }

  addUser(userData: {
    username: string;
    name: string;
    password: string;
    role: UserRole;
    jobTitle?: string;
    phone?: string;
    isActive?: boolean;
    permissions?: UserPermissions;
  }): { success: boolean; message: string; user?: User } {
    const cleanUsername = userData.username.trim().toLowerCase().replace(/\s+/g, '');
    const cleanName = userData.name.trim();
    const cleanPassword = normalizeEnglishPasswordInput(userData.password.trim());

    if (!cleanUsername || !cleanName) {
      return { success: false, message: 'يرجى إدخال الاسم الكامل واسم المستخدم للدخول' };
    }
    if (!cleanPassword) {
      return { success: false, message: 'يرجى تعيين كلمة مرور للمستخدم الجديد' };
    }
    if (this.state.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: `اسم المستخدم (@${cleanUsername}) مسجل مسبقاً، يرجى اختيار اسم آخر` };
    }

    const effectivePerms =
      userData.role === 'admin'
        ? { ...DEFAULT_ADMIN_PERMISSIONS }
        : { ...DEFAULT_CASHIER_PERMISSIONS, ...(userData.permissions || {}) };

    const nowIso = new Date().toISOString();
    const newUser: User = {
      id: `user-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      username: cleanUsername,
      name: cleanName,
      role: userData.role,
      jobTitle: userData.jobTitle?.trim() || (userData.role === 'admin' ? 'مدير النظام' : 'كاشير / موظف'),
      phone: userData.phone?.trim() || '',
      isActive: userData.isActive !== false,
      permissions: effectivePerms,
      passwordHash: hashPassword(cleanPassword),
      createdAt: nowIso,
      updatedAt: nowIso
    };

    this.state.users.push(newUser);
    this.state.users = orderUsersWithManagerFirstAndAdminLast(this.state.users);
    this.save();
    this.notifyRemoteListeners();
    return {
      success: true,
      message: `تم تسجيل المستخدم "${newUser.name}" (@${newUser.username}) وحفظ صلاحياته بنجاح!`,
      user: newUser
    };
  }

  updateUser(
    id: string,
    updates: {
      username?: string;
      name?: string;
      newPassword?: string;
      role?: UserRole;
      jobTitle?: string;
      phone?: string;
      isActive?: boolean;
      permissions?: UserPermissions;
    }
  ): { success: boolean; message: string; user?: User } {
    this.state.users = orderUsersWithManagerFirstAndAdminLast(this.state.users);
    const idx = this.state.users.findIndex(u => u.id === id);
    if (idx === -1) {
      return { success: false, message: 'المستخدم غير موجود في النظام' };
    }

    const current = this.state.users[idx];
    const nextUsername = updates.username ? updates.username.trim().toLowerCase().replace(/\s+/g, '') : current.username;

    if (
      nextUsername !== current.username.toLowerCase() &&
      this.state.users.some((u, i) => i !== idx && u.id !== id && u.username.toLowerCase() === nextUsername)
    ) {
      return { success: false, message: `اسم المستخدم (@${nextUsername}) مستخدم بالفعل لحساب آخر!` };
    }

    // Prevent deactivating or demoting primary admin account
    if (current.username.toLowerCase() === 'admin') {
      if (updates.role && updates.role !== 'admin') {
        return { success: false, message: 'لا يمكن تغيير صلاحية حساب الأدمن الرئيسي (admin) إلى غير مدير!' };
      }
      if (updates.isActive === false) {
        return { success: false, message: 'لا يمكن إيقاف حساب الأدمن الرئيسي (admin)!' };
      }
    }

    const nextRole = updates.role || current.role;
    const nextPermissions =
      nextRole === 'admin'
        ? { ...DEFAULT_ADMIN_PERMISSIONS }
        : {
            ...DEFAULT_CASHIER_PERMISSIONS,
            ...(current.permissions || {}),
            ...(updates.permissions || {})
          };

    const normalizedNewPw = updates.newPassword
      ? normalizeEnglishPasswordInput(updates.newPassword.trim())
      : '';
    const isPasswordUpdated = Boolean(normalizedNewPw.length > 0);
    const nextPasswordHash = isPasswordUpdated
      ? hashPassword(normalizedNewPw)
      : current.passwordHash;

    const updatedUser: User = {
      ...current,
      username: current.username.toLowerCase() === 'admin' ? 'admin' : nextUsername,
      name: updates.name !== undefined ? updates.name.trim() || current.name : current.name,
      role: nextRole,
      jobTitle: updates.jobTitle !== undefined ? updates.jobTitle.trim() : current.jobTitle,
      phone: updates.phone !== undefined ? updates.phone.trim() : current.phone,
      isActive: updates.isActive !== undefined ? updates.isActive : (current.isActive !== false),
      permissions: nextPermissions,
      passwordHash: nextPasswordHash,
      updatedAt: new Date().toISOString()
    };

    this.state.users[idx] = updatedUser;
    this.state.users = orderUsersWithManagerFirstAndAdminLast(this.state.users);
    this.save();
    this.notifyRemoteListeners();
    return {
      success: true,
      message: isPasswordUpdated
        ? `تم تغيير كلمة المرور وتحديث بيانات "${updatedUser.name}" (@${updatedUser.username}) بنجاح!`
        : `تم تحديث بيانات وصلاحيات المستخدم "${updatedUser.name}" بنجاح!`,
      user: updatedUser
    };
  }

  deleteUser(id: string): { success: boolean; message: string } {
    const target = this.state.users.find(u => u.id === id);
    if (!target) {
      return { success: false, message: 'المستخدم غير موجود' };
    }
    if (target.username.toLowerCase() === 'admin') {
      return { success: false, message: 'لا يمكن حذف حساب المدير العام الأساسي للنظام (admin)!' };
    }
    const adminCount = this.state.users.filter(u => u.role === 'admin' && u.isActive !== false).length;
    if (target.role === 'admin' && adminCount <= 1) {
      return { success: false, message: 'لا يمكن حذف المدير الوحيد النشط في النظام!' };
    }

    this.state.users = this.state.users.filter(u => u.id !== id);
    this.recordDeletedId(id);
    this.save();
    return {
      success: true,
      message: `تم حذف حساب المستخدم "${target.name}" (@${target.username}) بنجاح`
    };
  }

  // ---- Settings ----
  getSettings(): StoreSettings {
    return this.state.settings;
  }

  updateSettings(settings: Partial<StoreSettings>): StoreSettings {
    this.state.settings = { ...this.state.settings, ...settings };
    this.save();
    return this.state.settings;
  }

  // ---- Products ----
  getProducts(): Product[] {
    return this.state.products;
  }

  getProductByBarcode(barcode: string): Product | undefined {
    const clean = barcode.trim();
    if (!clean) return undefined;
    return this.state.products.find(p => 
      p.barcode.trim() === clean || 
      p.barcode.trim().toLowerCase() === clean.toLowerCase() ||
      (p.sku && p.sku.trim().toLowerCase() === clean.toLowerCase())
    );
  }

  addProduct(product: Omit<Product, 'id' | 'createdAt'>): Product {
    const defaultWhId = this.state.settings.defaultWarehouseId || (this.state.warehouses?.[0]?.id || 'wh-main');
    let warehouseStock = product.warehouseStock;
    if (!warehouseStock || Object.keys(warehouseStock).length === 0) {
      warehouseStock = { [defaultWhId]: product.stock || 0 };
    }
    const totalStock = Object.values(warehouseStock).reduce((sum, v) => sum + (Number(v) || 0), 0);
    const activeRate = this.getActiveCurrencyRate();

    const newProduct: Product = {
      ...product,
      baseCostPrice: product.baseCostPrice !== undefined
        ? product.baseCostPrice
        : Number(((product.costPrice || 0) * activeRate).toFixed(4)),
      baseSalePrice: product.baseSalePrice !== undefined
        ? product.baseSalePrice
        : Number(((product.salePrice || 0) * activeRate).toFixed(4)),
      stock: totalStock,
      warehouseStock,
      id: `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString()
    };
    this.state.products.unshift(newProduct);
    this.save();
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<Product>): Product | null {
    const index = this.state.products.findIndex(p => p.id === id);
    if (index === -1) return null;
    const current = this.state.products[index];
    let nextWarehouseStock = updates.warehouseStock ?? current.warehouseStock;
    let nextStock = updates.stock !== undefined ? updates.stock : current.stock;

    if (updates.warehouseStock) {
      nextStock = Object.values(updates.warehouseStock).reduce((sum, v) => sum + (Number(v) || 0), 0);
    } else if (updates.stock !== undefined && updates.stock !== current.stock) {
      const defaultWhId = this.state.settings.defaultWarehouseId || (this.state.warehouses?.[0]?.id || 'wh-main');
      nextWarehouseStock = {
        ...(nextWarehouseStock || {}),
        [defaultWhId]: updates.stock
      };
    }

    const activeRate = this.getActiveCurrencyRate();
    const nextBaseCost = updates.baseCostPrice !== undefined
      ? updates.baseCostPrice
      : updates.costPrice !== undefined
      ? Number((updates.costPrice * activeRate).toFixed(4))
      : (current.baseCostPrice ?? Number((current.costPrice * activeRate).toFixed(4)));

    const nextBaseSale = updates.baseSalePrice !== undefined
      ? updates.baseSalePrice
      : updates.salePrice !== undefined
      ? Number((updates.salePrice * activeRate).toFixed(4))
      : (current.baseSalePrice ?? Number((current.salePrice * activeRate).toFixed(4)));

    this.state.products[index] = {
      ...current,
      ...updates,
      baseCostPrice: nextBaseCost,
      baseSalePrice: nextBaseSale,
      stock: nextStock,
      warehouseStock: nextWarehouseStock
    };
    this.save();
    return this.state.products[index];
  }

  deleteProduct(id: string): boolean {
    const initialLen = this.state.products.length;
    this.state.products = this.state.products.filter(p => p.id !== id);
    if (this.state.products.length !== initialLen) {
      this.recordDeletedId(id);
      this.save();
      return true;
    }
    return false;
  }

  adjustProductStock(productId: string, quantityDelta: number, warehouseId?: string) {
    const product = this.state.products.find(p => p.id === productId);
    if (product) {
      const whId = warehouseId || this.state.settings.defaultWarehouseId || (this.state.warehouses?.[0]?.id || 'wh-main');
      if (!product.warehouseStock) {
        product.warehouseStock = { [whId]: product.stock };
      }
      const curWhStock = product.warehouseStock[whId] || 0;
      product.warehouseStock[whId] = Math.max(0, curWhStock + quantityDelta);
      // Overall stock equals sum of warehouse quantities
      product.stock = Object.values(product.warehouseStock).reduce((sum, v) => sum + (Number(v) || 0), 0);
      this.save();
    }
  }

  // ---- Sales ----
  getSales(): SaleInvoice[] {
    return this.state.sales;
  }

  createSale(saleData: Omit<SaleInvoice, 'id' | 'invoiceNumber' | 'date'> & { date?: string }): SaleInvoice {
    const dateStr = saleData.date || new Date().toISOString();
    const invoiceNumber = `INV-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(this.state.sales.length + 1).padStart(4, '0')}`;
    
    const newInvoice: SaleInvoice = {
      ...saleData,
      id: `sale-${Date.now()}`,
      invoiceNumber,
      date: dateStr
    };

    // Deduct stock for sold items from the specified warehouse
    newInvoice.items.forEach(item => {
      this.adjustProductStock(item.product.id, -item.quantity, newInvoice.warehouseId);
    });

    // If customer bought on credit or has remaining balance, update customer ledger
    if (newInvoice.customerId && newInvoice.grandTotal > newInvoice.paidAmount) {
      const debt = newInvoice.grandTotal - newInvoice.paidAmount;
      this.adjustCustomerBalance(newInvoice.customerId, debt);
    }

    this.state.sales.unshift(newInvoice);
    this.save();
    return newInvoice;
  }

  updateSale(id: string, updates: Partial<SaleInvoice>): SaleInvoice | null {
    const index = this.state.sales.findIndex(s => s.id === id);
    if (index === -1) return null;
    const oldSale = this.state.sales[index];

    // 1. Restore stock for old items to the original warehouse
    oldSale.items.forEach(item => {
      this.adjustProductStock(item.product.id, item.quantity, oldSale.warehouseId);
    });

    // 2. Revert old debt from old customer if applicable
    if (oldSale.customerId && oldSale.grandTotal > oldSale.paidAmount) {
      const oldDebt = oldSale.grandTotal - oldSale.paidAmount;
      this.adjustCustomerBalance(oldSale.customerId, -oldDebt);
    }

    const updatedSale: SaleInvoice = {
      ...oldSale,
      ...updates
    };

    // 3. Deduct stock for updated items from the target warehouse
    updatedSale.items.forEach(item => {
      this.adjustProductStock(item.product.id, -item.quantity, updatedSale.warehouseId);
    });

    // 4. Apply new debt to customer if applicable
    if (updatedSale.customerId && updatedSale.grandTotal > updatedSale.paidAmount) {
      const newDebt = updatedSale.grandTotal - updatedSale.paidAmount;
      this.adjustCustomerBalance(updatedSale.customerId, newDebt);
    }

    this.state.sales[index] = updatedSale;
    this.save();
    return updatedSale;
  }

  deleteSale(id: string): boolean {
    const target = this.state.sales.find(s => s.id === id);
    if (!target) return false;

    // Restore stock for deleted sale items to the original warehouse
    target.items.forEach(item => {
      this.adjustProductStock(item.product.id, item.quantity, target.warehouseId);
    });

    // Revert debt if customer had remaining balance
    if (target.customerId && target.grandTotal > target.paidAmount) {
      const debt = target.grandTotal - target.paidAmount;
      this.adjustCustomerBalance(target.customerId, -debt);
    }

    this.state.sales = this.state.sales.filter(s => s.id !== id);
    this.recordDeletedId(id);
    this.save();
    return true;
  }

  // ---- Purchases ----
  getPurchases(): PurchaseInvoice[] {
    return this.state.purchases;
  }

  createPurchase(purchaseData: Omit<PurchaseInvoice, 'id' | 'invoiceNumber' | 'date'>): PurchaseInvoice {
    const invoiceNumber = `PUR-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(this.state.purchases.length + 1).padStart(4, '0')}`;
    const newPurchase: PurchaseInvoice = {
      ...purchaseData,
      id: `pur-${Date.now()}`,
      invoiceNumber,
      date: new Date().toISOString()
    };

    // Increase product stocks in the specified receiving warehouse
    newPurchase.items.forEach(item => {
      this.adjustProductStock(item.productId, item.quantity, newPurchase.warehouseId);
    });

    // If not fully paid, increase supplier balance
    if (newPurchase.remainingAmount > 0) {
      this.adjustSupplierBalance(newPurchase.supplierId, newPurchase.remainingAmount);
    }

    this.state.purchases.unshift(newPurchase);
    this.save();
    return newPurchase;
  }

  updatePurchase(id: string, updates: Partial<PurchaseInvoice>): PurchaseInvoice | null {
    const index = this.state.purchases.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.state.purchases[index] = { ...this.state.purchases[index], ...updates };
    this.save();
    return this.state.purchases[index];
  }

  deletePurchase(id: string): boolean {
    const target = this.state.purchases.find(p => p.id === id);
    if (!target) return false;

    // Revert product stocks added by this purchase from the original receiving warehouse
    target.items.forEach(item => {
      this.adjustProductStock(item.productId, -item.quantity, target.warehouseId);
    });

    // Revert supplier balance
    if (target.remainingAmount > 0) {
      this.adjustSupplierBalance(target.supplierId, -target.remainingAmount);
    }

    this.state.purchases = this.state.purchases.filter(p => p.id !== id);
    this.recordDeletedId(id);
    this.save();
    return true;
  }

  // ---- Returns ----
  getReturns(): ReturnInvoice[] {
    return this.state.returns;
  }

  createReturn(returnData: Omit<ReturnInvoice, 'id' | 'returnNumber' | 'date'>): ReturnInvoice {
    const returnNumber = `RET-${returnData.type === 'sale' ? 'SAL' : 'PUR'}-${Date.now().toString().slice(-6)}`;
    const newReturn: ReturnInvoice = {
      ...returnData,
      id: `ret-${Date.now()}`,
      returnNumber,
      date: new Date().toISOString()
    };

    // If sale return, items come BACK into inventory (+qty)
    // If purchase return, items LEAVE inventory (-qty)
    newReturn.items.forEach(item => {
      const delta = returnData.type === 'sale' ? item.quantity : -item.quantity;
      this.adjustProductStock(item.productId, delta);
    });

    this.state.returns.unshift(newReturn);
    this.save();
    return newReturn;
  }

  deleteReturn(id: string): boolean {
    const target = this.state.returns.find(r => r.id === id);
    if (!target) return false;

    // Revert stock adjustment made during the return
    target.items.forEach(item => {
      const delta = target.type === 'sale' ? -item.quantity : item.quantity;
      this.adjustProductStock(item.productId, delta);
    });

    this.state.returns = this.state.returns.filter(r => r.id !== id);
    this.recordDeletedId(id);
    this.save();
    return true;
  }

  // ---- Customers ----
  getCustomers(): Customer[] {
    return this.state.customers;
  }

  addCustomer(customer: Omit<Customer, 'id' | 'createdAt'>): Customer {
    const newCust: Customer = {
      ...customer,
      id: `cust-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    this.state.customers.unshift(newCust);
    this.save();
    return newCust;
  }

  updateCustomer(id: string, updates: Partial<Customer>): Customer | null {
    const index = this.state.customers.findIndex(c => c.id === id);
    if (index === -1) return null;
    this.state.customers[index] = { ...this.state.customers[index], ...updates };
    this.save();
    return this.state.customers[index];
  }

  deleteCustomer(id: string): boolean {
    const initialLen = this.state.customers.length;
    this.state.customers = this.state.customers.filter(c => c.id !== id);
    if (this.state.customers.length !== initialLen) {
      this.recordDeletedId(id);
      this.save();
      return true;
    }
    return false;
  }

  adjustCustomerBalance(customerId: string, delta: number) {
    const customer = this.state.customers.find(c => c.id === customerId);
    if (customer) {
      customer.balance = (customer.balance || 0) + delta;
      this.save();
    }
  }

  // ---- Suppliers ----
  getSuppliers(): Supplier[] {
    return this.state.suppliers;
  }

  addSupplier(supplier: Omit<Supplier, 'id' | 'createdAt'>): Supplier {
    const newSup: Supplier = {
      ...supplier,
      id: `sup-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    this.state.suppliers.unshift(newSup);
    this.save();
    return newSup;
  }

  updateSupplier(id: string, updates: Partial<Supplier>): Supplier | null {
    const index = this.state.suppliers.findIndex(s => s.id === id);
    if (index === -1) return null;
    this.state.suppliers[index] = { ...this.state.suppliers[index], ...updates };
    this.save();
    return this.state.suppliers[index];
  }

  deleteSupplier(id: string): boolean {
    const initialLen = this.state.suppliers.length;
    this.state.suppliers = this.state.suppliers.filter(s => s.id !== id);
    if (this.state.suppliers.length !== initialLen) {
      this.recordDeletedId(id);
      this.save();
      return true;
    }
    return false;
  }

  adjustSupplierBalance(supplierId: string, delta: number) {
    const supplier = this.state.suppliers.find(s => s.id === supplierId);
    if (supplier) {
      supplier.balance = (supplier.balance || 0) + delta;
      this.save();
    }
  }

  // ---- Expenses ----
  getExpenses(): Expense[] {
    return this.state.expenses;
  }

  addExpense(expense: Omit<Expense, 'id'>): Expense {
    const newExp: Expense = {
      ...expense,
      id: `exp-${Date.now()}`
    };
    this.state.expenses.unshift(newExp);
    this.save();
    return newExp;
  }

  deleteExpense(id: string): boolean {
    const initialLen = this.state.expenses.length;
    this.state.expenses = this.state.expenses.filter(e => e.id !== id);
    if (this.state.expenses.length !== initialLen) {
      this.recordDeletedId(id);
      this.save();
      return true;
    }
    return false;
  }

  updateExpense(id: string, updates: Partial<Expense>): Expense | null {
    const index = this.state.expenses.findIndex(e => e.id === id);
    if (index === -1) return null;
    this.state.expenses[index] = { ...this.state.expenses[index], ...updates };
    this.save();
    return this.state.expenses[index];
  }

  // ---- Installments ----
  getInstallmentPlans(): InstallmentPlan[] {
    return this.state.installmentPlans;
  }

  createInstallmentPlan(plan: Omit<InstallmentPlan, 'id'>): InstallmentPlan {
    const newPlan: InstallmentPlan = {
      ...plan,
      id: `plan-${Date.now()}`
    };
    this.state.installmentPlans.unshift(newPlan);
    this.save();
    return newPlan;
  }

  updateInstallmentPlan(id: string, updates: Partial<InstallmentPlan>): InstallmentPlan | null {
    const index = this.state.installmentPlans.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.state.installmentPlans[index] = { ...this.state.installmentPlans[index], ...updates };
    this.save();
    return this.state.installmentPlans[index];
  }

  deleteInstallmentPlan(id: string): boolean {
    const target = this.state.installmentPlans.find(p => p.id === id);
    if (!target) return false;

    // Deduct remaining unpaid debt from customer balance
    const unpaidAmount = target.installments
      .filter(i => i.status !== 'paid')
      .reduce((sum, i) => sum + i.amount, 0);

    if (unpaidAmount > 0) {
      this.adjustCustomerBalance(target.customerId, -unpaidAmount);
    }

    this.state.installmentPlans = this.state.installmentPlans.filter(p => p.id !== id);
    this.recordDeletedId(id);
    this.save();
    return true;
  }

  payInstallmentItem(planId: string, installmentId: string, amount: number, notes?: string): boolean {
    const plan = this.state.installmentPlans.find(p => p.id === planId);
    if (!plan) return false;

    const inst = plan.installments.find(i => i.id === installmentId);
    if (!inst) return false;

    inst.status = 'paid';
    inst.paidDate = new Date().toISOString().split('T')[0];
    inst.paidAmount = amount;
    if (notes) inst.notes = notes;

    // Reduce customer balance
    this.adjustCustomerBalance(plan.customerId, -amount);

    this.save();
    return true;
  }

  // ---- Warehouses Management ----
  getWarehouses(): Warehouse[] {
    return this.state.warehouses || initialWarehouses;
  }

  addWarehouse(warehouse: Omit<Warehouse, 'id' | 'createdAt'>): Warehouse {
    const newWh: Warehouse = {
      ...warehouse,
      id: `wh-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString()
    };
    if (newWh.isDefault) {
      this.state.warehouses.forEach(w => { w.isDefault = false; });
      this.state.settings.defaultWarehouseId = newWh.id;
    }
    this.state.warehouses.push(newWh);
    this.state.settings.warehouses = this.state.warehouses;
    this.save();
    return newWh;
  }

  updateWarehouse(id: string, updates: Partial<Warehouse>): Warehouse | null {
    const idx = this.state.warehouses.findIndex(w => w.id === id);
    if (idx === -1) return null;

    if (updates.isDefault) {
      this.state.warehouses.forEach(w => { w.isDefault = false; });
      this.state.settings.defaultWarehouseId = id;
    }

    this.state.warehouses[idx] = { ...this.state.warehouses[idx], ...updates };
    this.state.settings.warehouses = this.state.warehouses;
    this.save();
    return this.state.warehouses[idx];
  }

  deleteWarehouse(id: string): { success: boolean; message?: string } {
    if (this.state.warehouses.length <= 1) {
      return { success: false, message: 'لا يمكن حذف المستودع الوحيد في النظام!' };
    }
    const target = this.state.warehouses.find(w => w.id === id);
    if (target?.isDefault) {
      return { success: false, message: 'لا يمكن حذف المستودع الافتراضي، يرجى تعيين مستودع افتراضي آخر أولاً.' };
    }

    // Check if any product has stock in this warehouse
    const hasStock = this.state.products.some(p => (p.warehouseStock?.[id] || 0) > 0);
    if (hasStock) {
      return { success: false, message: 'لا يمكن حذف المستودع لأنه يحتوي على بضاعة ومخزون حالي! يرجى نقل المخزون أولاً.' };
    }

    this.state.warehouses = this.state.warehouses.filter(w => w.id !== id);
    this.state.settings.warehouses = this.state.warehouses;
    this.recordDeletedId(id);
    this.save();
    return { success: true };
  }

  setDefaultWarehouse(id: string): boolean {
    const exists = this.state.warehouses.some(w => w.id === id);
    if (!exists) return false;
    this.state.warehouses.forEach(w => {
      w.isDefault = (w.id === id);
    });
    this.state.settings.defaultWarehouseId = id;
    this.state.settings.warehouses = this.state.warehouses;
    this.save();
    return true;
  }

  // ---- Warehouse Stock Distribution & Transfers ----
  distributeProductStock(productId: string, distribution: Record<string, number>): boolean {
    const product = this.state.products.find(p => p.id === productId);
    if (!product) return false;

    // Sanitize distribution numbers
    const cleanDist: Record<string, number> = {};
    let totalStock = 0;
    Object.entries(distribution).forEach(([whId, qty]) => {
      const q = Math.max(0, Number(qty) || 0);
      cleanDist[whId] = q;
      totalStock += q;
    });

    product.warehouseStock = cleanDist;
    product.stock = totalStock;
    this.save();
    return true;
  }

  transferStockBetweenWarehouses(params: {
    fromWarehouseId: string;
    toWarehouseId: string;
    productId: string;
    quantity: number;
    notes?: string;
    transferredBy?: string;
  }): { success: boolean; message: string; transfer?: WarehouseTransfer } {
    const { fromWarehouseId, toWarehouseId, productId, quantity, notes, transferredBy } = params;

    if (fromWarehouseId === toWarehouseId) {
      return { success: false, message: 'لا يمكن التحويل لنفس المستودع!' };
    }
    if (quantity <= 0) {
      return { success: false, message: 'يجب أن تكون الكمية المحولة أكبر من صفر!' };
    }

    const product = this.state.products.find(p => p.id === productId);
    if (!product) {
      return { success: false, message: 'المنتج غير موجود!' };
    }

    const fromWh = this.state.warehouses.find(w => w.id === fromWarehouseId);
    const toWh = this.state.warehouses.find(w => w.id === toWarehouseId);
    if (!fromWh || !toWh) {
      return { success: false, message: 'المستودع المصدر أو الوجهة غير صالح!' };
    }

    if (!product.warehouseStock) {
      product.warehouseStock = { [fromWarehouseId]: product.stock };
    }

    const currentFromStock = product.warehouseStock[fromWarehouseId] || 0;
    if (currentFromStock < quantity) {
      return {
        success: false,
        message: `المخزون المتوفر في "${fromWh.name}" (${currentFromStock}) لا يكفي لتحويل (${quantity}) قطعة!`
      };
    }

    // Execute transfer
    product.warehouseStock[fromWarehouseId] = currentFromStock - quantity;
    product.warehouseStock[toWarehouseId] = (product.warehouseStock[toWarehouseId] || 0) + quantity;

    const newTransfer: WarehouseTransfer = {
      id: `tr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      transferNumber: `TR-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString(),
      fromWarehouseId: fromWh.id,
      fromWarehouseName: fromWh.name,
      toWarehouseId: toWh.id,
      toWarehouseName: toWh.name,
      productId: product.id,
      productName: product.name,
      barcode: product.barcode,
      quantity,
      notes: notes || '',
      transferredBy: transferredBy || 'مسؤول النظام'
    };

    if (!this.state.warehouseTransfers) {
      this.state.warehouseTransfers = [];
    }
    this.state.warehouseTransfers.unshift(newTransfer);

    this.save();
    return {
      success: true,
      message: `تم بنجاح نقل ${quantity} قطعة من "${product.name}" من [${fromWh.name}] إلى [${toWh.name}]!`,
      transfer: newTransfer
    };
  }

  getWarehouseTransfers(): WarehouseTransfer[] {
    return this.state.warehouseTransfers || [];
  }

  // ---- Multi-Currency & Manual Exchange Rate Management ----
  getCurrencies(): CurrencyRate[] {
    if (!this.state.settings.currencies || this.state.settings.currencies.length === 0) {
      this.state.settings.currencies = [...defaultCurrencies];
    }
    return this.state.settings.currencies;
  }

  getBaseCurrency(): CurrencyRate {
    const currencies = this.getCurrencies();
    return (
      currencies.find(c => c.isBase) ||
      currencies.find(c => c.code === (this.state.settings.baseCurrency || 'EGP')) ||
      currencies[0]
    );
  }

  getActiveCurrency(): CurrencyRate {
    const currencies = this.getCurrencies();
    const activeCode = this.state.settings.activeCurrency || this.state.settings.currency || 'EGP';
    return currencies.find(c => c.code === activeCode) || this.getBaseCurrency();
  }

  getActiveCurrencyRate(): number {
    const active = this.getActiveCurrency();
    return active && active.exchangeRate > 0 ? active.exchangeRate : 1;
  }

  /**
   * التبديل بين العملات المختلفة وتحديث أسعار البيع والشراء للأصناف وفق العملة المختارة
   */
  switchActiveCurrency(code: string): {
    success: boolean;
    message: string;
    currency?: CurrencyRate;
    affectedProductsCount: number;
  } {
    const currencies = this.getCurrencies();
    const target = currencies.find(c => c.code.toUpperCase() === code.trim().toUpperCase());
    if (!target) {
      return { success: false, message: 'العملة المختارة غير موجودة في النظام', affectedProductsCount: 0 };
    }

    const oldActive = this.getActiveCurrency();
    const oldRate = oldActive.exchangeRate > 0 ? oldActive.exchangeRate : 1;
    const targetRate = target.exchangeRate > 0 ? target.exchangeRate : 1;

    // Ensure every product has accurate baseCostPrice & baseSalePrice before converting
    this.state.products = this.state.products.map(p => {
      const baseCost = p.baseCostPrice !== undefined ? p.baseCostPrice : Number((p.costPrice * oldRate).toFixed(4));
      const baseSale = p.baseSalePrice !== undefined ? p.baseSalePrice : Number((p.salePrice * oldRate).toFixed(4));
      return {
        ...p,
        baseCostPrice: baseCost,
        baseSalePrice: baseSale,
        costPrice: Number((baseCost / targetRate).toFixed(2)),
        salePrice: Number((baseSale / targetRate).toFixed(2))
      };
    });

    this.state.settings.activeCurrency = target.code;
    this.state.settings.currency = target.code;
    this.state.settings.currencySymbol = target.symbol;

    if (!this.state.settings.exchangeRateLogs) {
      this.state.settings.exchangeRateLogs = [];
    }
    this.state.settings.exchangeRateLogs.unshift({
      id: `fx-log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: new Date().toISOString(),
      currencyCode: target.code,
      currencyName: target.name,
      oldRate: oldRate,
      newRate: targetRate,
      affectedProductsCount: this.state.products.length,
      actionType: 'currency_switch',
      notes: `تم التبديل من (${oldActive.name} - ${oldActive.symbol}) إلى (${target.name} - ${target.symbol})`
    });

    this.save();
    return {
      success: true,
      message: `تم التبديل إلى عملة "${target.name} (${target.symbol})" وتحديث أسعار البيع والشراء لـ ${this.state.products.length} صنف بنجاح!`,
      currency: target,
      affectedProductsCount: this.state.products.length
    };
  }

  /**
   * تحديث سعر الصرف يدوياً وتطبيق تأثيره المباشر على أسعار البيع والشراء
   */
  updateCurrencyExchangeRate(
    code: string,
    newRate: number,
    options?: {
      applyToProductPrices?: boolean;
      priceImpactMode?: 'auto' | 'scale_all' | 'convert_active';
    }
  ): {
    success: boolean;
    message: string;
    oldRate: number;
    newRate: number;
    affectedProductsCount: number;
  } {
    if (isNaN(newRate) || newRate <= 0) {
      return {
        success: false,
        message: 'يرجى إدخال سعر صرف صحيح أكبر من الصفر',
        oldRate: 1,
        newRate,
        affectedProductsCount: 0
      };
    }

    const currencies = this.getCurrencies();
    const idx = currencies.findIndex(c => c.code.toUpperCase() === code.trim().toUpperCase());
    if (idx === -1) {
      return {
        success: false,
        message: 'العملة غير موجودة',
        oldRate: 1,
        newRate,
        affectedProductsCount: 0
      };
    }

    const targetCurr = currencies[idx];
    const oldRate = targetCurr.exchangeRate > 0 ? targetCurr.exchangeRate : 1;
    const cleanNewRate = Number(newRate.toFixed(6));

    currencies[idx] = {
      ...targetCurr,
      exchangeRate: cleanNewRate,
      updatedAt: new Date().toISOString()
    };
    this.state.settings.currencies = [...currencies];

    const activeCode = this.state.settings.activeCurrency || this.state.settings.currency || 'EGP';
    const shouldApplyToPrices =
      options?.applyToProductPrices !== undefined
        ? options.applyToProductPrices
        : (this.state.settings.autoUpdatePricesOnRateChange ?? true);

    const impactMode = options?.priceImpactMode || 'auto';
    let affectedCount = 0;

    if (shouldApplyToPrices && oldRate !== cleanNewRate) {
      if (targetCurr.code === activeCode && impactMode !== 'scale_all') {
        // Active currency rate changed: recalculate product costPrice & salePrice from base prices
        this.state.products = this.state.products.map(p => {
          const baseCost = p.baseCostPrice !== undefined ? p.baseCostPrice : Number((p.costPrice * oldRate).toFixed(4));
          const baseSale = p.baseSalePrice !== undefined ? p.baseSalePrice : Number((p.salePrice * oldRate).toFixed(4));
          return {
            ...p,
            baseCostPrice: baseCost,
            baseSalePrice: baseSale,
            costPrice: Number((baseCost / cleanNewRate).toFixed(2)),
            salePrice: Number((baseSale / cleanNewRate).toFixed(2))
          };
        });
        affectedCount = this.state.products.length;
      } else {
        // Scale product sale & purchase prices proportionally by (newRate / oldRate)
        const ratio = cleanNewRate / oldRate;
        this.state.products = this.state.products.map(p => {
          const nextCost = Number((p.costPrice * ratio).toFixed(2));
          const nextSale = Number((p.salePrice * ratio).toFixed(2));
          const nextBaseCost = Number(((p.baseCostPrice ?? p.costPrice) * ratio).toFixed(4));
          const nextBaseSale = Number(((p.baseSalePrice ?? p.salePrice) * ratio).toFixed(4));
          return {
            ...p,
            costPrice: nextCost,
            salePrice: nextSale,
            baseCostPrice: nextBaseCost,
            baseSalePrice: nextBaseSale
          };
        });
        affectedCount = this.state.products.length;
      }
    }

    if (!this.state.settings.exchangeRateLogs) {
      this.state.settings.exchangeRateLogs = [];
    }
    const pctChange = (((cleanNewRate - oldRate) / oldRate) * 100).toFixed(2);
    this.state.settings.exchangeRateLogs.unshift({
      id: `fx-log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: new Date().toISOString(),
      currencyCode: targetCurr.code,
      currencyName: targetCurr.name,
      oldRate,
      newRate: cleanNewRate,
      affectedProductsCount: affectedCount,
      actionType: 'rate_update',
      notes: `تعديل سعر الصرف يدوياً (${Number(pctChange) >= 0 ? '+' : ''}${pctChange}%) وتحديث أسعار البيع والشراء`
    });

    this.save();
    return {
      success: true,
      message:
        affectedCount > 0
          ? `تم تحديث سعر صرف "${targetCurr.name}" من (${oldRate}) إلى (${cleanNewRate}) وتحديث أسعار البيع والشراء لـ (${affectedCount}) صنف بنجاح!`
          : `تم تحديث سعر صرف "${targetCurr.name}" إلى (${cleanNewRate}) بنجاح!`,
      oldRate,
      newRate: cleanNewRate,
      affectedProductsCount: affectedCount
    };
  }

  /**
   * إضافة عملة جديدة للنظام
   */
  addCurrency(currency: Omit<CurrencyRate, 'id' | 'updatedAt'>): {
    success: boolean;
    message: string;
    currency?: CurrencyRate;
  } {
    const currencies = this.getCurrencies();
    const cleanCode = currency.code.trim().toUpperCase();
    if (!cleanCode || !currency.name.trim() || !currency.symbol.trim()) {
      return { success: false, message: 'يرجى إدخال كود العملة والاسم والرمز بشكل صحيح' };
    }
    if (currencies.some(c => c.code.toUpperCase() === cleanCode)) {
      return { success: false, message: `العملة ذات الكود (${cleanCode}) مضافة مسبقاً في النظام!` };
    }
    if (currency.exchangeRate <= 0) {
      return { success: false, message: 'سعر الصرف يجب أن يكون أكبر من الصفر' };
    }

    const newCurr: CurrencyRate = {
      id: `curr-${cleanCode.toLowerCase()}-${Date.now()}`,
      code: cleanCode,
      name: currency.name.trim(),
      symbol: currency.symbol.trim(),
      exchangeRate: Number(currency.exchangeRate.toFixed(6)),
      isBase: false,
      updatedAt: new Date().toISOString()
    };

    this.state.settings.currencies = [...currencies, newCurr];
    this.save();
    return {
      success: true,
      message: `تمت إضافة عملة "${newCurr.name} (${newCurr.symbol})" بسعر صرف (${newCurr.exchangeRate}) بنجاح!`,
      currency: newCurr
    };
  }

  /**
   * حذف عملة مضافة
   */
  deleteCurrency(code: string): { success: boolean; message: string } {
    const currencies = this.getCurrencies();
    const target = currencies.find(c => c.code.toUpperCase() === code.trim().toUpperCase());
    if (!target) {
      return { success: false, message: 'العملة غير موجودة' };
    }
    if (target.isBase || target.code === this.state.settings.baseCurrency) {
      return { success: false, message: 'لا يمكن حذف العملة الأساسية للنظام!' };
    }
    if (target.code === this.state.settings.activeCurrency) {
      return { success: false, message: 'لا يمكن حذف العملة النشطة حالياً، يرجى التبديل لعملة أخرى أولاً.' };
    }

    this.state.settings.currencies = currencies.filter(c => c.code !== target.code);
    this.save();
    return {
      success: true,
      message: `تم حذف عملة "${target.name}" بنجاح`
    };
  }

  /**
   * تعيين عملة كعملة أساسية مرجعية للنظام (سعر صرفها = 1.0)
   */
  setBaseCurrency(newBaseCode: string): { success: boolean; message: string } {
    const currencies = this.getCurrencies();
    const target = currencies.find(c => c.code.toUpperCase() === newBaseCode.trim().toUpperCase());
    if (!target) {
      return { success: false, message: 'العملة غير موجودة' };
    }

    const pivotRate = target.exchangeRate > 0 ? target.exchangeRate : 1;

    // Recalculate all currencies relative to the new base currency
    this.state.settings.currencies = currencies.map(c => ({
      ...c,
      isBase: c.code === target.code,
      exchangeRate: c.code === target.code ? 1.0 : Number((c.exchangeRate / pivotRate).toFixed(6)),
      updatedAt: new Date().toISOString()
    }));

    // Update product baseCostPrice and baseSalePrice to be expressed in the new base currency
    this.state.products = this.state.products.map(p => ({
      ...p,
      baseCostPrice: Number(((p.baseCostPrice ?? p.costPrice) / pivotRate).toFixed(4)),
      baseSalePrice: Number(((p.baseSalePrice ?? p.salePrice) / pivotRate).toFixed(4))
    }));

    this.state.settings.baseCurrency = target.code;

    // Also switch active currency to match if needed or recalculate active prices
    const activeCurr = this.getActiveCurrency();
    const activeRate = activeCurr.exchangeRate > 0 ? activeCurr.exchangeRate : 1;
    this.state.products = this.state.products.map(p => ({
      ...p,
      costPrice: Number(((p.baseCostPrice || p.costPrice) / activeRate).toFixed(2)),
      salePrice: Number(((p.baseSalePrice || p.salePrice) / activeRate).toFixed(2))
    }));

    this.save();
    return {
      success: true,
      message: `تم تعيين "${target.name} (${target.symbol})" كعملة أساسية مرجعية للنظام وإعادة معايرة أسعار الصرف بنجاح!`
    };
  }

  // ---- Backup & Database Export / Import (database.db) ----
  exportDatabaseFile(): Blob {
    // We format as a structured JSON/SQLite schema dump with binary header for database.db compatibility
    const dbDump = {
      format: 'SQLITE_JSON_DUMP_V1',
      version: 1,
      generatedAt: new Date().toISOString(),
      tables: this.state
    };
    return new Blob([JSON.stringify(dbDump, null, 2)], { type: 'application/json' });
  }

  importDatabaseFile(content: string): boolean {
    try {
      const parsed = JSON.parse(content);
      if (parsed.tables) {
        this.state = parsed.tables;
      } else if (parsed.products && parsed.sales) {
        this.state = parsed;
      } else {
        return false;
      }
      this.save();
      return true;
    } catch (e) {
      console.error('Failed to parse database file:', e);
      return false;
    }
  }

  resetToDefault() {
    this.deletedIds.clear();
    try {
      localStorage.removeItem(DB_DELETED_IDS_KEY);
    } catch {
      // ignore
    }
    this.state = {
      users: defaultUsers,
      products: initialProducts,
      customers: initialCustomers,
      suppliers: initialSuppliers,
      sales: initialSales,
      purchases: [],
      returns: [],
      expenses: initialExpenses,
      installmentPlans: initialInstallmentPlans,
      settings: initialSettings,
      warehouses: initialWarehouses,
      warehouseTransfers: []
    };
    this.save(true);
  }
}

export const db = new LocalDatabase();
