/**
 * @file components/TrialBanner.tsx
 * شريط التنبيه بالفترة التجريبية المتبقية (2 يوم) مع حصر التفعيل بالسيريل
 */

import React from 'react';
import { Clock, Key } from 'lucide-react';
import { LicenseState } from '../utils/licenseManager';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';

interface TrialBannerProps {
  licenseState: LicenseState;
  onOpenActivation: () => void;
}

export const TrialBanner: React.FC<TrialBannerProps> = ({
  licenseState,
  onOpenActivation
}) => {
  const { tr } = useApp();
  const { isAdmin } = useAuth();

  // If activated permanently, don't show the warning banner
  if (licenseState.isActivated) {
    return null;
  }

  const { remainingDays, remainingHours, remainingMinutes, isTrialExpired } = licenseState;

  if (isTrialExpired) {
    return null; // Handled by full-screen modal lock
  }

  // Only show trial banner details & activation trigger to Admin
  if (!isAdmin) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/15 border-b border-amber-300/60 px-4 py-2 flex items-center justify-between text-xs text-amber-900 no-print select-none">
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center shadow-xs">
          <Clock className="w-3.5 h-3.5" />
        </div>
        <div>
          <span className="font-bold">{tr('نسخة تجريبية (متبقي: ', 'Trial Version (Remaining: ')}</span>
          <span className="font-mono font-extrabold text-amber-800">
            {remainingDays > 0 ? tr(`${remainingDays} يوم و `, `${remainingDays}d `) : ''}
            {tr(`${remainingHours} ساعة و ${remainingMinutes} دقيقة`, `${remainingHours}h ${remainingMinutes}m`)}
          </span>
          <span className="font-bold">
            {tr(') — التفعيل متاح عبر إدخال سيريل التفعيل فقط.', ') — Activate via serial key.')}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onOpenActivation}
          className="px-3 py-1 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] flex items-center gap-1 shadow-xs cursor-pointer transition-all"
        >
          <Key className="w-3 h-3" />
          <span>{tr('إدخال سيريل التفعيل', 'Enter Serial Key')}</span>
        </button>
      </div>
    </div>
  );
};
