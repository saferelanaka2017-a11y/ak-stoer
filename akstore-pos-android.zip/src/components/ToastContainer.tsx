/**
 * @file components/ToastContainer.tsx
 * حاوية التنبيهات المنبثقة بتصميم Soft Glass
 * Glass Neumorphic Notification Container
 */

import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast, dir } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div
      className={`fixed bottom-5 ${
        dir === 'rtl' ? 'left-5' : 'right-5'
      } z-[200] flex flex-col gap-2.5 max-w-sm pointer-events-none no-print`}
    >
      {toasts.map(toast => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className="pointer-events-auto neu-card p-3 rounded-2xl flex items-center justify-between gap-3 shadow-xl border border-white/80 animate-in fade-in slide-in-from-bottom-2 duration-200"
          >
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-800">
              {isSuccess && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
              {isError && <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />}
              {!isSuccess && !isError && <Info className="w-4 h-4 text-blue-600 shrink-0" />}
              <span>{toast.message}</span>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
