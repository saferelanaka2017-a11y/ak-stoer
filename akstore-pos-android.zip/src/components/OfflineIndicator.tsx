/**
 * @file components/OfflineIndicator.tsx
 * مؤشر العمل بدون إنترنت والتحقق من اتصال قاعدة البيانات المحلية (IndexedDB + SQLite Offline-First Indicator)
 * يظهر للحظات قصيرة فقط عند تغير حالة الاتصال ثم يختفي تلقائياً حتى لا يغطي أي جزء من الشاشة
 */

import React, { useEffect, useState, useRef } from 'react';
import { WifiOff, Database, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import {
  getLocalDbHealthStatus,
  subscribeToLocalDbHealth,
  LocalDbHealthStatus
} from '../db/database';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [localHealth, setLocalHealth] = useState<LocalDbHealthStatus>(() =>
    getLocalDbHealthStatus()
  );
  const [showReadyToast, setShowReadyToast] = useState(false);
  const [showOfflineBanner, setShowOfflineBanner] = useState(false);
  const prevOfflineRef = useRef<boolean>(false);

  const isCurrentlyOffline = !isOnline || localHealth.networkReachable === false;

  useEffect(() => {
    const unsub = subscribeToLocalDbHealth((status) => {
      setLocalHealth({ ...status });
    });

    const handleOfflineReady = () => {
      if (sessionStorage.getItem('ak_offline_toast_shown') !== '1') {
        sessionStorage.setItem('ak_offline_toast_shown', '1');
        setShowReadyToast(true);
        setTimeout(() => setShowReadyToast(false), 1800);
      }
    };

    if ((window as unknown as { __akOfflineCacheReady?: boolean }).__akOfflineCacheReady) {
      handleOfflineReady();
    }
    window.addEventListener('ak-offline-ready', handleOfflineReady);

    return () => {
      unsub();
      window.removeEventListener('ak-offline-ready', handleOfflineReady);
    };
  }, []);

  // Show the offline notification briefly (1.8s) ONLY when transitioning into offline state, then auto-hide immediately
  useEffect(() => {
    if (isCurrentlyOffline && !prevOfflineRef.current) {
      prevOfflineRef.current = true;
      setShowOfflineBanner(true);
      const timer = setTimeout(() => {
        setShowOfflineBanner(false);
      }, 1800);
      return () => clearTimeout(timer);
    } else if (!isCurrentlyOffline) {
      prevOfflineRef.current = false;
      setShowOfflineBanner(false);
    }
  }, [isCurrentlyOffline]);

  if (!showOfflineBanner && !showReadyToast) return null;

  if (!isCurrentlyOffline && showReadyToast) {
    return (
      <div
        onClick={() => setShowReadyToast(false)}
        className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-2xl bg-emerald-950/95 px-3.5 py-2 text-xs font-bold text-emerald-100 shadow-xl border border-emerald-500/40 backdrop-blur-md cursor-pointer transition-opacity duration-200"
      >
        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        <span>جاهز للعمل أوفلاين 100%</span>
      </div>
    );
  }

  if (!showOfflineBanner) return null;

  return (
    <div
      onClick={() => setShowOfflineBanner(false)}
      className="fixed bottom-4 left-4 z-50 flex flex-wrap items-center gap-2 rounded-2xl bg-slate-900/95 px-3.5 py-2 text-xs font-bold text-white shadow-xl border border-emerald-500/40 backdrop-blur-md cursor-pointer transition-opacity duration-200"
    >
      <span className="flex items-center gap-1.5 text-amber-400">
        <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
        <WifiOff className="w-3.5 h-3.5" />
        <span>وضع الأوفلاين نشط</span>
      </span>
      <span className="text-slate-500">|</span>
      <span className="flex items-center gap-1 text-emerald-400">
        <Database className="w-3.5 h-3.5" />
        <CheckCircle2 className="w-3 h-3" />
        <span>متصل محلياً بقاعدة البيانات</span>
      </span>
    </div>
  );
};
