/**
 * @file pages/ReportsPage.tsx
 * شاشة التقارير التفصيلية والإحصائيات وتصدير إكسل وبي دي إف
 * Reports & Business Analytics with Excel & PDF Export (Admin Only)
 */

import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Download,
  Calendar,
  FileSpreadsheet,
  FileText,
  TrendingUp,
  CreditCard,
  User,
  ShieldAlert,
  ArrowUpRight,
  Printer,
  Trash2,
  PieChart as PieChartIcon,
  Activity,
  Layers
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { exportSalesToExcel, generateSalesReportPDF, exportSalesReportToWord } from '../utils/exportUtils';

export const ReportsPage: React.FC = () => {
  const { sales, expenses, formatCurrency, settings, showToast, refreshData, openInvoiceModal, t, tr, requestConfirm } = useApp();
  const { canViewReports } = useAuth();

  const [dateFilter, setDateFilter] = useState<'today' | 'week' | 'month' | 'all'>('month');
  const [selectedCashier, setSelectedCashier] = useState<string>('all');
  const [chartView, setChartView] = useState<'trend' | 'breakdown'>('trend');
  const [trendPeriod, setTrendPeriod] = useState<'auto' | 'today' | 'month'>('auto');

  // Guard for role
  if (!canViewReports) {
    return (
      <div className="neu-card p-12 rounded-3xl text-center space-y-3">
        <ShieldAlert className="w-12 h-12 text-red-500 mx-auto" />
        <h3 className="text-base font-bold text-slate-800">صلاحية محجوبة</h3>
        <p className="text-xs text-slate-500">
          حساب الكاشير لا يملك صلاحية الاطلاع على تقارير المبيعات والأرباح.
        </p>
      </div>
    );
  }

  // Cashiers list
  const cashiers = useMemo(() => {
    const set = new Set<string>();
    sales.forEach(s => {
      if (s.cashierName) set.add(s.cashierName);
    });
    return Array.from(set);
  }, [sales]);

  // Filtered Sales
  const filteredSales = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    return sales.filter(s => {
      // Cashier filter
      if (selectedCashier !== 'all' && s.cashierName !== selectedCashier) return false;

      const saleDate = new Date(s.date);
      const saleDateStr = s.date.split('T')[0];

      if (dateFilter === 'today') {
        return saleDateStr === todayStr;
      }
      if (dateFilter === 'week') {
        const diffDays = (now.getTime() - saleDate.getTime()) / (1000 * 3600 * 24);
        return diffDays <= 7;
      }
      if (dateFilter === 'month') {
        return saleDate.getMonth() === now.getMonth() && saleDate.getFullYear() === now.getFullYear();
      }
      return true;
    });
  }, [sales, dateFilter, selectedCashier]);

  // Financial totals
  const { totalRevenue, totalTax, totalDiscount, totalCost, netProfit, cashTotal, cardTotal } = useMemo(() => {
    let rev = 0;
    let tax = 0;
    let disc = 0;
    let cost = 0;
    let cash = 0;
    let card = 0;

    filteredSales.forEach(s => {
      rev += s.grandTotal;
      tax += s.taxTotal;
      disc += s.discountTotal;

      if (s.paymentMethod === 'cash') cash += s.grandTotal;
      if (s.paymentMethod === 'card') card += s.grandTotal;

      s.items.forEach(item => {
        cost += (item.product.costPrice || 0) * item.quantity;
      });
    });

    const profit = Math.max(0, rev - cost);

    return {
      totalRevenue: rev,
      totalTax: tax,
      totalDiscount: disc,
      totalCost: cost,
      netProfit: profit,
      cashTotal: cash,
      cardTotal: card
    };
  }, [filteredSales]);

  // Top Products sold
  const topProducts = useMemo(() => {
    const map: { [name: string]: { qty: number; total: number } } = {};
    filteredSales.forEach(s => {
      s.items.forEach(item => {
        const name = item.product.name;
        if (!map[name]) map[name] = { qty: 0, total: 0 };
        map[name].qty += item.quantity;
        map[name].total += item.total;
      });
    });

    return Object.entries(map)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [filteredSales]);

  // 1. Hourly sales data for "Today"
  const hourlyData = useMemo(() => {
    const hoursMap: { [hour: string]: { label: string; hourNum: number; sales: number; profit: number; count: number } } = {};
    for (let h = 8; h <= 23; h++) {
      const label = `${h.toString().padStart(2, '0')}:00`;
      hoursMap[label] = { label, hourNum: h, sales: 0, profit: 0, count: 0 };
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const targetSales = dateFilter === 'today' 
      ? filteredSales 
      : sales.filter(s => s.date.startsWith(todayStr));

    targetSales.forEach(s => {
      const d = new Date(s.date);
      const h = d.getHours();
      const label = `${h.toString().padStart(2, '0')}:00`;
      if (!hoursMap[label]) {
        hoursMap[label] = { label, hourNum: h, sales: 0, profit: 0, count: 0 };
      }
      hoursMap[label].sales += s.grandTotal;
      hoursMap[label].count += 1;
      let cost = 0;
      s.items.forEach(it => { cost += (it.product.costPrice || 0) * it.quantity; });
      hoursMap[label].profit += Math.max(0, s.grandTotal - cost);
    });

    return Object.values(hoursMap).sort((a, b) => a.hourNum - b.hourNum);
  }, [sales, filteredSales, dateFilter]);

  // 2. Monthly / Daily sales data for "This Month"
  const monthlyData = useMemo(() => {
    const daysMap: { [day: string]: { label: string; dayNum: number; sales: number; profit: number; count: number } } = {};
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

    for (let day = 1; day <= daysInMonth; day++) {
      const label = day < 10 ? `0${day}` : `${day}`;
      daysMap[label] = { label, dayNum: day, sales: 0, profit: 0, count: 0 };
    }

    const monthSales = (dateFilter === 'month')
      ? filteredSales
      : sales.filter(s => {
          const d = new Date(s.date);
          return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
        });

    monthSales.forEach(s => {
      const d = new Date(s.date);
      const day = d.getDate();
      const label = day < 10 ? `0${day}` : `${day}`;
      if (daysMap[label]) {
        daysMap[label].sales += s.grandTotal;
        daysMap[label].count += 1;
        let cost = 0;
        s.items.forEach(it => { cost += (it.product.costPrice || 0) * it.quantity; });
        daysMap[label].profit += Math.max(0, s.grandTotal - cost);
      }
    });

    return Object.values(daysMap).sort((a, b) => a.dayNum - b.dayNum);
  }, [sales, filteredSales, dateFilter]);

  // 3. Payment methods breakdown data
  const paymentMethodsData = useMemo(() => {
    let cash = 0;
    let card = 0;
    let split = 0;
    let credit = 0;

    filteredSales.forEach(s => {
      if (s.paymentMethod === 'cash') cash += s.grandTotal;
      else if (s.paymentMethod === 'card') card += s.grandTotal;
      else if (s.paymentMethod === 'split') split += s.grandTotal;
      else credit += s.grandTotal;
    });

    const data = [
      { name: 'نقداً (Cash)', value: Math.round(cash * 100) / 100, color: '#10b981' },
      { name: 'شبكة / بطاقة (Card)', value: Math.round(card * 100) / 100, color: '#3b82f6' },
      { name: 'دفع متعدد (Split)', value: Math.round(split * 100) / 100, color: '#8b5cf6' },
      { name: 'آجل / تقسيط (Credit)', value: Math.round(credit * 100) / 100, color: '#f59e0b' }
    ].filter(item => item.value > 0);

    return data.length > 0 ? data : [{ name: 'لا توجد مبيعات', value: 1, color: '#cbd5e1' }];
  }, [filteredSales]);

  // 4. Top products chart data
  const topProductsChartData = useMemo(() => {
    return topProducts.map(p => ({
      name: p.name.length > 18 ? p.name.slice(0, 16) + '...' : p.name,
      fullName: p.name,
      total: p.total,
      qty: p.qty
    }));
  }, [topProducts]);

  // Determine active timeline mode
  const isViewingToday = (trendPeriod === 'today') || (trendPeriod === 'auto' && dateFilter === 'today');
  const activeTimelineData: { label: string; sales: number; profit: number; count: number }[] = (isViewingToday ? hourlyData : monthlyData) as any;

  const handleExportPDF = async () => {
    try {
      showToast('جاري إنشاء تقرير المبيعات بدعم كامل للغة العربية...', 'info');
      await generateSalesReportPDF({
        sales: filteredSales,
        settings,
        totals: { totalRevenue, totalTax, totalDiscount, totalCost, netProfit, cashTotal, cardTotal },
        topProducts
      });
      showToast('تم تصدير تقرير المبيعات PDF بنجاح بحروف عربية واضحة!', 'success');
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء تصدير التقرير، يرجى المحاولة مرة أخرى', 'error');
    }
  };

  const handleDeleteSale = (id: string, invoiceNum: string) => {
    requestConfirm({
      title: 'حذف فاتورة المبيعات',
      message: `هل أنت متأكد من حذف الفاتورة رقم: "${invoiceNum}"؟ لن يتم التراجع عن هذا الإجراء وسيتم تعديل الإحصائيات.`,
      confirmText: 'نعم، حذف الفاتورة',
      onConfirm: () => {
        db.deleteSale(id);
        showToast('تم حذف الفاتورة بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrintInvoice = (invoice: any) => {
    openInvoiceModal(invoice);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>{tr('التقارير المالية والتحليلية', 'Financial & Business Analytics Reports')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('تحليل المبيعات، الأرباح، أداء الكاشير، وتصدير التقارير الرسمية', 'Analyze sales, net profit, cashier performance, and export official reports')}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => exportSalesToExcel(filteredSales)}
            className="neu-button px-3 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>{t('exportExcel')}</span>
          </button>
          <button
            onClick={() => {
              showToast(tr('جاري تصدير التقرير كملف Word (.doc)...', 'Exporting report as Word (.doc)...'), 'info');
              exportSalesReportToWord(filteredSales, settings);
              showToast(tr('تم تصدير التقرير بتنسيق Word بنجاح!', 'Report exported to Word successfully!'), 'success');
            }}
            className="neu-button px-3 py-2 rounded-xl flex items-center gap-1.5 text-xs font-bold text-blue-700 bg-blue-50/50 hover:bg-blue-100/50 cursor-pointer border border-blue-200"
          >
            <FileText className="w-3.5 h-3.5 text-blue-600" />
            <span>{tr('تصدير Word (.doc)', 'Export Word (.doc)')}</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="neu-button-primary px-3.5 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{t('exportPdf')}</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="neu-card p-4 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex p-1 neu-pressed rounded-2xl w-full sm:w-auto">
          <button
            onClick={() => setDateFilter('today')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              dateFilter === 'today' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('اليوم', 'Today')}
          </button>
          <button
            onClick={() => setDateFilter('week')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              dateFilter === 'week' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('آخر 7 أيام', 'Last 7 Days')}
          </button>
          <button
            onClick={() => setDateFilter('month')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              dateFilter === 'month' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('هذا الشهر', 'This Month')}
          </button>
          <button
            onClick={() => setDateFilter('all')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              dateFilter === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('كافة الفترات', 'All Time')}
          </button>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 font-semibold whitespace-nowrap">{tr('الكاشير:', 'Cashier:')}</span>
          <select
            value={selectedCashier}
            onChange={(e) => setSelectedCashier(e.target.value)}
            className="neu-input px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700"
          >
            <option value="all">{tr('كافة المستخدمين', 'All Users')}</option>
            {cashiers.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">{tr('إجمالي المبيعات', 'Total Revenue')}</span>
          <span className="text-xl font-black text-slate-800 tabular-nums">
            {formatCurrency(totalRevenue)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">
            {tr(`عدد الفواتير: ${filteredSales.length}`, `Invoices: ${filteredSales.length}`)}
          </span>
        </div>

        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">{tr('صافي الأرباح المقدرة', 'Estimated Net Profit')}</span>
          <span className="text-xl font-black text-emerald-600 tabular-nums">
            {formatCurrency(netProfit)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">
            تكلفة البضاعة: {formatCurrency(totalCost)}
          </span>
        </div>

        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">ضريبة القيمة المضافة</span>
          <span className="text-xl font-black text-blue-600 tabular-nums">
            {formatCurrency(totalTax)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">
            النسبة المقررة: {settings.vatPercentage}%
          </span>
        </div>

        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">طرق التحصيل</span>
          <span className="text-xs font-bold text-slate-700 block">
            نقداً: <span className="tabular-nums text-emerald-600">{formatCurrency(cashTotal)}</span>
          </span>
          <span className="text-xs font-bold text-slate-700 block mt-1">
            شبكة/بطاقة: <span className="tabular-nums text-blue-600">{formatCurrency(cardTotal)}</span>
          </span>
        </div>
      </div>

      {/* VISUAL CHARTS SECTION (Recharts Financial Analytics) */}
      <div className="neu-card p-5 rounded-3xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-100/80 flex items-center justify-center text-blue-700">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-slate-800 text-sm">
                التصور البياني للمبيعات والأداء المالي
              </h3>
              <p className="text-[11px] text-slate-400">
                متابعة دقيقة ومباشرة لمبيعات اليوم والشهر بواسطة الرسوم البيانية التفاعلية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* View switcher */}
            <div className="neu-flat p-1 rounded-xl flex items-center gap-1 text-xs">
              <button
                type="button"
                onClick={() => setChartView('trend')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  chartView === 'trend'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-600'
                }`}
              >
                مسار المبيعات والأرباح
              </button>
              <button
                type="button"
                onClick={() => setChartView('breakdown')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  chartView === 'breakdown'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-600'
                }`}
              >
                طرق الدفع والأصناف
              </button>
            </div>

            {/* If trend view, choose period */}
            {chartView === 'trend' && (
              <div className="flex items-center gap-1 neu-pressed px-2 py-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setTrendPeriod('today')}
                  className={`px-2 py-0.5 rounded-lg transition-all cursor-pointer ${
                    isViewingToday ? 'bg-white text-blue-600 shadow-2xs font-bold' : 'text-slate-500'
                  }`}
                >
                  اليوم (بالساعات)
                </button>
                <button
                  type="button"
                  onClick={() => setTrendPeriod('month')}
                  className={`px-2 py-0.5 rounded-lg transition-all cursor-pointer ${
                    !isViewingToday ? 'bg-white text-blue-600 shadow-2xs font-bold' : 'text-slate-500'
                  }`}
                >
                  الشهر (بالأيام)
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Chart View 1: Timeline Trend (AreaChart) */}
        {chartView === 'trend' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500 px-1">
              <span className="font-semibold">
                {isViewingToday
                  ? 'رسم بياني يوضح مبيعات اليوم موزعة بالساعات من الصباح وحتى المساء'
                  : 'رسم بياني يوضح تطور المبيعات وصافي الأرباح يوماً بيوم خلال الشهر الحالي'}
              </span>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 font-bold text-blue-600 text-[11px]">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
                  إجمالي المبيعات
                </span>
                <span className="flex items-center gap-1 font-bold text-emerald-600 text-[11px]">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
                  صافي الأرباح
                </span>
              </div>
            </div>

            <div className="w-full h-72 pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={activeTimelineData}
                  margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis
                    dataKey="label"
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    axisLine={{ stroke: '#cbd5e1' }}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      borderRadius: '16px',
                      border: '1px solid rgba(226, 232, 240, 0.8)',
                      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
                      fontSize: '12px',
                      direction: 'rtl',
                      textAlign: 'right'
                    }}
                    formatter={(val: unknown, name: unknown) => [
                      formatCurrency(Number(val) || 0),
                      name === 'sales' ? 'إجمالي المبيعات' : name === 'profit' ? 'صافي الأرباح' : String(name)
                    ]}
                    labelFormatter={(label) =>
                      isViewingToday ? `الساعة: ${label}` : `اليوم: ${label} من الشهر`
                    }
                  />
                  <Area
                    type="monotone"
                    dataKey="sales"
                    stroke="#2563eb"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#salesGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="profit"
                    stroke="#059669"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#profitGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Chart View 2: Breakdown (Pie & Bar) */}
        {chartView === 'breakdown' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            {/* Payment Methods Donut */}
            <div className="neu-flat p-4 rounded-2xl flex flex-col items-center justify-between">
              <div className="w-full flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                  <PieChartIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>توزيع طرق الدفع (نقداً / شبكة / تقسيط)</span>
                </span>
                <span className="text-[10px] text-slate-400">إجمالي: {formatCurrency(totalRevenue)}</span>
              </div>

              <div className="w-full h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={paymentMethodsData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={3}
                    >
                      {paymentMethodsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        borderRadius: '12px',
                        border: '1px solid #e2e8f0',
                        fontSize: '11px',
                        direction: 'rtl'
                      }}
                      formatter={(val: unknown) => [formatCurrency(Number(val) || 0), 'القيمة']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="w-full grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/50 text-[11px]">
                {paymentMethodsData.map((pm, idx) => (
                  <div key={idx} className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: pm.color }}></span>
                    <span className="text-slate-600 truncate">{pm.name}:</span>
                    <span className="font-bold tabular-nums text-slate-800">{formatCurrency(pm.value)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Products Horizontal Bars */}
            <div className="neu-flat p-4 rounded-2xl flex flex-col justify-between">
              <div className="w-full flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                  <BarChart3 className="w-3.5 h-3.5 text-blue-600" />
                  <span>الأصناف الأعلى إيراداً (Top Products)</span>
                </span>
                <span className="text-[10px] text-slate-400">أعلى 5 أصناف</span>
              </div>

              <div className="w-full h-52">
                {topProductsChartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={topProductsChartData}
                      layout="vertical"
                      margin={{ top: 5, right: 10, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                      <XAxis
                        type="number"
                        stroke="#94a3b8"
                        fontSize={10}
                        tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)}
                      />
                      <YAxis
                        type="category"
                        dataKey="name"
                        stroke="#64748b"
                        fontSize={10}
                        tickLine={false}
                        axisLine={false}
                        width={90}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'rgba(255, 255, 255, 0.95)',
                          borderRadius: '12px',
                          border: '1px solid #e2e8f0',
                          fontSize: '11px',
                          direction: 'rtl'
                        }}
                        formatter={(val: unknown, _: unknown, item: { payload?: { fullName?: string; qty?: number } }) => [
                          `${formatCurrency(Number(val) || 0)} (${item.payload?.qty || 0} قطعة)`,
                          'الإيراد'
                        ]}
                      />
                      <Bar
                        dataKey="total"
                        name="إجمالي الإيراد"
                        fill="#3b82f6"
                        radius={[0, 8, 8, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-xs text-slate-400">
                    لا توجد بيانات للأصناف في الفترة المحددة
                  </div>
                )}
              </div>

              <div className="text-[10px] text-slate-400 text-center pt-2 border-t border-slate-200/50">
                مرتبة تنازلياً حسب إجمالي الإيراد المحقق
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Detailed Sales & Top Products */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Table */}
        <div className="lg:col-span-2 neu-card p-5 rounded-3xl">
          <h3 className="font-bold text-slate-800 text-sm mb-3">
            سجل الفواتير المنفذة ({filteredSales.length})
          </h3>

          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-right text-xs">
              <thead className="sticky top-0 bg-white/90 backdrop-blur-sm border-b border-slate-200 text-slate-500">
                <tr>
                  <th className="pb-2">رقم الفاتورة</th>
                  <th className="pb-2">التاريخ</th>
                  <th className="pb-2">الكاشير</th>
                  <th className="pb-2 text-left">الإجمالي</th>
                  <th className="pb-2 text-center">طريقة الدفع</th>
                  <th className="pb-2 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSales.map(s => (
                  <tr key={s.id} className="hover:bg-slate-50/50">
                    <td className="py-2.5 font-mono font-bold text-blue-700">{s.invoiceNumber}</td>
                    <td className="py-2.5 text-slate-500 tabular-nums">
                      {new Date(s.date).toLocaleDateString('ar-SA')}
                    </td>
                    <td className="py-2.5 text-slate-700 font-medium">{s.cashierName}</td>
                    <td className="py-2.5 text-left font-black tabular-nums">{formatCurrency(s.grandTotal)}</td>
                    <td className="py-2.5 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {s.paymentMethod === 'cash' ? 'نقداً' : s.paymentMethod === 'card' ? 'بطاقة' : 'متعدد'}
                      </span>
                    </td>
                    <td className="py-2.5 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          onClick={() => handlePrintInvoice(s)}
                          className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                          title="طباعة الفاتورة"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSale(s.id, s.invoiceNumber)}
                          className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          title="حذف الفاتورة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Products */}
        <div className="neu-card p-5 rounded-3xl">
          <h3 className="font-bold text-slate-800 text-sm mb-3">
            الأصناف الأكثر مبيعاً
          </h3>

          <div className="space-y-3">
            {topProducts.map((p, idx) => (
              <div key={idx} className="neu-flat p-3 rounded-2xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800 block">{p.name}</span>
                  <span className="text-[10px] text-slate-500">الكمية المباعة: {p.qty} حبة</span>
                </div>
                <span className="font-black text-blue-600 tabular-nums">
                  {formatCurrency(p.total)}
                </span>
              </div>
            ))}

            {topProducts.length === 0 && (
              <div className="py-8 text-center text-xs text-slate-400">
                لا توجد مبيعات في الفترة المحددة
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
