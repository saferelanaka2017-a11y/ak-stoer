/**
 * @file hooks/useBarcodeScanner.ts
 * خطاف الاستماع المباشر والشامل لقارئات الباركود الخارجية (USB / Bluetooth / Wireless HID)
 * يدعم جميع أجهزة القراءة الآلية مع أو بدون مفتاح Enter (Enter Suffix & Timeout Fallback)
 * مع توليد نغمة صوتية فورية (Scanner Beep) لتأكيد المسح كأنظمة الكاشير العالمية
 */

import { useEffect, useRef } from 'react';

interface BarcodeScannerOptions {
  onScan: (barcode: string) => void;
  minChars?: number;
  maxIntervalMs?: number;
  enabled?: boolean;
  enableTimeoutCommit?: boolean;
}

/**
 * تشغيل نغمة صوتية واقعية لقارئ الباركود عبر Web Audio API
 */
export function playScannerBeep(type: 'success' | 'error' = 'success') {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'success') {
      // Crisp high-frequency supermarket checkout beep (1850Hz)
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1850, ctx.currentTime);
      gain.gain.setValueAtTime(0.16, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.08);
    } else {
      // Low dual warning beep (320Hz)
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(320, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.22);
    }

    setTimeout(() => {
      ctx.close().catch(() => {});
    }, 350);
  } catch (e) {
    console.debug('Audio beep omitted:', e);
  }
}

export function useBarcodeScanner({
  onScan,
  minChars = 3,
  maxIntervalMs = 70,
  enabled = true,
  enableTimeoutCommit = true
}: BarcodeScannerOptions) {
  const bufferRef = useRef<string>('');
  const lastTimeRef = useRef<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const onScanRef = useRef(onScan);

  // Keep callback reference updated without triggering effect cleanup
  useEffect(() => {
    onScanRef.current = onScan;
  }, [onScan]);

  useEffect(() => {
    if (!enabled) return;

    const clearScanTimeout = () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };

    const commitBarcode = (code: string, originEvent?: KeyboardEvent) => {
      clearScanTimeout();
      const cleanCode = code.trim();
      bufferRef.current = '';

      if (cleanCode.length >= minChars) {
        if (originEvent) {
          originEvent.preventDefault();
          originEvent.stopPropagation();
        }

        // If an input is currently active and contains the scanned code, clear it
        const activeEl = document.activeElement as HTMLElement | null;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
          const input = activeEl as HTMLInputElement;
          if (input.value && (input.value.includes(cleanCode) || input.getAttribute('data-barcode-scanner') === 'true')) {
            input.value = '';
            input.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }

        onScanRef.current(cleanCode);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore modifier keys
      if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock', 'Tab'].includes(e.key)) {
        return;
      }

      const now = Date.now();
      const interval = now - lastTimeRef.current;
      lastTimeRef.current = now;

      // When Enter or Carriage Return arrives (standard scanner suffix)
      if (e.key === 'Enter' || e.key === 'NumpadEnter') {
        const rawBuffer = bufferRef.current.trim();

        // 1. If buffer has collected characters at scanner speed
        if (rawBuffer.length >= minChars) {
          commitBarcode(rawBuffer, e);
          return;
        }

        // 2. If the user was focused on the barcode search input and pressed Enter
        const activeEl = document.activeElement as HTMLElement | null;
        const isBarcodeInput =
          activeEl?.getAttribute('data-barcode-scanner') === 'true' ||
          activeEl?.id === 'barcode-search-input';

        if (isBarcodeInput && activeEl && 'value' in activeEl) {
          const val = String((activeEl as HTMLInputElement).value || '').trim();
          if (val.length >= minChars) {
            commitBarcode(val, e);
            return;
          }
        }

        bufferRef.current = '';
        return;
      }

      // Check current focus
      const activeEl = document.activeElement as HTMLElement | null;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');
      const isBarcodeInput =
        activeEl?.getAttribute('data-barcode-scanner') === 'true' ||
        activeEl?.id === 'barcode-search-input';

      // If user is typing manually in a regular input/textarea (not the barcode input)
      // and keystroke speed is slow (human typing > maxIntervalMs), ignore from buffer
      if (isInput && !isBarcodeInput && interval > maxIntervalMs) {
        clearScanTimeout();
        bufferRef.current = '';
        return;
      }

      // Handle printable characters
      if (e.key.length === 1) {
        // If delay between characters is too long for a scanner, reset buffer to current char
        if (interval > maxIntervalMs) {
          bufferRef.current = e.key;
        } else {
          bufferRef.current += e.key;
        }

        // If scanning outside of an input, stop propagation to prevent unwanted browser hotkeys
        if (!isInput && bufferRef.current.length >= 2) {
          e.stopPropagation();
        }

        // Fallback for barcode scanners configured WITHOUT an Enter suffix:
        // If characters arrive rapidly and pause for > 95ms, commit automatically!
        if (enableTimeoutCommit) {
          clearScanTimeout();
          timeoutRef.current = setTimeout(() => {
            const currentBuffered = bufferRef.current.trim();
            if (currentBuffered.length >= minChars) {
              commitBarcode(currentBuffered);
            } else {
              bufferRef.current = '';
            }
          }, 95);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => {
      clearScanTimeout();
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [enabled, minChars, maxIntervalMs, enableTimeoutCommit]);
}
