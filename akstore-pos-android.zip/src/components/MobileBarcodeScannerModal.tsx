/**
 * @file components/MobileBarcodeScannerModal.tsx
 * نافذة مسح الباركود الذكية عبر كاميرا اللاب توب أو كاميرا الموبايل
 * Laptop Webcam & Mobile Camera Barcode Scanner with Macro Digital Zoom, 1D Unsharp Enhancer & Wireless QR Bridge
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import QRCode from 'qrcode';
import {
  Camera,
  Smartphone,
  Laptop,
  X,
  RefreshCw,
  Zap,
  ZapOff,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Repeat,
  ScanLine,
  Plus,
  QrCode,
  Wifi,
  Copy,
  Check,
  Send,
  Barcode,
  ZoomIn,
  FlipHorizontal,
  Sparkles
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { playScannerBeep } from '../hooks/useBarcodeScanner';
import {
  openCameraStreamWithFallback,
  setStreamTorch,
  decodeVideoFrame,
  decodeBarcodeFromImageFile,
  getOrCreatePosScannerSessionId,
  subscribeToMobileScannerSession
} from '../utils/barcodeDecoderEngine';

interface MobileBarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
  title?: string;
  subtitle?: string;
  /** If true, keeps the scanner open after scanning so user can scan multiple items in a row */
  defaultContinuous?: boolean;
}

interface ScannedLogItem {
  code: string;
  time: string;
  count: number;
}

type ScannerTabMode = 'live-camera' | 'wireless-qr' | 'photo-manual';

export const MobileBarcodeScannerModal: React.FC<MobileBarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title,
  subtitle,
  defaultContinuous = true
}) => {
  const { tr, products, showToast } = useApp();

  const [activeMode, setActiveMode] = useState<ScannerTabMode>('live-camera');
  const [isContinuous, setIsContinuous] = useState<boolean>(defaultContinuous);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [isStarting, setIsStarting] = useState<boolean>(false);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [torchSupported, setTorchSupported] = useState<boolean>(false);
  const [torchOn, setTorchOn] = useState<boolean>(false);
  const [scanFlash, setScanFlash] = useState<boolean>(false);
  const [scannedHistory, setScannedHistory] = useState<ScannedLogItem[]>([]);
  const [isScanningFile, setIsScanningFile] = useState<boolean>(false);
  const [manualCodeInput, setManualCodeInput] = useState<string>('');

  // Laptop Webcam & Macro Barcode Controls
  const [digitalZoom, setDigitalZoom] = useState<number>(1.5);
  const [enhanceForLaptop, setEnhanceForLaptop] = useState<boolean>(true);
  const [mirrorVideo, setMirrorVideo] = useState<boolean>(false);
  const [isLaptopCamDetected, setIsLaptopCamDetected] = useState<boolean>(false);

  // Wireless Phone-to-PC QR Bridge State
  const [sessionId] = useState<string>(() => getOrCreatePosScannerSessionId());
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [mobileConnected, setMobileConnected] = useState<boolean>(false);
  const [mobileDeviceName, setMobileDeviceName] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const lastScanRef = useRef<{ code: string; timestamp: number }>({ code: '', timestamp: 0 });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const onScanRef = useRef(onScan);
  const isContinuousRef = useRef(isContinuous);
  const isDecodingFrameRef = useRef<boolean>(false);

  useEffect(() => {
    onScanRef.current = onScan;
  }, [onScan]);

  useEffect(() => {
    isContinuousRef.current = isContinuous;
  }, [isContinuous]);

  useEffect(() => {
    setIsContinuous(defaultContinuous);
  }, [defaultContinuous, isOpen]);

  const mobileScannerUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}${window.location.pathname}?scannerSession=${encodeURIComponent(sessionId)}`
      : '';

  // Generate QR Code DataURL for Phone-to-PC Pairing
  useEffect(() => {
    if (!isOpen || !mobileScannerUrl) return;
    QRCode.toDataURL(mobileScannerUrl, {
      width: 240,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => setQrDataUrl(''));
  }, [isOpen, mobileScannerUrl]);

  // Stop active camera stream cleanly
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsStreaming(false);
    setTorchOn(false);
    setTorchSupported(false);
  }, []);

  // Trigger barcode read result with sound, haptic vibration, and cooldown protection
  const handleDecodedBarcode = useCallback(
    (decodedText: string, bypassCooldown = false) => {
      const cleanCode = decodedText.trim();
      if (!cleanCode) return;

      const now = Date.now();
      if (
        !bypassCooldown &&
        lastScanRef.current.code === cleanCode &&
        now - lastScanRef.current.timestamp < 1300
      ) {
        return;
      }

      lastScanRef.current = { code: cleanCode, timestamp: now };

      // Audio + Haptic feedback
      playScannerBeep('success');
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(100);
        } catch {
          // ignore
        }
      }

      // Visual green flash on viewfinder
      setScanFlash(true);
      setTimeout(() => setScanFlash(false), 450);

      // Update scanned history log inside modal
      setScannedHistory((prev) => {
        const existingIdx = prev.findIndex((item) => item.code === cleanCode);
        const timeStr = new Date().toLocaleTimeString('ar-EG', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });
        if (existingIdx > -1) {
          const updated = [...prev];
          const item = updated[existingIdx];
          updated.splice(existingIdx, 1);
          return [{ code: cleanCode, time: timeStr, count: item.count + 1 }, ...updated];
        }
        return [{ code: cleanCode, time: timeStr, count: 1 }, ...prev.slice(0, 9)];
      });

      // Emit barcode to parent page
      onScanRef.current(cleanCode);

      // If single scan mode, close modal automatically
      if (!isContinuousRef.current) {
        stopCamera();
        onClose();
      }
    },
    [onClose, stopCamera]
  );

  // Start live camera stream (Laptop webcam or Mobile camera)
  const startCamera = useCallback(
    async (preferredCamId?: string, preferredFacing?: 'environment' | 'user') => {
      if (!isOpen) return;
      setIsStarting(true);
      setCameraError(null);
      stopCamera();

      try {
        const {
          stream,
          cameras: detectedCams,
          torchSupported: hasTorch,
          isFrontOrLaptopCam
        } = await openCameraStreamWithFallback(preferredCamId, preferredFacing || facingMode);

        streamRef.current = stream;
        if (detectedCams.length > 0) {
          setCameras(detectedCams);
        }
        setTorchSupported(hasTorch);
        setIsLaptopCamDetected(isFrontOrLaptopCam);
        if (isFrontOrLaptopCam) {
          setMirrorVideo(true);
          setEnhanceForLaptop(true);
        }

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
        setIsStreaming(true);
      } catch (err: unknown) {
        setIsStreaming(false);
        const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
        if (msg.includes('permission') || msg.includes('notallowed')) {
          setCameraError(
            tr(
              'تم حظر صلاحية الكاميرا في المتصفح. يرجى السماح للمتصفح باستخدام الكاميرا من شريط العنوان بالأعلى، أو استخدم تبويب "ربط الموبايل عبر QR".',
              'Camera permission was denied. Please allow camera access in the address bar, or use the "Pair Phone via QR" tab.'
            )
          );
        } else {
          setCameraError(
            tr(
              'تعذر الوصول لكاميرا الجهاز (قد تكون الكاميرا مغلقة أو مستخدمة في برنامج آخر). تأكد من توصيل الكاميرا واضغط "إعادة محاولة الكاميرا".',
              'Could not access the camera (it may be disabled or in use by another app). Click "Retry Camera" below.'
            )
          );
        }
      } finally {
        setIsStarting(false);
      }
    },
    [facingMode, isOpen, stopCamera, tr]
  );

  // Manage camera lifecycle when modal opens/closes or tab changes
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    if (activeMode === 'live-camera') {
      const timer = setTimeout(() => {
        startCamera(selectedCameraId || undefined, facingMode);
      }, 60);
      return () => {
        clearTimeout(timer);
        stopCamera();
      };
    } else {
      stopCamera();
    }
  }, [isOpen, activeMode, selectedCameraId, facingMode, startCamera, stopCamera]);

  // Fast 10 FPS continuous live video frame barcode decoding loop (Laptop & Mobile)
  useEffect(() => {
    if (!isOpen || activeMode !== 'live-camera' || !isStreaming) return;
    let cycle = 0;

    const interval = setInterval(async () => {
      if (isDecodingFrameRef.current) return;
      const videoEl = videoRef.current;
      if (!videoEl || videoEl.readyState < 2) return;

      if (!canvasRef.current) {
        canvasRef.current = document.createElement('canvas');
      }

      isDecodingFrameRef.current = true;
      cycle += 1;
      try {
        const decoded = await decodeVideoFrame(videoEl, canvasRef.current, {
          digitalZoom,
          enhanceForLaptop,
          scanCycle: cycle
        });
        if (decoded) {
          handleDecodedBarcode(decoded, false);
        }
      } finally {
        isDecodingFrameRef.current = false;
      }
    }, 110);

    return () => clearInterval(interval);
  }, [isOpen, activeMode, isStreaming, digitalZoom, enhanceForLaptop, handleDecodedBarcode]);

  // Manual instant multi-zoom deep scan of current laptop webcam frame
  const handleInstantSnapScan = async () => {
    const videoEl = videoRef.current;
    if (!videoEl || videoEl.readyState < 2) return;
    if (!canvasRef.current) {
      canvasRef.current = document.createElement('canvas');
    }

    // Try multiple zoom levels (1x, 1.5x, 2x, 2.5x) and both mirror states immediately
    for (const testZoom of [digitalZoom, 1.5, 2.0, 1.0, 2.5]) {
      for (const testCycle of [0, 1]) {
        const res = await decodeVideoFrame(videoEl, canvasRef.current, {
          digitalZoom: testZoom,
          enhanceForLaptop: true,
          scanCycle: testCycle
        });
        if (res) {
          handleDecodedBarcode(res, true);
          return;
        }
      }
    }

    showToast(
      tr(
        'قرّب الباركود قليلاً داخل المستطيل الأخضر في إضاءة جيدة (مسافة 15–25 سم من كاميرا اللاب)',
        'Hold the barcode steadily inside the green box (15–25 cm from laptop camera)'
      ),
      'info'
    );
  };

  // Subscribe to Wireless Mobile-to-PC Session while modal is open
  useEffect(() => {
    if (!isOpen) return;
    const unsubscribe = subscribeToMobileScannerSession(sessionId, {
      onBarcodeScanned: (barcode) => {
        handleDecodedBarcode(barcode, true);
      },
      onMobileStatusChange: (connected, devName) => {
        setMobileConnected(connected);
        if (devName) setMobileDeviceName(devName);
      }
    });
    return () => unsubscribe();
  }, [isOpen, sessionId, handleDecodedBarcode]);

  // Toggle Rear / Front camera
  const handleSwitchCamera = async () => {
    if (cameras.length > 1) {
      const currentIdx = cameras.findIndex((c) => c.id === selectedCameraId);
      const nextIdx = (currentIdx + 1) % cameras.length;
      const nextCam = cameras[nextIdx];
      setSelectedCameraId(nextCam.id);
    } else {
      const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
      setFacingMode(nextFacing);
      setSelectedCameraId('');
    }
  };

  // Toggle Flash / Torch
  const handleToggleTorch = async () => {
    const nextState = await setStreamTorch(streamRef.current, !torchOn);
    setTorchOn(nextState);
  };

  // Scan barcode from captured photo or uploaded image
  const handleScanImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanningFile(true);
    setCameraError(null);

    try {
      const decodedText = await decodeBarcodeFromImageFile(file);
      if (decodedText) {
        handleDecodedBarcode(decodedText, true);
      } else {
        playScannerBeep('error');
        setCameraError(
          tr(
            'لم يتم العثور على باركود واضح في الصورة. يرجى تقريب الباركود في إضاءة جيدة أو اختيار الصنف من القائمة السريعة.',
            'No clear barcode was detected in the image. Please hold the barcode closer with good lighting.'
          )
        );
      }
    } finally {
      setIsScanningFile(false);
      e.target.value = '';
    }
  };

  const handleCopyMobileLink = async () => {
    if (!mobileScannerUrl) return;
    try {
      await navigator.clipboard.writeText(mobileScannerUrl);
      setCopiedLink(true);
      showToast(
        tr('تم نسخ رابط قارئ الموبايل! افتحه على هاتفك لبدء المسح', 'Copied mobile scanner link! Open it on your phone to scan'),
        'success'
      );
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleCloseModal = () => {
    stopCamera();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/65 backdrop-blur-xs overflow-y-auto">
      <div className="neu-card rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl border border-white/70 flex flex-col max-h-[95vh]">
        {/* Modal Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-200/80 flex items-center justify-between gap-2 bg-gradient-to-l from-emerald-50/70 via-white to-blue-50/70">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/25 shrink-0">
              {isLaptopCamDetected ? <Laptop className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
            </div>
            <div className="min-w-0">
              <h3 className="font-extrabold text-slate-800 text-sm truncate flex items-center gap-1.5">
                <span>
                  {title ||
                    tr(
                      'مسح الباركود بكاميرا اللاب توب أو الموبايل',
                      'Laptop Webcam & Mobile Barcode Scanner'
                    )}
                </span>
                {isLaptopCamDetected && (
                  <span className="text-[10px] font-bold text-blue-600">
                    · {tr('وضع كاميرا اللاب HD نشط', 'Laptop HD Mode')}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500 truncate">
                {subtitle ||
                  tr(
                    'تم تفعيل مُحسّن التركيز الرقمي وتوضيح خطوط الباركود لتقرأ كاميرا اللاب توب والموبايل فوراً',
                    'Digital macro zoom & 1D bar sharpener enabled for instant laptop webcam & mobile scanning'
                  )}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCloseModal}
            className="neu-button p-2 rounded-xl text-slate-500 hover:text-red-600 cursor-pointer shrink-0"
            title={tr('إغلاق النافذة', 'Close Scanner')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 3-Mode Interactive Switcher Tabs */}
        <div className="px-4 pt-3">
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl neu-pressed">
            <button
              type="button"
              onClick={() => setActiveMode('live-camera')}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeMode === 'live-camera'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Laptop className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{tr('كاميرا اللاب / الموبايل', 'Laptop / Mobile Cam')}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveMode('wireless-qr')}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeMode === 'wireless-qr'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <QrCode className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{tr('ربط الموبايل (QR)', 'Pair Phone (QR)')}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveMode('photo-manual')}
              className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeMode === 'photo-manual'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Barcode className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{tr('تصوير / باركود سريع', 'Photo / Quick Pick')}</span>
            </button>
          </div>
        </div>

        {/* Scanner Body */}
        <div className="p-4 space-y-3 overflow-y-auto flex-1">
          {/* =================================================================
              TAB 1: DIRECT LIVE CAMERA STREAM (LAPTOP WEBCAM & MOBILE CAMERA)
             ================================================================= */}
          {activeMode === 'live-camera' && (
            <>
              {/* Top Controls Bar: Continuous Mode + Laptop HD Sharpener + Mirror + Switch Cam */}
              <div className="flex flex-wrap items-center justify-between gap-1.5">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setIsContinuous(!isContinuous)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                      isContinuous
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'neu-button text-slate-700'
                    }`}
                  >
                    <Repeat className="w-3.5 h-3.5" />
                    <span>{isContinuous ? tr('مسح مستمر', 'Continuous') : tr('صنف واحد', 'Single')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setEnhanceForLaptop(!enhanceForLaptop)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                      enhanceForLaptop
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'neu-button text-slate-700'
                    }`}
                    title={tr(
                      'توضيح وتغميق خطوط الباركود تلقائياً لكاميرا اللاب توب لتقرأ من أول مرة',
                      'Automatically sharpen blurry laptop webcam barcode bars'
                    )}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{tr('توضيح كاميرا اللاب HD', 'Laptop HD Boost')}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setMirrorVideo(!mirrorVideo)}
                    className={`px-2 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                      mirrorVideo ? 'neu-pressed text-blue-700' : 'neu-button text-slate-700'
                    }`}
                    title={tr('عكس اتجاه عرض الكاميرا (مرآة)', 'Mirror camera preview')}
                  >
                    <FlipHorizontal className="w-3.5 h-3.5" />
                    <span>{tr('مرآة', 'Mirror')}</span>
                  </button>

                  {torchSupported && (
                    <button
                      type="button"
                      onClick={handleToggleTorch}
                      className={`px-2 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                        torchOn ? 'bg-amber-500 text-white' : 'neu-button text-slate-700'
                      }`}
                    >
                      {torchOn ? <Zap className="w-3.5 h-3.5" /> : <ZapOff className="w-3.5 h-3.5" />}
                    </button>
                  )}

                  {cameras.length > 1 && (
                    <button
                      type="button"
                      onClick={handleSwitchCamera}
                      disabled={isStarting}
                      className="neu-button px-2 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isStarting ? 'animate-spin text-blue-600' : ''}`} />
                      <span>{tr('تبديل', 'Switch')}</span>
                    </button>
                  )}
                </div>
              </div>

              {cameras.length > 1 && (
                <select
                  value={selectedCameraId}
                  onChange={(e) => setSelectedCameraId(e.target.value)}
                  className="neu-input w-full px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700"
                >
                  <option value="">{tr('الكاميرا الافتراضية (اللاب توب / الموبايل)', 'Default Camera')}</option>
                  {cameras.map((cam) => (
                    <option key={cam.id} value={cam.id}>
                      {cam.label}
                    </option>
                  ))}
                </select>
              )}

              {/* Live Video Viewfinder with Digital Macro Zoom & Contrast Filter */}
              <div
                className={`relative rounded-2xl overflow-hidden bg-slate-950 border-2 transition-all duration-300 h-60 sm:h-64 w-full ${
                  scanFlash
                    ? 'border-emerald-400 ring-4 ring-emerald-400/50'
                    : 'border-slate-800'
                }`}
              >
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover transition-transform duration-150"
                  style={{
                    transform: `${mirrorVideo ? 'scaleX(-1)' : 'scaleX(1)'} scale(${digitalZoom})`,
                    filter: enhanceForLaptop ? 'contrast(1.22) brightness(1.04) saturate(0.85)' : 'none'
                  }}
                  playsInline
                  muted
                  autoPlay
                />

                {/* Scanning Target Box Overlay */}
                {isStreaming && (
                  <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                    <div className="w-4/5 max-w-[310px] h-32 border-2 border-emerald-400/90 rounded-2xl relative shadow-[0_0_0_9999px_rgba(15,23,42,0.40)]">
                      <div className="absolute inset-x-2 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent shadow-[0_0_8px_#ef4444]" />
                      <span className="absolute -top-6 inset-x-0 text-center text-[10px] font-bold text-white bg-slate-900/85 px-2.5 py-0.5 rounded-full mx-auto w-max">
                        {tr(
                          'ثبّت الباركود داخل المستطيل الأخضر على بُعد 15–25 سم من الكاميرا',
                          'Hold barcode steadily inside green box (15–25 cm from camera)'
                        )}
                      </span>
                    </div>
                  </div>
                )}

                {/* Digital Macro Zoom Bar Floating at Bottom of Video */}
                {isStreaming && (
                  <div className="absolute bottom-2.5 inset-x-3 flex items-center justify-between gap-2 z-10">
                    <div className="bg-slate-900/85 backdrop-blur-xs border border-slate-700/80 rounded-xl px-2 py-1 flex items-center gap-1">
                      <ZoomIn className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="text-[10px] text-slate-300 font-bold mr-0.5">
                        {tr('تقريب الباركود:', 'Zoom:')}
                      </span>
                      {[1, 1.5, 2, 2.5].map((z) => (
                        <button
                          key={z}
                          type="button"
                          onClick={() => setDigitalZoom(z)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-black tabular-nums cursor-pointer transition-colors ${
                            digitalZoom === z
                              ? 'bg-emerald-500 text-white'
                              : 'text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          {z}x
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={handleInstantSnapScan}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-xl text-[11px] font-black flex items-center gap-1 shadow-lg cursor-pointer"
                      title={tr('التقاط الإطار الحالي وفحصه بأقصى دقة فوراً', 'Capture & deep-scan current webcam frame')}
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{tr('مسح اللقطة الآن', 'Snap & Scan')}</span>
                    </button>
                  </div>
                )}

                {(isStarting || isScanningFile) && (
                  <div className="absolute inset-0 bg-slate-900/85 flex flex-col items-center justify-center text-white p-4 text-center z-10">
                    <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin mb-2" />
                    <span className="text-xs font-bold">
                      {isScanningFile
                        ? tr('جاري قراءة الباركود من الصورة...', 'Decoding barcode from photo...')
                        : tr('جاري تشغيل الكاميرا بأعلى دقة HD...', 'Starting HD camera...')}
                    </span>
                  </div>
                )}

                {scanFlash && (
                  <div className="pointer-events-none absolute inset-0 bg-emerald-500/35 flex items-center justify-center z-20">
                    <div className="bg-emerald-600 text-white px-4 py-2 rounded-2xl font-black text-xs flex items-center gap-1.5 shadow-xl">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{tr('تمت قراءة الباركود بنجاح!', 'Barcode Scanned!')}</span>
                    </div>
                  </div>
                )}
              </div>

              {cameraError && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="flex-1 space-y-2">
                    <p className="font-bold leading-relaxed">{cameraError}</p>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => startCamera(selectedCameraId || undefined, facingMode)}
                        className="px-3 py-1.5 rounded-xl bg-amber-600 text-white font-bold text-[11px] cursor-pointer"
                      >
                        {tr('إعادة محاولة الكاميرا', 'Retry Camera')}
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveMode('wireless-qr')}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>{tr('ربط كاميرا الموبايل عبر QR', 'Pair Phone via QR')}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Quick Photo Upload & Instant Manual Input Bar */}
              <div className="neu-flat p-2.5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-2 border border-slate-200/70">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (manualCodeInput.trim()) {
                      handleDecodedBarcode(manualCodeInput.trim(), true);
                      setManualCodeInput('');
                    }
                  }}
                  className="flex items-center gap-1.5 w-full sm:flex-1"
                >
                  <input
                    type="text"
                    value={manualCodeInput}
                    onChange={(e) => setManualCodeInput(e.target.value)}
                    placeholder={tr('أو اكتب رقم الباركود يدوياً هنا...', 'Or type barcode number here...')}
                    className="neu-input flex-1 px-3 py-1.5 rounded-xl text-xs font-mono font-bold text-slate-800"
                  />
                  <button
                    type="submit"
                    className="neu-button-primary px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer shrink-0"
                  >
                    {tr('إضافة', 'Add')}
                  </button>
                </form>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleScanImageFile}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isScanningFile}
                  className="neu-button px-3 py-1.5 rounded-xl text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center gap-1.5 shrink-0 cursor-pointer w-full sm:w-auto justify-center"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>{tr('مسح من صورة', 'Scan Photo')}</span>
                </button>
              </div>
            </>
          )}

          {/* =================================================================
              TAB 2: WIRELESS PHONE-TO-PC QR BRIDGE (ربط الموبايل بالكمبيوتر)
             ================================================================= */}
          {activeMode === 'wireless-qr' && (
            <div className="space-y-3.5">
              <div className="neu-pressed p-4 rounded-3xl flex flex-col sm:flex-row items-center gap-4 border border-blue-200/70 bg-blue-50/30">
                {/* QR Code Box */}
                <div className="bg-white p-3 rounded-2xl shadow-md border border-slate-200 shrink-0 flex flex-col items-center">
                  {qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="Mobile Scanner QR Code"
                      className="w-40 h-40 object-contain"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-40 h-40 flex items-center justify-center text-xs text-slate-400">
                      {tr('جاري توليد رمز QR...', 'Generating QR...')}
                    </div>
                  )}
                  <span className="text-[10px] font-mono font-bold text-slate-600 mt-1 tabular-nums">
                    {sessionId}
                  </span>
                </div>

                {/* Instructions & Connection Status */}
                <div className="flex-1 space-y-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <Wifi
                      className={`w-4 h-4 ${
                        mobileConnected ? 'text-emerald-600' : 'text-blue-600'
                      }`}
                    />
                    <span className="font-black text-slate-800 text-sm">
                      {mobileConnected
                        ? tr(`متصل الآن بـ (${mobileDeviceName || 'كاميرا الموبايل'})`, `Connected to (${mobileDeviceName || 'Mobile Camera'})`)
                        : tr('حول موبايلك إلى قارئ باركود لاسلكي للكمبيوتر', 'Turn Your Phone into a Wireless PC Scanner')}
                    </span>
                  </div>

                  <ol className="space-y-1.5 text-[11px] text-slate-600 list-decimal list-inside leading-relaxed">
                    <li>
                      {tr(
                        'افتح كاميرا موبايلك وامسح رمز الـ QR المقابل (أو انسخ الرابط بالأسفل وافتحه على الموبايل).',
                        'Scan this QR code with your phone camera (or open the link below on your phone).'
                      )}
                    </li>
                    <li>
                      {tr(
                        'ستفتح على موبايلك شاشة قارئ الباركود اللاسلكي مباشرة بدون تسجيل دخول.',
                        'Your phone will open the Wireless Barcode Scanner screen immediately.'
                      )}
                    </li>
                    <li>
                      {tr(
                        'وجّه كاميرا الموبايل لأي صنف؛ سيُضاف الصنف فوراً في فاتورة الكمبيوتر هنا مع نغمة البيب!',
                        'Scan any product with your phone; it will drop directly into your PC cart in real time!'
                      )}
                    </li>
                  </ol>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyMobileLink}
                      className="neu-button-primary px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>
                        {copiedLink
                          ? tr('تم نسخ رابط الموبايل!', 'Link Copied!')
                          : tr('نسخ رابط قارئ الموبايل', 'Copy Mobile Scanner Link')}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================================
              TAB 3: PHOTO UPLOAD + MANUAL INPUT + QUICK CATALOG PICKER
             ================================================================= */}
          {activeMode === 'photo-manual' && (
            <div className="space-y-3.5">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (manualCodeInput.trim()) {
                    handleDecodedBarcode(manualCodeInput.trim(), true);
                    setManualCodeInput('');
                  }
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={manualCodeInput}
                  onChange={(e) => setManualCodeInput(e.target.value)}
                  placeholder={tr('اكتب أو الصق رقم الباركود هنا واضغط إدخال...', 'Type or paste barcode number here...')}
                  className="neu-input flex-1 px-3.5 py-2.5 rounded-xl text-xs font-mono font-bold text-slate-800"
                  autoFocus
                />
                <button
                  type="submit"
                  className="neu-button-primary px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{tr('مسح وإضافة', 'Scan & Add')}</span>
                </button>
              </form>

              <div className="neu-flat p-3 rounded-2xl flex items-center justify-between gap-2 border border-slate-200/70">
                <span className="text-xs font-bold text-slate-700">
                  {tr('أو اختر صورة باركود من اللاب توب أو الموبايل:', 'Or select a barcode image from your device:')}
                </span>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="neu-button px-3 py-1.5 rounded-xl text-xs font-bold text-blue-600 flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>{tr('اختيار صورة باركود', 'Choose Image')}</span>
                </button>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-600 block">
                  {tr('مسح سريع لباركود الأصناف المسجلة (اضغط لمسح الصنف فوراً):', 'Quick Product Barcode Scan (Click any item to scan):')}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {products.map((prod) => (
                    <button
                      key={prod.id}
                      type="button"
                      onClick={() => handleDecodedBarcode(prod.barcode, true)}
                      className="neu-button p-2.5 rounded-2xl flex items-center justify-between gap-2 text-right text-xs cursor-pointer hover:border-emerald-400"
                    >
                      <div className="min-w-0">
                        <div className="font-bold text-slate-800 truncate">{prod.name}</div>
                        <div className="font-mono text-[10px] text-emerald-700 tabular-nums">{prod.barcode}</div>
                      </div>
                      <span className="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold shrink-0">
                        {tr('+ مسح', '+ Scan')}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Scanned Items Log in Current Session */}
          {scannedHistory.length > 0 && (
            <div className="neu-pressed p-3 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                <span className="flex items-center gap-1">
                  <ScanLine className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{tr('الأصناف الممسوحة في هذه الجلسة:', 'Scanned in this session:')}</span>
                </span>
                <span className="text-emerald-700 font-black tabular-nums">
                  {scannedHistory.reduce((acc, i) => acc + i.count, 0)} {tr('عملية مسح', 'scans')}
                </span>
              </div>

              <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1">
                {scannedHistory.map((item) => (
                  <div
                    key={item.code}
                    className="bg-white/90 px-3 py-1.5 rounded-xl border border-emerald-200/80 flex items-center justify-between gap-2 text-xs shadow-2xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-mono font-bold text-slate-800 truncate tabular-nums">
                        {item.code}
                      </span>
                      <span className="text-emerald-800 font-black text-[10px] tabular-nums">
                        ×{item.count}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] text-slate-400 tabular-nums">{item.time}</span>
                      <button
                        type="button"
                        onClick={() => handleDecodedBarcode(item.code, true)}
                        className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{tr('تكرار +1', '+1 Again')}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 border-t border-slate-200/80 bg-slate-50/70 flex items-center justify-between gap-2">
          <span className="text-[11px] text-slate-500 font-medium">
            {tr('يدعم كاميرا اللاب توب (مع التقريب والتوضيح الذكي) وكاميرا الموبايل', 'Supports Laptop Webcam (with Macro Zoom & HD Sharpener) & Mobile')}
          </span>
          <button
            type="button"
            onClick={handleCloseModal}
            className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold cursor-pointer"
          >
            {tr('إنهاء المسح وإغلاق', 'Done & Close')}
          </button>
        </div>
      </div>
    </div>
  );
};
