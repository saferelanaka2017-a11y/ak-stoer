/**
 * @file pages/CustomersPage.tsx
 * شاشة إدارة العملاء والموردين وكشوفات الحساب والديون مع الإضافة والتعديل والحذف والطباعة
 * Customers & Suppliers Management Page with Full CRUD and Statement Printing
 */

import React, { useState } from 'react';
import {
  Users,
  Building2,
  Plus,
  Search,
  Phone,
  MessageCircle,
  Download,
  Trash2,
  Edit2,
  Printer,
  DollarSign
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import { Customer, Supplier } from '../types';
import {
  exportCustomersToExcel,
  generateCustomerStatementPDF,
  generateSupplierStatementPDF
} from '../utils/exportUtils';
import { openSmartWhatsAppModal } from '../utils/installmentAlerts';
import { NumberStepperInput } from '../components/NumberStepperInput';

export const CustomersPage: React.FC = () => {
  const { customers, suppliers, formatCurrency, refreshData, showToast, settings, t, tr, requestConfirm } = useApp();

  const [activeTab, setActiveTab] = useState<'customers' | 'suppliers'>('customers');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Editing State
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  // Customer Form
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [custBalance, setCustBalance] = useState(0);
  const [custTaxNumber, setCustTaxNumber] = useState('');

  // Supplier Form
  const [supName, setSupName] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supCompany, setSupCompany] = useState('');
  const [supAddress, setSupAddress] = useState('');
  const [supBalance, setSupBalance] = useState(0);
  const [supTaxNumber, setSupTaxNumber] = useState('');

  // Filtering
  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  );

  const filteredSuppliers = suppliers.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.phone.includes(searchQuery)
  );

  // Customer actions
  const handleOpenAddCustomer = () => {
    setEditingCustomer(null);
    setCustName('');
    setCustPhone('');
    setCustEmail('');
    setCustAddress('');
    setCustBalance(0);
    setCustTaxNumber('');
    setIsCustomerModalOpen(true);
  };

  const handleOpenEditCustomer = (c: Customer) => {
    setEditingCustomer(c);
    setCustName(c.name);
    setCustPhone(c.phone);
    setCustEmail(c.email || '');
    setCustAddress(c.address || '');
    setCustBalance(c.balance);
    setCustTaxNumber(c.taxNumber || '');
    setIsCustomerModalOpen(true);
  };

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !custPhone.trim()) {
      showToast('يرجى إدخال اسم العميل ورقم الهاتف', 'error');
      return;
    }

    if (editingCustomer) {
      db.updateCustomer(editingCustomer.id, {
        name: custName,
        phone: custPhone,
        email: custEmail,
        address: custAddress,
        balance: custBalance,
        taxNumber: custTaxNumber
      });
      showToast('تم تحديث بيانات العميل بنجاح!', 'success');
    } else {
      db.addCustomer({
        name: custName,
        phone: custPhone,
        email: custEmail,
        address: custAddress,
        balance: custBalance,
        taxNumber: custTaxNumber
      });
      showToast('تمت إضافة العميل بنجاح!', 'success');
    }

    refreshData();
    setIsCustomerModalOpen(false);
  };

  const handlePrintCustomer = async (customer: Customer) => {
    try {
      showToast(`جاري إنشاء كشف حساب العميل: ${customer.name}...`, 'info');
      await generateCustomerStatementPDF(customer, settings);
      showToast(`تم تحميل كشف حساب العميل: ${customer.name} بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء كشف حساب العميل', 'error');
    }
  };

  // Supplier actions
  const handleOpenAddSupplier = () => {
    setEditingSupplier(null);
    setSupName('');
    setSupPhone('');
    setSupCompany('');
    setSupAddress('');
    setSupBalance(0);
    setSupTaxNumber('');
    setIsSupplierModalOpen(true);
  };

  const handleOpenEditSupplier = (s: Supplier) => {
    setEditingSupplier(s);
    setSupName(s.name);
    setSupPhone(s.phone);
    setSupCompany(s.companyName);
    setSupAddress(s.address || '');
    setSupBalance(s.balance);
    setSupTaxNumber(s.taxNumber || '');
    setIsSupplierModalOpen(true);
  };

  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName.trim() || !supPhone.trim()) {
      showToast('يرجى إدخال اسم المورد ورقم الهاتف', 'error');
      return;
    }

    if (editingSupplier) {
      db.updateSupplier(editingSupplier.id, {
        name: supName,
        companyName: supCompany || supName,
        phone: supPhone,
        address: supAddress,
        balance: supBalance,
        taxNumber: supTaxNumber
      });
      showToast('تم تحديث بيانات المورد بنجاح!', 'success');
    } else {
      db.addSupplier({
        name: supName,
        companyName: supCompany || supName,
        phone: supPhone,
        address: supAddress,
        balance: supBalance,
        taxNumber: supTaxNumber
      });
      showToast('تمت إضافة المورد بنجاح!', 'success');
    }

    refreshData();
    setIsSupplierModalOpen(false);
  };

  const handlePrintSupplier = async (supplier: Supplier) => {
    try {
      showToast(`جاري إنشاء كشف حساب المورد: ${supplier.name}...`, 'info');
      await generateSupplierStatementPDF(supplier, settings);
      showToast(`تم تحميل كشف حساب المورد: ${supplier.name} بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء كشف حساب المورد', 'error');
    }
  };

  const handleDeleteCustomer = (id: string, name: string) => {
    requestConfirm({
      title: 'حذف بيانات العميل',
      message: `هل أنت متأكد من رغبتك في حذف العميل "${name}" نهائياً من النظام؟`,
      confirmText: 'نعم، حذف العميل',
      onConfirm: () => {
        db.deleteCustomer(id);
        showToast('تم حذف العميل بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handleDeleteSupplier = (id: string, name: string) => {
    requestConfirm({
      title: 'حذف بيانات المورد',
      message: `هل أنت متأكد من رغبتك في حذف المورد "${name}" نهائياً من النظام؟`,
      confirmText: 'نعم، حذف المورد',
      onConfirm: () => {
        db.deleteSupplier(id);
        showToast('تم حذف المورد بنجاح', 'success');
        refreshData();
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>{t('customers')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('إدارة جهات الاتصال، التعديل، الحذف، وطباعة كشوفات الحساب', 'Manage contacts, edit/delete accounts, and print statements')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'customers' ? (
            <>
              <button
                onClick={() => exportCustomersToExcel(customers)}
                className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('exportExcel')}</span>
              </button>
              <button
                onClick={handleOpenAddCustomer}
                className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{tr('إضافة عميل جديد', 'Add Customer')}</span>
              </button>
            </>
          ) : (
            <button
              onClick={handleOpenAddSupplier}
              className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{tr('إضافة مورد جديد', 'Add Supplier')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Segmented Switcher & Search */}
      <div className="neu-card p-4 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex p-1 neu-pressed rounded-2xl w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('customers')}
            className={`flex-1 sm:flex-none px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'customers' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('العملاء', 'Customers')} ({customers.length})
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`flex-1 sm:flex-none px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'suppliers' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            {tr('الموردين', 'Suppliers')} ({suppliers.length})
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={tr('بحث بالاسم أو الهاتف...', 'Search by name or phone...')}
            className="neu-input w-full pl-4 pr-10 py-2 rounded-xl text-xs"
          />
          <Search className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
        </div>
      </div>

      {/* Content Table */}
      <div className="neu-card p-5 rounded-3xl">
        {activeTab === 'customers' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="pb-3 pr-2">{tr('الاسم', 'Name')}</th>
                  <th className="pb-3">{tr('الهاتف', 'Phone')}</th>
                  <th className="pb-3">{tr('الرقم الضريبي', 'Tax ID')}</th>
                  <th className="pb-3">{tr('العنوان', 'Address')}</th>
                  <th className="pb-3 text-left">{tr('المديونية / الرصيد', 'Balance / Debt')}</th>
                  <th className="pb-3 text-left">{tr('الإجراءات', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCustomers.map(customer => {
                  const hasDebt = customer.balance > 0;
                  return (
                    <tr key={customer.id} className="hover:bg-slate-50/50">
                      <td className="py-3 pr-2 font-bold text-slate-800">{customer.name}</td>
                      <td className="py-3 font-mono text-slate-600">{customer.phone}</td>
                      <td className="py-3 font-mono text-slate-500">{customer.taxNumber || '—'}</td>
                      <td className="py-3 text-slate-500">{customer.address || '—'}</td>
                      <td className="py-3 text-left">
                        <span
                          className={`font-black tabular-nums text-xs ${
                            hasDebt ? 'text-red-500' : 'text-slate-700'
                          }`}
                        >
                          {formatCurrency(customer.balance)}
                        </span>
                      </td>
                      <td className="py-3 text-left">
                        <div className="flex items-center gap-1.5 justify-end">
                          <button
                            onClick={() => handlePrintCustomer(customer)}
                            className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                            title="طباعة كشف الحساب"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEditCustomer(customer)}
                            className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                            title="تعديل بيانات العميل"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const defaultMsg =
                                customer.balance > 0
                                  ? `مرحباً بك أستاذ/ة *${customer.name}* في *${settings.storeName || 'AK Store'}* 🌷\n\nنود التذكير بأن الرصيد المستحق في حسابكم حالياً هو: *${formatCurrency(customer.balance)}*.\nنسعد بتواصلكم معنا في أي وقت.\n📞 ${settings.storePhone || ''}`
                                  : `مرحباً بك أستاذ/ة *${customer.name}* في *${settings.storeName || 'AK Store'}* 🌷\n\nنسعد دائماً بخدمتكم وتواصلكم معنا.`;
                              openSmartWhatsAppModal({
                                recipientName: customer.name,
                                phone: customer.phone,
                                message: defaultMsg,
                                title: 'مراسلة العميل عبر واتساب',
                                subtitle: customer.balance > 0 ? `مديونية حالية: ${formatCurrency(customer.balance)}` : 'حساب خالص'
                              });
                            }}
                            className="neu-button p-1.5 rounded-lg text-emerald-600 hover:text-emerald-700 cursor-pointer"
                            title="مراسلة واتساب"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteCustomer(customer.id, customer.name)}
                            className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="pb-3 pr-2">اسم المورد</th>
                  <th className="pb-3">الشركة</th>
                  <th className="pb-3">الهاتف</th>
                  <th className="pb-3">الرقم الضريبي</th>
                  <th className="pb-3 text-left">مستحقات المورد</th>
                  <th className="pb-3 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSuppliers.map(supplier => (
                  <tr key={supplier.id} className="hover:bg-slate-50/50">
                    <td className="py-3 pr-2 font-bold text-slate-800">{supplier.name}</td>
                    <td className="py-3 font-semibold text-slate-700">{supplier.companyName}</td>
                    <td className="py-3 font-mono text-slate-600">{supplier.phone}</td>
                    <td className="py-3 font-mono text-slate-500">{supplier.taxNumber || '—'}</td>
                    <td className="py-3 text-left font-black text-amber-600 tabular-nums">
                      {formatCurrency(supplier.balance)}
                    </td>
                    <td className="py-3 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          onClick={() => handlePrintSupplier(supplier)}
                          className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                          title="طباعة كشف حساب المورد"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEditSupplier(supplier)}
                          className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                          title="تعديل بيانات المورد"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSupplier(supplier.id, supplier.name)}
                          className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Customer Add/Edit Modal */}
      {isCustomerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="font-bold text-slate-800 text-sm mb-4">
              {editingCustomer ? 'تعديل بيانات العميل' : 'إضافة عميل جديد'}
            </h3>
            <form onSubmit={handleSaveCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">اسم العميل:</label>
                <input
                  type="text"
                  required
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">رقم الهاتف:</label>
                <input
                  type="text"
                  required
                  value={custPhone}
                  onChange={(e) => setCustPhone(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                  placeholder="05xxxxxxxx"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">الرقم الضريبي (إن وجد):</label>
                <input
                  type="text"
                  value={custTaxNumber}
                  onChange={(e) => setCustTaxNumber(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">العنوان:</label>
                <input
                  type="text"
                  value={custAddress}
                  onChange={(e) => setCustAddress(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">الرصيد الافتتاحي (مديونية سابقة):</label>
                <NumberStepperInput
                  min={0}
                  step={10}
                  value={custBalance}
                  onChange={(val) => setCustBalance(val)}
                  className="w-full"
                  inputClassName="font-bold text-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCustomerModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  {editingCustomer ? 'حفظ التعديلات' : 'حفظ العميل'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Supplier Add/Edit Modal */}
      {isSupplierModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="font-bold text-slate-800 text-sm mb-4">
              {editingSupplier ? 'تعديل بيانات المورد' : 'إضافة مورد جديد'}
            </h3>
            <form onSubmit={handleSaveSupplier} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">اسم المندوب / جهة الاتصال:</label>
                <input
                  type="text"
                  required
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">اسم شركة المورد:</label>
                <input
                  type="text"
                  value={supCompany}
                  onChange={(e) => setSupCompany(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">رقم الهاتف:</label>
                <input
                  type="text"
                  required
                  value={supPhone}
                  onChange={(e) => setSupPhone(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">الرقم الضريبي للمورد:</label>
                <input
                  type="text"
                  value={supTaxNumber}
                  onChange={(e) => setSupTaxNumber(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">رصيد مستحق له:</label>
                <NumberStepperInput
                  min={0}
                  step={10}
                  value={supBalance}
                  onChange={(val) => setSupBalance(val)}
                  className="w-full"
                  inputClassName="font-bold text-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsSupplierModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  {editingSupplier ? 'حفظ التعديلات' : 'حفظ المورد'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
