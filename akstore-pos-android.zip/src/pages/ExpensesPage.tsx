/**
 * @file pages/ExpensesPage.tsx
 * شاشة إدارة المصروفات اليومية والنثريات للمتجر مع الإضافة والتعديل والحذف والطباعة
 * Daily Store Expenses Management Page with Full CRUD & Print
 */

import React, { useState, useMemo } from 'react';
import { ReceiptText, Plus, Trash2, Edit2, Printer, Calendar, DollarSign, Filter } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { Expense } from '../types';
import { generateExpenseVoucherPDF } from '../utils/exportUtils';
import { NumberStepperInput } from '../components/NumberStepperInput';

export const ExpensesPage: React.FC = () => {
  const { expenses, formatCurrency, refreshData, showToast, settings, t, tr, requestConfirm } = useApp();
  const { user } = useAuth();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('فواتير ومرافق');
  const [amount, setAmount] = useState(0);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  // Total summary
  const totalExpenses = useMemo(() => {
    return expenses.reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const handleOpenAdd = () => {
    setEditingExpense(null);
    setTitle('');
    setCategory('فواتير ومرافق');
    setAmount(0);
    setDate(new Date().toISOString().split('T')[0]);
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (exp: Expense) => {
    setEditingExpense(exp);
    setTitle(exp.title);
    setCategory(exp.category);
    setAmount(exp.amount);
    setDate(exp.date);
    setNotes(exp.notes || '');
    setIsModalOpen(true);
  };

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) {
      showToast('يرجى كتابة بند المصروف وقيمة صحيحة', 'error');
      return;
    }

    if (editingExpense) {
      db.updateExpense(editingExpense.id, {
        title,
        category,
        amount,
        date,
        notes
      });
      showToast('تم تحديث بيانات المصروف بنجاح!', 'success');
    } else {
      db.addExpense({
        title,
        category,
        amount,
        date,
        notes,
        recordedBy: user?.username || 'admin'
      });
      showToast('تم تسجيل المصروف بنجاح!', 'success');
    }

    refreshData();
    setIsModalOpen(false);
  };

  const handleDeleteExpense = (id: string, title: string) => {
    requestConfirm({
      title: 'حذف المصروف',
      message: `هل أنت متأكد من حذف بند المصروف "${title}"؟`,
      confirmText: 'نعم، حذف المصروف',
      onConfirm: () => {
        db.deleteExpense(id);
        showToast('تم حذف المصروف بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrintExpense = async (exp: Expense) => {
    try {
      showToast(`جاري إنشاء سند الصرف: ${exp.title} باللغة العربية...`, 'info');
      await generateExpenseVoucherPDF(exp, settings);
      showToast(`تم تحميل سند الصرف: ${exp.title} PDF بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء سند الصرف', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-blue-600" />
            <span>{tr('المصروفات اليومية والنثريات', 'Daily Store Expenses')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('تسجيل ومتابعة نفقات التشغيل، التعديل، الحذف، وطباعة سندات الصرف', 'Record and track operating expenses, edit/delete records, and print payment vouchers')}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="neu-pressed px-4 py-2 rounded-2xl text-xs font-bold text-slate-700">
            {tr('إجمالي المصروفات:', 'Total Expenses:')} <span className="text-red-500 tabular-nums">{formatCurrency(totalExpenses)}</span>
          </div>
          <button
            onClick={handleOpenAdd}
            className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{tr('تسجيل مصروف جديد', 'Add New Expense')}</span>
          </button>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="neu-card p-5 rounded-3xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-3 pr-2">{tr('بند المصروف', 'Expense Item')}</th>
                <th className="pb-3">{t('category')}</th>
                <th className="pb-3">{tr('التاريخ', 'Date')}</th>
                <th className="pb-3">{tr('المسجل', 'Recorded By')}</th>
                <th className="pb-3">{tr('ملاحظات', 'Notes')}</th>
                <th className="pb-3 text-left">{tr('المبلغ', 'Amount')}</th>
                <th className="pb-3 text-left">{tr('الإجراءات', 'Actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {expenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/50">
                  <td className="py-3 pr-2 font-bold text-slate-800">{exp.title}</td>
                  <td className="py-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {exp.category}
                    </span>
                  </td>
                  <td className="py-3 text-slate-500 tabular-nums">{exp.date}</td>
                  <td className="py-3 text-slate-600 font-mono text-[11px]">{exp.recordedBy}</td>
                  <td className="py-3 text-slate-500">{exp.notes || '—'}</td>
                  <td className="py-3 text-left font-black text-red-500 tabular-nums">
                    {formatCurrency(exp.amount)}
                  </td>
                  <td className="py-3 text-left">
                    <div className="flex items-center gap-1.5 justify-end">
                      <button
                        onClick={() => handlePrintExpense(exp)}
                        className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                        title="طباعة سند صرف"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(exp)}
                        className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                        title="تعديل المصروف"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteExpense(exp.id, exp.title)}
                        className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                        title="حذف المصروف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {expenses.length === 0 && (
            <div className="py-12 text-center text-xs text-slate-400">
              لا توجد مصروفات مسجلة بعد
            </div>
          )}
        </div>
      </div>

      {/* New / Edit Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="font-bold text-slate-800 text-sm mb-4">
              {editingExpense ? 'تعديل بيانات المصروف' : 'تسجيل مصروف جديد'}
            </h3>
            <form onSubmit={handleSaveExpense} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">اسم / بند المصروف:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: فاتورة كهرباء، صيانة مكيف، قهوة وضيافة..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">التصنيف:</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
                >
                  <option value="فواتير ومرافق">فواتير ومرافق (كهرباء، مياه، إنترنت)</option>
                  <option value="مستلزمات تشغيل">مستلزمات تشغيل وأوراق طباعة</option>
                  <option value="صيانة وإصلاحات">صيانة وإصلاحات</option>
                  <option value="رواتب وسلف">رواتب وسلف عاملين</option>
                  <option value="نثريات وضيافة">نثريات وضيافة</option>
                  <option value="أخرى">أخرى</option>
                </select>
              </div>

              <div>
                <label className="font-semibold block mb-1">المبلغ:</label>
                <NumberStepperInput
                  min={0}
                  step={10}
                  required
                  value={amount}
                  onChange={(val) => setAmount(val)}
                  className="w-full"
                  inputClassName="font-bold text-red-500"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">التاريخ:</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1">ملاحظات إضافية:</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  {editingExpense ? 'حفظ التعديلات' : 'حفظ المصروف'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
