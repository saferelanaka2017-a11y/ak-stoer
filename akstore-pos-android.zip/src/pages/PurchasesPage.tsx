/**
 * @file pages/PurchasesPage.tsx
 * شاشة المشتريات من الموردين وتحديث المخزون مع أزرار الإضافة والتعديل والحذف والطباعة
 * Supplier Purchases & Inventory Stocking Page with Full CRUD & Print
 */

import React, { useState } from 'react';
import {
  ShoppingBag,
  Plus,
  Trash2,
  Edit2,
  Printer,
  Calendar,
  Building2,
  DollarSign,
  Package,
  Smartphone,
  Camera
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';
import { PurchaseInvoice } from '../types';
import { generatePurchaseInvoicePDF } from '../utils/exportUtils';
import { MobileBarcodeScannerModal } from '../components/MobileBarcodeScannerModal';
import { NumberStepperInput } from '../components/NumberStepperInput';

export const PurchasesPage: React.FC = () => {
  const {
    suppliers,
    products,
    purchases,
    formatCurrency,
    refreshData,
    showToast,
    settings,
    t,
    tr,
    requestConfirm,
    warehouses,
    currencies,
    activeCurrency,
    switchActiveCurrency
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [updateInventoryCost, setUpdateInventoryCost] = useState(true);
  const [editingPurchase, setEditingPurchase] = useState<PurchaseInvoice | null>(null);

  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [warehouseId, setWarehouseId] = useState<string>(settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main');
  const [purchaseItems, setPurchaseItems] = useState<{
    productId: string;
    productName: string;
    barcode: string;
    costPrice: number;
    quantity: number;
    total: number;
  }[]>([]);

  // Selected item inputs
  const [selectedProdId, setSelectedProdId] = useState('');
  const [costPrice, setCostPrice] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [paidAmount, setPaidAmount] = useState(0);
  const [notes, setNotes] = useState('');
  const [isMobileScannerOpen, setIsMobileScannerOpen] = useState(false);

  // Handle product select
  const handleSelectProduct = (prodId: string) => {
    setSelectedProdId(prodId);
    const prod = products.find(p => p.id === prodId);
    if (prod) {
      setCostPrice(prod.costPrice);
    }
  };

  const handleAddItem = () => {
    const prod = products.find(p => p.id === selectedProdId);
    if (!prod) {
      showToast('يرجى اختيار الصنف أولاً', 'error');
      return;
    }
    if (quantity <= 0 || costPrice < 0) {
      showToast('يرجى تحديد كمية وسعر تكلفة صحيحين', 'error');
      return;
    }

    const itemTotal = costPrice * quantity;
    setPurchaseItems(prev => [
      ...prev,
      {
        productId: prod.id,
        productName: prod.name,
        barcode: prod.barcode,
        costPrice,
        quantity,
        total: itemTotal
      }
    ]);

    setSelectedProdId('');
    setCostPrice(0);
    setQuantity(1);
  };

  const grandTotal = purchaseItems.reduce((acc, item) => acc + item.total, 0);

  const handleOpenAdd = () => {
    setEditingPurchase(null);
    setPurchaseItems([]);
    setPaidAmount(0);
    setNotes('');
    setSupplierId(suppliers[0]?.id || '');
    setWarehouseId(settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: PurchaseInvoice) => {
    setEditingPurchase(p);
    setSupplierId(p.supplierId);
    setWarehouseId(p.warehouseId || settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main');
    setPurchaseItems([...p.items]);
    setPaidAmount(p.paidAmount);
    setNotes(p.notes || '');
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, invoiceNum: string) => {
    requestConfirm({
      title: 'حذف فاتورة الشراء',
      message: `هل أنت متأكد من حذف فاتورة الشراء رقم: "${invoiceNum}"؟ لن يتم التراجع عن هذا الإجراء.`,
      confirmText: 'نعم، حذف الفاتورة',
      onConfirm: () => {
        db.deletePurchase(id);
        showToast('تم حذف فاتورة الشراء بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrint = async (purchase: PurchaseInvoice) => {
    try {
      showToast(`جاري تصدير فاتورة الشراء #${purchase.invoiceNumber} باللغة العربية...`, 'info');
      await generatePurchaseInvoicePDF(purchase, settings);
      showToast(`تم تحميل فاتورة الشراء #${purchase.invoiceNumber} PDF بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء ملف PDF لفاتورة الشراء', 'error');
    }
  };

  const handleSubmitPurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (purchaseItems.length === 0) {
      showToast('يرجى إضافة صنف واحد على الأقل لفاتورة الشراء', 'error');
      return;
    }

    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) {
      showToast('يرجى اختيار المورد', 'error');
      return;
    }

    const remainingAmount = Math.max(0, grandTotal - paidAmount);
    const targetWh = warehouses.find(w => w.id === warehouseId);

    // Update product costPrice in inventory if option is enabled
    if (updateInventoryCost) {
      purchaseItems.forEach(item => {
        if (item.costPrice > 0) {
          db.updateProduct(item.productId, { costPrice: item.costPrice });
        }
      });
    }

    if (editingPurchase) {
      db.updatePurchase(editingPurchase.id, {
        supplierId: supplier.id,
        supplierName: supplier.name,
        items: purchaseItems,
        grandTotal,
        paidAmount,
        remainingAmount,
        notes,
        warehouseId,
        warehouseName: targetWh?.name || 'المستودع الرئيسي',
        currency: activeCurrency?.code || settings.currency,
        currencySymbol: activeCurrency?.symbol || settings.currencySymbol,
        exchangeRate: activeCurrency?.exchangeRate || 1
      });
      showToast('تم تحديث فاتورة الشراء وأسعار التكلفة بنجاح!', 'success');
    } else {
      db.createPurchase({
        supplierId: supplier.id,
        supplierName: supplier.name,
        items: purchaseItems,
        grandTotal,
        paidAmount,
        remainingAmount,
        notes,
        warehouseId,
        warehouseName: targetWh?.name || 'المستودع الرئيسي',
        currency: activeCurrency?.code || settings.currency,
        currencySymbol: activeCurrency?.symbol || settings.currencySymbol,
        exchangeRate: activeCurrency?.exchangeRate || 1
      });
      showToast(`تم حفظ فاتورة الشراء وتوريد البضاعة لمستودع [${targetWh?.name || 'الرئيسي'}] بنجاح!`, 'success');
    }

    refreshData();
    setIsModalOpen(false);
    setPurchaseItems([]);
    setNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-600" />
            <span>{tr('فواتير المشتريات وإمداد المخزون', 'Supplier Purchases & Inventory Restocking')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('تسجيل البضائع الواردة، التعديل، الحذف، والطباعة', 'Record incoming supplier goods, update inventory costs, and print invoices')}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={activeCurrency?.code || settings.currency || 'EGP'}
            onChange={(e) => {
              const res = switchActiveCurrency(e.target.value);
              if (res.success) {
                showToast(res.message, 'success');
              }
            }}
            className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-emerald-700"
            title={tr('تبديل عملة الشراء والتسعير', 'Switch purchase currency')}
          >
            {currencies.map(c => (
              <option key={c.code} value={c.code}>
                💱 {tr('عملة الشراء:', 'Purchase Currency:')} {c.name} ({c.symbol}) — {tr('صرف:', 'Rate:')} {c.exchangeRate}
              </option>
            ))}
          </select>

          <button
            onClick={handleOpenAdd}
            className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t('newPurchaseInvoice')}</span>
          </button>
        </div>
      </div>

      {/* Purchase Invoices List */}
      <div className="neu-card p-5 rounded-3xl">
        <h3 className="font-bold text-slate-800 text-sm mb-4">
          سجل فواتير المشتريات السابقة ({purchases.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-3 pr-2">رقم الفاتورة</th>
                <th className="pb-3">المورد</th>
                <th className="pb-3">التاريخ</th>
                <th className="pb-3 text-center">عدد الأصناف</th>
                <th className="pb-3 text-left">إجمالي الفاتورة</th>
                <th className="pb-3 text-left">المدفوع</th>
                <th className="pb-3 text-left">المتبقي (آجل)</th>
                <th className="pb-3 text-left">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {purchases.map((purchase) => (
                <tr key={purchase.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-3 pr-2 font-mono font-bold text-blue-700">{purchase.invoiceNumber}</td>
                  <td className="py-3 font-semibold text-slate-800">{purchase.supplierName}</td>
                  <td className="py-3 text-slate-500 tabular-nums">
                    {new Date(purchase.date).toLocaleDateString('ar-SA')}
                  </td>
                  <td className="py-3 text-center font-bold">{purchase.items.length}</td>
                  <td className="py-3 text-left font-black tabular-nums">{formatCurrency(purchase.grandTotal)}</td>
                  <td className="py-3 text-left font-semibold text-emerald-600 tabular-nums">{formatCurrency(purchase.paidAmount)}</td>
                  <td className="py-3 text-left font-semibold text-red-500 tabular-nums">{formatCurrency(purchase.remainingAmount)}</td>
                  <td className="py-3 text-left">
                    <div className="flex items-center gap-1.5 justify-end">
                      <button
                        onClick={() => handlePrint(purchase)}
                        className="neu-button p-1.5 rounded-lg text-blue-600 hover:text-blue-700 cursor-pointer"
                        title="طباعة فاتورة الشراء"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(purchase)}
                        className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                        title="تعديل فاتورة الشراء"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(purchase.id, purchase.invoiceNumber)}
                        className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                        title="حذف فاتورة الشراء"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {purchases.length === 0 && (
            <div className="py-12 text-center text-xs text-slate-400">
              لا توجد فواتير شراء مسجلة بعد. اضغط على "فاتورة شراء جديدة" للبدء.
            </div>
          )}
        </div>
      </div>

      {/* New / Edit Purchase Invoice Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/60 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-blue-600" />
                <span>{editingPurchase ? 'تعديل فاتورة الشراء' : 'تسجيل فاتورة شراء بضاعة جديدة'}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-xs font-bold"
              >
                إغلاق ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* Supplier & Currency Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    المورد:
                  </label>
                  <select
                    value={supplierId}
                    onChange={(e) => setSupplierId(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl text-xs font-semibold"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.companyName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    عملة فاتورة الشراء (سعر الصرف: {activeCurrency?.exchangeRate}):
                  </label>
                  <select
                    value={activeCurrency?.code || settings.currency || 'SAR'}
                    onChange={(e) => {
                      const res = switchActiveCurrency(e.target.value);
                      if (res.success) {
                        showToast(res.message, 'success');
                      }
                    }}
                    className="neu-input w-full px-3 py-2 rounded-xl text-xs font-bold text-emerald-700"
                  >
                    {currencies.map(c => (
                      <option key={c.code} value={c.code}>
                        {c.name} ({c.symbol}) — سعر الصرف: {c.exchangeRate}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={updateInventoryCost}
                  onChange={(e) => setUpdateInventoryCost(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <span>تحديث سعر الشراء (التكلفة) للأصناف في المخزون تلقائياً حسب هذه الفاتورة</span>
              </label>

              {/* Add Items Sub-form */}
              <div className="neu-flat p-4 rounded-2xl space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-800 block">إضافة أصناف للشحنة:</span>
                  <button
                    type="button"
                    onClick={() => setIsMobileScannerOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title={tr('مسح باركود الصنف بكاميرا الموبايل وإضافته لفاتورة الشراء', 'Scan item barcode with mobile camera to add to purchase invoice')}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <Camera className="w-3.5 h-3.5" />
                    <span>{tr('مسح باركود بالموبايل', 'Mobile Barcode Scan')}</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <div className="sm:col-span-2">
                    <select
                      value={selectedProdId}
                      onChange={(e) => handleSelectProduct(e.target.value)}
                      className="neu-input w-full px-3 py-2 rounded-xl text-xs"
                    >
                      <option value="">اختر الصنف...</option>
                      {products.map(p => (
                        <option key={p.id} value={p.id}>
                          {p.name} (المتوفر: {p.stock})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <NumberStepperInput
                      min={0}
                      step={1}
                      placeholder="سعر التكلفة"
                      value={costPrice}
                      onChange={(val) => setCostPrice(val)}
                      className="w-full"
                      inputClassName="font-bold text-slate-800"
                    />
                  </div>
                  <div>
                    <NumberStepperInput
                      min={1}
                      step={1}
                      fallbackOnBlur={1}
                      placeholder="الكمية"
                      value={quantity}
                      onChange={(val) => setQuantity(Math.max(0, Math.round(val)))}
                      className="w-full"
                      inputClassName="font-bold text-slate-800"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddItem}
                  className="neu-button px-4 py-2 rounded-xl text-xs font-bold text-blue-600 flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة الصنف إلى الفاتورة</span>
                </button>
              </div>

              {/* Added Items Table */}
              {purchaseItems.length > 0 && (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-100/70 text-slate-600">
                      <tr>
                        <th className="p-2">الصنف</th>
                        <th className="p-2 text-center">الكمية</th>
                        <th className="p-2 text-center">التكلفة</th>
                        <th className="p-2 text-left">الإجمالي</th>
                        <th className="p-2 text-center">حذف</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {purchaseItems.map((item, idx) => (
                        <tr key={idx}>
                          <td className="p-2 font-medium">{item.productName}</td>
                          <td className="p-2 text-center">
                            <NumberStepperInput
                              size="xs"
                              min={1}
                              step={1}
                              fallbackOnBlur={1}
                              value={item.quantity}
                              onChange={(val) => {
                                const nextQty = Math.max(1, Math.round(val));
                                setPurchaseItems((prev) =>
                                  prev.map((row, i) =>
                                    i === idx
                                      ? { ...row, quantity: nextQty, total: nextQty * row.costPrice }
                                      : row
                                  )
                                );
                              }}
                              className="w-20 mx-auto"
                              inputClassName="text-center font-bold text-slate-800"
                            />
                          </td>
                          <td className="p-2 text-center">
                            <NumberStepperInput
                              size="xs"
                              min={0}
                              step={1}
                              value={item.costPrice}
                              onChange={(val) => {
                                const nextCost = Math.max(0, val);
                                setPurchaseItems((prev) =>
                                  prev.map((row, i) =>
                                    i === idx
                                      ? { ...row, costPrice: nextCost, total: row.quantity * nextCost }
                                      : row
                                  )
                                );
                              }}
                              className="w-24 mx-auto"
                              inputClassName="text-center font-bold text-blue-700"
                            />
                          </td>
                          <td className="p-2 text-left font-bold">{formatCurrency(item.total)}</td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => setPurchaseItems(prev => prev.filter((_, i) => i !== idx))}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-3.5 h-3.5 mx-auto" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Totals & Payment */}
              <div className="neu-card p-3 rounded-2xl space-y-2 text-xs">
                <div className="flex justify-between font-black text-slate-800 text-sm">
                  <span>إجمالي فاتورة الشراء:</span>
                  <span className="tabular-nums text-blue-600">{formatCurrency(grandTotal)}</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <span className="font-semibold text-slate-700">المبلغ المدفوع للمورد نقداً:</span>
                  <NumberStepperInput
                    size="sm"
                    min={0}
                    step={10}
                    value={paidAmount}
                    onChange={(val) => setPaidAmount(val)}
                    className="w-32"
                    inputClassName="text-left font-bold"
                  />
                </div>
                <div className="flex justify-between text-slate-500 font-medium">
                  <span>المتبقي في ذمة المتجر (دين للمورد):</span>
                  <span className="tabular-nums text-red-500 font-bold">
                    {formatCurrency(Math.max(0, grandTotal - paidAmount))}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-white/60 neu-card flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="neu-button px-4 py-2 rounded-xl text-xs font-semibold text-slate-600"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSubmitPurchase}
                className="neu-button-primary px-5 py-2 rounded-xl text-xs font-bold"
              >
                {editingPurchase ? 'تحديث الفاتورة' : 'حفظ الفاتورة وتحديث المخزون'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Camera Barcode Scanner Modal */}
      <MobileBarcodeScannerModal
        isOpen={isMobileScannerOpen}
        onClose={() => setIsMobileScannerOpen(false)}
        defaultContinuous={true}
        title={tr('مسح أصناف المشتريات بكاميرا الموبايل', 'Scan Purchase Items with Mobile Camera')}
        onScan={(scannedCode) => {
          const clean = scannedCode.trim();
          const matchedProd = products.find(
            p =>
              p.barcode.trim().toLowerCase() === clean.toLowerCase() ||
              (p.sku && p.sku.trim().toLowerCase() === clean.toLowerCase())
          );
          if (matchedProd) {
            setPurchaseItems(prev => {
              const existingIdx = prev.findIndex(item => item.productId === matchedProd.id);
              if (existingIdx > -1) {
                const updated = [...prev];
                const newQty = updated[existingIdx].quantity + 1;
                updated[existingIdx] = {
                  ...updated[existingIdx],
                  quantity: newQty,
                  total: updated[existingIdx].costPrice * newQty
                };
                return updated;
              }
              return [
                ...prev,
                {
                  productId: matchedProd.id,
                  productName: matchedProd.name,
                  barcode: matchedProd.barcode,
                  costPrice: matchedProd.costPrice,
                  quantity: 1,
                  total: matchedProd.costPrice
                }
              ];
            });
            showToast(`تم مسح وإضافة "${matchedProd.name}" لفاتورة الشراء`, 'success');
          } else {
            showToast(`لم يتم العثور على منتج بالباركود: ${clean}`, 'error');
          }
        }}
      />
    </div>
  );
};
