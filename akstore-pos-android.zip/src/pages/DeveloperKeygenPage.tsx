/**
 * @file pages/DeveloperKeygenPage.tsx
 * برنامج المطور المستقل لتوليد سيريلات التفعيل للعملاء من كود الجهاز فقط
 * Dedicated Developer Keygen Tool for generating permanent activation keys from client device codes
 */

import React, { useState } from 'react';
import { 
  Key, 
  Copy, 
  Check, 
  MessageSquare, 
  Download, 
  ShieldCheck, 
  Sparkles, 
  RotateCcw, 
  AlertTriangle,
  FileCode,
  Laptop,
  ExternalLink
} from 'lucide-react';
import { 
  generateLicenseKey, 
  getWhatsAppSerialSendUrl, 
  downloadStandaloneKeygenHtml,
  resetTrialForTesting,
  simulateTrialExpired,
  activateLicense,
  getLicenseState
} from '../utils/licenseManager';
import {
  downloadWindows7InstallerBat,
  downloadWindowsSilentLauncherVbs,
  downloadElectronWin7ExeBuilder,
  downloadExeAutoUpdaterScriptBat
} from '../utils/windowsDesktopBuilder';
import { exportOfflineUpdatePackage } from '../utils/updateManager';
import { useApp } from '../contexts/AppContext';
import { copyTextFallback } from '../utils/win7Polyfills';

interface DeveloperKeygenPageProps {
  onBackToApp?: () => void;
  onRefreshLicense?: () => void;
}

export const DeveloperKeygenPage: React.FC<DeveloperKeygenPageProps> = ({
  onBackToApp,
  onRefreshLicense
}) => {
  const { showToast } = useApp();

  const [inputDeviceCode, setInputDeviceCode] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [licenseType, setLicenseType] = useState<'lifetime' | 'annual'>('lifetime');
  const [generatedSerial, setGeneratedSerial] = useState('');
  const [copiedSerial, setCopiedSerial] = useState(false);

  // History of generated keys during this session
  const [history, setHistory] = useState<Array<{
    deviceCode: string;
    serial: string;
    clientName: string;
    date: string;
  }>>([]);

  const currentDeviceState = getLicenseState();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputDeviceCode.trim()) {
      showToast('يرجى إدخال كود جهاز العميل أولاً', 'error');
      return;
    }

    const serial = generateLicenseKey(inputDeviceCode.trim(), licenseType);
    setGeneratedSerial(serial);
    showToast('تم توليد سيريل التفعيل بنجاح!', 'success');

    // Add to session history
    setHistory(prev => [
      {
        deviceCode: inputDeviceCode.trim(),
        serial,
        clientName: clientName.trim() || 'عميل غير مسمى',
        date: new Date().toLocaleTimeString('ar-SA')
      },
      ...prev.slice(0, 9)
    ]);
  };

  const handleCopy = () => {
    if (!generatedSerial) return;
    copyTextFallback(generatedSerial);
    setCopiedSerial(true);
    showToast('تم نسخ سيريل التفعيل للحافظة!', 'success');
    setTimeout(() => setCopiedSerial(false), 2000);
  };

  const whatsappUrl = generatedSerial 
    ? getWhatsAppSerialSendUrl(inputDeviceCode, generatedSerial, clientPhone)
    : '#';

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="neu-card p-6 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-slate-800">
                برنامج المطور المستقل: مولد سيريلات التفعيل (Keygen)
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700 border border-purple-200">
                خاص بالأدمن فقط
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              لا يتم تفعيل النظام إلا بالسيريل المولد من هذا البرنامج بناءً على كود جهاز العميل
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={downloadStandaloneKeygenHtml}
            className="neu-button px-3.5 py-2 rounded-xl text-xs font-bold text-blue-700 bg-blue-50/60 hover:bg-blue-100/60 border border-blue-200 flex items-center gap-1.5 cursor-pointer"
            title="تحميل البرنامج الثاني المستقل (Keygen) ليعمل على جهازك أو هاتفك بدون إنترنت"
          >
            <Download className="w-4 h-4 text-blue-600" />
            <span>تحميل برنامج توليد السيريلات المستقل (.html)</span>
          </button>

          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="neu-button px-4 py-2 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
            >
              العودة للبرنامج
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left/Main Column: Generator Form */}
        <div className="lg:col-span-7 space-y-5">
          <div className="neu-card p-6 rounded-3xl space-y-4 text-xs">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>توليد سيريل تفعيل لجهاز عميل</span>
            </h3>

            <form onSubmit={handleGenerate} className="space-y-4">
              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  كود جهاز العميل (Device Hardware ID):
                </label>
                <input
                  type="text"
                  required
                  value={inputDeviceCode}
                  onChange={(e) => setInputDeviceCode(e.target.value.toUpperCase())}
                  placeholder="مثال: POS-A1B2-C3D4-E5F6"
                  className="neu-input w-full px-4 py-2.5 rounded-xl font-mono text-sm font-bold tracking-wider placeholder:text-slate-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">
                    اسم العميل أو المتجر (اختياري للأرشفة):
                  </label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="مثال: سوبرماركت البركة"
                    className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">
                    رقم واتساب العميل (اختياري للإرسال):
                  </label>
                  <input
                    type="text"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="مثال: 2010XXXXXXXX"
                    className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  نوع مدة الترخيص:
                </label>
                <select
                  value={licenseType}
                  onChange={(e) => setLicenseType(e.target.value as 'lifetime' | 'annual')}
                  className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
                >
                  <option value="lifetime">تفعيل دائم مدى الحياة (Full Lifetime License) — لا ينتهي</option>
                  <option value="annual">ترخيص سنوي لمدة عام واحد (1 Year License)</option>
                </select>
              </div>

              <button
                type="submit"
                className="neu-button-primary w-full py-3 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <Key className="w-4 h-4" />
                <span>توليد سيريل التفعيل الآن</span>
              </button>
            </form>

            {/* Generated Output Box */}
            {generatedSerial && (
              <div className="p-4 bg-emerald-500/10 border-2 border-emerald-500/40 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-900 text-xs">سيريل التفعيل المولد لهذا الجهاز فقط:</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-800">
                    جاهز للإرسال
                  </span>
                </div>

                <div className="p-3 bg-white rounded-xl border border-emerald-300 font-mono text-center text-base sm:text-lg font-black text-emerald-800 tracking-wider select-all shadow-inner">
                  {generatedSerial}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="neu-button py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 font-bold text-slate-700 cursor-pointer text-xs"
                  >
                    {copiedSerial ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                        <span className="text-emerald-700">تم النسخ بنجاح</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 text-slate-500" />
                        <span>نسخ السيريل</span>
                      </>
                    )}
                  </button>

                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer text-xs"
                  >
                    <MessageSquare className="w-4 h-4 fill-white" />
                    <span>إرسال عبر الواتساب للعميل</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const res = activateLicense(generatedSerial);
                    if (res.success) {
                      showToast(res.message, 'success');
                      if (onRefreshLicense) onRefreshLicense();
                    } else {
                      showToast(res.message, 'error');
                    }
                  }}
                  className="w-full py-2.5 rounded-xl neu-button-primary font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer mt-1"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>تأكيد تفعيل البرنامج الآن بهذا السيريل</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Standalone Keygen Download & Admin Tools */}
        <div className="lg:col-span-5 space-y-5">
          {/* Standalone Keygen Download Card */}
          <div className="neu-card p-5 rounded-3xl space-y-3 text-xs bg-gradient-to-br from-blue-50/60 to-indigo-50/60 border border-blue-200/80">
            <h4 className="font-bold text-blue-900 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-blue-600" />
              <span>البرنامج الثاني المستقل لتوليد السيريلات (Offline Keygen)</span>
            </h4>
            <p className="text-[11px] text-blue-800/80 leading-relaxed">
              قم بتحميل هذا الملف (<span className="font-bold font-mono">AK_Store_Keygen_Generator.html</span>) والاحتفاظ به على جهازك الشخصي أو هاتفك. يعمل بدون إنترنت تماماً ويقوم بتوليد السيريل الوحيد الذي يقبل به نظام العميل.
            </p>
            <button
              type="button"
              onClick={downloadStandaloneKeygenHtml}
              className="neu-button-primary w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>تحميل برنامج المولد المستقل الآن</span>
            </button>
          </div>

          {/* Windows 7 / 8 / 10 / 11 Desktop Packager Card */}
          <div className="neu-card p-5 rounded-3xl space-y-3 text-xs bg-gradient-to-br from-emerald-50/60 to-teal-50/60 border border-emerald-200/80">
            <h4 className="font-bold text-emerald-900 flex items-center gap-2">
              <Laptop className="w-4 h-4 text-emerald-600" />
              <span>أدوات تثبيت ويندوز 7 / 8 / 10 / 11 (خاصة بالأدمن)</span>
            </h4>
            <p className="text-[11px] text-emerald-800/90 leading-relaxed">
              أدوات تحويل وتثبيت البرنامج كنسخة سطح مكتب مستقلة على أجهزة الكاشير (تعمل على Windows 7 32-bit و 64-bit فما فوق):
            </p>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => downloadWindows7InstallerBat(false, true)}
                className="neu-button-emerald w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Download className="w-4 h-4" />
                <span>تحميل مثبت سطح المكتب لـ Windows 7–11 (.BAT)</span>
              </button>
              <button
                type="button"
                onClick={() => downloadWindowsSilentLauncherVbs(true)}
                className="neu-button w-full py-2 rounded-xl font-bold text-slate-700 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-blue-600" />
                <span>تحميل المشغل الصامت المباشر (.VBS)</span>
              </button>
              <button
                type="button"
                onClick={downloadElectronWin7ExeBuilder}
                className="neu-button w-full py-2 rounded-xl font-bold text-purple-700 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileCode className="w-3.5 h-3.5 text-purple-600" />
                <span>تحميل أداة استخراج ملف .EXE قابل للتحديث (Win 7–11)</span>
              </button>
              <button
                type="button"
                onClick={downloadExeAutoUpdaterScriptBat}
                className="neu-button w-full py-2 rounded-xl font-bold text-emerald-800 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>تحميل أداة تحديث الـ .EXE لدى العميل (.BAT)</span>
              </button>
              <button
                type="button"
                onClick={exportOfflineUpdatePackage}
                className="neu-button w-full py-2 rounded-xl font-bold text-indigo-800 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-indigo-600" />
                <span>تصدير حزمة تحديث أوفلاين للـ .EXE (.akupdate)</span>
              </button>
            </div>
          </div>

          {/* Machine Status Card */}
          <div className="neu-card p-5 rounded-3xl space-y-3 text-xs">
            <h3 className="font-bold text-slate-800 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <span>معاينة حالة الفترة التجريبية على هذا الجهاز</span>
            </h3>

            <div className="p-3 bg-slate-100 rounded-2xl space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500 font-sans">كود هذا الجهاز:</span>
                <span className="font-bold text-slate-800">{currentDeviceState.deviceCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-sans">حالة التفعيل:</span>
                <span className={`font-bold font-sans ${currentDeviceState.isActivated ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {currentDeviceState.isActivated ? 'مفعل دائم بالسيريل' : 'فترة تجريبية'}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200/80 space-y-2">
              <div className="flex flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    simulateTrialExpired();
                    showToast('تمت محاكاة انتهاء الفترة التجريبية (شاشة القفل ستظهر الآن)', 'info');
                    if (onRefreshLicense) onRefreshLicense();
                  }}
                  className="neu-button px-3 py-2 rounded-xl text-[11px] font-bold text-red-600 flex items-center gap-1.5 cursor-pointer text-right"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  <span>محاكاة انتهاء الـ 2 يوم (معاينة شاشة القفل)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    resetTrialForTesting();
                    showToast('تمت إعادة ضبط الفترة التجريبية إلى 48 ساعة كاملة!', 'success');
                    if (onRefreshLicense) onRefreshLicense();
                  }}
                  className="neu-button px-3 py-2 rounded-xl text-[11px] font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer text-right"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                  <span>إعادة تعيين الفترة التجريبية (إلغاء التفعيل للاختبار)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Recent Keys Session History */}
          {history.length > 0 && (
            <div className="neu-card p-5 rounded-3xl space-y-3 text-xs">
              <h4 className="font-bold text-slate-800">السيريلات المولدة في هذه الجلسة:</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {history.map((h, i) => (
                  <div key={i} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>{h.clientName}</span>
                      <span>{h.date}</span>
                    </div>
                    <div className="font-mono text-[11px] font-bold text-slate-800 truncate">
                      {h.serial}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
