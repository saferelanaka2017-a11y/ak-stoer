/**
 * @file utils/exportUtils.ts
 * أدوات تصدير واستيراد البيانات (Excel, PDF, CSV) مع دعم كامل للغة العربية 100%
 * وتوليد كود ZATCA QR وطباعة الفواتير والتقارير بدقة عالية دون أي رموز غريبة
 */

import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Product, Customer, SaleInvoice, StoreSettings, PrinterType } from '../types';
import { db } from '../db/database';
import { AK_STORE_DEFAULT_LOGO_DATA_URL, normalizeLogoForPrint } from '../components/AKStoreLogo';

/**
 * استرجاع شعار المتجر المعتمد بصيغة PNG جاهزة للطباعة 100%
 * (يحول أي شعار SVG قديم إلى PNG Bitmap متوافق مع كافة الطابعات الحرارية وA4)
 */
export function getResolvedStoreLogo(settings?: StoreSettings): string {
  if (settings?.logoUrl && settings.logoUrl.trim()) {
    return normalizeLogoForPrint(settings.logoUrl.trim());
  }
  return normalizeLogoForPrint(AK_STORE_DEFAULT_LOGO_DATA_URL);
}

/**
 * الانتظار حتى اكتمال تحميل وفك تشفير (decode) ورسم جميع الصور والشعار داخل عنصر الطباعة قبل إرسال أمر الطباعة الفعلي
 */
async function waitForContainerImages(root: Document | HTMLElement, maxWaitMs = 900): Promise<void> {
  const imgs = Array.from(root.querySelectorAll('img'));
  if (imgs.length === 0) return;

  await new Promise<void>((resolve) => {
    let settled = false;
    const finish = () => {
      if (!settled) {
        settled = true;
        resolve();
      }
    };

    const timer = setTimeout(finish, maxWaitMs);

    let pending = imgs.length;
    const checkOne = () => {
      pending -= 1;
      if (pending <= 0) {
        clearTimeout(timer);
        finish();
      }
    };

    imgs.forEach((img) => {
      img.loading = 'eager';
      img.decoding = 'sync';
      if (img.complete && img.naturalWidth > 0) {
        checkOne();
      } else {
        img.addEventListener('load', checkOne, { once: true });
        img.addEventListener('error', checkOne, { once: true });
      }
    });
  });

  // Force synchronous bitmap decode so Chromium/Electron print compositor has the rasterized texture ready
  await Promise.all(
    imgs.map((img) =>
      typeof img.decode === 'function' ? img.decode().catch(() => {}) : Promise.resolve()
    )
  );

  // Wait 2 animation frames to guarantee the decoded bitmap is painted to the layer tree
  await new Promise<void>((resolve) => {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => resolve());
    });
  });
}

function getInvoiceInstallmentDetails(invoice: SaleInvoice) {
  const matchedPlan = db
    .getInstallmentPlans()
    .find((p) => p.invoiceNumber === invoice.invoiceNumber);
  const isInstallment = Boolean(invoice.hasInstallment || matchedPlan);
  const instCount = invoice.installmentCount || matchedPlan?.installmentCount || 0;
  const downPay = invoice.downPayment ?? matchedPlan?.downPayment ?? invoice.paidAmount;
  const remainingBalance =
    invoice.remainingInstallmentAmount ??
    matchedPlan?.remainingAmount ??
    Math.max(0, invoice.grandTotal - downPay);
  const monthlyAmount =
    invoice.monthlyInstallmentAmount ??
    (instCount > 0 ? Math.round((remainingBalance / instCount) * 100) / 100 : 0);
  const unpaidCredit = Math.max(0, invoice.grandTotal - invoice.paidAmount);

  return {
    isInstallment,
    instCount,
    downPay,
    remainingBalance,
    monthlyAmount,
    unpaidCredit
  };
}

/**
 * توليد كود Base64 متوافق مع نظام الفوترة الإلكترونية (ZATCA TLV format)
 */
export function generateZatcaQRString(
  sellerName: string,
  vatNumber: string,
  timestamp: string,
  totalAmount: number,
  vatAmount: number
): string {
  const getTLV = (tagNum: number, value: string): Uint8Array => {
    const encoder = new TextEncoder();
    const valBytes = encoder.encode(value);
    const length = valBytes.length;
    const tlv = new Uint8Array(2 + length);
    tlv[0] = tagNum;
    tlv[1] = length;
    tlv.set(valBytes, 2);
    return tlv;
  };

  const tag1 = getTLV(1, sellerName || 'Store');
  const tag2 = getTLV(2, vatNumber || '300000000000003');
  const tag3 = getTLV(3, timestamp || new Date().toISOString());
  const tag4 = getTLV(4, totalAmount.toFixed(2));
  const tag5 = getTLV(5, vatAmount.toFixed(2));

  const totalLength = tag1.length + tag2.length + tag3.length + tag4.length + tag5.length;
  const merged = new Uint8Array(totalLength);
  let offset = 0;
  [tag1, tag2, tag3, tag4, tag5].forEach((tag) => {
    merged.set(tag, offset);
    offset += tag.length;
  });

  let binary = '';
  for (let i = 0; i < merged.length; i++) {
    binary += String.fromCharCode(merged[i]);
  }
  return btoa(binary);
}

/**
 * تصدير قائمة المنتجات إلى ملف Excel (.xlsx)
 */
export function exportProductsToExcel(products: Product[], filename = 'products_inventory.xlsx') {
  const rows = products.map((p, idx) => ({
    '#': idx + 1,
    'الباركود': p.barcode,
    'اسم المنتج': p.name,
    'التصنيف': p.category,
    'سعر الشراء / التكلفة': p.costPrice,
    'سعر البيع': p.salePrice,
    'المخزون المتوفر': p.stock,
    'حد التنبيه': p.minStockAlert,
    'الوحدة': p.unit,
    'الوصف': p.description || ''
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'المنتجات');
  XLSX.writeFile(workbook, filename);
}

/**
 * استيراد منتجات من ملف Excel أو CSV
 */
export async function parseProductsFromFile(file: File): Promise<Partial<Product>[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json: any[] = XLSX.utils.sheet_to_json(worksheet);

        const parsedProducts: Partial<Product>[] = json.map((row) => {
          return {
            barcode: String(
              row['الباركود'] || row['barcode'] || row['Barcode'] || Date.now().toString().slice(-8)
            ),
            name: String(row['اسم المنتج'] || row['name'] || row['Name'] || 'صنف جديد'),
            category: String(row['التصنيف'] || row['category'] || 'عام'),
            costPrice: Number(row['سعر الشراء / التكلفة'] || row['costPrice'] || row['Cost'] || 0),
            salePrice: Number(row['سعر البيع'] || row['salePrice'] || row['Price'] || 0),
            stock: Number(row['المخزون المتوفر'] || row['stock'] || row['Stock'] || 10),
            minStockAlert: Number(row['حد التنبيه'] || row['minStockAlert'] || 5),
            unit: String(row['الوحدة'] || row['unit'] || 'حبة'),
            description: String(row['الوصف'] || row['description'] || '')
          };
        });

        resolve(parsedProducts);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * تصدير تقرير المبيعات إلى Excel
 */
export function exportSalesToExcel(sales: SaleInvoice[], filename = 'sales_report.xlsx') {
  const rows = sales.map((s, idx) => ({
    '#': idx + 1,
    'رقم الفاتورة': s.invoiceNumber,
    'التاريخ': new Date(s.date).toLocaleString('ar-SA'),
    'الكاشير': s.cashierName,
    'العميل': s.customerName || 'عميل نقدي',
    'عدد الأصناف': s.items.length,
    'المجموع قبل الضريبة': s.subtotal,
    'الخصم': s.discountTotal,
    'ضريبة القيمة المضافة': s.taxTotal,
    'الإجمالي النهائي': s.grandTotal,
    'المدفوع': s.paidAmount,
    'طريقة الدفع':
      s.paymentMethod === 'cash'
        ? 'نقداً'
        : s.paymentMethod === 'card'
        ? 'بطاقة'
        : s.paymentMethod === 'credit'
        ? 'آجل'
        : 'متعدد',
    'ملاحظات': s.notes || ''
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'تقرير المبيعات');
  XLSX.writeFile(workbook, filename);
}

/**
 * تصدير قائمة العملاء إلى Excel
 */
export function exportCustomersToExcel(customers: Customer[], filename = 'customers_list.xlsx') {
  const rows = customers.map((c, idx) => ({
    '#': idx + 1,
    'اسم العميل': c.name,
    'الهاتف': c.phone,
    'البريد الإلكتروني': c.email || '',
    'الرصيد / المديونية': c.balance,
    'الرقم الضريبي': c.taxNumber || '',
    'العنوان': c.address || '',
    'تاريخ التسجيل': new Date(c.createdAt).toLocaleDateString('ar-SA')
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'العملاء');
  XLSX.writeFile(workbook, filename);
}

// ============================================================================
// محرك تصدير PDF فائق الدقة مع الدعم الكامل للغة العربية بدون أي رموز أو تشويه
// Arabic High-Resolution PDF & Print Rendering Engine
// ============================================================================

/**
 * تحويل أي عنصر DOM مباشرة إلى ملف PDF عالي الجودة يدعم اللغة العربية تماماً
 */
export async function exportElementToPDF(
  element: HTMLElement,
  filename: string,
  layout: 'thermal' | 'a4' | 'a5' = 'a4'
): Promise<void> {
  try {
    // Wait for fonts and images to be ready
    if ((document as any).fonts?.ready) {
      await (document as any).fonts.ready;
    }
    await waitForContainerImages(element, 600);

    const canvas = await html2canvas(element, {
      scale: 2, // High DPI rendering
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');

    if (layout === 'thermal') {
      const imgHeight = (canvas.height * 80) / canvas.width;
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [80, Math.max(100, imgHeight)]
      });
      pdf.addImage(imgData, 'PNG', 0, 0, 80, imgHeight);
      pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
    } else {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: layout === 'a5' ? 'a5' : 'a4'
      });
      const pw = pdf.internal.pageSize.getWidth();
      const ph = (canvas.height * pw) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, pw, ph);
      pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
    }
  } catch (err) {
    console.error('Error generating PDF from element:', err);
    throw err;
  }
}

/**
 * تحويل محتوى HTML عربي إلى PDF عبر عنصر افتراضي نظيف
 */
export async function exportHtmlToPDF(options: {
  htmlContent: string;
  filename: string;
  layout?: 'thermal' | 'a4' | 'a5' | 'label';
  title?: string;
}): Promise<void> {
  const { htmlContent, filename, layout = 'a4' } = options;

  if ((document as any).fonts?.ready) {
    await (document as any).fonts.ready;
  }

  // Create isolated render container
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.zIndex = '-1000';
  container.style.background = '#ffffff';
  container.style.color = '#1e293b';
  container.style.fontFamily = "'Readex Pro', system-ui, -apple-system, sans-serif";
  container.style.direction = 'rtl';

  if (layout === 'thermal') {
    container.style.width = '320px'; // 80mm equivalent
    container.style.padding = '14px';
  } else if (layout === 'label') {
    container.style.width = '240px'; // 50x30mm thermal sticker
    container.style.padding = '10px';
  } else if (layout === 'a5') {
    container.style.width = '560px';
    container.style.padding = '24px';
  } else {
    // a4
    container.style.width = '800px';
    container.style.padding = '36px';
  }

  container.innerHTML = htmlContent;
  document.body.appendChild(container);

  try {
    await waitForContainerImages(container, 600);

    const canvas = await html2canvas(container, {
      scale: 2.5, // Crisp vector-like quality
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');

    if (layout === 'label') {
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: [50, 30]
      });
      pdf.addImage(imgData, 'PNG', 0, 0, 50, 30);
      pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
    } else if (layout === 'thermal') {
      const imgHeight = (canvas.height * 80) / canvas.width;
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [80, Math.max(100, imgHeight)]
      });
      pdf.addImage(imgData, 'PNG', 0, 0, 80, imgHeight);
      pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
    } else {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: layout === 'a5' ? 'a5' : 'a4'
      });
      const pw = pdf.internal.pageSize.getWidth();
      const ph = (canvas.height * pw) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, pw, ph);
      pdf.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
    }
  } catch (err) {
    console.error('Failed to export HTML to PDF:', err);
    throw err;
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

/**
 * طباعة محتوى HTML عبر إطار مخفي (يدعم الطباعة المباشرة وحفظ كـ PDF من المتصفح بدون نوافذ منبثقة)
 */
export function printHtmlViaIframe(htmlContent: string, title = 'طباعة مستند'): void {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-9999px';
  iframe.style.top = '0';
  iframe.style.width = '800px';
  iframe.style.height = '1000px';
  iframe.style.opacity = '0.01';
  iframe.style.pointerEvents = 'none';
  iframe.style.zIndex = '-1';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) return;

  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
  const fontLinks = isOnline
    ? `<link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">`
    : '';

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <title>${title}</title>
      ${fontLinks}
      <style>
        * { font-family: 'Readex Pro', system-ui, Arial, sans-serif; box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        body { margin: 0; padding: 16px; color: #1e293b; background: #fff; direction: rtl; }
        img { max-width: 100%; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; margin-bottom: 12px; }
        th, td { border: 1px solid #cbd5e1; padding: 7px 10px; text-align: right; font-size: 11px; }
        th { background: #f1f5f9; font-weight: bold; }
        @media print {
          body { padding: 0; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
          @page { margin: 8mm; }
        }
      </style>
    </head>
    <body>
      ${htmlContent}
    </body>
    </html>
  `);
  doc.close();

  waitForContainerImages(doc, 900).then(() => {
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        if (document.body.contains(iframe)) {
          document.body.removeChild(iframe);
        }
      }, 3000);
    }, 150);
  });
}

/**
 * طباعة الفاتورة فورياً بشكل مباشر بدون نوافذ غير مرغوبة
 * تدعم مقاسات الطابعات الحرارية (80mm و 58mm) أو الطابعة المكتبية (A4)
 */
export function printInvoiceDirect(
  invoice: SaleInvoice,
  settings: StoreSettings,
  printerType?: PrinterType
): void {
  const targetPrinter = printerType || settings.selectedPrinter || 'thermal-80';
  const is58mm = targetPrinter === 'thermal-58';
  const isA4 = targetPrinter === 'a4-standard' || settings.printLayout === 'a4';

  const itemsHtml = invoice.items
    .map(
      (item) => `
    <tr>
      <td style="padding: 4px 6px; border-bottom: 1px dashed #000; font-weight: bold; text-align: right;">
        ${item.product.name}
        ${!is58mm ? `<div style="font-size: 8px; color: #475569; font-weight: normal;">${item.product.barcode}</div>` : ''}
      </td>
      <td style="padding: 4px 2px; border-bottom: 1px dashed #000; text-align: center; font-weight: bold;">
        ${item.quantity}
      </td>
      <td style="padding: 4px 2px; border-bottom: 1px dashed #000; text-align: center;">
        ${item.price.toFixed(2)}
      </td>
      <td style="padding: 4px 2px; border-bottom: 1px dashed #000; text-align: left; font-weight: bold;">
        ${item.total.toFixed(2)}
      </td>
    </tr>
  `
    )
    .join('');

  const logoSrc = getResolvedStoreLogo(settings);
  const logoSizeNum = is58mm ? 52 : isA4 ? 76 : 64;
  const logoSizePx = `${logoSizeNum}px`;

  const htmlContent = `
    <div style="font-family: 'Readex Pro', Tahoma, 'Segoe UI', sans-serif; direction: rtl; text-align: right; color: #000000; background: #ffffff;">
      <div style="text-align: center; border-bottom: 2px dashed #000; padding-bottom: 8px; margin-bottom: 8px;">
        <div style="text-align: center; margin-bottom: 6px; width: 100%; display: flex; justify-content: center; align-items: center;">
          <img
            src="${logoSrc}"
            width="${logoSizeNum}"
            height="${logoSizeNum}"
            alt="${settings.storeName || 'AK Store'}"
            style="width: ${logoSizePx}; height: ${logoSizePx}; min-width: ${logoSizePx}; min-height: ${logoSizePx}; max-width: ${logoSizePx}; max-height: ${logoSizePx}; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important;"
          />
        </div>
        <h2 style="margin: 0; font-size: ${is58mm ? '13px' : '17px'}; font-weight: 800;">${settings.storeName || 'Soft Glass POS'}</h2>
        <p style="margin: 2px 0; font-size: ${is58mm ? '9px' : '11px'};">${settings.storeAddress || ''} | هاتف: ${settings.storePhone || ''}</p>
        <p style="margin: 2px 0; font-size: ${is58mm ? '9px' : '11px'}; font-weight: bold;">الرقم الضريبي: ${settings.taxNumber || 'غير محدد'}</p>
        <div style="display: inline-block; border: 1px solid #000; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; margin-top: 4px;">
          فاتورة ضريبية مبسطة
        </div>
      </div>

      <div style="font-size: ${is58mm ? '9px' : '11px'}; line-height: 1.5; border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px;">
        <div style="display: flex; justify-content: space-between;">
          <span><strong>رقم الفاتورة:</strong> ${invoice.invoiceNumber}</span>
          <span>${new Date(invoice.date).toLocaleDateString('ar-SA')}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-top: 2px;">
          <span><strong>الكاشير:</strong> ${invoice.cashierName}</span>
          <span><strong>العميل:</strong> ${invoice.customerName || 'نقدي'}</span>
        </div>
        <div style="margin-top: 2px;">
          <strong>طريقة الدفع:</strong> ${
            getInvoiceInstallmentDetails(invoice).isInstallment
              ? `تقسيط (دفع مقدم والباقي أقساط على ${getInvoiceInstallmentDetails(invoice).instCount} شهر)`
              : invoice.paymentMethod === 'cash'
              ? 'نقداً'
              : invoice.paymentMethod === 'card'
              ? 'شبكة / بطاقة'
              : invoice.paymentMethod === 'credit'
              ? 'آجل'
              : 'دفعة مقدمة والباقي آجل'
          }
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: ${is58mm ? '9px' : '11px'}; margin-bottom: 8px;">
        <thead>
          <tr style="border-bottom: 1.5px solid #000;">
            <th style="padding: 4px 2px; text-align: right;">الصنف</th>
            <th style="padding: 4px 2px; text-align: center;">الكمية</th>
            <th style="padding: 4px 2px; text-align: center;">السعر</th>
            <th style="padding: 4px 2px; text-align: left;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
      </table>

      <div style="border-top: 1px dashed #000; padding-top: 6px; font-size: ${is58mm ? '10px' : '11px'}; line-height: 1.6;">
        <div style="display: flex; justify-content: space-between;">
          <span>${invoice.taxTotal > 0 ? 'المجموع قبل الضريبة:' : 'المجموع:'}</span>
          <span>${invoice.subtotal.toFixed(2)} ${settings.currencySymbol}</span>
        </div>
        ${
          invoice.taxTotal > 0
            ? `<div style="display: flex; justify-content: space-between;">
                <span>ضريبة القيمة المضافة (${
                  invoice.subtotal > 0
                    ? Math.round((invoice.taxTotal / invoice.subtotal) * 10000) / 100
                    : settings.vatPercentage
                }%):</span>
                <span>${invoice.taxTotal.toFixed(2)} ${settings.currencySymbol}</span>
              </div>`
            : ''
        }
        ${
          invoice.discountTotal > 0
            ? `<div style="display: flex; justify-content: space-between;">
                <span>الخصم:</span>
                <span>-${invoice.discountTotal.toFixed(2)} ${settings.currencySymbol}</span>
              </div>`
            : ''
        }
        <div style="display: flex; justify-content: space-between; font-size: ${is58mm ? '12px' : '14px'}; font-weight: 800; border-top: 1.5px solid #000; padding-top: 4px; margin-top: 4px;">
          <span>الإجمالي النهائي:</span>
          <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
        </div>
        ${(() => {
          const inst = getInvoiceInstallmentDetails(invoice);
          if (inst.isInstallment) {
            return `
              <div style="margin-top: 6px; padding: 6px; border: 1.5px solid #000; border-radius: 6px; background: #f8fafc; font-size: ${is58mm ? '9px' : '10.5px'}; line-height: 1.5;">
                <div style="font-weight: 800; border-bottom: 1px dashed #000; padding-bottom: 3px; margin-bottom: 3px; text-align: center;">
                  تفصيل نظام السداد: تقسيط (${inst.instCount} شهر)
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>الدفعة المقدمة المدفوعة (المقدم):</span>
                  <span>${inst.downPay.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>المبلغ المتبقي للتقسيط:</span>
                  <span>${inst.remainingBalance.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>عدد الأقساط الشهرية:</span>
                  <span>${inst.instCount} أقساط (على ${inst.instCount} شهر)</span>
                </div>
                ${
                  inst.monthlyAmount > 0
                    ? `<div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed #000; padding-top: 2px; margin-top: 2px;">
                        <span>قيمة القسط الشهري:</span>
                        <span>${inst.monthlyAmount.toFixed(2)} ${settings.currencySymbol} / شهرياً</span>
                      </div>`
                    : ''
                }
                <div style="margin-top: 4px; text-align: center; font-weight: bold; font-size: ${is58mm ? '8.5px' : '9.5px'};">
                  تم دفع مقدم (${inst.downPay.toFixed(2)} ${settings.currencySymbol}) والباقي (${inst.remainingBalance.toFixed(2)} ${settings.currencySymbol}) أقساط على (${inst.instCount}) شهر
                </div>
              </div>
            `;
          }
          if (inst.unpaidCredit > 0 && invoice.paidAmount > 0) {
            return `
              <div style="margin-top: 6px; padding: 6px; border: 1.5px solid #000; border-radius: 6px; background: #f8fafc; font-size: ${is58mm ? '9px' : '10.5px'}; line-height: 1.5;">
                <div style="font-weight: 800; border-bottom: 1px dashed #000; padding-bottom: 3px; margin-bottom: 3px; text-align: center;">
                  تفصيل نظام السداد: دفعة مقدمة والباقي آجل (سداد جزئي)
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>إجمالي الفاتورة:</span>
                  <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>المبلغ المدفوع مقدماً (المسدد الآن):</span>
                  <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed #000; padding-top: 2px; margin-top: 2px;">
                  <span>المبلغ المتبقي (آجل بذمة العميل):</span>
                  <span>${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="margin-top: 4px; text-align: center; font-weight: bold; font-size: ${is58mm ? '8.5px' : '9.5px'};">
                  تم سداد دفعة مقدمة (${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}) والمتبقي (${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}) آجل على حساب (${invoice.customerName || 'العميل'})
                </div>
              </div>
            `;
          }
          if (inst.unpaidCredit > 0) {
            return `
              <div style="margin-top: 6px; padding: 6px; border: 1.5px solid #000; border-radius: 6px; background: #f8fafc; font-size: ${is58mm ? '9px' : '10.5px'}; line-height: 1.5;">
                <div style="font-weight: 800; border-bottom: 1px dashed #000; padding-bottom: 3px; margin-bottom: 3px; text-align: center;">
                  تفصيل نظام السداد: بيع آجل بالكامل (على الحساب)
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>إجمالي الفاتورة:</span>
                  <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>المبلغ المدفوع عند الإصدار:</span>
                  <span>0.00 ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed #000; padding-top: 2px; margin-top: 2px;">
                  <span>إجمالي المبلغ الآجل المستحق:</span>
                  <span>${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="margin-top: 4px; text-align: center; font-weight: bold; font-size: ${is58mm ? '8.5px' : '9.5px'};">
                  فاتورة آجلة بالكامل بقيمة (${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}) مسجلة في ذمة (${invoice.customerName || 'العميل'})
                </div>
              </div>
            `;
          }
          if (invoice.paymentMethod === 'card') {
            return `
              <div style="margin-top: 6px; padding: 6px; border: 1.5px solid #000; border-radius: 6px; background: #f8fafc; font-size: ${is58mm ? '9px' : '10.5px'}; line-height: 1.5;">
                <div style="font-weight: 800; border-bottom: 1px dashed #000; padding-bottom: 3px; margin-bottom: 3px; text-align: center;">
                  تفصيل نظام السداد: بطاقة شبكة / تحويل بنكي (مسددة ✓)
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>إجمالي الفاتورة المستحقة:</span>
                  <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>المبلغ المحصل عبر الشبكة / البنك:</span>
                  <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed #000; padding-top: 2px; margin-top: 2px;">
                  <span>المتبقي على العميل:</span>
                  <span>0.00 ${settings.currencySymbol} (خالصة)</span>
                </div>
                <div style="margin-top: 4px; text-align: center; font-weight: bold; font-size: ${is58mm ? '8.5px' : '9.5px'};">
                  تم سداد كامل الفاتورة (${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}) عبر بطاقة الشبكة / البنك ولا يوجد متبقي
                </div>
              </div>
            `;
          }
          return `
            <div style="margin-top: 6px; padding: 6px; border: 1.5px solid #000; border-radius: 6px; background: #f8fafc; font-size: ${is58mm ? '9px' : '10.5px'}; line-height: 1.5;">
              <div style="font-weight: 800; border-bottom: 1px dashed #000; padding-bottom: 3px; margin-bottom: 3px; text-align: center;">
                تفصيل نظام السداد: سداد نقدي كاش (مسددة ✓)
              </div>
              <div style="display: flex; justify-content: space-between; font-weight: bold;">
                <span>إجمالي الفاتورة المستحقة:</span>
                <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-weight: bold;">
                <span>المبلغ النقدي المستلم:</span>
                <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              ${
                invoice.changeAmount > 0
                  ? `<div style="display: flex; justify-content: space-between; font-weight: bold;">
                      <span>المتبقي للعميل (الفكة):</span>
                      <span>${invoice.changeAmount.toFixed(2)} ${settings.currencySymbol}</span>
                    </div>`
                  : ''
              }
              <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed #000; padding-top: 2px; margin-top: 2px;">
                <span>المتبقي على العميل:</span>
                <span>0.00 ${settings.currencySymbol} (خالصة)</span>
              </div>
              <div style="margin-top: 4px; text-align: center; font-weight: bold; font-size: ${is58mm ? '8.5px' : '9.5px'};">
                تم سداد كامل قيمة الفاتورة (${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}) نقداً بالخزينة ولا يوجد متبقي
              </div>
            </div>
          `;
        })()}
      </div>

      <div style="text-align: center; margin-top: 12px; font-size: 9px; border-top: 1px dashed #000; padding-top: 8px;">
        <p style="margin: 0;">${settings.footerNotes || 'شكراً لزيارتكم!'}</p>
        <p style="margin: 3px 0 0 0; font-size: 8px; color: #475569;">فاتورة إلكترونية معتمدة ZATCA</p>
      </div>
    </div>
  `;

  // Create offscreen iframe with non-zero viewport dimensions so Chromium/Electron decodes & rasterizes images before print()
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-9999px';
  iframe.style.top = '0';
  iframe.style.width = isA4 ? '800px' : '380px';
  iframe.style.height = '900px';
  iframe.style.opacity = '0.01';
  iframe.style.pointerEvents = 'none';
  iframe.style.zIndex = '-1';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) return;

  const pageSizeStyle = is58mm
    ? '@page { size: 58mm auto; margin: 0; } body { width: 54mm; margin: 0 auto; padding: 2mm; }'
    : isA4
    ? '@page { size: A4 portrait; margin: 10mm; } body { width: 100%; max-width: 190mm; margin: 0 auto; padding: 10px; }'
    : '@page { size: 80mm auto; margin: 0; } body { width: 76mm; margin: 0 auto; padding: 2.5mm; }';

  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
  const fontLinks = isOnline
    ? `<link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@400;600;700;800&display=swap" rel="stylesheet">`
    : '';

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <title>طباعة فاتورة #${invoice.invoiceNumber}</title>
      ${fontLinks}
      <style>
        * { font-family: 'Readex Pro', Tahoma, 'Segoe UI', Arial, sans-serif; box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        body { margin: 0; background: #ffffff; color: #000000; direction: rtl; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        img { display: block !important; margin: 0 auto !important; visibility: visible !important; opacity: 1 !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        ${pageSizeStyle}
        @media print {
          * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color-adjust: exact !important; }
          body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
          img { display: block !important; margin: 0 auto !important; visibility: visible !important; opacity: 1 !important; }
        }
      </style>
    </head>
    <body>
      ${htmlContent}
    </body>
    </html>
  `);
  doc.close();

  waitForContainerImages(doc, 900).then(() => {
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        if (document.body.contains(iframe)) {
          document.body.removeChild(iframe);
        }
      }, 3000);
    }, 150);
  });
}

/**
 * تصدير الفاتورة إلى ملف Microsoft Word (.doc) كامل التنسيق يدعم العربية 100%
 * يفتح مباشرة في برنامج Word أو WordPad أو Google Docs بدون أي تشويه للحروف أو الجداول
 */
export function exportInvoiceToWord(
  invoice: SaleInvoice,
  settings: StoreSettings,
  filename?: string
): void {
  const safeFilename = filename || `فاتورة_${invoice.invoiceNumber}.doc`;

  const itemsRows = invoice.items
    .map(
      (item, index) => `
    <tr>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 8px 10px;">${index + 1}</td>
      <td style="text-align: right; border: 1px solid #cbd5e1; padding: 8px 10px; font-weight: bold;">
        ${item.product.name}
        <div style="font-size: 10pt; color: #64748b; font-weight: normal;">باركود: ${item.product.barcode}</div>
      </td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 8px 10px; font-weight: bold;">${item.quantity}</td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 8px 10px;">${item.price.toFixed(2)} ${settings.currencySymbol}</td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 8px 10px;">${(item.discount || 0).toFixed(2)} ${settings.currencySymbol}</td>
      <td style="text-align: left; border: 1px solid #cbd5e1; padding: 8px 10px; font-weight: bold;">${item.total.toFixed(2)} ${settings.currencySymbol}</td>
    </tr>
  `
    )
    .join('');

  const wordContent = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" 
          xmlns:w="urn:schemas-microsoft-com:office:word" 
          xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>فاتورة ضريبية مبسطة - ${invoice.invoiceNumber}</title>
      <!--[if gte mso 9]>
      <xml>
        <w:WordDocument>
          <w:View>Print</w:View>
          <w:Zoom>100</w:Zoom>
          <w:DoNotOptimizeForBrowser/>
        </w:WordDocument>
      </xml>
      <![endif]-->
      <style>
        @page {
          size: 21cm 29.7cm; /* A4 */
          margin: 1.5cm 1.5cm 1.5cm 1.5cm;
          mso-page-orientation: portrait;
        }
        body {
          font-family: 'Segoe UI', Tahoma, 'Arial', sans-serif;
          direction: rtl;
          text-align: right;
          color: #0f172a;
          background: #ffffff;
          padding: 20px;
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #0284c7;
          padding-bottom: 15px;
          margin-bottom: 20px;
        }
        .store-name {
          font-size: 20pt;
          font-weight: bold;
          color: #0369a1;
          margin-bottom: 5px;
        }
        .badge {
          display: inline-block;
          background: #e0f2fe;
          color: #0284c7;
          border: 1px solid #7dd3fc;
          padding: 4px 16px;
          border-radius: 999px;
          font-weight: bold;
          font-size: 11pt;
          margin-top: 8px;
        }
        .meta-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
          background: #f8fafc;
          border: 1px solid #e2e8f0;
        }
        .meta-table td {
          padding: 10px 14px;
          border: 1px solid #e2e8f0;
          font-size: 11pt;
        }
        .items-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
          border: 1px solid #cbd5e1;
        }
        .items-table th {
          background-color: #0284c7;
          color: #ffffff;
          padding: 10px;
          font-size: 11pt;
          border: 1px solid #0284c7;
        }
        .totals-table {
          width: 55%;
          margin-right: auto;
          margin-left: 0;
          border-collapse: collapse;
          margin-top: 15px;
          border: 1px solid #94a3b8;
          background: #f8fafc;
        }
        .totals-table td {
          padding: 8px 12px;
          border: 1px solid #cbd5e1;
          font-size: 11pt;
        }
        .grand-total {
          background-color: #e0f2fe;
          font-size: 13pt;
          font-weight: bold;
          color: #0369a1;
        }
        .zatca-box {
          margin-top: 25px;
          padding: 12px;
          border: 1px dashed #0284c7;
          background: #f0f9ff;
          text-align: center;
          font-size: 10pt;
          color: #0369a1;
        }
        .footer {
          margin-top: 30px;
          text-align: center;
          font-size: 10pt;
          color: #64748b;
          border-top: 1px solid #e2e8f0;
          padding-top: 12px;
        }
      </style>
    </head>
    <body dir="rtl">
      <div class="header">
        <div style="text-align: center; margin-bottom: 8px;">
          <img src="${getResolvedStoreLogo(settings)}" width="64" height="64" alt="${settings.storeName || 'AK Store'}" style="width: 64px; height: 64px; object-fit: contain; border-radius: 10px;" />
        </div>
        <div class="store-name">${settings.storeName || 'Soft Glass POS'}</div>
        <div style="font-size: 11pt; color: #475569;">
          ${settings.storeAddress || ''} | هاتف: ${settings.storePhone || ''}
        </div>
        <div style="font-size: 11pt; font-weight: bold; color: #334155; margin-top: 4px;">
          الرقم الضريبي للمنشأة: ${settings.taxNumber || 'غير محدد'} | السجل التجاري: ${settings.crNumber || 'غير محدد'}
        </div>
        <div>
          <span class="badge">فاتورة مبيعات ضريبية مبسطة (Simplified Tax Invoice)</span>
        </div>
      </div>

      <table class="meta-table" dir="rtl">
        <tr>
          <td><strong>رقم الفاتورة:</strong> ${invoice.invoiceNumber}</td>
          <td><strong>التاريخ والوقت:</strong> ${new Date(invoice.date).toLocaleString('ar-SA')}</td>
        </tr>
        <tr>
          <td><strong>اسم العميل:</strong> ${invoice.customerName || 'عميل نقدي'}</td>
          <td><strong>الكاشير / البائع:</strong> ${invoice.cashierName}</td>
        </tr>
        <tr>
          <td><strong>طريقة الدفع:</strong> ${
            getInvoiceInstallmentDetails(invoice).isInstallment
              ? `تقسيط — دفع مقدم والباقي أقساط على (${getInvoiceInstallmentDetails(invoice).instCount}) شهر`
              : invoice.paymentMethod === 'cash'
              ? 'نقداً (Cash)'
              : invoice.paymentMethod === 'card'
              ? 'بطاقة شبكة (Card / Mada)'
              : invoice.paymentMethod === 'credit'
              ? 'آجل (On Credit)'
              : 'دفعة مقدمة والباقي آجل (Split)'
          }</td>
          <td><strong>حالة الفاتورة:</strong> ${
            getInvoiceInstallmentDetails(invoice).isInstallment
              ? `تقسيط على ${getInvoiceInstallmentDetails(invoice).instCount} شهر`
              : getInvoiceInstallmentDetails(invoice).unpaidCredit > 0
              ? 'متبقي آجل بذمة العميل'
              : 'مسددة ومكتملة'
          }</td>
        </tr>
      </table>

      <table class="items-table" dir="rtl">
        <thead>
          <tr>
            <th style="width: 5%;">#</th>
            <th style="width: 45%; text-align: right;">الصنف / البيان</th>
            <th style="width: 10%; text-align: center;">الكمية</th>
            <th style="width: 13%; text-align: center;">السعر</th>
            <th style="width: 12%; text-align: center;">الخصم</th>
            <th style="width: 15%; text-align: left;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${itemsRows}
        </tbody>
      </table>

      <table class="totals-table" dir="rtl">
        <tr>
          <td>${invoice.taxTotal > 0 ? 'المجموع الخاضع للضريبة:' : 'المجموع:'}</td>
          <td style="text-align: left; font-weight: bold;">${invoice.subtotal.toFixed(2)} ${settings.currencySymbol}</td>
        </tr>
        ${
          invoice.discountTotal > 0
            ? `<tr>
                <td style="color: #059669;">إجمالي الخصم الممنوح:</td>
                <td style="text-align: left; font-weight: bold; color: #059669;">-${invoice.discountTotal.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>`
            : ''
        }
        ${
          invoice.taxTotal > 0
            ? `<tr>
                <td>ضريبة القيمة المضافة (${
                  invoice.subtotal > 0
                    ? Math.round((invoice.taxTotal / invoice.subtotal) * 10000) / 100
                    : settings.vatPercentage
                }%):</td>
                <td style="text-align: left; font-weight: bold;">${invoice.taxTotal.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>`
            : ''
        }
        <tr class="grand-total">
          <td>${invoice.taxTotal > 0 ? 'الإجمالي النهائي شامل الضريبة:' : 'الإجمالي النهائي:'}</td>
          <td style="text-align: left; font-weight: bold;">${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</td>
        </tr>
        ${(() => {
          const inst = getInvoiceInstallmentDetails(invoice);
          if (inst.isInstallment) {
            return `
              <tr>
                <td colspan="2" style="background: #fef3c7; color: #92400e; font-weight: bold; text-align: center;">
                  تفصيل نظام السداد: تقسيط شهري (${inst.instCount} شهر)
                </td>
              </tr>
              <tr>
                <td style="color: #059669; font-weight: bold;">الدفعة المقدمة المدفوعة (المقدم):</td>
                <td style="text-align: left; color: #059669; font-weight: bold;">${inst.downPay.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td style="color: #dc2626; font-weight: bold;">المبلغ المتبقي للتقسيط:</td>
                <td style="text-align: left; color: #dc2626; font-weight: bold;">${inst.remainingBalance.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td style="color: #0f172a; font-weight: bold;">عدد الأقساط الشهرية:</td>
                <td style="text-align: left; color: #0f172a; font-weight: bold;">${inst.instCount} أقساط (على ${inst.instCount} شهر)</td>
              </tr>
              ${
                inst.monthlyAmount > 0
                  ? `<tr>
                      <td style="color: #0369a1; font-weight: bold;">قيمة القسط الشهري:</td>
                      <td style="text-align: left; color: #0369a1; font-weight: bold;">${inst.monthlyAmount.toFixed(2)} ${settings.currencySymbol} / شهرياً</td>
                    </tr>`
                  : ''
              }
              <tr>
                <td colspan="2" style="background: #fffbeb; color: #92400e; font-weight: bold; text-align: center;">
                  تم دفع مقدم (${inst.downPay.toFixed(2)} ${settings.currencySymbol}) والباقي (${inst.remainingBalance.toFixed(2)} ${settings.currencySymbol}) أقساط على (${inst.instCount}) شهر
                </td>
              </tr>
            `;
          }
          if (inst.unpaidCredit > 0 && invoice.paidAmount > 0) {
            return `
              <tr>
                <td colspan="2" style="background: #f3e8ff; color: #6b21a8; font-weight: bold; text-align: center;">
                  تفصيل نظام السداد: دفعة مقدمة والباقي آجل (سداد جزئي)
                </td>
              </tr>
              <tr>
                <td style="color: #059669; font-weight: bold;">المبلغ المدفوع مقدماً (المسدد الآن):</td>
                <td style="text-align: left; color: #059669; font-weight: bold;">${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td style="color: #dc2626; font-weight: bold;">المبلغ المتبقي (آجل بذمة العميل):</td>
                <td style="text-align: left; color: #dc2626; font-weight: bold;">${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td colspan="2" style="background: #faf5ff; color: #6b21a8; font-weight: bold; text-align: center;">
                  تم سداد دفعة مقدمة (${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}) والمتبقي (${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}) آجل على حساب (${invoice.customerName || 'العميل'})
                </td>
              </tr>
            `;
          }
          if (inst.unpaidCredit > 0) {
            return `
              <tr>
                <td colspan="2" style="background: #fee2e2; color: #991b1b; font-weight: bold; text-align: center;">
                  تفصيل نظام السداد: بيع آجل بالكامل (على الحساب)
                </td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: bold;">المبلغ المدفوع عند الإصدار:</td>
                <td style="text-align: left; color: #64748b; font-weight: bold;">0.00 ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td style="color: #dc2626; font-weight: bold;">إجمالي المبلغ الآجل المستحق:</td>
                <td style="text-align: left; color: #dc2626; font-weight: bold;">${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td colspan="2" style="background: #fef2f2; color: #991b1b; font-weight: bold; text-align: center;">
                  فاتورة آجلة بالكامل بقيمة (${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}) مسجلة في ذمة (${invoice.customerName || 'العميل'})
                </td>
              </tr>
            `;
          }
          if (invoice.paymentMethod === 'card') {
            return `
              <tr>
                <td colspan="2" style="background: #dbeafe; color: #1e40af; font-weight: bold; text-align: center;">
                  تفصيل نظام السداد: بطاقة شبكة / تحويل بنكي (مسددة بالكامل ✓)
                </td>
              </tr>
              <tr>
                <td style="color: #1d4ed8; font-weight: bold;">المبلغ المحصل عبر الشبكة / البنك:</td>
                <td style="text-align: left; color: #1d4ed8; font-weight: bold;">${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</td>
              </tr>
              <tr>
                <td style="color: #059669; font-weight: bold;">المتبقي على العميل:</td>
                <td style="text-align: left; color: #059669; font-weight: bold;">0.00 ${settings.currencySymbol} (خالصة)</td>
              </tr>
            `;
          }
          return `
            <tr>
              <td colspan="2" style="background: #d1fae5; color: #065f46; font-weight: bold; text-align: center;">
                تفصيل نظام السداد: سداد نقدي كاش (مسددة بالكامل ✓)
              </td>
            </tr>
            <tr>
              <td style="color: #059669; font-weight: bold;">المبلغ النقدي المستلم:</td>
              <td style="text-align: left; color: #059669; font-weight: bold;">${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</td>
            </tr>
            ${
              invoice.changeAmount > 0
                ? `<tr>
                    <td style="color: #0369a1; font-weight: bold;">المتبقي للعميل (الفكة):</td>
                    <td style="text-align: left; color: #0369a1; font-weight: bold;">${invoice.changeAmount.toFixed(2)} ${settings.currencySymbol}</td>
                  </tr>`
                : ''
            }
            <tr>
              <td style="color: #059669; font-weight: bold;">المتبقي على العميل:</td>
              <td style="text-align: left; color: #059669; font-weight: bold;">0.00 ${settings.currencySymbol} (خالصة)</td>
            </tr>
          `;
        })()}
      </table>

      <div class="zatca-box">
        <strong>فاتورة إلكترونية معتمدة مطابقة لمتطلبات هيئة الزكاة والضريبة والجمارك (ZATCA)</strong>
        <div style="font-size: 9pt; color: #475569; margin-top: 4px;">
          الرقم الضريبي: ${settings.taxNumber} | تاريخ الإصدار: ${new Date(invoice.date).toLocaleString('ar-SA')}
        </div>
      </div>

      <div class="footer">
        <p>${settings.footerNotes || 'شكراً لزيارتكم! نسعد بخدمتكم دائماً.'}</p>
        <p style="font-size: 9pt; color: #94a3b8; margin-top: 4px;">تم الإصدار بواسطة نظام Soft Glass POS</p>
      </div>
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', wordContent], {
    type: 'application/msword;charset=utf-8'
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeFilename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * تصدير تقرير المبيعات كملف Word (.doc)
 */
export function exportSalesReportToWord(sales: SaleInvoice[], settings: StoreSettings): void {
  const totalSales = sales.reduce((acc, s) => acc + s.grandTotal, 0);
  const totalTax = sales.reduce((acc, s) => acc + s.taxTotal, 0);
  const totalDiscount = sales.reduce((acc, s) => acc + s.discountTotal, 0);

  const rows = sales
    .map(
      (s, idx) => `
    <tr>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 6px;">${idx + 1}</td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 6px; font-weight: bold;">${s.invoiceNumber}</td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 6px;">${new Date(s.date).toLocaleDateString('ar-SA')}</td>
      <td style="text-align: right; border: 1px solid #cbd5e1; padding: 6px;">${s.customerName || 'نقدي'}</td>
      <td style="text-align: center; border: 1px solid #cbd5e1; padding: 6px;">${s.cashierName}</td>
      <td style="text-align: left; border: 1px solid #cbd5e1; padding: 6px; font-weight: bold;">${s.grandTotal.toFixed(2)} ${settings.currencySymbol}</td>
    </tr>
  `
    )
    .join('');

  const wordContent = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" 
          xmlns:w="urn:schemas-microsoft-com:office:word" 
          xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>تقرير المبيعات - ${settings.storeName}</title>
      <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; direction: rtl; text-align: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th { background: #0284c7; color: white; padding: 8px; border: 1px solid #0284c7; }
        td { padding: 6px; border: 1px solid #cbd5e1; font-size: 10pt; }
      </style>
    </head>
    <body dir="rtl">
      <h2>تقرير المبيعات والأرباح - ${settings.storeName}</h2>
      <p>تاريخ التقرير: ${new Date().toLocaleString('ar-SA')} | عدد العمليات: ${sales.length}</p>
      <p><strong>إجمالي المبيعات:</strong> ${totalSales.toFixed(2)} ${settings.currencySymbol} | <strong>الضريبة:</strong> ${totalTax.toFixed(2)} ${settings.currencySymbol}</p>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>رقم الفاتورة</th>
            <th>التاريخ</th>
            <th>العميل</th>
            <th>الكاشير</th>
            <th>الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', wordContent], { type: 'application/msword;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `تقرير_المبيعات_${new Date().toISOString().slice(0, 10)}.doc`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * تصدير فاتورة رسمية بصيغة PDF (مع دعم كامل للعربية 100% ونظام حماية واحتياط فوري من الأخطاء)
 */
export async function generateInvoicePDF(
  invoice: SaleInvoice,
  settings: StoreSettings,
  element?: HTMLElement
): Promise<void> {
  // Layer 1: Attempt element conversion if provided, with safe try/catch
  if (element) {
    try {
      await exportElementToPDF(
        element,
        `${invoice.invoiceNumber}.pdf`,
        settings.printLayout || 'thermal'
      );
      return;
    } catch (elementErr) {
      console.warn('exportElementToPDF on DOM failed, falling back to clean offscreen template:', elementErr);
    }
  }

  // Layer 2: Pristine isolated offscreen HTML rendering
  const itemsHtml = invoice.items
    .map(
      (item) => `
    <tr>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-weight: 500;">
        ${item.product.name}
        <div style="font-size: 9px; color: #64748b;">${item.product.barcode}</div>
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold;">
        ${item.quantity}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">
        ${item.price.toFixed(2)}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: left; font-weight: bold;">
        ${item.total.toFixed(2)} ${settings.currencySymbol}
      </td>
    </tr>
  `
    )
    .join('');

  const logoSrc = getResolvedStoreLogo(settings);

  const html = `
    <div style="text-align: center; border-bottom: 2px dashed #cbd5e1; padding-bottom: 12px; margin-bottom: 12px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" alt="${settings.storeName || 'AK Store'}" style="width: 58px; height: 58px; object-fit: contain; display: inline-block; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 18px; font-weight: bold; color: #0f172a;">${settings.storeName || 'Soft Glass POS'}</h2>
      <p style="margin: 3px 0; font-size: 11px; color: #64748b;">${settings.storeAddress || ''} | هاتف: ${settings.storePhone || ''}</p>
      <p style="margin: 2px 0; font-size: 11px; font-weight: 600; color: #334155;">الرقم الضريبي: ${settings.taxNumber || 'غير محدد'}</p>
      <div style="display: inline-block; background: #e0f2fe; color: #0369a1; padding: 3px 12px; border-radius: 999px; font-size: 11px; font-weight: bold; margin-top: 6px;">
        فاتورة ضريبية مبسطة
      </div>
    </div>

    <div style="font-size: 11px; line-height: 1.6; border-bottom: 1px dashed #cbd5e1; padding-bottom: 10px; margin-bottom: 10px;">
      <div style="display: flex; justify-content: space-between;">
        <span><strong>رقم الفاتورة:</strong> ${invoice.invoiceNumber}</span>
        <span><strong>التاريخ:</strong> ${new Date(invoice.date).toLocaleString('ar-SA')}</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 4px;">
        <span><strong>الكاشير:</strong> ${invoice.cashierName}</span>
        <span><strong>العميل:</strong> ${invoice.customerName || 'عميل نقدي'}</span>
      </div>
      <div style="margin-top: 4px;">
        <strong>طريقة الدفع:</strong> ${
          getInvoiceInstallmentDetails(invoice).isInstallment
            ? `تقسيط (دفع مقدم والباقي أقساط على ${getInvoiceInstallmentDetails(invoice).instCount} شهر)`
            : invoice.paymentMethod === 'cash'
            ? 'نقداً (كاش بالكامل)'
            : invoice.paymentMethod === 'card'
            ? 'بطاقة شبكة / تحويل بنكي'
            : invoice.paymentMethod === 'credit'
            ? 'آجل بالكامل (على الحساب)'
            : 'دفعة مقدمة والباقي آجل (سداد جزئي)'
        }
      </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 12px;">
      <thead>
        <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
          <th style="padding: 6px 8px; text-align: right;">الصنف</th>
          <th style="padding: 6px 8px; text-align: center;">الكمية</th>
          <th style="padding: 6px 8px; text-align: center;">السعر</th>
          <th style="padding: 6px 8px; text-align: left;">الإجمالي</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px; font-size: 12px; line-height: 1.8;">
      <div style="display: flex; justify-content: space-between;">
        <span>${invoice.taxTotal > 0 ? 'المجموع قبل الضريبة:' : 'المجموع:'}</span>
        <span style="font-weight: 600;">${invoice.subtotal.toFixed(2)} ${settings.currencySymbol}</span>
      </div>
      ${
        invoice.taxTotal > 0
          ? `<div style="display: flex; justify-content: space-between;">
              <span>ضريبة القيمة المضافة (${
                invoice.subtotal > 0
                  ? Math.round((invoice.taxTotal / invoice.subtotal) * 10000) / 100
                  : settings.vatPercentage
              }%):</span>
              <span style="font-weight: 600;">${invoice.taxTotal.toFixed(2)} ${settings.currencySymbol}</span>
            </div>`
          : ''
      }
      ${
        invoice.discountTotal > 0
          ? `
      <div style="display: flex; justify-content: space-between; color: #059669;">
        <span>الخصم الممنوح:</span>
        <span style="font-weight: 600;">-${invoice.discountTotal.toFixed(2)} ${settings.currencySymbol}</span>
      </div>`
          : ''
      }
      <div style="display: flex; justify-content: space-between; font-size: 15px; font-weight: bold; color: #1d4ed8; border-top: 1px solid #cbd5e1; padding-top: 6px; margin-top: 4px;">
        <span>${invoice.taxTotal > 0 ? 'الإجمالي النهائي شامل الضريبة:' : 'الإجمالي النهائي:'}</span>
        <span>${invoice.grandTotal.toFixed(2)} ${settings.currencySymbol}</span>
      </div>
      ${(() => {
        const inst = getInvoiceInstallmentDetails(invoice);
        if (inst.isInstallment) {
          return `
            <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #f59e0b; border-radius: 8px; background: #fffbeb; font-size: 11px;">
              <div style="font-weight: 800; color: #92400e; border-bottom: 1px solid #fde68a; padding-bottom: 4px; margin-bottom: 4px;">
                تفصيل نظام السداد: تقسيط شهري (${inst.instCount} شهر)
              </div>
              <div style="display: flex; justify-content: space-between; color: #047857; font-weight: bold;">
                <span>الدفعة المقدمة المدفوعة (المقدم):</span>
                <span>${inst.downPay.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #dc2626; font-weight: bold;">
                <span>المبلغ المتبقي للتقسيط:</span>
                <span>${inst.remainingBalance.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #1e293b; font-weight: bold;">
                <span>عدد الأقساط الشهرية:</span>
                <span>${inst.instCount} أقساط (على ${inst.instCount} شهر)</span>
              </div>
              ${
                inst.monthlyAmount > 0
                  ? `<div style="display: flex; justify-content: space-between; color: #1d4ed8; font-weight: 800; border-top: 1px solid #fde68a; padding-top: 4px; margin-top: 4px;">
                      <span>قيمة القسط الشهري:</span>
                      <span>${inst.monthlyAmount.toFixed(2)} ${settings.currencySymbol} / شهرياً</span>
                    </div>`
                  : ''
              }
            </div>
          `;
        }
        if (inst.unpaidCredit > 0 && invoice.paidAmount > 0) {
          return `
            <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #a855f7; border-radius: 8px; background: #faf5ff; font-size: 11px;">
              <div style="font-weight: 800; color: #6b21a8; border-bottom: 1px solid #e9d5ff; padding-bottom: 4px; margin-bottom: 4px;">
                تفصيل نظام السداد: دفعة مقدمة والباقي آجل (سداد جزئي)
              </div>
              <div style="display: flex; justify-content: space-between; color: #047857; font-weight: bold;">
                <span>المبلغ المدفوع مقدماً (المسدد الآن):</span>
                <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #dc2626; font-weight: 800; border-top: 1px solid #e9d5ff; padding-top: 4px; margin-top: 4px;">
                <span>المبلغ المتبقي (آجل بذمة العميل):</span>
                <span>${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
            </div>
          `;
        }
        if (inst.unpaidCredit > 0) {
          return `
            <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #ef4444; border-radius: 8px; background: #fef2f2; font-size: 11px;">
              <div style="font-weight: 800; color: #991b1b; border-bottom: 1px solid #fecaca; padding-bottom: 4px; margin-bottom: 4px;">
                تفصيل نظام السداد: بيع آجل بالكامل (على الحساب)
              </div>
              <div style="display: flex; justify-content: space-between; color: #475569; font-weight: bold;">
                <span>المبلغ المدفوع عند الإصدار:</span>
                <span>0.00 ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #dc2626; font-weight: 800; border-top: 1px solid #fecaca; padding-top: 4px; margin-top: 4px;">
                <span>إجمالي المبلغ الآجل المستحق:</span>
                <span>${inst.unpaidCredit.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
            </div>
          `;
        }
        if (invoice.paymentMethod === 'card') {
          return `
            <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #3b82f6; border-radius: 8px; background: #eff6ff; font-size: 11px;">
              <div style="font-weight: 800; color: #1e40af; border-bottom: 1px solid #bfdbfe; padding-bottom: 4px; margin-bottom: 4px;">
                تفصيل نظام السداد: بطاقة شبكة / تحويل بنكي (مسددة بالكامل ✓)
              </div>
              <div style="display: flex; justify-content: space-between; color: #1d4ed8; font-weight: bold;">
                <span>المبلغ المحصل عبر الشبكة / البنك:</span>
                <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #047857; font-weight: 800; border-top: 1px solid #bfdbfe; padding-top: 4px; margin-top: 4px;">
                <span>المتبقي على العميل:</span>
                <span>0.00 ${settings.currencySymbol} (خالصة)</span>
              </div>
            </div>
          `;
        }
        return `
          <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #10b981; border-radius: 8px; background: #ecfdf5; font-size: 11px;">
            <div style="font-weight: 800; color: #065f46; border-bottom: 1px solid #a7f3d0; padding-bottom: 4px; margin-bottom: 4px;">
              تفصيل نظام السداد: سداد نقدي كاش (مسددة بالكامل ✓)
            </div>
            <div style="display: flex; justify-content: space-between; color: #047857; font-weight: bold;">
              <span>المبلغ النقدي المستلم:</span>
              <span>${invoice.paidAmount.toFixed(2)} ${settings.currencySymbol}</span>
            </div>
            ${
              invoice.changeAmount > 0
                ? `<div style="display: flex; justify-content: space-between; color: #1d4ed8; font-weight: bold;">
                    <span>المتبقي للعميل (الفكة):</span>
                    <span>${invoice.changeAmount.toFixed(2)} ${settings.currencySymbol}</span>
                  </div>`
                : ''
            }
            <div style="display: flex; justify-content: space-between; color: #047857; font-weight: 800; border-top: 1px solid #a7f3d0; padding-top: 4px; margin-top: 4px;">
              <span>المتبقي على العميل:</span>
              <span>0.00 ${settings.currencySymbol} (خالصة)</span>
            </div>
          </div>
        `;
      })()}
    </div>

    <div style="text-align: center; margin-top: 16px; font-size: 10px; color: #64748b;">
      ${settings.footerNotes || 'شكراً لتعاملكم معنا'}
    </div>
  `;

  try {
    await exportHtmlToPDF({
      htmlContent: html,
      filename: `${invoice.invoiceNumber}.pdf`,
      layout: settings.printLayout || 'thermal',
      title: `فاتورة ${invoice.invoiceNumber}`
    });
  } catch (pdfErr) {
    console.warn('exportHtmlToPDF failed, executing Word export fallback:', pdfErr);
    exportInvoiceToWord(invoice, settings);
  }
}

/**
 * تصدير فاتورة شراء مورد PDF
 */
export async function generatePurchaseInvoicePDF(purchase: any, settings: StoreSettings): Promise<void> {
  const itemsHtml = purchase.items
    .map(
      (item: any) => `
    <tr>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; font-weight: 500;">
        ${item.productName}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold;">
        ${item.quantity}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: center;">
        ${Number(item.costPrice).toFixed(2)}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: left; font-weight: bold;">
        ${Number(item.total).toFixed(2)} ${settings.currencySymbol}
      </td>
    </tr>
  `
    )
    .join('');

  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${getResolvedStoreLogo(settings)}" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: inline-block; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'Soft Glass POS'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #3b82f6;">سند استلام بضاعة / فاتورة مشتريات مورد</h3>
    </div>

    <div style="display: flex; justify-content: space-between; font-size: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div>
        <p style="margin: 2px 0;"><strong>رقم الفاتورة:</strong> ${purchase.invoiceNumber}</p>
        <p style="margin: 2px 0;"><strong>اسم المورد:</strong> ${purchase.supplierName}</p>
      </div>
      <div style="text-align: left;">
        <p style="margin: 2px 0;"><strong>التاريخ:</strong> ${new Date(purchase.date).toLocaleDateString('ar-SA')}</p>
        <p style="margin: 2px 0;"><strong>الرقم الضريبي للمتجر:</strong> ${settings.taxNumber || '—'}</p>
      </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 14px;">
      <thead>
        <tr style="background: #e2e8f0; border-bottom: 2px solid #94a3b8;">
          <th style="padding: 8px 10px; text-align: right;">الصنف</th>
          <th style="padding: 8px 10px; text-align: center;">الكمية</th>
          <th style="padding: 8px 10px; text-align: center;">سعر التكلفة</th>
          <th style="padding: 8px 10px; text-align: left;">الإجمالي</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div style="background: #f1f5f9; border-radius: 8px; padding: 12px; font-size: 13px; line-height: 1.8;">
      <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: bold; color: #1e3a8a;">
        <span>إجمالي فاتورة الشراء:</span>
        <span>${Number(purchase.grandTotal).toFixed(2)} ${settings.currencySymbol}</span>
      </div>
      <div style="margin-top: 8px; padding: 8px; border: 1.5px solid #94a3b8; border-radius: 8px; background: #ffffff; font-size: 12px;">
        <div style="font-weight: bold; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 4px;">
          تفصيل نظام السداد للمورد: ${
            Number(purchase.remainingAmount) <= 0
              ? 'مسددة بالكامل نقداً ✓'
              : Number(purchase.paidAmount) > 0
              ? 'دفعة مقدمة والباقي آجل للمورد'
              : 'فاتورة شراء آجلة بالكامل'
          }
        </div>
        <div style="display: flex; justify-content: space-between; color: #047857; font-weight: bold;">
          <span>المبلغ المدفوع للمورد:</span>
          <span>${Number(purchase.paidAmount).toFixed(2)} ${settings.currencySymbol}</span>
        </div>
        <div style="display: flex; justify-content: space-between; color: ${Number(purchase.remainingAmount) > 0 ? '#dc2626' : '#047857'}; font-weight: bold;">
          <span>المبلغ المتبقي في ذمة المتجر للمورد:</span>
          <span>${Number(purchase.remainingAmount).toFixed(2)} ${settings.currencySymbol}</span>
        </div>
      </div>
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 40px; font-size: 12px; color: #475569;">
      <div>توقيع المستلم: ..............................</div>
      <div>ختم وتوقيع المورد: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `${purchase.invoiceNumber}.pdf`,
    layout: 'a4',
    title: `فاتورة شراء ${purchase.invoiceNumber}`
  });
}

/**
 * تصدير سند مرتجع بيع أو شراء PDF
 */
export async function generateReturnInvoicePDF(ret: any, settings: StoreSettings): Promise<void> {
  const itemsHtml = ret.items
    .map(
      (item: any) => `
    <tr>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; font-weight: 500;">
        ${item.productName}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold;">
        ${item.quantity}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: center;">
        ${Number(item.price).toFixed(2)}
      </td>
      <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: left; font-weight: bold;">
        ${Number(item.refundTotal).toFixed(2)} ${settings.currencySymbol}
      </td>
    </tr>
  `
    )
    .join('');

  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${getResolvedStoreLogo(settings)}" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: inline-block; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'Soft Glass POS'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #dc2626;">
        ${ret.type === 'sale' ? 'سند إرجاع مبيعات (Sales Return)' : 'سند إرجاع مشتريات إلى مورد (Purchase Return)'}
      </h3>
    </div>

    <div style="display: flex; justify-content: space-between; font-size: 12px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div>
        <p style="margin: 2px 0;"><strong>رقم السند:</strong> ${ret.returnNumber}</p>
        <p style="margin: 2px 0;"><strong>الفاتورة الأصلية:</strong> ${ret.originalInvoiceNumber}</p>
        <p style="margin: 2px 0;"><strong>الطرف (عميل/مورد):</strong> ${ret.entityName}</p>
      </div>
      <div style="text-align: left;">
        <p style="margin: 2px 0;"><strong>التاريخ:</strong> ${new Date(ret.date).toLocaleDateString('ar-SA')}</p>
        <p style="margin: 2px 0;"><strong>سبب الإرجاع:</strong> ${ret.reason || 'غير محدد'}</p>
      </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 14px;">
      <thead>
        <tr style="background: #fee2e2; border-bottom: 2px solid #f87171;">
          <th style="padding: 8px 10px; text-align: right;">الصنف المرتجع</th>
          <th style="padding: 8px 10px; text-align: center;">الكمية</th>
          <th style="padding: 8px 10px; text-align: center;">السعر</th>
          <th style="padding: 8px 10px; text-align: left;">المسترد</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; padding: 12px; font-size: 16px; font-weight: bold; color: #991b1b; display: flex; justify-content: space-between;">
      <span>إجمالي المبلغ المسترد:</span>
      <span>${Number(ret.totalRefund).toFixed(2)} ${settings.currencySymbol}</span>
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 40px; font-size: 12px; color: #475569;">
      <div>توقيع المستلم: ..............................</div>
      <div>اعتماد الإدارة: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `${ret.returnNumber}.pdf`,
    layout: 'a4',
    title: `سند إرجاع ${ret.returnNumber}`
  });
}

/**
 * تصدير سند صرف مصروف PDF
 */
export async function generateExpenseVoucherPDF(expense: any, settings: StoreSettings): Promise<void> {
  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 10px; margin-bottom: 12px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${getResolvedStoreLogo(settings)}" alt="Logo" style="width: 52px; height: 52px; object-fit: contain; display: inline-block; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 18px; font-weight: bold; color: #0f172a;">${settings.storeName || 'Soft Glass POS'}</h2>
      <h3 style="margin: 3px 0 0 0; font-size: 13px; color: #d97706;">سند صرف نقدية / مصروفات</h3>
    </div>

    <div style="font-size: 12px; line-height: 1.8; background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div style="display: flex; justify-content: space-between;">
        <span><strong>رقم السند:</strong> EXP-${expense.id.slice(-6)}</span>
        <span><strong>التاريخ:</strong> ${expense.date}</span>
      </div>
      <div><strong>بند المصروف:</strong> ${expense.title}</div>
      <div><strong>التصنيف:</strong> ${expense.category}</div>
      <div><strong>المسؤول عن التسجيل:</strong> ${expense.recordedBy}</div>
      ${expense.notes ? `<div><strong>ملاحظات:</strong> ${expense.notes}</div>` : ''}
    </div>

    <div style="background: #fef3c7; border: 1px solid #fcd34d; border-radius: 8px; padding: 14px; text-align: center; font-size: 18px; font-weight: bold; color: #92400e; margin-bottom: 20px;">
      المبلغ المصروف: ${Number(expense.amount).toFixed(2)} ${settings.currencySymbol}
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 30px; font-size: 11px; color: #475569;">
      <div>توقيع المستلم: ..............................</div>
      <div>توقيع المحاسب / المدير: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Expense_${expense.id}.pdf`,
    layout: 'a5',
    title: `سند صرف ${expense.title}`
  });
}

/**
 * تصدير جدول الأقساط PDF
 */
export async function generateInstallmentSchedulePDF(plan: any, settings: StoreSettings): Promise<void> {
  const installmentsHtml = plan.installments
    .map(
      (inst: any) => `
    <tr>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">
        القسط #${inst.installmentNumber}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">
        ${inst.dueDate}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold;">
        ${Number(inst.amount).toFixed(2)} ${settings.currencySymbol}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: left;">
        <span style="display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; ${
          inst.status === 'paid' ? 'background: #dcfce7; color: #15803d;' : 'background: #fee2e2; color: #b91c1c;'
        }">
          ${inst.status === 'paid' ? 'مسدد' : 'مستحق'}
        </span>
      </td>
    </tr>
  `
    )
    .join('');

  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${getResolvedStoreLogo(settings)}" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: inline-block; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'Soft Glass POS'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #4338ca;">جدول وسند خطة التقسيط للعميل</h3>
    </div>

    <div style="display: flex; justify-content: space-between; font-size: 12px; background: #e0e7ff; border: 1px solid #c7d2fe; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div>
        <p style="margin: 2px 0;"><strong>اسم العميل:</strong> ${plan.customerName}</p>
        <p style="margin: 2px 0;"><strong>رقم الهاتف:</strong> ${plan.customerPhone}</p>
        <p style="margin: 2px 0;"><strong>رقم الفاتورة:</strong> ${plan.invoiceNumber}</p>
      </div>
      <div style="text-align: left;">
        <p style="margin: 2px 0;"><strong>إجمالي التمويل:</strong> ${Number(plan.totalAmount).toFixed(2)} ${settings.currencySymbol}</p>
        <p style="margin: 2px 0;"><strong>الدفعة المقدمة:</strong> ${Number(plan.downPayment).toFixed(2)} ${settings.currencySymbol}</p>
        <p style="margin: 2px 0;"><strong>المتبقي المقسط:</strong> ${Number(plan.remainingAmount).toFixed(2)} ${settings.currencySymbol}</p>
      </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 14px;">
      <thead>
        <tr style="background: #c7d2fe; border-bottom: 2px solid #818cf8;">
          <th style="padding: 7px 10px; text-align: right;">القسط</th>
          <th style="padding: 7px 10px; text-align: center;">تاريخ الاستحقاق</th>
          <th style="padding: 7px 10px; text-align: center;">المبلغ</th>
          <th style="padding: 7px 10px; text-align: left;">الحالة</th>
        </tr>
      </thead>
      <tbody>
        ${installmentsHtml}
      </tbody>
    </table>

    <div style="display: flex; justify-content: space-between; margin-top: 35px; font-size: 11px; color: #475569;">
      <div>توقيع العميل المقترض: ..............................</div>
      <div>ختم المؤسسة / التاجر: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Installment_Plan_${plan.customerName}.pdf`,
    layout: 'a4',
    title: `خطة أقساط ${plan.customerName}`
  });
}

/**
 * تصدير كشف حساب عميل PDF
 */
export async function generateCustomerStatementPDF(customer: any, settings: StoreSettings): Promise<void> {
  const logoSrc = getResolvedStoreLogo(settings);
  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="56" height="56" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'AK Store'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #0284c7;">كشف حساب ومطالبة مالية للعميل</h3>
    </div>

    <div style="display: flex; justify-content: space-between; font-size: 12px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div>
        <p style="margin: 2px 0;"><strong>اسم العميل:</strong> ${customer.name}</p>
        <p style="margin: 2px 0;"><strong>الهاتف:</strong> ${customer.phone}</p>
        <p style="margin: 2px 0;"><strong>العنوان:</strong> ${customer.address || '—'}</p>
      </div>
      <div style="text-align: left;">
        <p style="margin: 2px 0;"><strong>الرقم الضريبي:</strong> ${customer.taxNumber || '—'}</p>
        <p style="margin: 2px 0;"><strong>تاريخ الاستخراج:</strong> ${new Date().toLocaleDateString('ar-SA')}</p>
      </div>
    </div>

    <div style="background: #e0f2fe; border: 1px solid #7dd3fc; border-radius: 8px; padding: 16px; text-align: center; font-size: 18px; font-weight: bold; color: #0369a1; margin-bottom: 24px;">
      الرصيد / إجمالي المديونية المستحقة: ${Number(customer.balance).toFixed(2)} ${settings.currencySymbol}
    </div>

    <div style="font-size: 11px; color: #64748b; line-height: 1.6; border-top: 1px dashed #cbd5e1; padding-top: 10px;">
      <p style="margin: 0;">يُرجى تسوية المديونية في أقرب فرصة. للمراجعة أو الاستفسار يرجى التواصل على هاتف المتجر: ${settings.storePhone || ''}.</p>
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 35px; font-size: 11px; color: #475569;">
      <div>المحاسب المسؤول: ..............................</div>
      <div>ختم المنشأة: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Statement_${customer.name}.pdf`,
    layout: 'a4',
    title: `كشف حساب ${customer.name}`
  });
}

/**
 * تصدير كشف حساب ومستحقات مورد PDF
 */
export async function generateSupplierStatementPDF(supplier: any, settings: StoreSettings): Promise<void> {
  const logoSrc = getResolvedStoreLogo(settings);
  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="56" height="56" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'AK Store'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #0d9488;">كشف حساب ومستحقات المورد</h3>
    </div>

    <div style="display: flex; justify-content: space-between; font-size: 12px; background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
      <div>
        <p style="margin: 2px 0;"><strong>اسم المورد:</strong> ${supplier.name} ${supplier.companyName ? `(${supplier.companyName})` : ''}</p>
        <p style="margin: 2px 0;"><strong>الهاتف:</strong> ${supplier.phone}</p>
        <p style="margin: 2px 0;"><strong>العنوان:</strong> ${supplier.address || '—'}</p>
      </div>
      <div style="text-align: left;">
        <p style="margin: 2px 0;"><strong>الرقم الضريبي للمورد:</strong> ${supplier.taxNumber || '—'}</p>
        <p style="margin: 2px 0;"><strong>تاريخ استخراج الكشف:</strong> ${new Date().toLocaleDateString('ar-SA')}</p>
      </div>
    </div>

    <div style="background: #ccfbf1; border: 1px solid #5eead4; border-radius: 8px; padding: 16px; text-align: center; font-size: 18px; font-weight: bold; color: #0f766e; margin-bottom: 24px;">
      إجمالي المستحقات للمورد في الذمة: ${Number(supplier.balance).toFixed(2)} ${settings.currencySymbol}
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 35px; font-size: 11px; color: #475569;">
      <div>المحاسب المسؤول: ..............................</div>
      <div>ختم وتوقيع المورد: ..............................</div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Statement_Supplier_${supplier.name}.pdf`,
    layout: 'a4',
    title: `كشف حساب المورد ${supplier.name}`
  });
}

/**
 * تصدير تقرير المبيعات المالي الكامل PDF
 */
export async function generateSalesReportPDF(options: {
  sales: SaleInvoice[];
  settings: StoreSettings;
  totals: {
    totalRevenue: number;
    totalTax: number;
    totalDiscount: number;
    totalCost: number;
    netProfit: number;
    cashTotal: number;
    cardTotal: number;
  };
  topProducts: { name: string; qty: number; total: number }[];
}): Promise<void> {
  const { sales, settings, totals, topProducts } = options;
  const logoSrc = getResolvedStoreLogo(settings);

  const topProductsHtml = topProducts
    .map(
      (p, idx) => `
    <tr>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">#${idx + 1} ${p.name}</td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">${p.qty}</td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: left; font-weight: bold;">
        ${p.total.toFixed(2)} ${settings.currencySymbol}
      </td>
    </tr>
  `
    )
    .join('');

  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="56" height="56" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'AK Store'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #2563eb;">تقرير المبيعات والأرباح التحليلي</h3>
      <p style="margin: 3px 0 0 0; font-size: 11px; color: #64748b;">تاريخ استخراج التقرير: ${new Date().toLocaleString('ar-SA')}</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 16px;">
      <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #1e40af;">إجمالي المبيعات:</div>
        <div style="font-size: 18px; font-weight: bold; color: #1d4ed8;">${totals.totalRevenue.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #166534;">صافي الأرباح:</div>
        <div style="font-size: 18px; font-weight: bold; color: #15803d;">${totals.netProfit.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #475569;">ضريبة القيمة المضافة:</div>
        <div style="font-size: 15px; font-weight: bold; color: #334155;">${totals.totalTax.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #475569;">تكلفة البضاعة:</div>
        <div style="font-size: 15px; font-weight: bold; color: #334155;">${totals.totalCost.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #475569;">مبيعات النقد (كاش):</div>
        <div style="font-size: 15px; font-weight: bold; color: #334155;">${totals.cashTotal.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
        <div style="font-size: 11px; color: #475569;">مبيعات البطاقة / الشبكة:</div>
        <div style="font-size: 15px; font-weight: bold; color: #334155;">${totals.cardTotal.toFixed(2)} ${settings.currencySymbol}</div>
      </div>
    </div>

    <div style="margin-bottom: 16px;">
      <h4 style="margin: 0 0 8px 0; font-size: 13px; font-weight: bold; color: #1e293b;">أكثر المنتجات مبيعاً:</h4>
      <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
        <thead>
          <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
            <th style="padding: 6px 8px; text-align: right;">اسم الصنف</th>
            <th style="padding: 6px 8px; text-align: center;">الكمية المباعة</th>
            <th style="padding: 6px 8px; text-align: left;">إجمالي الإيراد</th>
          </tr>
        </thead>
        <tbody>
          ${topProductsHtml}
        </tbody>
      </table>
    </div>

    <div style="font-size: 11px; color: #64748b; text-align: center; border-top: 1px dashed #cbd5e1; padding-top: 10px;">
      إجمالي عدد الفواتير المنفذة في هذه الفترة: <strong>${sales.length} فاتورة</strong>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Sales_Report_${Date.now()}.pdf`,
    layout: 'a4',
    title: 'تقرير المبيعات والأرباح'
  });
}

/**
 * طباعة ملصق باركود صنف فردي (حراري 50x30mm)
 */
export async function generateBarcodeLabelPDF(product: Product, settings: StoreSettings): Promise<void> {
  const html = `
    <div style="text-align: center; font-family: 'Readex Pro', sans-serif; padding: 2px;">
      <div style="font-size: 10px; font-weight: bold; color: #475569; margin-bottom: 2px;">
        ${settings.storeName || 'AK Store'}
      </div>
      <div style="font-size: 11px; font-weight: 800; color: #0f172a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
        ${product.name}
      </div>
      <div style="font-size: 15px; font-weight: 900; color: #1d4ed8; margin: 3px 0;">
        ${product.salePrice.toFixed(2)} ${settings.currencySymbol}
      </div>
      <div style="font-family: monospace; font-size: 11px; letter-spacing: 2px; font-weight: bold; color: #334155; border-top: 1px solid #cbd5e1; padding-top: 2px;">
        * ${product.barcode} *
      </div>
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Barcode_${product.barcode}.pdf`,
    layout: 'label',
    title: `ملصق باركود ${product.name}`
  });
}

/**
 * طباعة كتالوج الأصناف وأسعار البيع A4
 */
export async function generateProductsCatalogPDF(products: Product[], settings: StoreSettings): Promise<void> {
  const logoSrc = getResolvedStoreLogo(settings);
  const rows = products
    .map(
      (p, idx) => `
    <tr>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-weight: 500;">
        #${idx + 1} ${p.name}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; font-family: monospace; text-align: center;">
        ${p.barcode}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">
        ${p.stock} ${p.unit || 'حبة'}
      </td>
      <td style="padding: 6px 8px; border-bottom: 1px solid #e2e8f0; text-align: left; font-weight: bold; color: #1d4ed8;">
        ${p.salePrice.toFixed(2)} ${settings.currencySymbol}
      </td>
    </tr>
  `
    )
    .join('');

  const html = `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="56" height="56" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 20px; font-weight: bold; color: #0f172a;">${settings.storeName || 'AK Store'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 14px; color: #2563eb;">قائمة الأصناف وأسعار البيع والمخزون</h3>
      <p style="margin: 3px 0 0 0; font-size: 11px; color: #64748b;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')} | إجمالي الأصناف: ${products.length}</p>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
      <thead>
        <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
          <th style="padding: 6px 8px; text-align: right;">اسم الصنف</th>
          <th style="padding: 6px 8px; text-align: center;">الباركود</th>
          <th style="padding: 6px 8px; text-align: center;">المخزون المتوفر</th>
          <th style="padding: 6px 8px; text-align: left;">سعر البيع</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
    </table>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: `Products_Catalog_${Date.now()}.pdf`,
    layout: 'a4',
    title: 'قائمة الأصناف والأسعار'
  });
}

/**
 * صفحة اختبار الطباعة (A4 أو حراري 80mm)
 */
export async function generateTestPrintPDF(settings: StoreSettings, layout: 'thermal' | 'a4'): Promise<void> {
  const logoSrc = getResolvedStoreLogo(settings);
  const html =
    layout === 'thermal'
      ? `
    <div style="text-align: center; padding: 4px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="56" height="56" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h3 style="margin: 0; font-size: 16px; font-weight: bold;">${settings.storeName || 'AK Store'}</h3>
      <p style="margin: 3px 0; font-size: 11px; color: #3b82f6; font-weight: bold;">اختبار طباعة إيصال حراري 80mm</p>
      <div style="border-top: 1px dashed #94a3b8; margin: 8px 0;"></div>
      <div style="font-size: 11px; line-height: 1.6; text-align: right;">
        <div>التاريخ: ${new Date().toLocaleDateString('ar-SA')}</div>
        <div>الساعة: ${new Date().toLocaleTimeString('ar-SA')}</div>
        <div>الرقم الضريبي: ${settings.taxNumber || '300000000000003'}</div>
      </div>
      <div style="background: #dcfce7; color: #166534; font-weight: bold; padding: 8px; border-radius: 6px; font-size: 12px; margin: 10px 0;">
        حالة الطابعة: متصلة وجاهزة للعمل بنجاح
      </div>
      <div style="font-size: 10px; color: #64748b;">
        نظام نقاط البيع AK Store
      </div>
    </div>
  `
      : `
    <div style="text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 14px;">
      <div style="text-align: center; margin-bottom: 6px;">
        <img src="${logoSrc}" width="68" height="68" alt="Logo" style="width: 68px; height: 68px; object-fit: contain; display: block; margin: 0 auto; border-radius: 10px;" />
      </div>
      <h2 style="margin: 0; font-size: 22px; font-weight: bold;">${settings.storeName || 'AK Store'}</h2>
      <h3 style="margin: 4px 0 0 0; font-size: 15px; color: #2563eb;">صفحة اختبار الطباعة الرسمية A4</h3>
    </div>
    <div style="font-size: 13px; line-height: 2; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
      <div><strong>الرقم الضريبي:</strong> ${settings.taxNumber || '300000000000003'}</div>
      <div><strong>الهاتف:</strong> ${settings.storePhone || ''}</div>
      <div><strong>العنوان:</strong> ${settings.storeAddress || ''}</div>
      <div><strong>تاريخ وتوقيت الاختبار:</strong> ${new Date().toLocaleString('ar-SA')}</div>
    </div>
    <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 16px; text-align: center; color: #065f46; font-size: 14px; font-weight: bold;">
      تمت طباعة هذه الصفحة بنجاح للتأكد من تناسق الأبعاد وجودة المخرجات ودعم اللغة العربية 100%.
    </div>
  `;

  await exportHtmlToPDF({
    htmlContent: html,
    filename: layout === 'thermal' ? 'Test_Thermal_Receipt.pdf' : 'Test_A4_Print.pdf',
    layout: layout,
    title: 'اختبار الطباعة'
  });
}
