/**
 * @file components/SmartWhatsAppModal.tsx
 * نافذة إرسال رسائل الواتساب الذكية (تدعم تطبيق الويندوز/الموبايل المباشر + واتساب ويب + QR Code للهاتف + تصحيح كود الدولة)
 * Smart Multi-Channel WhatsApp Sender Modal
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  MessageCircle,
  Copy,
  Check,
  Smartphone,
  Monitor,
  Globe,
  QrCode,
  Send,
  Phone
} from 'lucide-react';
import QRCode from 'qrcode';
import { useApp } from '../contexts/AppContext';
import {
  WHATSAPP_DISPATCH_EVENT,
  WhatsAppDispatchPayload,
  formatWhatsAppPhone,
  normalizeDigits
} from '../utils/installmentAlerts';

const COUNTRY_CODES = [
  { code: '20', label: 'مصر (+20)', prefixHint: '010 / 011 / 012 / 015' },
  { code: '966', label: 'السعودية (+966)', prefixHint: '05XXXXXXXX' },
  { code: '971', label: 'الإمارات (+971)', prefixHint: '05XXXXXXXX' },
  { code: '965', label: 'الكويت (+965)', prefixHint: 'XXXXXXXX' },
  { code: '962', label: 'الأردن (+962)', prefixHint: '07XXXXXXXX' },
  { code: '974', label: 'قطر (+974)', prefixHint: 'XXXXXXXX' },
  { code: '968', label: 'عُمان (+968)', prefixHint: 'XXXXXXXX' },
  { code: '973', label: 'البحرين (+973)', prefixHint: 'XXXXXXXX' },
  { code: '964', label: 'العراق (+964)', prefixHint: '07XXXXXXXX' },
  { code: '218', label: 'ليبيا (+218)', prefixHint: '09XXXXXXXX' },
  { code: '249', label: 'السودان (+249)', prefixHint: '09XXXXXXXX' }
];

export const SmartWhatsAppModal: React.FC = () => {
  const { showToast, tr } = useApp();

  const [isOpen, setIsOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [modalTitle, setModalTitle] = useState('');
  const [countryCode, setCountryCode] = useState('20');
  const [localPhone, setLocalPhone] = useState('');
  const [messageText, setMessageText] = useState('');
  const [copied, setCopied] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [showQr, setShowQr] = useState<boolean>(false);

  // Listen to global WhatsApp dispatch events from any page/button
  useEffect(() => {
    const handleOpen = (e: Event) => {
      const customEvent = e as CustomEvent<WhatsAppDispatchPayload>;
      const detail = customEvent.detail;
      if (!detail) return;

      setCustomerName(detail.customerName || detail.recipientName || '');
      setModalTitle(detail.title || 'إرسال رسالة واتساب للعميل');
      setMessageText(detail.message || '');
      setShowQr(false);

      // Detect country code & local phone from provided phone
      const raw = normalizeDigits(detail.phone || '').replace(/\D/g, '');
      const formatted = formatWhatsAppPhone(raw, '20');

      const matchedCountry = COUNTRY_CODES.find((c) => formatted.startsWith(c.code));
      if (matchedCountry) {
        setCountryCode(matchedCountry.code);
        setLocalPhone('0' + formatted.substring(matchedCountry.code.length));
      } else {
        setCountryCode('20');
        setLocalPhone(detail.phone || '');
      }

      setIsOpen(true);
    };

    window.addEventListener(WHATSAPP_DISPATCH_EVENT, handleOpen);
    return () => window.removeEventListener(WHATSAPP_DISPATCH_EVENT, handleOpen);
  }, []);

  // Compute clean international phone number
  const finalInternationalPhone = useMemo(() => {
    const digits = normalizeDigits(localPhone).replace(/\D/g, '');
    if (!digits) return '';

    // If user typed full international number already starting with countryCode
    if (digits.startsWith('00' + countryCode)) {
      return digits.substring(2);
    }
    if (digits.startsWith(countryCode) && digits.length >= 11) {
      // Check if they accidentally put a 0 after countryCode (e.g., 20010...)
      const afterCode = digits.substring(countryCode.length);
      return countryCode + (afterCode.startsWith('0') ? afterCode.substring(1) : afterCode);
    }
    // Strip leading zeros from local phone and prepend selected countryCode
    const withoutLeadingZeros = digits.replace(/^0+/, '');
    return countryCode + withoutLeadingZeros;
  }, [localPhone, countryCode]);

  const encodedMessage = useMemo(() => encodeURIComponent(messageText || ''), [messageText]);

  const whatsappAppUrl = useMemo(() => {
    if (!finalInternationalPhone) return '#';
    return `whatsapp://send?phone=${finalInternationalPhone}&text=${encodedMessage}`;
  }, [finalInternationalPhone, encodedMessage]);

  const whatsappWebUrl = useMemo(() => {
    if (!finalInternationalPhone) return '#';
    return `https://web.whatsapp.com/send?phone=${finalInternationalPhone}&text=${encodedMessage}`;
  }, [finalInternationalPhone, encodedMessage]);

  const whatsappApiUrl = useMemo(() => {
    if (!finalInternationalPhone) return '#';
    return `https://api.whatsapp.com/send?phone=${finalInternationalPhone}&text=${encodedMessage}`;
  }, [finalInternationalPhone, encodedMessage]);

  // Generate QR code when requested or when URL updates
  useEffect(() => {
    if (!isOpen || !finalInternationalPhone) {
      setQrDataUrl('');
      return;
    }
    let active = true;
    QRCode.toDataURL(whatsappApiUrl, {
      width: 220,
      margin: 1,
      color: {
        dark: '#064e3b',
        light: '#ffffff'
      }
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [isOpen, finalInternationalPhone, whatsappApiUrl]);

  if (!isOpen) return null;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    showToast(tr('تم نسخ نص الرسالة إلى الحافظة بنجاح!', 'Message copied to clipboard!'), 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSMS = () => {
    if (!finalInternationalPhone) {
      showToast(tr('يرجى إدخال رقم هاتف صحيح أولاً', 'Please enter a valid phone number'), 'error');
      return;
    }
    window.location.href = `sms:+${finalInternationalPhone}?body=${encodedMessage}`;
  };

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-slate-900/55 backdrop-blur-sm overflow-y-auto"
      onClick={() => setIsOpen(false)}
    >
      <div
        className="neu-card rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-emerald-300/80 bg-slate-50 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base leading-tight">
                {modalTitle} {customerName ? `· ${customerName}` : ''}
              </h3>
              <p className="text-[11px] text-emerald-100 mt-0.5">
                {tr(
                  'تم نسخ الرسالة تلقائياً — اختر طريقة الفتح المناسبة لجهازك',
                  'Message auto-copied — choose your preferred WhatsApp launch method'
                )}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Country Code + Phone Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{tr('رقم هاتف الواتساب ومفتاح الدولة:', 'WhatsApp Phone & Country Code:')}</span>
              </label>
              {finalInternationalPhone && (
                <span
                  dir="ltr"
                  className="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md tabular-nums"
                >
                  +{finalInternationalPhone}
                </span>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="neu-input px-3 py-2 rounded-xl text-xs font-bold text-slate-800 sm:w-44 cursor-pointer"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.label}
                  </option>
                ))}
              </select>

              <input
                type="tel"
                dir="ltr"
                value={localPhone}
                onChange={(e) => setLocalPhone(e.target.value)}
                placeholder="01012345678"
                className="neu-input flex-1 px-3.5 py-2 rounded-xl text-sm font-mono font-black text-slate-900 tabular-nums"
              />
            </div>
          </div>

          {/* Editable Message Textarea */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">
                {tr('نص الرسالة الجاهزة للإرسال:', 'Message Text:')}
              </label>
              <button
                type="button"
                onClick={handleCopyMessage}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? tr('تم نسخ النص!', 'Copied!') : tr('نسخ النص', 'Copy Text')}</span>
              </button>
            </div>
            <textarea
              rows={5}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              className="neu-input w-full p-3 rounded-2xl text-xs font-medium text-slate-800 leading-relaxed resize-y"
              placeholder={tr('اكتب نص رسالة الواتساب هنا...', 'Type WhatsApp message here...')}
            />
          </div>

          {/* 3 Direct Launch Methods */}
          <div className="space-y-2 pt-1">
            <span className="text-[11px] font-bold text-slate-500 block">
              {tr('اختر طريقة الإرسال المباشرة:', 'Select Direct Send Method:')}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Method 1: Native WhatsApp Desktop / Mobile App Protocol (whatsapp://) */}
              <a
                href={whatsappAppUrl}
                onClick={(e) => {
                  if (!finalInternationalPhone) {
                    e.preventDefault();
                    showToast(tr('يرجى إدخال رقم هاتف صحيح', 'Please enter a valid phone number'), 'error');
                    return;
                  }
                  navigator.clipboard?.writeText(messageText).catch(() => {});
                  showToast(
                    tr(
                      'جاري فتح برنامج واتساب المباشر مع الرسالة...',
                      'Opening WhatsApp App with message...'
                    ),
                    'success'
                  );
                }}
                className="p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2.5 shadow-sm transition-colors cursor-pointer no-underline"
              >
                <Smartphone className="w-5 h-5 shrink-0" />
                <div className="text-right">
                  <div className="text-xs font-black">
                    {tr('فتح برنامج واتساب مباشرة', 'Open WhatsApp App')}
                  </div>
                  <div className="text-[10px] text-emerald-100">
                    {tr('لتطبيق الويندوز أو الموبايل مباشرة', 'Direct Desktop / Mobile App')}
                  </div>
                </div>
              </a>

              {/* Method 2: Direct WhatsApp Web (web.whatsapp.com) */}
              <a
                href={whatsappWebUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  if (!finalInternationalPhone) {
                    e.preventDefault();
                    showToast(tr('يرجى إدخال رقم هاتف صحيح', 'Please enter a valid phone number'), 'error');
                    return;
                  }
                  navigator.clipboard?.writeText(messageText).catch(() => {});
                  showToast(
                    tr('جاري فتح واتساب ويب في المتصفح...', 'Opening WhatsApp Web in browser...'),
                    'info'
                  );
                }}
                className="p-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2.5 shadow-sm transition-colors cursor-pointer no-underline"
              >
                <Monitor className="w-5 h-5 shrink-0" />
                <div className="text-right">
                  <div className="text-xs font-black">
                    {tr('فتح واتساب ويب (Web)', 'Open WhatsApp Web')}
                  </div>
                  <div className="text-[10px] text-blue-100">
                    {tr('يفتح بالمتصفح مباشرة بدون تحويل', 'Direct browser web.whatsapp.com')}
                  </div>
                </div>
              </a>
            </div>

            {/* Secondary Row: Universal API Link + QR Code for Mobile + SMS */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <a
                href={whatsappApiUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  if (!finalInternationalPhone) {
                    e.preventDefault();
                    showToast(tr('يرجى إدخال رقم هاتف صحيح', 'Please enter a valid phone number'), 'error');
                  }
                }}
                className="neu-button py-2 px-2.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-emerald-700 flex items-center justify-center gap-1.5 cursor-pointer no-underline"
              >
                <Globe className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>{tr('رابط واتساب العام', 'Universal Link')}</span>
              </a>

              <button
                type="button"
                onClick={() => setShowQr((prev) => !prev)}
                className={`py-2 px-2.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  showQr
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'neu-button text-slate-700'
                }`}
              >
                <QrCode className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>{tr('إرسال بالموبايل (QR)', 'Send via Phone QR')}</span>
              </button>

              <button
                type="button"
                onClick={handleSMS}
                className="neu-button py-2 px-2.5 rounded-xl text-[11px] font-bold text-slate-700 hover:text-blue-700 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>{tr('رسالة SMS', 'Send SMS')}</span>
              </button>
            </div>
          </div>

          {/* QR Code Panel for scanning with Cashier's Phone */}
          {showQr && qrDataUrl && (
            <div className="p-4 rounded-2xl bg-white border border-emerald-200 flex flex-col sm:flex-row items-center gap-4">
              <img
                src={qrDataUrl}
                alt="WhatsApp QR Code"
                className="w-36 h-36 rounded-xl border border-slate-200 p-1 bg-white shrink-0"
              />
              <div className="space-y-1.5 text-xs text-slate-600">
                <h4 className="font-black text-slate-900 text-sm">
                  {tr(
                    'امسح الكود بكاميرا هاتفك لإرسال الرسالة فوراً',
                    'Scan with your phone camera to send immediately'
                  )}
                </h4>
                <p className="leading-relaxed">
                  {tr(
                    'إذا كان جهاز الكمبيوتر غير متصل بالواتساب، وجه كاميرا موبايلك إلى هذا الكود ليفتح تطبيق واتساب على هاتفك مباشرة بمحادثة العميل وبداخلها نص الرسالة جاهزاً للإرسال.',
                    'Point your phone camera at this QR code to open WhatsApp on your phone with the customer number and pre-filled message ready to send.'
                  )}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
