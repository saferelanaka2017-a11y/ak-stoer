/**
 * @file utils/updateManager.ts
 * نظام إدارة التحديثات الذكي والمباشر (Live OTA & Offline Updater) لنسخة الموبايل (PWA) واللابتوب (.EXE) والويب
 * Seamless Live Update Manager for Mobile PWA, Standalone .EXE (Electron), and Desktop Mode
 * يضمن تحديث النسخة المحملة على الموبايل واللابتوب (.EXE) تلقائياً وفورياً عند أي تعديل على النظام
 * مع حماية 100% لقاعدة البيانات وتفعيل السيريل والمزامنة
 */

export const APP_VERSION = '2.7.0';
export const APP_BUILD_NUMBER = 1793566800;
export const APP_RELEASE_DATE = '2026-11-01';

export const DEFAULT_CLOUD_SERVER_URL =
  'https://ais-pre-dtdtj6sx4wxmcf7m5rnwyq-461022146256.europe-west2.run.app';

const DB_PRIMARY_STORAGE_KEY = 'soft_glass_pos_db_v1';
const DB_LEGACY_STORAGE_KEY = 'offline_pos_sqlite_db';
const UPDATE_HISTORY_KEY = 'akstore_update_history_v1';
const UPDATE_SERVER_URL_KEY = 'akstore_update_server_url_v1';
const LAST_UPDATE_CHECK_KEY = 'akstore_last_update_check_v1';
const INSTALLED_BUNDLE_SIG_KEY = 'akstore_installed_bundle_sig_v1';

export interface VersionManifest {
  version: string;
  buildNumber: number;
  bundleSignature?: string;
  mainScriptAsset?: string;
  assets?: string[];
  releaseDate: string;
  updatedAtIso?: string;
  channel: string;
  minWindowsVersion: string;
  preserveDatabaseOnUpdate: boolean;
  preserveLicenseOnUpdate: boolean;
  notesAr: string[];
  notesEn: string[];
}

export interface UpdateHistoryRecord {
  id: string;
  version: string;
  buildNumber: number;
  date: string;
  method: 'online_ota' | 'offline_patch' | 'exe_upgrade';
  status: 'success' | 'up_to_date';
  details: string;
}

export interface ExeRuntimeInfo {
  isElectronExe: boolean;
  appVersion: string;
  electronVersion?: string;
  chromeVersion?: string;
  platform?: string;
  arch?: string;
  userDataPath?: string;
  vaultFilePath?: string;
}

/**
 * قراءة اسم ملف الـ JS الرئيسي المشغّل حالياً في الصفحة لمعرفة ما إذا كان هناك بناء أحدث على السيرفر
 */
export function getCurrentRunningMainScript(): string {
  try {
    if (typeof document === 'undefined') return '';
    const scripts = document.querySelectorAll('script[src]');
    for (let i = 0; i < scripts.length; i++) {
      const src = scripts[i].getAttribute('src') || '';
      if (src.indexOf('/assets/index-') !== -1 && src.endsWith('.js')) {
        const cleanIdx = src.indexOf('/assets/index-');
        return src.slice(cleanIdx).split('?')[0];
      }
    }
  } catch {
    // ignore
  }
  return '';
}

/**
 * التحقق مما إذا كان البرنامج يعمل داخل ملف تنفيذي (.EXE) عبر Electron أو وضع سطح المكتب
 */
export function isRunningInElectronExe(): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const ua = navigator.userAgent || '';
    if (ua.indexOf('Electron') !== -1) return true;
    const winAny = window as any;
    if (winAny.process && winAny.process.versions && winAny.process.versions.electron) {
      return true;
    }
    const params = new URLSearchParams(window.location.search);
    return params.get('exe') === '1' || window.location.protocol === 'file:';
  } catch {
    return false;
  }
}

/**
 * الحصول على واجهة IPC الخاصة بـ Electron إن وجدت
 */
function getElectronIpcRenderer(): any | null {
  try {
    const winAny = window as any;
    if (winAny.require) {
      const electron = winAny.require('electron');
      return electron ? electron.ipcRenderer : null;
    }
  } catch {
    // Not in Electron with nodeIntegration
  }
  return null;
}

/**
 * جلب معلومات بيئة الـ EXE ومسار الحفظ الدائم (%APPDATA%\AKStorePOS_Data)
 */
export async function getExeRuntimeInfo(): Promise<ExeRuntimeInfo> {
  const ipc = getElectronIpcRenderer();
  if (ipc) {
    try {
      const info = await ipc.invoke('akstore-get-exe-info');
      if (info) return info;
    } catch {
      // Fallback below
    }
  }
  return {
    isElectronExe: isRunningInElectronExe(),
    appVersion: APP_VERSION,
    userDataPath: '%APPDATA%\\AKStorePOS_Data',
    vaultFilePath: '%APPDATA%\\AKStorePOS_Data\\akstore_persistent_vault.json'
  };
}

/**
 * حفظ نسخة احتياطية فورية من قاعدة البيانات والترخيص في الخزنة الدائمة (IndexedDB + Electron File Vault)
 * قبل أي عملية تحديث لضمان عدم ضياع أي فاتورة أو تفعيل
 */
export async function syncDatabaseAndLicenseToSafeVault(): Promise<boolean> {
  try {
    const primaryDbJson =
      localStorage.getItem(DB_PRIMARY_STORAGE_KEY) ||
      localStorage.getItem(DB_LEGACY_STORAGE_KEY) ||
      null;

    const vaultPayload = {
      timestamp: new Date().toISOString(),
      appVersion: APP_VERSION,
      databaseJson: primaryDbJson,
      softGlassDbJson: primaryDbJson,
      licenseDataJson: localStorage.getItem('soft_glass_pos_license_data_v1') || null,
      deviceCode: localStorage.getItem('soft_glass_pos_device_id_v1') || null,
      trialStartTs: localStorage.getItem('soft_glass_pos_trial_start_v1') || null,
      lowSpecMode: localStorage.getItem('pos_low_spec_mode') || null,
      appTheme: localStorage.getItem('pos_app_theme') || null,
      appLanguage: localStorage.getItem('pos_app_language') || null
    };

    // 1. الحفظ على القرص الصلب في مسار %APPDATA%\AKStorePOS_Data إذا كان البرنامج يعمل كـ EXE
    const ipc = getElectronIpcRenderer();
    if (ipc) {
      await ipc.invoke('akstore-save-vault', vaultPayload);
    }

    // 2. الحفظ في IndexedDB كطبقة حماية إضافية ضد مسح الكاش في جميع البيئات
    await saveVaultToIndexedDB(vaultPayload);
    return true;
  } catch (e) {
    console.warn('Safe vault sync warning:', e);
    return false;
  }
}

/**
 * استرجاع قاعدة البيانات والترخيص تلقائياً بعد تحديث الـ EXE في حال تم تشغيل محرك جديد
 */
export async function restoreDatabaseAndLicenseFromSafeVaultIfNeeded(): Promise<boolean> {
  try {
    const currentDb = localStorage.getItem(DB_PRIMARY_STORAGE_KEY);
    const currentLicense = localStorage.getItem('soft_glass_pos_license_data_v1');

    let restoredPayload: any = null;

    // 1. محاولة الاسترجاع من ملف خزنة الـ EXE في %APPDATA%\AKStorePOS_Data
    const ipc = getElectronIpcRenderer();
    if (ipc) {
      const res = await ipc.invoke('akstore-load-vault');
      if (res && res.success && res.data) {
        restoredPayload = res.data;
      }
    }

    // 2. محاولة الاسترجاع من IndexedDB إن لم يوجد في ملف الـ EXE
    if (!restoredPayload) {
      restoredPayload = await loadVaultFromIndexedDB();
    }

    if (!restoredPayload) {
      if (currentDb || currentLicense) {
        await syncDatabaseAndLicenseToSafeVault();
      }
      return false;
    }

    let restoredAny = false;
    const savedDb = restoredPayload.softGlassDbJson || restoredPayload.databaseJson;
    if (!currentDb && savedDb) {
      localStorage.setItem(DB_PRIMARY_STORAGE_KEY, savedDb);
      restoredAny = true;
    }
    if (!currentLicense && restoredPayload.licenseDataJson) {
      localStorage.setItem('soft_glass_pos_license_data_v1', restoredPayload.licenseDataJson);
      restoredAny = true;
    }
    if (!localStorage.getItem('soft_glass_pos_device_id_v1') && restoredPayload.deviceCode) {
      localStorage.setItem('soft_glass_pos_device_id_v1', restoredPayload.deviceCode);
    }
    if (!localStorage.getItem('soft_glass_pos_trial_start_v1') && restoredPayload.trialStartTs) {
      localStorage.setItem('soft_glass_pos_trial_start_v1', restoredPayload.trialStartTs);
    }

    if (currentDb || currentLicense) {
      await syncDatabaseAndLicenseToSafeVault();
    }

    return restoredAny;
  } catch {
    return false;
  }
}

function saveVaultToIndexedDB(payload: any): Promise<void> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve();
        return;
      }
      const req = indexedDB.open('AKStore_Safe_Update_Vault', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('vault')) {
          db.createObjectStore('vault');
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction('vault', 'readwrite');
          tx.objectStore('vault').put(payload, 'latest_snapshot');
          tx.oncomplete = () => {
            db.close();
            resolve();
          };
          tx.onerror = () => {
            db.close();
            resolve();
          };
        } catch {
          resolve();
        }
      };
      req.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function loadVaultFromIndexedDB(): Promise<any | null> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve(null);
        return;
      }
      const req = indexedDB.open('AKStore_Safe_Update_Vault', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('vault')) {
          db.createObjectStore('vault');
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction('vault', 'readonly');
          const getReq = tx.objectStore('vault').get('latest_snapshot');
          getReq.onsuccess = () => {
            db.close();
            resolve(getReq.result || null);
          };
          getReq.onerror = () => {
            db.close();
            resolve(null);
          };
        } catch {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

/**
 * جلب رابط سيرفر التحديثات والمزامنة المعتمد
 */
export function getUpdateServerUrl(): string {
  try {
    const saved = localStorage.getItem(UPDATE_SERVER_URL_KEY);
    if (saved && saved.trim() && saved.trim().startsWith('http')) {
      return saved.trim().replace(/\/$/, '');
    }
  } catch {
    // ignore
  }
  if (
    typeof window !== 'undefined' &&
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http')
  ) {
    return window.location.origin.replace(/\/$/, '');
  }
  return DEFAULT_CLOUD_SERVER_URL;
}

export function setUpdateServerUrl(url: string): void {
  const cleaned = (url || DEFAULT_CLOUD_SERVER_URL).trim().replace(/\/$/, '');
  try {
    localStorage.setItem(UPDATE_SERVER_URL_KEY, cleaned);
    const ipc = getElectronIpcRenderer();
    if (ipc) {
      ipc.invoke('akstore-configure-exe-update', {
        remoteServerUrl: cleaned,
        useRemoteUpdateServer: true
      });
    }
  } catch {
    // ignore
  }
}

/**
 * تحميل وتخزين أحدث ملفات النظام (index.html + /assets/*) داخل CacheStorage و IndexedDB على الموبايل واللابتوب
 */
export async function downloadAndCacheLatestWebBundle(baseUrl: string): Promise<VersionManifest | null> {
  const cleanBase = baseUrl.replace(/\/$/, '');
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(`${cleanBase}/api/update/live-bundle?t=${Date.now()}`, {
      cache: 'no-store',
      credentials: 'same-origin',
      signal: controller.signal
    });
    clearTimeout(timer);

    if (!res.ok) return null;
    const data = await res.json();
    if (!data || !data.success || !data.indexHtml || !data.manifest) return null;

    const manifest: VersionManifest = data.manifest;
    const htmlText: string = data.indexHtml;

    if ('caches' in window) {
      // مسح الكاش القديم وتخزين النسخة الجديدة بالكامل في ak-store-offline-v4
      const keys = await caches.keys();
      for (const k of keys) {
        if (k !== 'ak-store-offline-v4') {
          await caches.delete(k).catch(() => {});
        }
      }
      const cache = await caches.open('ak-store-offline-v4');
      const cleanHtmlRes = new Response(htmlText, {
        status: 200,
        statusText: 'OK',
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
      await cache.put('/', cleanHtmlRes.clone());
      await cache.put('/index.html', cleanHtmlRes.clone());

      // تحميل وتخزين جميع ملفات JS و CSS الجديدة
      const assets: string[] = Array.isArray(manifest.assets) ? manifest.assets : [];
      await Promise.allSettled(
        assets.map(async (assetPath) => {
          if (!assetPath || assetPath === '/' || assetPath === '/index.html') return;
          const assetRes = await fetch(`${cleanBase}${assetPath}?t=${manifest.buildNumber || Date.now()}`, {
            cache: 'no-store',
            credentials: 'same-origin'
          });
          if (assetRes && assetRes.ok && assetRes.status === 200) {
            const ct = assetRes.headers.get('content-type') || '';
            if (!ct.includes('text/html')) {
              const buf = await assetRes.arrayBuffer();
              const cleanAsset = new Response(buf, {
                status: 200,
                statusText: 'OK',
                headers: { 'Content-Type': ct || 'application/octet-stream' }
              });
              await cache.put(assetPath, cleanAsset);
            }
          }
        })
      );
    }

    // تحديث النسخة الاحتياطية لواجهة التطبيق داخل IndexedDB
    try {
      if (typeof indexedDB !== 'undefined') {
        await new Promise<void>((resolve) => {
          const req = indexedDB.open('AKStore_Local_SQLite_Engine_v1', 1);
          req.onsuccess = () => {
            try {
              const db = req.result;
              const tx = db.transaction(['engine_meta'], 'readwrite');
              tx.objectStore('engine_meta').put(htmlText, 'offline_app_shell_html');
              tx.oncomplete = () => {
                try { db.close(); } catch {}
                resolve();
              };
              tx.onerror = () => {
                try { db.close(); } catch {}
                resolve();
              };
            } catch {
              resolve();
            }
          };
          req.onerror = () => resolve();
        });
      }
    } catch {
      // ignore
    }

    if (manifest.bundleSignature) {
      localStorage.setItem(INSTALLED_BUNDLE_SIG_KEY, manifest.bundleSignature);
    }

    return manifest;
  } catch {
    return null;
  }
}

/**
 * فحص وجود تحديث أو تعديل جديد على السيرفر (يدعم الموبايل PWA ونسخة اللابتوب .EXE والويب)
 */
export async function checkForSystemUpdate(customServerUrl?: string): Promise<{
  checked: boolean;
  hasNewerVersion: boolean;
  remoteManifest: VersionManifest | null;
  messageAr: string;
  messageEn: string;
}> {
  await syncDatabaseAndLicenseToSafeVault();

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return {
      checked: false,
      hasNewerVersion: false,
      remoteManifest: null,
      messageAr:
        'البرنامج يعمل بوضع Offline-First عبر قاعدة البيانات المحلية المؤمنة! للاتصال بسيرفر التحديث تأكد من اتصال الإنترنت أو استخدم ملف التحديث الأوفلاين (.akupdate).',
      messageEn:
        'Running in Offline-First mode via local database! Connect to internet for online update or use an offline (.akupdate) package.'
    };
  }

  const candidateUrls: string[] = [];
  if (customServerUrl && customServerUrl.trim().startsWith('http')) {
    candidateUrls.push(customServerUrl.trim().replace(/\/$/, ''));
  }
  const primaryUrl = getUpdateServerUrl();
  if (primaryUrl && !candidateUrls.includes(primaryUrl)) {
    candidateUrls.push(primaryUrl);
  }
  if (!candidateUrls.includes(DEFAULT_CLOUD_SERVER_URL)) {
    candidateUrls.push(DEFAULT_CLOUD_SERVER_URL);
  }

  const runningScript = getCurrentRunningMainScript();
  const savedBundleSig = localStorage.getItem(INSTALLED_BUNDLE_SIG_KEY) || '';

  for (const base of candidateUrls) {
    try {
      const manifestUrl = `${base}/version.json?t=${Date.now()}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);
      const response = await fetch(manifestUrl, {
        cache: 'no-store',
        credentials: 'same-origin',
        signal: controller.signal,
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Pragma: 'no-cache'
        }
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        continue;
      }

      const manifest: VersionManifest = await response.json();
      if ((manifest as any).offline) {
        continue;
      }
      localStorage.setItem(LAST_UPDATE_CHECK_KEY, new Date().toISOString());

      const scriptChanged =
        Boolean(manifest.mainScriptAsset) &&
        Boolean(runningScript) &&
        manifest.mainScriptAsset !== runningScript;

      const sigChanged =
        Boolean(manifest.bundleSignature) &&
        Boolean(savedBundleSig) &&
        manifest.bundleSignature !== savedBundleSig;

      const isNewer =
        scriptChanged ||
        sigChanged ||
        (manifest.buildNumber && manifest.buildNumber > APP_BUILD_NUMBER) ||
        (manifest.version && manifest.version !== APP_VERSION);

      if (!savedBundleSig && manifest.bundleSignature && !scriptChanged) {
        localStorage.setItem(INSTALLED_BUNDLE_SIG_KEY, manifest.bundleSignature);
      }

      return {
        checked: true,
        hasNewerVersion: Boolean(isNewer),
        remoteManifest: manifest,
        messageAr: isNewer
          ? `يتوفر تعديل وتحديث جديد للنظام للموبايل ونسخة الـ EXE (بناء رقم ${manifest.buildNumber}) جاهز للتثبيت الفوري بدون مساس بالبيانات!`
          : `تم الاتصال بسيرفر التحديث بنجاح! نسخة الموبايل واللابتوب (.EXE) محدّثة لآخر تعديل (${manifest.version || APP_VERSION}).`,
        messageEn: isNewer
          ? `A new live system modification (Build #${manifest.buildNumber}) is ready for instant update on Mobile & .EXE!`
          : `Connected to update server! Your Mobile & Laptop (.EXE) version (${manifest.version || APP_VERSION}) has the latest changes.`
      };
    } catch {
      // try next candidate URL
    }
  }

  return {
    checked: false,
    hasNewerVersion: false,
    remoteManifest: null,
    messageAr:
      'تم تأمين قاعدة البيانات والتفعيل محلياً! للاتصال بسيرفر التحديث تأكد من اتصال الإنترنت أو استخدم ملف التحديث الأوفلاين (.akupdate).',
    messageEn:
      'Database and license secured locally! Check internet connection for online update or use an offline (.akupdate) package.'
  };
}

/**
 * تنفيذ التحديث الفوري لنسخة الموبايل (PWA) واللابتوب (.EXE) والمتصفح
 * يسحب أحدث ملفات النظام المعدلة هنا ويخزنها أوفلاين مع الحفاظ الكامل على قاعدة البيانات والسيريل
 */
export async function applySafeOnlineUpdateAndReload(remoteUrl?: string): Promise<{
  success: boolean;
  messageAr: string;
}> {
  try {
    // 1. تأمين نسخة كاملة من قاعدة البيانات والترخيص في الخزنة الدائمة قبل التحديث
    await syncDatabaseAndLicenseToSafeVault();

    const targetServer = (remoteUrl && remoteUrl.trim()) || getUpdateServerUrl() || DEFAULT_CLOUD_SERVER_URL;
    setUpdateServerUrl(targetServer);

    // 2. رفع ومزامنة قاعدة البيانات المحلية الحالية مع السيرفر قبل إعادة التحميل لضمان عدم ضياع أي بيان
    if (typeof navigator === 'undefined' || navigator.onLine !== false) {
      try {
        const rawDb = localStorage.getItem(DB_PRIMARY_STORAGE_KEY);
        const syncEmail = localStorage.getItem('soft_glass_pos_sync_email_v1') || '';
        if (rawDb && syncEmail) {
          const parsedState = JSON.parse(rawDb);
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 2500);
          await fetch(`${targetServer.replace(/\/$/, '')}/api/sync/push`, {
            method: 'POST',
            signal: controller.signal,
            headers: {
              'Content-Type': 'application/json',
              'X-Sync-Email': syncEmail
            },
            body: JSON.stringify({
              email: syncEmail,
              deviceId: localStorage.getItem('soft_glass_pos_device_id_v1') || 'exe-updater',
              deviceName: isRunningInElectronExe() ? 'نسخة سطح المكتب (.EXE)' : 'جهاز متصل',
              state: parsedState
            })
          });
          clearTimeout(timeoutId);
        }
      } catch {
        // ignore if offline
      }
    }

    // 3. سحب أحدث ملفات البناء المعدلة وتخزينها في CacheStorage + IndexedDB للموبايل واللابتوب
    const updatedManifest = await downloadAndCacheLatestWebBundle(targetServer);

    // 4. تسجيل عملية التحديث في السجل
    addUpdateHistoryRecord({
      version: updatedManifest?.version || APP_VERSION,
      buildNumber: updatedManifest?.buildNumber || APP_BUILD_NUMBER,
      method: 'online_ota',
      status: 'success',
      details: 'تم سحب أحدث تعديلات النظام وتحديث نسخة الموبايل واللابتوب (.EXE) مع تأمين قاعدة البيانات والتفعيل'
    });

    // 5. تحديث Service Worker لتفعيل النسخة الجديدة فوراً
    if ('serviceWorker' in navigator) {
      try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (let i = 0; i < registrations.length; i++) {
          await registrations[i].update().catch(() => {});
          if (registrations[i].waiting) {
            registrations[i].waiting?.postMessage({ type: 'SKIP_WAITING' });
          }
          if (registrations[i].active) {
            registrations[i].active?.postMessage({ type: 'PRECACHE_NOW' });
          }
        }
      } catch {
        // ignore
      }
    }

    // 6. إذا كان يعمل داخل EXE (Electron)، نطلب من Electron تحميل التحديث الجديد على القرص الصلب وإعادة تحميل الواجهة
    const ipc = getElectronIpcRenderer();
    if (ipc) {
      await ipc.invoke('akstore-refresh-exe-ui', { targetServerUrl: targetServer });
      return {
        success: true,
        messageAr:
          'تم تحديث نسخة اللابتوب (.EXE) بأحدث التعديلات ومزامنة البيانات بنجاح مع الاحتفاظ بجميع الفواتير والتفعيل!'
      };
    }

    // 7. إذا كان يعمل من ملف محلي (file://) خارج Electron، ننتقل إلى السيرفر المحدث مباشرة
    if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
      setTimeout(() => {
        window.location.href = `${targetServer.replace(/\/$/, '')}/?exe=1&updated=${Date.now()}`;
      }, 400);
      return {
        success: true,
        messageAr: 'جاري فتح أحدث إصدار معدل من السيرفر لنسخة سطح المكتب مع حفظ كافة البيانات...'
      };
    }

    // 8. إعادة تحميل الصفحة بجلب أحدث نسخة معدلة للموبايل والكمبيوتر
    setTimeout(() => {
      const url = new URL(window.location.href);
      url.searchParams.set('updated', String(Date.now()));
      window.location.replace(url.toString());
    }, 450);

    return {
      success: true,
      messageAr: 'تم تحديث النسخة المحملة على جهازك بأحدث التعديلات! جاري إعادة تشغيل الواجهة...'
    };
  } catch (err) {
    return {
      success: false,
      messageAr: 'حدث خطأ أثناء تطبيق التحديث: ' + String(err)
    };
  }
}

/**
 * المراقب التلقائي للتحديثات الحية (Live Auto-Update Watcher)
 * يعمل في الخلفية على الموبايل (PWA) واللابتوب (.EXE) ويكتشف أي تعديل يتم على النظام هنا ليحدث النسخة المحملة تلقائياً
 */
export function startAutoLiveUpdateWatcher(
  onNewBuildReady?: (manifest: VersionManifest) => void
): () => void {
  if (typeof window === 'undefined') return () => {};

  let isUpdating = false;

  const checkAndSyncBuild = async () => {
    if (isUpdating) return;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return;

    try {
      const base = getUpdateServerUrl();
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2500);
      const res = await fetch(`${base}/version.json?t=${Date.now()}`, {
        cache: 'no-store',
        credentials: 'same-origin',
        signal: controller.signal
      });
      clearTimeout(timer);
      if (!res.ok) return;

      const manifest: VersionManifest = await res.json();
      if (!manifest || (manifest as any).offline) return;

      const runningScript = getCurrentRunningMainScript();
      const savedSig = localStorage.getItem(INSTALLED_BUNDLE_SIG_KEY) || '';

      // إذا لم يكن هناك توقيع محفوظ بعد، نحفظ التوقيع الحالي إذا كان نفس ملف الـ JS
      if (!savedSig && manifest.bundleSignature) {
        if (!runningScript || !manifest.mainScriptAsset || runningScript === manifest.mainScriptAsset) {
          localStorage.setItem(INSTALLED_BUNDLE_SIG_KEY, manifest.bundleSignature);
          return;
        }
      }

      const scriptDiffers =
        Boolean(runningScript) &&
        Boolean(manifest.mainScriptAsset) &&
        runningScript !== manifest.mainScriptAsset;

      const sigDiffers =
        Boolean(savedSig) &&
        Boolean(manifest.bundleSignature) &&
        savedSig !== manifest.bundleSignature;

      if (scriptDiffers || sigDiffers) {
        isUpdating = true;
        await syncDatabaseAndLicenseToSafeVault();
        await downloadAndCacheLatestWebBundle(base);

        const ipc = getElectronIpcRenderer();
        if (ipc) {
          ipc.invoke('akstore-refresh-exe-ui', { targetServerUrl: base }).catch(() => {});
        }

        if (onNewBuildReady) {
          onNewBuildReady(manifest);
        }
        isUpdating = false;
      }
    } catch {
      isUpdating = false;
    }
  };

  // فحص أولي بعد ثانيتين من التشغيل، ثم كل 30 ثانية وعند عودة الإنترنت أو فتح التطبيق على الموبايل
  const initTimer = setTimeout(checkAndSyncBuild, 2500);
  const intervalId = setInterval(checkAndSyncBuild, 30000);

  const onVisibilityChange = () => {
    if (document.visibilityState === 'visible') {
      checkAndSyncBuild();
    }
  };

  const onSwMessage = (event: MessageEvent) => {
    if (event.data && event.data.type === 'AK_LIVE_UPDATE_READY') {
      checkAndSyncBuild();
    }
  };

  window.addEventListener('online', checkAndSyncBuild);
  document.addEventListener('visibilitychange', onVisibilityChange);
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', onSwMessage);
  }

  return () => {
    clearTimeout(initTimer);
    clearInterval(intervalId);
    window.removeEventListener('online', checkAndSyncBuild);
    document.removeEventListener('visibilitychange', onVisibilityChange);
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.removeEventListener('message', onSwMessage);
    }
  };
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, Array.from(chunk));
  }
  return btoa(binary);
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * أخذ وتصدير ملف التحديث الشامل (.akupdate) الذي يحتوي على أحدث تعديلات النظام وملفات التشغيل
 * لتحديث نسخة الموبايل واللابتوب (.EXE) بضغطة زر (أونلاين أو أوفلاين)
 */
export async function exportOfflineUpdatePackage(): Promise<boolean> {
  const updateServerUrl = getUpdateServerUrl();
  const currentDbJson = localStorage.getItem(DB_PRIMARY_STORAGE_KEY) || null;

  let fullServerPackage: any = null;
  if (typeof navigator === 'undefined' || navigator.onLine !== false) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(`${updateServerUrl}/api/update/full-package?t=${Date.now()}`, {
        cache: 'no-store',
        credentials: 'same-origin',
        signal: controller.signal
      });
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        if (data && data.success) {
          fullServerPackage = data;
        }
      }
    } catch {
      // Fallback to local cache extraction below
    }
  }

  // Fallback: extract indexHtml and assets from local CacheStorage if offline
  let localIndexHtml = fullServerPackage?.indexHtml || '';
  const bundledAssets: Record<string, { contentType: string; base64: string }> =
    fullServerPackage?.bundledAssets || {};

  if (!localIndexHtml && typeof document !== 'undefined') {
    localIndexHtml = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
  }

  if (Object.keys(bundledAssets).length === 0 && typeof window !== 'undefined' && 'caches' in window) {
    try {
      const cache = await caches.open('ak-store-offline-v4');
      const requests = await cache.keys();
      for (const req of requests) {
        const urlObj = new URL(req.url);
        if (urlObj.pathname.startsWith('/assets/')) {
          const resp = await cache.match(req);
          if (resp && resp.ok) {
            const buf = await resp.arrayBuffer();
            bundledAssets[urlObj.pathname] = {
              contentType: resp.headers.get('content-type') || 'application/octet-stream',
              base64: arrayBufferToBase64(buf)
            };
          }
        }
      }
    } catch {
      // ignore
    }
  }

  const pkg = {
    packageType: 'AKSTORE_EXE_UPDATE_PACKAGE',
    version: fullServerPackage?.version || APP_VERSION,
    buildNumber: fullServerPackage?.buildNumber || APP_BUILD_NUMBER,
    bundleSignature: fullServerPackage?.bundleSignature || '',
    releaseDate: fullServerPackage?.releaseDate || APP_RELEASE_DATE,
    exportedAt: new Date().toISOString(),
    updateServerUrl,
    preserveDatabase: true,
    preserveLicense: true,
    manifest: fullServerPackage?.manifest || null,
    indexHtml: localIndexHtml,
    bundledAssets,
    databaseSnapshotJson: currentDbJson,
    changelogAr: [
      'ملف تحديث شامل يحتوي على أحدث التعديلات البرمجية وملفات النظام للموبايل واللابتوب (.EXE)',
      'إصلاح ظهور شعار المتجر في جميع الفواتير المطبوعة (حراري 80mm / 58mm / A4) وملفات PDF و Word',
      'إضافة زر خروج من البرنامج في نهاية القائمة الجانبية بعد الإعدادات',
      'الحفاظ الكامل 100% على قاعدة البيانات المحلية وتفعيل السيريل بدون أي تغيير'
    ]
  };

  const content = JSON.stringify(pkg);
  const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AK_Store_Update_v${pkg.version}.akupdate`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 3000);
  return true;
}

/**
 * تثبيت ملف التحديث (.akupdate) داخل نسخة الموبايل أو اللابتوب (.EXE) دون المساس بقاعدة البيانات أو السيريل
 */
export async function installOfflineUpdatePackage(jsonContent: string): Promise<{
  success: boolean;
  messageAr: string;
  version?: string;
}> {
  try {
    const parsed = JSON.parse(jsonContent);
    if (!parsed || parsed.packageType !== 'AKSTORE_EXE_UPDATE_PACKAGE') {
      return {
        success: false,
        messageAr: 'ملف التحديث غير صالح. يرجى اختيار ملف حزمة تحديث رسمي بصيغة (.akupdate).'
      };
    }

    // 1. حفظ قاعدة البيانات والترخيص أولاً في الخزنة الدائمة
    await syncDatabaseAndLicenseToSafeVault();

    if (parsed.updateServerUrl) {
      setUpdateServerUrl(parsed.updateServerUrl);
    }

    // 2. إذا كان ملف التحديث يحتوي على الكود المجمع (indexHtml + bundledAssets)، نخزنه في الكاش و IndexedDB فوراً
    if ('caches' in window && parsed.indexHtml) {
      try {
        const keys = await caches.keys();
        for (const k of keys) {
          if (k !== 'ak-store-offline-v4') {
            await caches.delete(k).catch(() => {});
          }
        }
        const cache = await caches.open('ak-store-offline-v4');
        const htmlRes = new Response(parsed.indexHtml, {
          status: 200,
          statusText: 'OK',
          headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
        await cache.put('/', htmlRes.clone());
        await cache.put('/index.html', htmlRes.clone());

        if (parsed.bundledAssets && typeof parsed.bundledAssets === 'object') {
          for (const [assetPath, entry] of Object.entries(parsed.bundledAssets as Record<string, any>)) {
            if (entry && entry.base64) {
              const bytes = base64ToUint8Array(entry.base64);
              const assetRes = new Response(bytes.buffer as ArrayBuffer, {
                status: 200,
                statusText: 'OK',
                headers: { 'Content-Type': entry.contentType || 'application/octet-stream' }
              });
              await cache.put(assetPath, assetRes);
            }
          }
        }
      } catch {
        // ignore cache error
      }
    }

    if (parsed.indexHtml && typeof indexedDB !== 'undefined') {
      try {
        await new Promise<void>((resolve) => {
          const req = indexedDB.open('AKStore_Local_SQLite_Engine_v1', 1);
          req.onsuccess = () => {
            try {
              const db = req.result;
              const tx = db.transaction(['engine_meta'], 'readwrite');
              tx.objectStore('engine_meta').put(parsed.indexHtml, 'offline_app_shell_html');
              tx.oncomplete = () => {
                try { db.close(); } catch {}
                resolve();
              };
              tx.onerror = () => {
                try { db.close(); } catch {}
                resolve();
              };
            } catch {
              resolve();
            }
          };
          req.onerror = () => resolve();
        });
      } catch {
        // ignore
      }
    }

    if (parsed.bundleSignature) {
      localStorage.setItem(INSTALLED_BUNDLE_SIG_KEY, parsed.bundleSignature);
    }

    addUpdateHistoryRecord({
      version: parsed.version || APP_VERSION,
      buildNumber: parsed.buildNumber || APP_BUILD_NUMBER,
      method: 'offline_patch',
      status: 'success',
      details: `تم تثبيت ملف التحديث الشامل (الإصدار ${parsed.version || APP_VERSION}) بنجاح مع حفظ قاعدة البيانات والتفعيل`
    });

    // 3. إذا كان يعمل داخل اللابتوب (.EXE)، نرسل الحزمة إلى Electron لحفظها على القرص الصلب وإعادة تحميل الواجهة
    const ipc = getElectronIpcRenderer();
    if (ipc) {
      await ipc.invoke('akstore-install-offline-bundle', parsed);
      return {
        success: true,
        version: parsed.version,
        messageAr: `تم تثبيت ملف التحديث (الإصدار ${parsed.version}) على اللابتوب (.EXE) بنجاح تام مع الاحتفاظ بجميع الفواتير وتفعيل الجهاز!`
      };
    }

    // 4. إذا كان متصلاً بالإنترنت أيضاً، نسحب أي أصول إضافية ونعيد تشغيل الواجهة
    setTimeout(() => {
      const url = new URL(window.location.href);
      url.searchParams.set('updated', String(Date.now()));
      window.location.replace(url.toString());
    }, 600);

    return {
      success: true,
      version: parsed.version,
      messageAr: `تم تثبيت ملف التحديث (الإصدار ${parsed.version}) بنجاح تام مع الاحتفاظ بجميع الفواتير والأصناف وتفعيل الجهاز! جاري تحديث الواجهة...`
    };
  } catch {
    return {
      success: false,
      messageAr: 'تعذر قراءة ملف التحديث، تأكد من سلامة ملف (.akupdate).'
    };
  }
}

/**
 * سجل التحديثات السابقة
 */
export function getUpdateHistory(): UpdateHistoryRecord[] {
  try {
    const raw = localStorage.getItem(UPDATE_HISTORY_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return [
    {
      id: 'init-v2.7.0',
      version: APP_VERSION,
      buildNumber: APP_BUILD_NUMBER,
      date: new Date().toLocaleDateString('ar-SA'),
      method: 'exe_upgrade',
      status: 'up_to_date',
      details: 'الإصدار المعتمد 2.7.0 مع التحديث المباشر التلقائي لنسخة الموبايل (PWA) واللابتوب (.EXE) فور تعديل النظام'
    }
  ];
}

export function addUpdateHistoryRecord(
  record: Omit<UpdateHistoryRecord, 'id' | 'date'>
): void {
  try {
    const current = getUpdateHistory();
    const newEntry: UpdateHistoryRecord = {
      ...record,
      id: 'upd-' + Date.now(),
      date: new Date().toLocaleString('ar-SA')
    };
    localStorage.setItem(UPDATE_HISTORY_KEY, JSON.stringify([newEntry, ...current.slice(0, 14)]));
  } catch {
    // ignore
  }
}
