import './utils/win7Polyfills';
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class Win7SafeErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Unexpected rendering error'
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('AK Store Safe Boundary caught error:', error, errorInfo);
  }

  handleEnableSafeMode = () => {
    try {
      localStorage.setItem('pos_low_spec_mode', 'true');
      document.documentElement.classList.add('low-spec-mode');
    } catch {
      // ignore storage errors
    }
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen flex items-center justify-center p-6 bg-slate-100 text-slate-800"
        >
          <div className="max-w-md w-full bg-white rounded-2xl border border-slate-300 p-6 shadow-md text-center space-y-4">
            <div className="w-12 h-12 rounded-xl bg-blue-600 text-white font-bold text-lg flex items-center justify-center mx-auto">
              AK
            </div>
            <h1 className="text-base font-bold text-slate-900">
              AK Store — وضع الحماية والتوافق مع أنظمة ويندوز (7 / 8 / 10 / 11)
            </h1>
            <p className="text-xs text-slate-600 leading-relaxed">
              تم اكتشاف تعارض بسيط في كرت الشاشة أو المتصفح على هذا الجهاز. يمكنك تفعيل{' '}
              <strong>وضع الأجهزة الضعيفة وويندوز 7 (Safe Lite Mode)</strong> ليعمل البرنامج بأقصى سرعة وبدون أي مؤثرات ثقيلة.
            </p>
            {this.state.errorMessage && (
              <div className="p-2 rounded-lg bg-slate-100 border border-slate-200 text-[11px] font-mono text-slate-500 dir-ltr text-left truncate">
                {this.state.errorMessage}
              </div>
            )}
            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={this.handleEnableSafeMode}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer"
              >
                ⚡ تفعيل وضع الأجهزة الضعيفة وإعادة التشغيل الآن
              </button>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="w-full py-2 px-4 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs cursor-pointer"
              >
                إعادة تحميل الصفحة
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <Win7SafeErrorBoundary>
    <App />
  </Win7SafeErrorBoundary>
);
