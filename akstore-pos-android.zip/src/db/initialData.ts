/**
 * @file db/initialData.ts
 * البيانات التجريبية الأولية لملء قاعدة البيانات عند التشغيل الأول
 * Initial Seed Data for SQLite Database
 */

import { Product, Customer, Supplier, Expense, StoreSettings, InstallmentPlan, SaleInvoice, CurrencyRate, Warehouse } from '../types';
import { AK_STORE_DEFAULT_LOGO_DATA_URL } from '../components/AKStoreLogo';

export const initialWarehouses: Warehouse[] = [
  {
    id: 'wh-main',
    name: 'المستودع الرئيسي (المركزي)',
    code: 'WH-01',
    location: 'الرياض - المستودع اللوجستي الرئيسي',
    managerName: 'أحمد سعيد القحطاني',
    phone: '0551122334',
    isDefault: true,
    notes: 'المستودع المركزي لاستقبال وتخزين شحنات المشتريات من الموردين',
    createdAt: new Date().toISOString()
  },
  {
    id: 'wh-pos',
    name: 'مستودع صالة العرض ونقطة البيع',
    code: 'WH-02',
    location: 'معرض المتجر - صالة الكاشير',
    managerName: 'خالد عبد الله',
    phone: '0559988776',
    isDefault: false,
    notes: 'مخزن صالة العرض المباشر لخدمة الكاشير والزبائن',
    createdAt: new Date().toISOString()
  },
  {
    id: 'wh-backup',
    name: 'مستودع التخزين الاحتياطي',
    code: 'WH-03',
    location: 'المنطقة الصناعية الثانية - مستودع ب-4',
    managerName: 'سلمان العتيبي',
    phone: '0554433221',
    isDefault: false,
    notes: 'مستودع البضائع الفائضة والكميات الكبيرة',
    createdAt: new Date().toISOString()
  }
];

export const defaultCurrencies: CurrencyRate[] = [
  {
    id: 'curr-egp',
    code: 'EGP',
    name: 'جنيه مصري',
    symbol: 'ج.م',
    exchangeRate: 1.0,
    isBase: true,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'curr-sar',
    code: 'SAR',
    name: 'ريال سعودي',
    symbol: 'ر.س',
    exchangeRate: 13.15, // 1 SAR = 13.15 EGP
    isBase: false,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'curr-usd',
    code: 'USD',
    name: 'دولار أمريكي',
    symbol: '$',
    exchangeRate: 49.30, // 1 USD = 49.30 EGP
    isBase: false,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'curr-eur',
    code: 'EUR',
    name: 'يورو أوروبي',
    symbol: '€',
    exchangeRate: 53.25, // 1 EUR = 53.25 EGP
    isBase: false,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'curr-aed',
    code: 'AED',
    name: 'درهم إماراتي',
    symbol: 'د.إ',
    exchangeRate: 13.42, // 1 AED = 13.42 EGP
    isBase: false,
    updatedAt: new Date().toISOString()
  },
  {
    id: 'curr-kwd',
    code: 'KWD',
    name: 'دينار كويتي',
    symbol: 'د.ك',
    exchangeRate: 161.10, // 1 KWD = 161.10 EGP
    isBase: false,
    updatedAt: new Date().toISOString()
  }
];

export const initialSettings: StoreSettings = {
  storeName: 'AK Store',
  storePhone: '01012345678',
  storeAddress: 'جمهورية مصر العربية - القاهرة - مدينة نصر',
  taxNumber: '310123456700003',
  crNumber: '1010987654',
  vatPercentage: 0,
  installmentInterestPercentage: 10,
  currency: 'EGP',
  currencySymbol: 'ج.م',
  enableMultiCurrency: true,
  baseCurrency: 'EGP',
  activeCurrency: 'EGP',
  currencies: defaultCurrencies,
  autoUpdatePricesOnRateChange: true,
  exchangeRateLogs: [],
  enableMultiWarehouse: true,
  defaultWarehouseId: 'wh-main',
  warehouses: initialWarehouses,
  printLayout: 'thermal',
  logoUrl: AK_STORE_DEFAULT_LOGO_DATA_URL,
  footerNotes: 'شكراً لزيارتكم لـ AK Store! البضاعة المباعة ترد وتستبدل خلال 7 أيام بموجب أصل الفاتورة.',
  enableZatcaQR: true,
  language: 'ar',
  selectedPrinter: 'thermal-80',
  printerCustomName: 'طابعة فواتير حرارية 80mm الافتراضية',
  autoPrintOnSale: false,
  showPrinterDialogBeforePrint: false
};

export const initialProducts: Product[] = [
  {
    id: 'prod-1',
    barcode: '628100123001',
    name: 'قهوة اسبريسو فاخرة 500 جرام',
    category: 'مشروبات',
    costPrice: 28.00,
    salePrice: 42.00,
    stock: 45,
    warehouseStock: {
      'wh-main': 30,
      'wh-pos': 15,
      'wh-backup': 0
    },
    minStockAlert: 10,
    unit: 'حبة',
    description: 'بن قهوة فاخر محمص بدرجة متوسطة',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-2',
    barcode: '628100123002',
    name: 'سماعات بلوتوث لاسلكية Pro',
    category: 'إلكترونيات',
    costPrice: 110.00,
    salePrice: 185.00,
    stock: 18,
    warehouseStock: { 'wh-main': 12, 'wh-pos': 6, 'wh-backup': 0 },
    minStockAlert: 5,
    unit: 'قطعة',
    description: 'سماعات مانعة للضوضاء وبطارية تدوم 30 ساعة',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-3',
    barcode: '628100123003',
    name: 'عطر العود الملكي 100 مل',
    category: 'عطور',
    costPrice: 95.00,
    salePrice: 190.00,
    stock: 12,
    warehouseStock: { 'wh-main': 8, 'wh-pos': 4, 'wh-backup': 0 },
    minStockAlert: 4,
    unit: 'زجاجة',
    description: 'عطر شرقي أصيل بخلاصة خشب الصندل والعود',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-4',
    barcode: '628100123004',
    name: 'زيت زيتون بكر ممتاز 1 لتر',
    category: 'غذائية',
    costPrice: 24.50,
    salePrice: 35.00,
    stock: 3, // Low stock on purpose for alert demonstration
    warehouseStock: { 'wh-main': 2, 'wh-pos': 1, 'wh-backup': 0 },
    minStockAlert: 8,
    unit: 'لتر',
    description: 'عصرة أولى على البارد طبيعي 100%',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-5',
    barcode: '628100123005',
    name: 'تيشيرت بولو قطن أسود رجالي',
    category: 'ملابس',
    costPrice: 35.00,
    salePrice: 65.00,
    stock: 25,
    warehouseStock: { 'wh-main': 15, 'wh-pos': 10, 'wh-backup': 0 },
    minStockAlert: 5,
    unit: 'قطعة',
    description: 'قطن مصري 100% عالي الجودة',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-6',
    barcode: '628100123006',
    name: 'شاحن حائط سريع 45 واط Type-C',
    category: 'إلكترونيات',
    costPrice: 32.00,
    salePrice: 59.00,
    stock: 30,
    warehouseStock: { 'wh-main': 20, 'wh-pos': 10, 'wh-backup': 0 },
    minStockAlert: 6,
    unit: 'قطعة',
    description: 'شاحن فائق السرعة يدعم كافة الأجهزة الذكية',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-7',
    barcode: '628100123007',
    name: 'عسل سدر طبيعي جبلي 500 جرام',
    category: 'غذائية',
    costPrice: 85.00,
    salePrice: 140.00,
    stock: 14,
    warehouseStock: { 'wh-main': 10, 'wh-pos': 4, 'wh-backup': 0 },
    minStockAlert: 5,
    unit: 'برطمان',
    description: 'عسل سدر بلدي نقي ومفحوص مخبرياً',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-8',
    barcode: '628100123008',
    name: 'مياه ينابيع طبيعية 330 مل (كرتون 40)',
    category: 'مشروبات',
    costPrice: 14.00,
    salePrice: 21.00,
    stock: 80,
    minStockAlert: 15,
    unit: 'كرتون',
    description: 'مياه شرب نقية ومعبأة بمواصفات عالمية',
    createdAt: new Date().toISOString()
  }
];

export const initialCustomers: Customer[] = [
  {
    id: 'cust-1',
    name: 'عبدالرحمن محمد الدوسري',
    phone: '0501112233',
    email: 'abdulrahman@example.com',
    address: 'الرياض - حي النرجس',
    balance: 1300.00,
    taxNumber: '310099887700003',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString()
  },
  {
    id: 'cust-2',
    name: 'مؤسسة الأفق للتجارة (شركة)',
    phone: '0544556677',
    email: 'info@alofoq.sa',
    address: 'جدة - طريق الملك فهد',
    balance: 1700.00,
    taxNumber: '310223344500003',
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString()
  },
  {
    id: 'cust-3',
    name: 'سارة خالد المنصور',
    phone: '0567788990',
    email: 'sara.m@example.com',
    address: 'الدمام - حي الشاطئ',
    balance: 800.00,
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString()
  },
  {
    id: 'cust-4',
    name: 'أحمد محمود الشريف',
    phone: '01098765432',
    email: 'ahmed.sharif@example.com',
    address: 'القاهرة - مدينة نصر',
    balance: 1000.00,
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString()
  },
  {
    id: 'cust-5',
    name: 'منى طارق عبد العزيز',
    phone: '01122334455',
    email: 'mona.tarek@example.com',
    address: 'الجيزة - المهندسين',
    balance: 900.00,
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString()
  }
];

export const initialSuppliers: Supplier[] = [
  {
    id: 'sup-1',
    name: 'شركة الوارد للمنتجات الغذائية',
    companyName: 'مجموعة الوارد للتجارة والتوزيع',
    phone: '0114002233',
    address: 'الرياض - المنطقة الصناعية الثانية',
    balance: 3200.00,
    taxNumber: '300123987400003',
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString()
  },
  {
    id: 'sup-2',
    name: 'مؤسسة التكنولوجيا الرقمية',
    companyName: 'تكنو برو للأجهزة الذكية',
    phone: '0126558899',
    address: 'جدة - مركز المدينة للاتصالات',
    balance: 1500.00,
    taxNumber: '300987654300003',
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString()
  }
];

export const initialExpenses: Expense[] = [
  {
    id: 'exp-1',
    title: 'فاتورة الكهرباء لشهر أكتوبر',
    category: 'فواتير ومرافق',
    amount: 650.00,
    date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
    notes: 'الشركة السعودية للكهرباء',
    recordedBy: 'admin'
  },
  {
    id: 'exp-2',
    title: 'شراء ورق طباعة فواتير حرارية (كرتون)',
    category: 'مستلزمات تشغيل',
    amount: 140.00,
    date: new Date(Date.now() - 5 * 86400000).toISOString().split('T')[0],
    notes: '50 رول مقاس 80 مم',
    recordedBy: 'admin'
  },
  {
    id: 'exp-3',
    title: 'أدوات نظافة وضيافة للمتجر',
    category: 'نثريات',
    amount: 85.00,
    date: new Date().toISOString().split('T')[0],
    notes: 'مشتريات للمحل',
    recordedBy: 'cashier'
  }
];

const makePastDateISO = (daysAgo: number, hour = 14, minute = 30): string => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
};

export const initialSales: SaleInvoice[] = [
  {
    id: 'inv-1001',
    invoiceNumber: 'INV-202610-001',
    date: makePastDateISO(6, 11, 15),
    cashierId: 'cashier',
    cashierName: 'كاشير الفرع (أحمد)',
    customerId: 'cust-1',
    customerName: 'عبدالرحمن محمد الدوسري',
    items: [
      {
        product: initialProducts[1],
        quantity: 2,
        price: 185.00,
        discount: 0,
        tax: 45.44,
        total: 370.00
      },
      {
        product: initialProducts[0],
        quantity: 3,
        price: 42.00,
        discount: 0,
        tax: 15.47,
        total: 126.00
      }
    ],
    subtotal: 435.09,
    discountTotal: 0,
    taxTotal: 60.91,
    grandTotal: 496.00,
    paidAmount: 496.00,
    changeAmount: 0.00,
    paymentMethod: 'cash',
    notes: 'مبيعات بداية الأسبوع'
  },
  {
    id: 'inv-1002',
    invoiceNumber: 'INV-202610-002',
    date: makePastDateISO(5, 16, 40),
    cashierId: 'cashier',
    cashierName: 'كاشير الفرع (أحمد)',
    customerId: 'cust-2',
    customerName: 'مؤسسة الأفق للتجارة (شركة)',
    items: [
      {
        product: initialProducts[2],
        quantity: 3,
        price: 190.00,
        discount: 20,
        tax: 67.54,
        total: 550.00
      },
      {
        product: initialProducts[5],
        quantity: 2,
        price: 59.00,
        discount: 0,
        tax: 14.49,
        total: 118.00
      }
    ],
    subtotal: 585.97,
    discountTotal: 20,
    taxTotal: 82.03,
    grandTotal: 668.00,
    paidAmount: 668.00,
    changeAmount: 0.00,
    paymentMethod: 'card',
    notes: 'توريد عطور وشواحن سريعة'
  },
  {
    id: 'inv-1003',
    invoiceNumber: 'INV-202610-003',
    date: makePastDateISO(4, 13, 20),
    cashierId: 'sara',
    cashierName: 'سارة عبد الله',
    customerId: 'cust-3',
    customerName: 'سارة خالد المنصور',
    items: [
      {
        product: initialProducts[6],
        quantity: 2,
        price: 140.00,
        discount: 0,
        tax: 34.39,
        total: 280.00
      },
      {
        product: initialProducts[4],
        quantity: 2,
        price: 65.00,
        discount: 0,
        tax: 15.96,
        total: 130.00
      }
    ],
    subtotal: 359.65,
    discountTotal: 0,
    taxTotal: 50.35,
    grandTotal: 410.00,
    paidAmount: 410.00,
    changeAmount: 0.00,
    paymentMethod: 'cash',
    notes: 'فاتورة مبيعات نقدية'
  },
  {
    id: 'inv-1004',
    invoiceNumber: 'INV-202610-004',
    date: makePastDateISO(3, 19, 10),
    cashierId: 'admin',
    cashierName: 'المدير العام',
    customerId: 'cust-1',
    customerName: 'عبدالرحمن محمد الدوسري',
    items: [
      {
        product: initialProducts[1],
        quantity: 3,
        price: 185.00,
        discount: 15,
        tax: 66.32,
        total: 540.00
      },
      {
        product: initialProducts[6],
        quantity: 2,
        price: 140.00,
        discount: 0,
        tax: 34.39,
        total: 280.00
      }
    ],
    subtotal: 719.29,
    discountTotal: 15,
    taxTotal: 100.71,
    grandTotal: 820.00,
    paidAmount: 820.00,
    changeAmount: 0.00,
    paymentMethod: 'card',
    notes: 'مبيعات المساء'
  },
  {
    id: 'inv-1005',
    invoiceNumber: 'INV-202610-005',
    date: makePastDateISO(2, 15, 45),
    cashierId: 'cashier',
    cashierName: 'كاشير الفرع (أحمد)',
    customerId: 'cust-2',
    customerName: 'مؤسسة الأفق للتجارة (شركة)',
    items: [
      {
        product: initialProducts[2],
        quantity: 2,
        price: 190.00,
        discount: 0,
        tax: 46.67,
        total: 380.00
      },
      {
        product: initialProducts[7],
        quantity: 10,
        price: 21.00,
        discount: 0,
        tax: 25.79,
        total: 210.00
      }
    ],
    subtotal: 517.54,
    discountTotal: 0,
    taxTotal: 72.46,
    grandTotal: 590.00,
    paidAmount: 590.00,
    changeAmount: 0.00,
    paymentMethod: 'cash',
    notes: 'طلبية مياه وعطور'
  },
  {
    id: 'inv-1006',
    invoiceNumber: 'INV-202610-006',
    date: makePastDateISO(1, 18, 0),
    cashierId: 'sara',
    cashierName: 'سارة عبد الله',
    customerId: 'cust-3',
    customerName: 'سارة خالد المنصور',
    items: [
      {
        product: initialProducts[1],
        quantity: 2,
        price: 185.00,
        discount: 0,
        tax: 45.44,
        total: 370.00
      },
      {
        product: initialProducts[2],
        quantity: 2,
        price: 190.00,
        discount: 10,
        tax: 45.44,
        total: 370.00
      },
      {
        product: initialProducts[0],
        quantity: 2,
        price: 42.00,
        discount: 0,
        tax: 10.32,
        total: 84.00
      }
    ],
    subtotal: 722.80,
    discountTotal: 10,
    taxTotal: 101.20,
    grandTotal: 824.00,
    paidAmount: 824.00,
    changeAmount: 0.00,
    paymentMethod: 'card',
    notes: 'مبيعات الأمس'
  },
  {
    id: 'inv-1007',
    invoiceNumber: 'INV-202610-007',
    date: makePastDateISO(0, 10, 30),
    cashierId: 'admin',
    cashierName: 'المدير العام',
    customerId: 'cust-1',
    customerName: 'عبدالرحمن محمد الدوسري',
    items: [
      {
        product: initialProducts[2],
        quantity: 2,
        price: 190.00,
        discount: 0,
        tax: 46.67,
        total: 380.00
      },
      {
        product: initialProducts[5],
        quantity: 3,
        price: 59.00,
        discount: 0,
        tax: 21.74,
        total: 177.00
      }
    ],
    subtotal: 488.59,
    discountTotal: 0,
    taxTotal: 68.41,
    grandTotal: 557.00,
    paidAmount: 557.00,
    changeAmount: 0.00,
    paymentMethod: 'cash',
    notes: 'مبيعات الفترة الصباحية اليوم'
  },
  {
    id: 'inv-1008',
    invoiceNumber: 'INV-202610-008',
    date: makePastDateISO(0, 13, 15),
    cashierId: 'cashier',
    cashierName: 'كاشير الفرع (أحمد)',
    customerId: 'cust-2',
    customerName: 'مؤسسة الأفق للتجارة (شركة)',
    items: [
      {
        product: initialProducts[1],
        quantity: 2,
        price: 185.00,
        discount: 0,
        tax: 45.44,
        total: 370.00
      },
      {
        product: initialProducts[6],
        quantity: 1,
        price: 140.00,
        discount: 0,
        tax: 17.19,
        total: 140.00
      }
    ],
    subtotal: 447.37,
    discountTotal: 0,
    taxTotal: 62.63,
    grandTotal: 510.00,
    paidAmount: 510.00,
    changeAmount: 0.00,
    paymentMethod: 'card',
    notes: 'مبيعات الظهيرة اليوم'
  }
];

const makeLocalOffsetDateStr = (daysOffset: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const initialInstallmentPlans: InstallmentPlan[] = [
  {
    id: 'plan-1',
    invoiceNumber: 'INV-202610-001',
    customerId: 'cust-3',
    customerName: 'سارة خالد المنصور',
    customerPhone: '0567788990',
    totalAmount: 2400.00,
    downPayment: 1200.00,
    remainingAmount: 1200.00,
    installmentCount: 3,
    startDate: makeLocalOffsetDateStr(-28),
    installments: [
      {
        id: 'inst-1',
        installmentNumber: 1,
        dueDate: makeLocalOffsetDateStr(-28),
        amount: 400.00,
        status: 'paid',
        paidDate: makeLocalOffsetDateStr(-27),
        paidAmount: 400.00,
        notes: 'سداد عن طريق تحويل بنكي'
      },
      {
        id: 'inst-2',
        installmentNumber: 2,
        dueDate: makeLocalOffsetDateStr(2),
        amount: 400.00,
        status: 'pending',
        notes: 'مستحق هذا الأسبوع (خلال يومين)'
      },
      {
        id: 'inst-3',
        installmentNumber: 3,
        dueDate: makeLocalOffsetDateStr(32),
        amount: 400.00,
        status: 'pending',
        notes: 'القسط النهائي'
      }
    ]
  },
  {
    id: 'plan-2',
    invoiceNumber: 'INV-202610-002',
    customerId: 'cust-1',
    customerName: 'عبدالرحمن محمد الدوسري',
    customerPhone: '0501112233',
    totalAmount: 1950.00,
    downPayment: 650.00,
    remainingAmount: 1300.00,
    installmentCount: 2,
    startDate: makeLocalOffsetDateStr(-30),
    installments: [
      {
        id: 'inst-201',
        installmentNumber: 1,
        dueDate: makeLocalOffsetDateStr(0),
        amount: 650.00,
        status: 'pending',
        notes: 'مستحق اليوم - أولوية تحصيل'
      },
      {
        id: 'inst-202',
        installmentNumber: 2,
        dueDate: makeLocalOffsetDateStr(30),
        amount: 650.00,
        status: 'pending',
        notes: 'القسط الثاني'
      }
    ]
  },
  {
    id: 'plan-3',
    invoiceNumber: 'INV-202610-004',
    customerId: 'cust-4',
    customerName: 'أحمد محمود الشريف',
    customerPhone: '01098765432',
    totalAmount: 2000.00,
    downPayment: 500.00,
    remainingAmount: 1500.00,
    installmentCount: 3,
    startDate: makeLocalOffsetDateStr(-26),
    installments: [
      {
        id: 'inst-301',
        installmentNumber: 1,
        dueDate: makeLocalOffsetDateStr(-26),
        amount: 500.00,
        status: 'paid',
        paidDate: makeLocalOffsetDateStr(-26),
        paidAmount: 500.00,
        notes: 'تم السداد نقداً بالفرع'
      },
      {
        id: 'inst-302',
        installmentNumber: 2,
        dueDate: makeLocalOffsetDateStr(4),
        amount: 500.00,
        status: 'pending',
        notes: 'مستحق خلال هذا الأسبوع (بعد 4 أيام)'
      },
      {
        id: 'inst-303',
        installmentNumber: 3,
        dueDate: makeLocalOffsetDateStr(34),
        amount: 500.00,
        status: 'pending',
        notes: 'القسط الثالث والأخير'
      }
    ]
  },
  {
    id: 'plan-4',
    invoiceNumber: 'INV-202610-005',
    customerId: 'cust-5',
    customerName: 'منى طارق عبد العزيز',
    customerPhone: '01122334455',
    totalAmount: 1350.00,
    downPayment: 450.00,
    remainingAmount: 900.00,
    installmentCount: 2,
    startDate: makeLocalOffsetDateStr(-24),
    installments: [
      {
        id: 'inst-401',
        installmentNumber: 1,
        dueDate: makeLocalOffsetDateStr(6),
        amount: 450.00,
        status: 'pending',
        notes: 'مستحق نهاية هذا الأسبوع (بعد 6 أيام)'
      },
      {
        id: 'inst-402',
        installmentNumber: 2,
        dueDate: makeLocalOffsetDateStr(36),
        amount: 450.00,
        status: 'pending',
        notes: 'القسط الثاني'
      }
    ]
  },
  {
    id: 'plan-5',
    invoiceNumber: 'INV-202610-006',
    customerId: 'cust-2',
    customerName: 'مؤسسة الأفق للتجارة (شركة)',
    customerPhone: '0544556677',
    totalAmount: 2550.00,
    downPayment: 850.00,
    remainingAmount: 1700.00,
    installmentCount: 2,
    startDate: makeLocalOffsetDateStr(-32),
    installments: [
      {
        id: 'inst-501',
        installmentNumber: 1,
        dueDate: makeLocalOffsetDateStr(-2),
        amount: 850.00,
        status: 'pending',
        notes: 'قسط متأخر منذ يومين - يرجى المتابعة'
      },
      {
        id: 'inst-502',
        installmentNumber: 2,
        dueDate: makeLocalOffsetDateStr(28),
        amount: 850.00,
        status: 'pending',
        notes: 'القسط الثاني'
      }
    ]
  }
];
