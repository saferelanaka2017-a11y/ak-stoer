/**
 * @file components/InvoicePrintModal.tsx
 * نافذة معاينة وطباعة الفواتير (إيصال حراري 80mm أو A4 رسمي) مع كود QR للفاتورة الضريبية المبسطة
 * تدعم: الطباعة الفورية المباشرة، قائمة اختيار وتعريف الطابعة، وتصدير Word (.doc) و PDF بالعربية
 */

import React, { useRef, useState } from 'react';
import { 
  Printer, 
  Download, 
  X, 
  QrCode, 
  CheckCircle2, 
  FileText, 
  Sliders, 
  Settings,
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { SaleInvoice, PrinterType } from '../types';
import { useApp } from '../contexts/AppContext';
import { 
  generateInvoicePDF, 
  generateZatcaQRString, 
  exportInvoiceToWord, 
  printInvoiceDirect 
} from '../utils/exportUtils';
import { PrinterSelectionModal } from './PrinterSelectionModal';
import { normalizeLogoForPrint } from './AKStoreLogo';

interface InvoicePrintModalProps {
  invoice: SaleInvoice;
  onClose: () => void;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({ invoice, onClose }) => {
  const { settings, formatCurrency, t, showToast, installmentPlans } = useApp();
  const [printLayout, setPrintLayout] = useState<'thermal' | 'a4'>(settings.printLayout || 'thermal');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [isPrinterModalOpen, setIsPrinterModalOpen] = useState(false);
  const printAreaRef = useRef<HTMLDivElement>(null);

  // Match installment plan if this invoice is an installment sale
  const matchedPlan = installmentPlans.find(p => p.invoiceNumber === invoice.invoiceNumber);
  const isInstallment = Boolean(invoice.hasInstallment || matchedPlan);
  const instCount = invoice.installmentCount || matchedPlan?.installmentCount || 0;
  const downPay = invoice.downPayment ?? matchedPlan?.downPayment ?? invoice.paidAmount;
  const remainingBalance =
    invoice.remainingInstallmentAmount ??
    matchedPlan?.remainingAmount ??
    Math.max(0, invoice.grandTotal - downPay);
  const monthlyAmount =
    invoice.monthlyInstallmentAmount ??
    (instCount > 0 ? Math.round((remainingBalance / instCount) * 100) / 100 : 0);
  const unpaidCredit = Math.max(0, invoice.grandTotal - invoice.paidAmount);

  // Friendly name for currently active printer
  const getPrinterLabel = (type?: PrinterType) => {
    switch (type) {
      case 'thermal-80':
        return 'طابعة حرارية (80mm)';
      case 'thermal-58':
        return 'طابعة حرارية صغيرة (58mm)';
      case 'a4-standard':
        return 'طابعة مكتبية (A4)';
      case 'system-dialog':
        return 'قائمة طابعات النظام';
      case 'pdf-export':
        return 'حفظ رقمي (PDF)';
      default:
        return 'طابعة فواتير حرارية (80mm)';
    }
  };

  // Generate ZATCA QR code payload
  const qrString = generateZatcaQRString(
    settings.storeName,
    settings.taxNumber,
    invoice.date,
    invoice.grandTotal,
    invoice.taxTotal
  );

  // Instant 1-Click Print
  const handleInstantPrint = () => {
    // If no printer is selected yet or user opted to always show selection, open selection list
    if (!settings.selectedPrinter || settings.showPrinterDialogBeforePrint) {
      setIsPrinterModalOpen(true);
      return;
    }

    try {
      showToast(`جاري إرسال الفاتورة إلى ${getPrinterLabel(settings.selectedPrinter)}...`, 'info');
      printInvoiceDirect(invoice, {
        ...settings,
        printLayout
      });
      showToast('تم إرسال أمر الطباعة الفورية بنجاح!', 'success');
    } catch (e) {
      console.warn('Direct print failed, falling back to window.print():', e);
      window.print();
    }
  };

  // Export as Word (.doc)
  const handleDownloadWord = () => {
    try {
      showToast('جاري تجهيز الفاتورة كملف Word يدعم العربية 100%...', 'info');
      exportInvoiceToWord(invoice, settings);
      showToast('تم تحميل الفاتورة بتنسيق Word (.doc) بنجاح!', 'success');
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء تصدير ملف Word', 'error');
    }
  };

  // Export as Arabic PDF
  const handleDownloadPDF = async () => {
    try {
      setIsGeneratingPDF(true);
      showToast('جاري تصدير الفاتورة بدعم كامل للغة العربية...', 'info');
      await generateInvoicePDF(invoice, settings, printAreaRef.current || undefined);
      showToast('تم تحميل ملف PDF بنجاح بحروف عربية واضحة!', 'success');
    } catch (e) {
      console.error(e);
      showToast('تم تحويل التصدير تلقائياً لضمان استلام الفاتورة', 'info');
      exportInvoiceToWord(invoice, settings);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
        <div className="neu-card rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
          {/* Modal Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/60 no-print">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center shadow-inner">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <span>معاينة وطباعة الفاتورة #{invoice.invoiceNumber}</span>
                </h3>
                <span className="text-xs text-slate-500">
                  {new Date(invoice.date).toLocaleString('ar-SA')}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Format Switcher */}
              <div className="flex items-center p-1 neu-pressed rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setPrintLayout('thermal')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    printLayout === 'thermal' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  حراري (80mm)
                </button>
                <button
                  onClick={() => setPrintLayout('a4')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    printLayout === 'a4' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  رسمي (A4)
                </button>
              </div>

              <button
                onClick={onClose}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Printer Target Bar */}
          <div className="px-6 py-2.5 bg-slate-50/80 border-b border-slate-200/60 flex items-center justify-between text-xs no-print">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">الطابعة المستهدفة:</span>
              <span className="font-bold text-slate-800 flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                {getPrinterLabel(settings.selectedPrinter)}
              </span>
              {settings.printerCustomName && (
                <span className="text-[11px] text-slate-400 hidden sm:inline">
                  ({settings.printerCustomName})
                </span>
              )}
            </div>

            <button
              onClick={() => setIsPrinterModalOpen(true)}
              className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer hover:underline text-xs"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>اختيار / تغيير الطابعة</span>
            </button>
          </div>

          {/* Scrollable Printable Receipt Content */}
          <div className="p-6 overflow-y-auto flex justify-center bg-slate-100/50 flex-1">
            <div
              ref={printAreaRef}
              id="printable-invoice"
              className={`bg-white text-slate-900 rounded-2xl shadow-sm border border-slate-200/80 transition-all ${
                printLayout === 'thermal'
                  ? 'w-[360px] p-4 text-xs font-mono space-y-3'
                  : 'w-full max-w-[560px] p-6 text-sm space-y-4 font-sans'
              }`}
            >
              {/* Receipt Header */}
              <div className="text-center space-y-1 pb-3 border-b-2 border-dashed border-slate-300">
                <div className="flex justify-center mb-2">
                  <img
                    src={normalizeLogoForPrint(settings.logoUrl)}
                    width={64}
                    height={64}
                    alt="AK Store Logo"
                    className="h-16 w-16 mx-auto rounded-xl object-contain block"
                  />
                </div>
                <h2 className="font-extrabold text-base text-slate-800 tracking-tight">
                  {settings.storeName || 'AK Store'}
                </h2>
                <p className="text-[11px] text-slate-500 font-sans">
                  {settings.storeAddress}
                </p>
                <p className="text-[11px] text-slate-500 font-sans">
                  هاتف: {settings.storePhone}
                </p>
                <div className="pt-1 flex items-center justify-center gap-1.5 text-[11px] font-semibold text-slate-700 font-sans">
                  <span>الرقم الضريبي:</span>
                  <span className="font-mono text-blue-600 font-bold">{settings.taxNumber}</span>
                </div>
                {settings.crNumber && (
                  <div className="text-[10px] text-slate-500 font-sans">
                    سجل تجاري: {settings.crNumber}
                  </div>
                )}
                <div className="inline-block mt-1 px-3 py-0.5 rounded-full bg-slate-100 border border-slate-300 text-[10px] font-bold text-slate-700 font-sans">
                  فاتورة مبيعات ضريبية مبسطة
                </div>
              </div>

              {/* Invoice Meta */}
              <div className="grid grid-cols-2 gap-1.5 text-[11px] pb-2 border-b border-dashed border-slate-300 font-sans">
                <div>
                  <span className="text-slate-500">رقم الفاتورة:</span>{' '}
                  <span className="font-bold font-mono">{invoice.invoiceNumber}</span>
                </div>
                <div className="text-left" dir="ltr">
                  <span className="font-mono text-slate-600">
                    {new Date(invoice.date).toLocaleDateString('ar-SA')}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">الكاشير:</span>{' '}
                  <span className="font-semibold">{invoice.cashierName}</span>
                </div>
                <div className="text-left">
                  <span className="text-slate-500">العميل:</span>{' '}
                  <span className="font-semibold">{invoice.customerName || 'عميل نقدي'}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500">طريقة الدفع:</span>{' '}
                  <span className="font-bold text-slate-800">
                    {isInstallment
                      ? `تقسيط (دفع مقدم والباقي أقساط على ${instCount} شهر)`
                      : invoice.paymentMethod === 'cash'
                      ? 'نقداً'
                      : invoice.paymentMethod === 'card'
                      ? 'بطاقة شبكة (مدى)'
                      : invoice.paymentMethod === 'credit'
                      ? 'آجل'
                      : 'دفعة مقدمة والباقي آجل'}
                  </span>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-1.5 font-sans">
                <div className="grid grid-cols-12 text-[10px] font-bold text-slate-500 pb-1 border-b border-slate-200">
                  <div className="col-span-6 text-right">الصنف</div>
                  <div className="col-span-2 text-center">الكمية</div>
                  <div className="col-span-2 text-center">السعر</div>
                  <div className="col-span-2 text-left">الإجمالي</div>
                </div>

                <div className="divide-y divide-slate-100 text-[11px]">
                  {invoice.items.map((item, idx) => (
                    <div key={idx} className="grid grid-cols-12 py-1 items-center">
                      <div className="col-span-6 text-right pr-1">
                        <div className="font-bold text-slate-800 truncate">{item.product.name}</div>
                        <div className="text-[9px] text-slate-400 font-mono">{item.product.barcode}</div>
                      </div>
                      <div className="col-span-2 text-center font-mono font-bold">{item.quantity}</div>
                      <div className="col-span-2 text-center font-mono text-slate-600">
                        {item.price.toFixed(2)}
                      </div>
                      <div className="col-span-2 text-left font-mono font-bold text-slate-800">
                        {item.total.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals Breakdown */}
              <div className="pt-2 border-t-2 border-dashed border-slate-300 space-y-1 text-xs font-sans">
                <div className="flex justify-between text-slate-600">
                  <span>{invoice.taxTotal > 0 ? 'المجموع الخاضع للضريبة:' : 'المجموع:'}</span>
                  <span className="font-mono">{formatCurrency(invoice.subtotal)}</span>
                </div>

                {invoice.discountTotal > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>خصم ممنوح:</span>
                    <span className="font-mono">-{formatCurrency(invoice.discountTotal)}</span>
                  </div>
                )}

                {invoice.taxTotal > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>
                      ضريبة القيمة المضافة (
                      {invoice.subtotal > 0
                        ? Math.round((invoice.taxTotal / invoice.subtotal) * 10000) / 100
                        : settings.vatPercentage}
                      %):
                    </span>
                    <span className="font-mono">{formatCurrency(invoice.taxTotal)}</span>
                  </div>
                )}

                <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-1.5 border-t border-slate-200">
                  <span>الإجمالي النهائي المستحق:</span>
                  <span className="font-mono text-blue-700 font-black">
                    {formatCurrency(invoice.grandTotal)}
                  </span>
                </div>

                {isInstallment ? (
                  <div className="mt-2 p-2.5 rounded-xl bg-amber-50/90 border-2 border-amber-300 space-y-1.5 text-[11px]">
                    <div className="font-extrabold text-amber-900 border-b border-amber-200 pb-1 flex items-center justify-between">
                      <span>تفصيل نظام السداد (تقسيط شهري):</span>
                      <span className="px-2 py-0.5 rounded-md bg-amber-200/80 text-amber-950 font-mono text-[10px]">
                        {instCount} شهر
                      </span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-700">
                      <span>إجمالي قيمة الفاتورة:</span>
                      <span className="font-mono">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-emerald-700">
                      <span>الدفعة المقدمة المدفوعة (المقدم):</span>
                      <span className="font-mono">{formatCurrency(downPay)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-red-600">
                      <span>المبلغ المتبقي للتقسيط:</span>
                      <span className="font-mono">{formatCurrency(remainingBalance)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-800">
                      <span>عدد الأقساط الشهرية:</span>
                      <span className="font-mono">{instCount} أقساط (على {instCount} شهر)</span>
                    </div>
                    {monthlyAmount > 0 && (
                      <div className="flex justify-between font-extrabold text-blue-800 pt-1 border-t border-amber-200/80">
                        <span>قيمة القسط الشهري:</span>
                        <span className="font-mono">{formatCurrency(monthlyAmount)} / شهرياً</span>
                      </div>
                    )}
                    <div className="text-[10px] font-bold text-slate-700 bg-white/80 rounded-lg px-2 py-1 border border-amber-200 text-center">
                      تم دفع مقدم ({formatCurrency(downPay)}) والباقي ({formatCurrency(remainingBalance)}) أقساط على ({instCount}) شهر
                    </div>
                  </div>
                ) : unpaidCredit > 0 && invoice.paidAmount > 0 ? (
                  <div className="mt-2 p-2.5 rounded-xl bg-purple-50/90 border-2 border-purple-300 space-y-1.5 text-[11px]">
                    <div className="font-extrabold text-purple-900 border-b border-purple-200 pb-1 flex items-center justify-between">
                      <span>تفصيل نظام السداد (دفعة مقدمة والباقي آجل):</span>
                      <span className="px-2 py-0.5 rounded-md bg-purple-200/80 text-purple-950 font-bold text-[10px]">
                        سداد جزئي
                      </span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-700">
                      <span>إجمالي قيمة الفاتورة:</span>
                      <span className="font-mono">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-emerald-700">
                      <span>المبلغ المدفوع مقدماً (المسدد الآن):</span>
                      <span className="font-mono">{formatCurrency(invoice.paidAmount)}</span>
                    </div>
                    <div className="flex justify-between font-extrabold text-red-600 pt-1 border-t border-purple-200/80">
                      <span>المبلغ المتبقي (آجل بذمة العميل):</span>
                      <span className="font-mono">{formatCurrency(unpaidCredit)}</span>
                    </div>
                    <div className="text-[10px] font-bold text-slate-700 bg-white/80 rounded-lg px-2 py-1 border border-purple-200 text-center">
                      تم سداد دفعة مقدمة ({formatCurrency(invoice.paidAmount)}) والمتبقي ({formatCurrency(unpaidCredit)}) آجل على حساب ({invoice.customerName || 'العميل'})
                    </div>
                  </div>
                ) : unpaidCredit > 0 ? (
                  <div className="mt-2 p-2.5 rounded-xl bg-red-50/90 border-2 border-red-300 space-y-1.5 text-[11px]">
                    <div className="font-extrabold text-red-900 border-b border-red-200 pb-1 flex items-center justify-between">
                      <span>تفصيل نظام السداد (بيع آجل بالكامل):</span>
                      <span className="px-2 py-0.5 rounded-md bg-red-200/80 text-red-950 font-bold text-[10px]">
                        ذمة عميل
                      </span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-700">
                      <span>إجمالي قيمة الفاتورة:</span>
                      <span className="font-mono">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-600">
                      <span>المبلغ المدفوع عند الإصدار:</span>
                      <span className="font-mono">{formatCurrency(0)}</span>
                    </div>
                    <div className="flex justify-between font-extrabold text-red-600 pt-1 border-t border-red-200/80">
                      <span>إجمالي المبلغ الآجل المستحق:</span>
                      <span className="font-mono">{formatCurrency(unpaidCredit)}</span>
                    </div>
                    <div className="text-[10px] font-bold text-slate-700 bg-white/80 rounded-lg px-2 py-1 border border-red-200 text-center">
                      فاتورة آجلة بالكامل بقيمة ({formatCurrency(unpaidCredit)}) مسجلة في ذمة ({invoice.customerName || 'العميل'})
                    </div>
                  </div>
                ) : invoice.paymentMethod === 'card' ? (
                  <div className="mt-2 p-2.5 rounded-xl bg-blue-50/90 border-2 border-blue-300 space-y-1.5 text-[11px]">
                    <div className="font-extrabold text-blue-900 border-b border-blue-200 pb-1 flex items-center justify-between">
                      <span>تفصيل نظام السداد (بطاقة شبكة / تحويل بنكي):</span>
                      <span className="px-2 py-0.5 rounded-md bg-blue-200/80 text-blue-950 font-bold text-[10px]">
                        مسددة بالكامل ✓
                      </span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-700">
                      <span>إجمالي قيمة الفاتورة:</span>
                      <span className="font-mono">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-blue-700">
                      <span>المبلغ المحصل عبر الشبكة / البنك:</span>
                      <span className="font-mono">{formatCurrency(invoice.paidAmount)}</span>
                    </div>
                    <div className="flex justify-between font-extrabold text-emerald-700 pt-1 border-t border-blue-200/80">
                      <span>المتبقي على العميل:</span>
                      <span className="font-mono">{formatCurrency(0)} (خالصة)</span>
                    </div>
                    <div className="text-[10px] font-bold text-slate-700 bg-white/80 rounded-lg px-2 py-1 border border-blue-200 text-center">
                      تم سداد كامل الفاتورة ({formatCurrency(invoice.grandTotal)}) عبر بطاقة الشبكة / البنك ولا يوجد متبقي
                    </div>
                  </div>
                ) : (
                  <div className="mt-2 p-2.5 rounded-xl bg-emerald-50/90 border-2 border-emerald-300 space-y-1.5 text-[11px]">
                    <div className="font-extrabold text-emerald-900 border-b border-emerald-200 pb-1 flex items-center justify-between">
                      <span>تفصيل نظام السداد (سداد نقدي كاش):</span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-200/80 text-emerald-950 font-bold text-[10px]">
                        مسددة نقداً ✓
                      </span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-700">
                      <span>إجمالي قيمة الفاتورة المستحقة:</span>
                      <span className="font-mono">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-emerald-700">
                      <span>المبلغ النقدي المستلم:</span>
                      <span className="font-mono">{formatCurrency(invoice.paidAmount)}</span>
                    </div>
                    {invoice.changeAmount > 0 && (
                      <div className="flex justify-between font-bold text-blue-700">
                        <span>المتبقي للعميل (الفكة):</span>
                        <span className="font-mono">{formatCurrency(invoice.changeAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-extrabold text-emerald-800 pt-1 border-t border-emerald-200/80">
                      <span>المتبقي على العميل:</span>
                      <span className="font-mono">{formatCurrency(0)} (خالصة)</span>
                    </div>
                    <div className="text-[10px] font-bold text-slate-700 bg-white/80 rounded-lg px-2 py-1 border border-emerald-200 text-center">
                      تم سداد كامل قيمة الفاتورة ({formatCurrency(invoice.grandTotal)}) نقداً بالخزينة ولا يوجد متبقي
                    </div>
                  </div>
                )}

                {invoice.notes && (
                  <div className="mt-2 p-2 rounded-xl bg-slate-50 border border-slate-200 text-[10px] text-slate-700">
                    <span className="font-bold">ملاحظات الفاتورة: </span>
                    <span>{invoice.notes}</span>
                  </div>
                )}
              </div>

              {/* ZATCA QR Code Stamp */}
              {settings.enableZatcaQR && (
                <div className="pt-3 pb-1 border-t border-dashed border-slate-300 flex flex-col items-center justify-center">
                  <div className="p-2 bg-white rounded-xl border border-slate-200 shadow-2xs">
                    <div className="w-24 h-24 flex items-center justify-center bg-slate-50 border border-dashed border-slate-300 rounded-lg">
                      <svg viewBox="0 0 100 100" className="w-20 h-20">
                        <rect x="0" y="0" width="100" height="100" fill="white" />
                        <rect x="10" y="10" width="24" height="24" fill="black" />
                        <rect x="14" y="14" width="16" height="16" fill="white" />
                        <rect x="18" y="18" width="8" height="8" fill="black" />
                        <rect x="66" y="10" width="24" height="24" fill="black" />
                        <rect x="70" y="14" width="16" height="16" fill="white" />
                        <rect x="74" y="18" width="8" height="8" fill="black" />
                        <rect x="10" y="66" width="24" height="24" fill="black" />
                        <rect x="14" y="70" width="16" height="16" fill="white" />
                        <rect x="18" y="74" width="8" height="8" fill="black" />
                        <rect x="42" y="14" width="8" height="8" fill="black" />
                        <rect x="42" y="32" width="12" height="6" fill="black" />
                        <rect x="60" y="44" width="6" height="6" fill="black" />
                        <rect x="54" y="44" width="8" height="8" fill="black" />
                        <rect x="68" y="42" width="6" height="6" fill="black" />
                        <rect x="80" y="48" width="6" height="6" fill="black" />
                        <rect x="42" y="60" width="6" height="6" fill="black" />
                        <rect x="54" y="62" width="6" height="6" fill="black" />
                        <rect x="44" y="76" width="6" height="6" fill="black" />
                        <rect x="66" y="68" width="10" height="6" fill="black" />
                        <rect x="80" y="74" width="8" height="8" fill="black" />
                        <rect x="68" y="82" width="6" height="6" fill="black" />
                      </svg>
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1 text-center">كود التحقق الإلكتروني (ZATCA)</p>
                  </div>
                </div>
              )}

              {/* Footer Policy Notes */}
              <div className="text-center text-[10px] text-slate-500 pt-2 border-t border-dashed border-slate-300">
                <p>{settings.footerNotes}</p>
                <p className="mt-1 font-mono text-[9px] text-slate-400">Powered by Soft Glass POS</p>
              </div>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="px-6 py-4 border-t border-white/60 flex items-center justify-between neu-card no-print flex-wrap gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Word Export Button */}
              <button
                type="button"
                onClick={handleDownloadWord}
                title="تصدير الفاتورة كملف Word (.doc) يفتح مباشرة في وورد بدون أي أخطاء أو رموز"
                className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-bold text-blue-700 bg-blue-50/50 hover:bg-blue-100/50 cursor-pointer border border-blue-200"
              >
                <FileText className="w-4 h-4 text-blue-600" />
                <span>تحميل Word (.doc)</span>
              </button>

              {/* PDF Export Button */}
              <button
                type="button"
                onClick={handleDownloadPDF}
                disabled={isGeneratingPDF}
                title="تحميل كملف PDF بالعربية مع دعم كامل"
                className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer disabled:opacity-50"
              >
                <Download className={`w-4 h-4 text-emerald-600 ${isGeneratingPDF ? 'animate-bounce' : ''}`} />
                <span>{isGeneratingPDF ? 'جاري التحميل...' : 'تحميل PDF'}</span>
              </button>
            </div>

            <div className="flex items-center gap-2.5">
              {/* Change Printer Button */}
              <button
                type="button"
                onClick={() => setIsPrinterModalOpen(true)}
                className="neu-button px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                title="قائمة اختيار الطابعة"
              >
                <Sliders className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">اختر الطابعة</span>
              </button>

              {/* Close Button */}
              <button
                type="button"
                onClick={onClose}
                className="neu-button px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 cursor-pointer"
              >
                إغلاق
              </button>

              {/* Instant Print Button */}
              <button
                type="button"
                onClick={handleInstantPrint}
                className="neu-button-primary px-5 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer shadow-md"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة فورية</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Printer Selection Modal */}
      <PrinterSelectionModal
        isOpen={isPrinterModalOpen}
        onClose={() => setIsPrinterModalOpen(false)}
        currentInvoice={invoice}
        onSelectAndPrint={(printerType) => {
          printInvoiceDirect(invoice, {
            ...settings,
            selectedPrinter: printerType,
            printLayout: printerType === 'a4-standard' ? 'a4' : 'thermal'
          });
        }}
      />
    </>
  );
};
