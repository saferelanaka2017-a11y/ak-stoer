/**
 * @file pages/InstallmentsPage.tsx
 * شاشة إدارة الأقساط ومتابعة مواعيد الاستحقاق والتنبيهات التلقائية مع إرسال رسائل تذكير عبر واتساب
 * Installment Plans Tracking, Automated Due Alerts Hub & WhatsApp Reminder Engine
 */

import React, { useState, useMemo } from 'react';
import {
  CalendarClock,
  AlertCircle,
  CheckCircle2,
  Clock,
  MessageCircle,
  DollarSign,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Printer,
  UserCheck,
  Percent,
  EyeOff,
  ShieldCheck,
  BellRing,
  Send,
  Calendar,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { InstallmentPlan } from '../types';
import { InstallmentReminderModal } from '../components/InstallmentReminderModal';
import { generateInstallmentSchedulePDF } from '../utils/exportUtils';
import { NumberStepperInput } from '../components/NumberStepperInput';
import { db } from '../db/database';
import {
  getApproachingInstallments,
  createWhatsAppUrl,
  generateReminderMessage,
  formatWhatsAppPhone,
  openSmartWhatsAppModal,
  ApproachingInstallment,
  AlertUrgency
} from '../utils/installmentAlerts';

export const InstallmentsPage: React.FC = () => {
  const { installmentPlans, customers, formatCurrency, refreshData, showToast, settings, t, tr, requestConfirm } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'overdue' | 'upcoming' | 'pending' | 'paid'>('all');

  // Automated Alert Threshold: Days before due date to alert
  const [alertDaysThreshold, setAlertDaysThreshold] = useState<number>(7);
  const [isAlertCenterExpanded, setIsAlertCenterExpanded] = useState<boolean>(true);
  const [alertFilterUrgency, setAlertFilterUrgency] = useState<'all' | AlertUrgency>('all');

  // Reminder / Payment Modal
  const [activePlan, setActivePlan] = useState<InstallmentPlan | null>(null);
  const [selectedInstId, setSelectedInstId] = useState<string | undefined>(undefined);

  // Add / Edit Modal State
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<InstallmentPlan | null>(null);

  // Form fields
  const [planCustomerId, setPlanCustomerId] = useState('');
  const [planInvoiceNumber, setPlanInvoiceNumber] = useState('');
  const [planOriginalAmount, setPlanOriginalAmount] = useState<number>(1000);
  const [planInterestPercent, setPlanInterestPercent] = useState<number>(settings.installmentInterestPercentage ?? 10);
  const [planDownPayment, setPlanDownPayment] = useState<number>(200);
  const [planMonths, setPlanMonths] = useState<number>(3);
  const [planStartDate, setPlanStartDate] = useState(new Date().toISOString().split('T')[0]);

  // Dynamic Interest and Totals Calculation: calculated STRICTLY from the remaining amount after down payment
  const remainingBeforeInterest = Math.max(0, planOriginalAmount - planDownPayment);

  const effectiveInterestAmount = useMemo(() => {
    return Math.round((remainingBeforeInterest * ((planInterestPercent || 0) / 100)) * 100) / 100;
  }, [remainingBeforeInterest, planInterestPercent]);

  const calculatedRemainingWithInterest = remainingBeforeInterest + effectiveInterestAmount;
  const calculatedTotalWithInterest = planDownPayment + calculatedRemainingWithInterest;
  const calculatedMonthly = planMonths > 0 ? Math.round((calculatedRemainingWithInterest / planMonths) * 100) / 100 : 0;

  const todayStr = new Date().toISOString().split('T')[0];

  // Automated Approaching Installments
  const approachingInstallments = useMemo(() => {
    return getApproachingInstallments(installmentPlans, alertDaysThreshold);
  }, [installmentPlans, alertDaysThreshold]);

  // Filtered Approaching Installments
  const filteredApproaching = useMemo(() => {
    return approachingInstallments.filter(item => {
      if (alertFilterUrgency !== 'all' && item.urgency !== alertFilterUrgency) {
        return false;
      }
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          item.customerName.toLowerCase().includes(q) ||
          item.customerPhone.includes(q) ||
          item.invoiceNumber.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [approachingInstallments, alertFilterUrgency, searchQuery]);

  // Urgency Counts
  const alertStats = useMemo(() => {
    let overdue = 0;
    let today = 0;
    let upcoming = 0;
    let totalAlertAmount = 0;

    approachingInstallments.forEach(item => {
      totalAlertAmount += item.amount;
      if (item.urgency === 'overdue') overdue++;
      else if (item.urgency === 'today') today++;
      else if (item.urgency === 'upcoming') upcoming++;
    });

    return { overdue, today, upcoming, totalAlertAmount };
  }, [approachingInstallments]);

  // Aggregated Overall Stats
  const stats = useMemo(() => {
    let totalFinanced = 0;
    let totalCollected = 0;
    let totalPending = 0;
    let overdueCount = 0;

    installmentPlans.forEach(plan => {
      totalFinanced += plan.totalAmount;
      totalCollected += plan.downPayment;

      plan.installments.forEach(inst => {
        if (inst.status === 'paid') {
          totalCollected += (inst.paidAmount || inst.amount);
        } else {
          totalPending += inst.amount;
          if (inst.dueDate < todayStr) {
            overdueCount++;
          }
        }
      });
    });

    return { totalFinanced, totalCollected, totalPending, overdueCount };
  }, [installmentPlans, todayStr]);

  // Filtered plans
  const filteredPlans = useMemo(() => {
    return installmentPlans.filter(plan => {
      const matchSearch =
        plan.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        plan.customerPhone.includes(searchQuery) ||
        plan.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchSearch) return false;

      if (statusFilter === 'all') return true;

      const hasOverdue = plan.installments.some(i => i.status === 'pending' && i.dueDate < todayStr);
      const hasUpcoming = plan.installments.some(i => {
        if (i.status === 'paid') return false;
        const diff = Math.round((new Date(i.dueDate).getTime() - new Date(todayStr).getTime()) / (1000 * 60 * 60 * 24));
        return diff >= 0 && diff <= alertDaysThreshold;
      });
      const hasPending = plan.installments.some(i => i.status === 'pending');
      const allPaid = plan.installments.every(i => i.status === 'paid');

      if (statusFilter === 'overdue') return hasOverdue;
      if (statusFilter === 'upcoming') return hasUpcoming;
      if (statusFilter === 'pending') return hasPending && !hasOverdue;
      if (statusFilter === 'paid') return allPaid;

      return true;
    });
  }, [installmentPlans, searchQuery, statusFilter, todayStr, alertDaysThreshold]);

  // Instant WhatsApp Send Action
  const handleQuickWhatsApp = (item: ApproachingInstallment) => {
    const rawPhone = item.customerPhone;
    const formatted = formatWhatsAppPhone(rawPhone);
    if (!formatted) {
      showToast('رقم هاتف العميل غير صحيح', 'error');
      return;
    }

    const msg = generateReminderMessage({
      customerName: item.customerName,
      installmentNumber: item.installment.installmentNumber,
      amount: item.amount,
      dueDate: item.dueDate,
      currencySymbol: settings.currencySymbol || 'ر.س',
      storeName: settings.storeName || 'المتجر',
      storePhone: settings.storePhone,
      daysDiff: item.daysDiff,
      templateType: item.urgency === 'overdue' ? 'overdue' : item.urgency === 'today' ? 'due_today' : 'gentle'
    });

    openSmartWhatsAppModal({
      recipientName: item.customerName,
      phone: rawPhone,
      message: msg,
      title: 'إرسال تذكير بالقسط عبر واتساب',
      subtitle: `فاتورة #${item.invoiceNumber} · القسط #${item.installment.installmentNumber}`
    });
  };

  const handleOpenReminder = (plan: InstallmentPlan, instId?: string) => {
    setActivePlan(plan);
    setSelectedInstId(instId);
  };

  const handleOpenAddPlan = () => {
    setEditingPlan(null);
    setPlanCustomerId(customers[0]?.id || '');
    setPlanInvoiceNumber(`INV-${Date.now().toString().slice(-6)}`);
    setPlanOriginalAmount(1000);
    setPlanInterestPercent(settings.installmentInterestPercentage ?? 10);
    setPlanDownPayment(200);
    setPlanMonths(3);
    setPlanStartDate(new Date().toISOString().split('T')[0]);
    setIsPlanModalOpen(true);
  };

  const handleOpenEditPlan = (plan: InstallmentPlan) => {
    setEditingPlan(plan);
    setPlanCustomerId(plan.customerId);
    setPlanInvoiceNumber(plan.invoiceNumber);
    const orig = plan.originalAmount !== undefined ? plan.originalAmount : (plan.totalAmount - (plan.interestAmount || 0));
    setPlanOriginalAmount(orig > 0 ? orig : plan.totalAmount);
    setPlanInterestPercent(plan.interestRate !== undefined ? plan.interestRate : (settings.installmentInterestPercentage ?? 10));
    setPlanDownPayment(plan.downPayment);
    setPlanMonths(plan.installmentCount);
    setPlanStartDate(plan.startDate);
    setIsPlanModalOpen(true);
  };

  const handleDeletePlan = (id: string, name: string) => {
    requestConfirm({
      title: 'حذف خطة الأقساط',
      message: `هل أنت متأكد من حذف خطة أقساط العميل "${name}" بالكامل؟`,
      confirmText: 'نعم، حذف الخطة',
      onConfirm: () => {
        db.deleteInstallmentPlan(id);
        showToast('تم حذف خطة القسط بنجاح', 'success');
        refreshData();
      }
    });
  };

  const handlePrintPlan = async (plan: InstallmentPlan) => {
    try {
      showToast(`جاري إنشاء جدول أقساط العميل ${plan.customerName} باللغة العربية...`, 'info');
      await generateInstallmentSchedulePDF(plan, settings);
      showToast(`تم تحميل جدول أقساط العميل ${plan.customerName} PDF بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء جدول الأقساط', 'error');
    }
  };

  const handleSavePlan = (e: React.FormEvent) => {
    e.preventDefault();
    const customer = customers.find(c => c.id === planCustomerId);
    if (!customer) {
      showToast('يرجى اختيار العميل', 'error');
      return;
    }

    if (planOriginalAmount <= 0) {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
      return;
    }

    const remBeforeInterest = Math.max(0, planOriginalAmount - planDownPayment);
    const effectiveInterest = Math.round((remBeforeInterest * ((planInterestPercent || 0) / 100)) * 100) / 100;
    const remainingWithInterest = remBeforeInterest + effectiveInterest;
    const totalWithInterest = planDownPayment + remainingWithInterest;
    const monthlyAmt = Math.round((remainingWithInterest / planMonths) * 100) / 100;
    const installmentsList = [];

    const start = new Date(planStartDate);
    for (let i = 1; i <= planMonths; i++) {
      const d = new Date(start);
      d.setMonth(d.getMonth() + i);
      installmentsList.push({
        id: `inst-${Date.now()}-${i}`,
        installmentNumber: i,
        dueDate: d.toISOString().split('T')[0],
        amount: i === planMonths ? remainingWithInterest - (monthlyAmt * (planMonths - 1)) : monthlyAmt,
        status: 'pending' as const
      });
    }

    if (editingPlan) {
      db.updateInstallmentPlan(editingPlan.id, {
        customerId: customer.id,
        customerName: customer.name,
        customerPhone: customer.phone,
        originalAmount: planOriginalAmount,
        interestAmount: effectiveInterest,
        interestRate: planInterestPercent,
        totalAmount: totalWithInterest,
        downPayment: planDownPayment,
        remainingAmount: remainingWithInterest,
        installmentCount: planMonths,
        startDate: planStartDate,
        installments: installmentsList
      });
      showToast('تم تحديث خطة القسط بنجاح!', 'success');
    } else {
      db.createInstallmentPlan({
        invoiceNumber: planInvoiceNumber || `INV-${Date.now().toString().slice(-6)}`,
        customerId: customer.id,
        customerName: customer.name,
        customerPhone: customer.phone,
        originalAmount: planOriginalAmount,
        interestAmount: effectiveInterest,
        interestRate: planInterestPercent,
        totalAmount: totalWithInterest,
        downPayment: planDownPayment,
        remainingAmount: remainingWithInterest,
        installmentCount: planMonths,
        startDate: planStartDate,
        installments: installmentsList
      });
      db.adjustCustomerBalance(customer.id, remainingWithInterest);
      showToast('تم إنشاء خطة أقساط جديدة بنجاح!', 'success');
    }

    refreshData();
    setIsPlanModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <CalendarClock className="w-5 h-5 text-amber-600" />
            <span>{tr('نظام تنبيهات الأقساط وإدارتها', 'Installments & Automated Alerts Hub')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('تنبيهات تلقائية عند اقتراب مواعيد السداد مع إمكانية إرسال رسائل تذكير مباشرة عبر واتساب', 'Automated due date alerts with direct one-click WhatsApp payment reminders')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAlertCenterExpanded(!isAlertCenterExpanded)}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
              isAlertCenterExpanded ? 'neu-pressed text-emerald-700 bg-emerald-50/50' : 'neu-button text-slate-700'
            }`}
          >
            <BellRing className="w-4 h-4 text-emerald-600" />
            <span>{tr('مركز التنبيهات', 'Alert Center')}</span>
            {approachingInstallments.length > 0 && (
              <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                {approachingInstallments.length}
              </span>
            )}
            {isAlertCenterExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handleOpenAddPlan}
            className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{tr('إضافة خطة تقسيط جديدة', 'Add Installment Plan')}</span>
          </button>
        </div>
      </div>

      {/* AUTOMATED ALERT CENTER (مركز التنبيهات الآلية) */}
      {isAlertCenterExpanded && (
        <div className="neu-card p-5 rounded-3xl border-2 border-emerald-400/30 bg-gradient-to-br from-white/95 to-emerald-50/20 space-y-4 shadow-lg transition-all">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-emerald-100">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
                <BellRing className="w-5 h-5 animate-bounce" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                  <span>{tr('مركز التنبيهات الآلية وسداد الأقساط', 'Automated Due Installments & WhatsApp Reminder Hub')}</span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {tr('تلقائي ومباشر', 'Live & Automated')}
                  </span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  {tr('يرصد تلقائياً الأقساط المتأخرة، المستحقة اليوم، والتي اقترب موعدها لإرسال تذكيرات واتساب بنقرة واحدة', 'Automatically detects overdue, due today, and upcoming installments for instant WhatsApp reminders')}
                </span>
              </div>
            </div>

            {/* Threshold Selector */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-600 font-semibold whitespace-nowrap">{tr('نطاق التنبيه قبل الموعد:', 'Alert Window:')}</span>
              <div className="flex p-0.5 neu-pressed rounded-xl">
                {[3, 7, 14, 30].map(days => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setAlertDaysThreshold(days)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      alertDaysThreshold === days ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    {days} {tr('أيام', 'Days')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Metrics of Approaching Installments */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              onClick={() => setAlertFilterUrgency(alertFilterUrgency === 'today' ? 'all' : 'today')}
              className={`p-3 rounded-2xl text-right transition-all cursor-pointer border ${
                alertFilterUrgency === 'today'
                  ? 'border-amber-400 bg-amber-50 shadow-inner'
                  : 'border-amber-200/60 bg-amber-50/40 hover:bg-amber-50/80'
              }`}
            >
              <div className="flex items-center justify-between text-amber-800 text-xs font-bold mb-1">
                <span>مستحق اليوم</span>
                <Clock className="w-3.5 h-3.5 text-amber-600" />
              </div>
              <div className="text-xl font-black text-amber-900 tabular-nums">
                {alertStats.today} <span className="text-xs font-normal">أقساط</span>
              </div>
            </button>

            <button
              onClick={() => setAlertFilterUrgency(alertFilterUrgency === 'upcoming' ? 'all' : 'upcoming')}
              className={`p-3 rounded-2xl text-right transition-all cursor-pointer border ${
                alertFilterUrgency === 'upcoming'
                  ? 'border-blue-400 bg-blue-50 shadow-inner'
                  : 'border-blue-200/60 bg-blue-50/40 hover:bg-blue-50/80'
              }`}
            >
              <div className="flex items-center justify-between text-blue-800 text-xs font-bold mb-1">
                <span>يقترب موعدها (≤ {alertDaysThreshold} أيام)</span>
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <div className="text-xl font-black text-blue-900 tabular-nums">
                {alertStats.upcoming} <span className="text-xs font-normal">أقساط</span>
              </div>
            </button>

            <button
              onClick={() => setAlertFilterUrgency(alertFilterUrgency === 'overdue' ? 'all' : 'overdue')}
              className={`p-3 rounded-2xl text-right transition-all cursor-pointer border ${
                alertFilterUrgency === 'overdue'
                  ? 'border-red-400 bg-red-50 shadow-inner'
                  : 'border-red-200/60 bg-red-50/40 hover:bg-red-50/80'
              }`}
            >
              <div className="flex items-center justify-between text-red-800 text-xs font-bold mb-1">
                <span>متأخرة عن موعدها</span>
                <AlertCircle className="w-3.5 h-3.5 text-red-600" />
              </div>
              <div className="text-xl font-black text-red-900 tabular-nums">
                {alertStats.overdue} <span className="text-xs font-normal">أقساط</span>
              </div>
            </button>

            <div className="p-3 rounded-2xl border border-emerald-200/60 bg-emerald-50/40">
              <div className="flex items-center justify-between text-emerald-800 text-xs font-bold mb-1">
                <span>إجمالي مبالغ التنبيهات</span>
                <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              </div>
              <div className="text-lg font-black text-emerald-900 tabular-nums">
                {formatCurrency(alertStats.totalAlertAmount)}
              </div>
            </div>
          </div>

          {/* List of Approaching Installments */}
          {filteredApproaching.length > 0 ? (
            <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
              {filteredApproaching.map((item) => {
                const plan = installmentPlans.find(p => p.id === item.planId);
                const isOverdue = item.urgency === 'overdue';
                const isToday = item.urgency === 'today';

                return (
                  <div
                    key={`${item.planId}-${item.installment.id}`}
                    className={`p-3.5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-3 border transition-all ${
                      isOverdue
                        ? 'bg-red-50/50 border-red-200'
                        : isToday
                        ? 'bg-amber-50/60 border-amber-200'
                        : 'bg-white border-slate-200/80'
                    }`}
                  >
                    {/* Customer & Installment Info */}
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-xs font-black shadow-xs ${
                          isOverdue
                            ? 'bg-red-100 text-red-700'
                            : isToday
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        #{item.installment.installmentNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-800 text-xs">
                            {item.customerName}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isOverdue
                                ? 'bg-red-200/80 text-red-800'
                                : isToday
                                ? 'bg-amber-200/80 text-amber-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {isOverdue
                              ? `متأخر بـ ${Math.abs(item.daysDiff)} يوم`
                              : isToday
                              ? 'يستحق اليوم!'
                              : item.daysDiff === 1
                              ? 'يستحق غداً'
                              : item.daysDiff === 2
                              ? 'يستحق بعد يومين'
                              : `يستحق خلال ${item.daysDiff} أيام`}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          هاتف: {item.customerPhone} · فاتورة #{item.invoiceNumber} · الاستحقاق: <strong className="text-slate-700">{item.dueDate}</strong>
                        </div>
                      </div>
                    </div>

                    {/* Amount & Actions */}
                    <div className="flex items-center justify-between md:justify-end gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-slate-200/60">
                      <div className="text-right md:text-left">
                        <span className="text-[10px] text-slate-400 block">المبلغ:</span>
                        <span className="font-black text-slate-900 text-sm tabular-nums">
                          {formatCurrency(item.amount)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* 1-Click Instant WhatsApp Button */}
                        <button
                          type="button"
                          onClick={() => handleQuickWhatsApp(item)}
                          className="neu-button-emerald px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs hover:scale-102 transition-transform"
                          title="إرسال تذكير واتساب فوري بنص النموذج المجهز"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>تذكير واتساب فوري</span>
                        </button>

                        {/* Open Custom Reminder Modal */}
                        {plan && (
                          <button
                            type="button"
                            onClick={() => handleOpenReminder(plan, item.installment.id)}
                            className="neu-button px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-700 hover:text-blue-600 cursor-pointer"
                            title="تعديل النص أو تسجيل السداد"
                          >
                            <span>تخصيص / سداد</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-500 neu-pressed rounded-2xl bg-white/60">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1.5" />
              <span>لا توجد أي أقساط متأخرة أو قادمة خلال {alertDaysThreshold} أيام القادمة بحسب المعايير المحددة. جميع الحسابات منتظمة!</span>
            </div>
          )}
        </div>
      )}

      {/* General KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">إجمالي التمويل بالتقسيط</span>
          <span className="text-xl font-black text-slate-800 tabular-nums">
            {formatCurrency(stats.totalFinanced)}
          </span>
        </div>
        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">المبالغ المحصلة</span>
          <span className="text-xl font-black text-emerald-600 tabular-nums">
            {formatCurrency(stats.totalCollected)}
          </span>
        </div>
        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">المبالغ المتبقية للتحصيل</span>
          <span className="text-xl font-black text-blue-600 tabular-nums">
            {formatCurrency(stats.totalPending)}
          </span>
        </div>
        <div className="neu-card p-4 rounded-3xl">
          <span className="text-xs text-slate-500 font-medium block mb-1">أقساط متأخرة عن موعدها</span>
          <span className={`text-xl font-black tabular-nums ${stats.overdueCount > 0 ? 'text-red-500' : 'text-slate-700'}`}>
            {stats.overdueCount} أقساط
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="neu-card p-4 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex p-1 neu-pressed rounded-2xl w-full sm:w-auto overflow-x-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            الكل ({installmentPlans.length})
          </button>
          <button
            onClick={() => setStatusFilter('overdue')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'overdue' ? 'bg-white text-red-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            المتأخرة
          </button>
          <button
            onClick={() => setStatusFilter('upcoming')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'upcoming' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            اقترب موعدها ({alertStats.upcoming + alertStats.today})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'pending' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            السارية
          </button>
          <button
            onClick={() => setStatusFilter('paid')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'paid' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            المكتملة
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالعميل، الهاتف، أو الفاتورة..."
            className="neu-input w-full pl-4 pr-10 py-2 rounded-xl text-xs"
          />
          <Search className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
        </div>
      </div>

      {/* Plans List */}
      <div className="space-y-4">
        {filteredPlans.map(plan => {
          const allPaid = plan.installments.every(i => i.status === 'paid');
          return (
            <div key={plan.id} className="neu-card p-5 rounded-3xl space-y-4">
              {/* Plan Header */}
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-3 border-b border-white/60">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-800 text-sm">{plan.customerName}</h3>
                    {allPaid ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                        مكتمل السداد
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">
                        ساري ({plan.installmentCount} أقساط)
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-500 font-mono">
                    هاتف: {plan.customerPhone} · فاتورة #{plan.invoiceNumber}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-left ml-3">
                    <span className="text-xs text-slate-500 block">إجمالي التقسيط:</span>
                    <span className="font-black text-slate-800 text-sm tabular-nums">
                      {formatCurrency(plan.totalAmount)}
                    </span>
                    {plan.interestAmount && plan.interestAmount > 0 ? (
                      <div className="text-[10px] text-amber-700 font-bold flex items-center gap-1 justify-end">
                        <EyeOff className="w-2.5 h-2.5 text-amber-600" />
                        <span>فائدة: +{formatCurrency(plan.interestAmount)} (مخفية)</span>
                      </div>
                    ) : null}
                  </div>

                  <button
                    onClick={() => handlePrintPlan(plan)}
                    className="neu-button p-2 rounded-xl text-blue-600 hover:text-blue-700 cursor-pointer"
                    title="طباعة جدول الأقساط"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleOpenEditPlan(plan)}
                    className="neu-button p-2 rounded-xl text-slate-600 hover:text-blue-600 cursor-pointer"
                    title="تعديل خطة القسط"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeletePlan(plan.id, plan.customerName)}
                    className="neu-button p-2 rounded-xl text-slate-400 hover:text-red-500 cursor-pointer"
                    title="حذف خطة القسط"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Installments Breakdown Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {plan.installments.map(inst => {
                  const isPaid = inst.status === 'paid';
                  const isOverdue = !isPaid && inst.dueDate < todayStr;
                  const isToday = !isPaid && inst.dueDate === todayStr;

                  return (
                    <div
                      key={inst.id}
                      className={`p-3 rounded-2xl flex flex-col justify-between text-xs transition-all ${
                        isPaid
                          ? 'neu-pressed border-emerald-300'
                          : isOverdue
                          ? 'neu-flat border-red-300 bg-red-50/20'
                          : isToday
                          ? 'neu-flat border-amber-300 bg-amber-50/20'
                          : 'neu-flat'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-slate-800">قسط #{inst.installmentNumber}</span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              isPaid
                                ? 'bg-emerald-100 text-emerald-700'
                                : isOverdue
                                ? 'bg-red-100 text-red-600'
                                : isToday
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {isPaid ? 'تم السداد' : isOverdue ? 'متأخر' : isToday ? 'مستحق اليوم' : 'مستحق'}
                          </span>
                        </div>
                        <div className="text-slate-500 text-[11px]">
                          الاستحقاق: <span className="font-semibold tabular-nums text-slate-700">{inst.dueDate}</span>
                        </div>
                        <div className="font-extrabold text-blue-700 text-sm mt-1 tabular-nums">
                          {formatCurrency(inst.amount)}
                        </div>
                      </div>

                      {/* Action buttons */}
                      {!isPaid && (
                        <div className="flex gap-1.5 mt-3 pt-2 border-t border-slate-200/50">
                          <button
                            type="button"
                            onClick={() => handleOpenReminder(plan, inst.id)}
                            className="neu-button flex-1 py-1 rounded-lg text-[10px] font-bold text-slate-700 flex items-center justify-center gap-1 cursor-pointer hover:text-emerald-700"
                            title="إرسال تذكير واتساب أو رسالة"
                          >
                            <MessageCircle className="w-3 h-3 text-emerald-600" />
                            <span>تذكير واتساب</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenReminder(plan, inst.id)}
                            className="neu-button-emerald flex-1 py-1 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                            title="تسجيل سداد القسط"
                          >
                            <DollarSign className="w-3 h-3" />
                            <span>سداد</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

        {filteredPlans.length === 0 && (
          <div className="neu-card p-12 text-center text-xs text-slate-400 rounded-3xl">
            لا توجد خطط أقساط مسجلة تطابق بحثك. اضغط على "إضافة خطة تقسيط جديدة" للبدء.
          </div>
        )}
      </div>

      {/* Add / Edit Installment Plan Modal */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 shadow-2xl my-6">
            <h3 className="font-bold text-slate-800 text-sm mb-4">
              {editingPlan ? 'تعديل خطة التقسيط' : 'إنشاء خطة تقسيط جديدة'}
            </h3>
            <form onSubmit={handleSavePlan} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">العميل:</label>
                <select
                  value={planCustomerId}
                  onChange={(e) => setPlanCustomerId(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                >
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold block mb-1">رقم الفاتورة المرتبطة:</label>
                <input
                  type="text"
                  value={planInvoiceNumber}
                  onChange={(e) => setPlanInvoiceNumber(e.target.value)}
                  className="neu-input w-full px-3 py-2 rounded-xl font-mono"
                  placeholder="INV-..."
                />
              </div>

              {/* Principal Amount (قيمة الفاتورة بدون الفائدة) */}
              <div>
                <label className="font-semibold block mb-1 text-slate-800">
                  المبلغ الأساسي (قيمة الفاتورة بدون فوائد):
                </label>
                <div className="relative">
                  <NumberStepperInput
                    value={planOriginalAmount}
                    onChange={(val) => setPlanOriginalAmount(val)}
                    step={50}
                    min={0}
                    fallbackOnBlur={0}
                    size="md"
                    placeholder="1000"
                    inputClassName="text-center text-slate-800"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  هذا هو المبلغ الأصلي للمبيعات الذي يظهر في الفاتورة الرسمية للعميل ({settings.currencySymbol})
                </p>
              </div>

              {/* Down Payment */}
              <div>
                <label className="font-semibold block mb-1 text-slate-800">الدفعة المقدمة (إن وجدت):</label>
                <div className="relative">
                  <NumberStepperInput
                    value={planDownPayment}
                    onChange={(val) => setPlanDownPayment(val)}
                    step={50}
                    min={0}
                    max={planOriginalAmount || undefined}
                    fallbackOnBlur={0}
                    size="md"
                    placeholder="0"
                    inputClassName="text-center"
                  />
                </div>
              </div>

              {/* Interest Field */}
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-300/70 space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-amber-900 text-xs flex items-center gap-1.5">
                    <Percent className="w-4 h-4 text-amber-600" />
                    <span>نسبة فائدة التقسيط (%):</span>
                  </label>
                  <span className="text-[11px] text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded-lg font-bold">
                    الإعدادات الافتراضية: {settings.installmentInterestPercentage ?? 10}%
                  </span>
                </div>

                <div className="relative">
                  <NumberStepperInput
                    value={planInterestPercent}
                    onChange={(val) => setPlanInterestPercent(val)}
                    step={1}
                    min={0}
                    max={100}
                    fallbackOnBlur={0}
                    size="md"
                    placeholder="10"
                    className="bg-white/90"
                    inputClassName="text-center text-amber-800 text-sm"
                  />
                </div>

                {/* Calculation Detail on Remaining Amount */}
                <div className="text-[11px] text-amber-900 space-y-1 bg-amber-50/90 p-2.5 rounded-xl border border-amber-200/70">
                  <div className="flex justify-between font-semibold">
                    <span>المبلغ الباقي بعد المقدم ({formatCurrency(planOriginalAmount)} - {formatCurrency(planDownPayment)}):</span>
                    <span className="tabular-nums font-bold text-slate-800">{formatCurrency(remainingBeforeInterest)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-amber-900 pt-1 border-t border-amber-200">
                    <span>قيمة الفائدة المحسوبة من الباقي فقط ({planInterestPercent}%):</span>
                    <span className="tabular-nums font-black text-amber-700">+{formatCurrency(effectiveInterestAmount)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-[10px] text-emerald-800 bg-emerald-50/90 px-2.5 py-1.5 rounded-xl border border-emerald-200">
                  <EyeOff className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="font-semibold">
                    مضمون: الفائدة تحتسب بالنسبة من المبلغ الباقي فقط، وتوزع على الأقساط ولا تظهر إطلاقاً في فاتورة العميل.
                  </span>
                </div>
              </div>

              {/* Installment Months & Start Date */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold block mb-1">عدد الأشهر / الأقساط:</label>
                  <select
                    value={planMonths}
                    onChange={(e) => setPlanMonths(parseInt(e.target.value) || 3)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold"
                  >
                    <option value={2}>شهرين</option>
                    <option value={3}>3 أشهر</option>
                    <option value={4}>4 أشهر</option>
                    <option value={6}>6 أشهر</option>
                    <option value={10}>10 أشهر</option>
                    <option value={12}>12 شهراً</option>
                    <option value={24}>24 شهراً</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold block mb-1">تاريخ البدء:</label>
                  <input
                    type="date"
                    value={planStartDate}
                    onChange={(e) => setPlanStartDate(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl"
                  />
                </div>
              </div>

              {/* Complete Financial Breakdown Summary */}
              <div className="p-3.5 neu-flat rounded-2xl space-y-1.5 text-xs text-slate-700 border border-slate-200/80">
                <div className="flex justify-between">
                  <span>المبلغ الأساسي (المسجل بالفاتورة):</span>
                  <span className="font-bold tabular-nums">{formatCurrency(planOriginalAmount)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>- الدفعة المقدمة:</span>
                  <span className="tabular-nums font-semibold">-{formatCurrency(planDownPayment)}</span>
                </div>
                <div className="flex justify-between text-slate-800 font-semibold pt-1 border-t border-slate-200">
                  <span>المبلغ الباقي قبل الفائدة:</span>
                  <span className="tabular-nums font-bold">{formatCurrency(remainingBeforeInterest)}</span>
                </div>
                {effectiveInterestAmount > 0 && (
                  <div className="flex justify-between text-amber-700 font-bold">
                    <span>+ فائدة التقسيط ({planInterestPercent}% من الباقي):</span>
                    <span className="tabular-nums font-black">+{formatCurrency(effectiveInterestAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-emerald-700 font-black pt-1 border-t border-slate-200 text-sm">
                  <span>إجمالي المتبقي المقسط ({planMonths} أشهر):</span>
                  <span className="tabular-nums">{formatCurrency(calculatedRemainingWithInterest)}</span>
                </div>
                <div className="flex justify-between text-slate-900 font-extrabold text-xs">
                  <span>إجمالي التمويل الكامل:</span>
                  <span className="tabular-nums text-blue-700">{formatCurrency(calculatedTotalWithInterest)}</span>
                </div>
                <div className="flex justify-between text-blue-700 font-black bg-blue-50/80 p-2.5 rounded-xl mt-1">
                  <span>القسط الشهري المطلوب:</span>
                  <span className="tabular-nums text-sm">{formatCurrency(calculatedMonthly)} / شهر</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsPlanModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  {editingPlan ? 'حفظ التعديلات' : 'إنشاء الخطة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reminder & Payment Modal */}
      {activePlan && (
        <InstallmentReminderModal
          plan={activePlan}
          selectedInstallmentId={selectedInstId}
          onClose={() => setActivePlan(null)}
          onSuccess={() => {
            refreshData();
            setActivePlan(null);
          }}
        />
      )}
    </div>
  );
};
