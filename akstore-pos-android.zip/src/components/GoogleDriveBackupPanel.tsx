/**
 * @file components/GoogleDriveBackupPanel.tsx
 * لوحة النسخ الاحتياطي السحابي واسترجاع قاعدة البيانات عبر Google Drive API (للأدمن فقط)
 * Admin-Only Cloud Database Backup & Restore Panel powered by Google Drive API
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Cloud,
  CloudUpload,
  RefreshCw,
  Download,
  Trash2,
  ExternalLink,
  CheckCircle2,
  LogOut,
  FileText,
  ShieldCheck,
  Clock,
  FolderOpen
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  initGoogleDriveAuth,
  googleSignInForDrive,
  googleSignOutFromDrive,
  getDriveAccessToken,
  listGoogleDriveBackups,
  uploadDatabaseToGoogleDrive,
  overwriteGoogleDriveBackupFile,
  downloadGoogleDriveBackupFile,
  deleteGoogleDriveBackupFile,
  DriveBackupFile
} from '../utils/googleDriveBackup';
import { useApp } from '../contexts/AppContext';
import { db } from '../db/database';

export const GoogleDriveBackupPanel: React.FC = () => {
  const { settings, showToast, refreshData, requestConfirm, tr } = useApp();

  const [needsAuth, setNeedsAuth] = useState<boolean>(true);
  const [driveUser, setDriveUser] = useState<FirebaseUser | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);
  const [isLoadingFiles, setIsLoadingFiles] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [activeActionFileId, setActiveActionFileId] = useState<string | null>(null);
  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [customBackupNote, setCustomBackupNote] = useState<string>('');

  const fetchBackupsList = useCallback(async () => {
    const token = await getDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }

    setIsLoadingFiles(true);
    try {
      const files = await listGoogleDriveBackups();
      setDriveFiles(files);
      setNeedsAuth(false);
    } catch (err: any) {
      if (err?.message === 'UNAUTHENTICATED') {
        setNeedsAuth(true);
      } else {
        console.error('Error listing Google Drive backups:', err);
        showToast(
          tr('تعذر جلب قائمة النسخ الاحتياطية من Google Drive', 'Could not load backups from Google Drive'),
          'error'
        );
      }
    } finally {
      setIsLoadingFiles(false);
    }
  }, [showToast, tr]);

  useEffect(() => {
    const unsubscribe = initGoogleDriveAuth(
      (user) => {
        setDriveUser(user);
        setNeedsAuth(false);
        fetchBackupsList();
      },
      (user) => {
        setDriveUser(user || null);
        setNeedsAuth(true);
        setDriveFiles([]);
      }
    );
    return () => unsubscribe();
  }, [fetchBackupsList]);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignInForDrive();
      if (result) {
        setDriveUser(result.user);
        setNeedsAuth(false);
        showToast(
          tr(
            `تم ربط حساب Google Drive بنجاح (${result.user.email || result.user.displayName})`,
            `Connected to Google Drive (${result.user.email || result.user.displayName})`
          ),
          'success'
        );
        await fetchBackupsList();
      }
    } catch (err: any) {
      console.error('Google Sign-In failed:', err);
      showToast(
        tr('تم إلغاء أو تعذر تسجيل الدخول إلى Google Drive', 'Google Drive sign-in was cancelled or failed'),
        'error'
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await googleSignOutFromDrive();
      setDriveUser(null);
      setNeedsAuth(true);
      setDriveFiles([]);
      showToast(
        tr('تم فصل حساب Google Drive بنجاح', 'Disconnected from Google Drive'),
        'info'
      );
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const getCurrentDatabaseSerialized = async (): Promise<string> => {
    const raw = localStorage.getItem('offline_pos_sqlite_db');
    if (raw) return raw;
    const blob = db.exportDatabaseFile();
    return await blob.text();
  };

  const handleUploadNewBackup = async () => {
    const token = await getDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      showToast(
        tr('يرجى تسجيل الدخول إلى Google Drive أولاً', 'Please sign in with Google first'),
        'error'
      );
      return;
    }

    setIsUploading(true);
    try {
      const dbContent = await getCurrentDatabaseSerialized();
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = now.toTimeString().slice(0, 5).replace(':', '-');
      const noteSlug = customBackupNote.trim()
        ? `_${customBackupNote.trim().replace(/\s+/g, '_')}`
        : '';
      const fileName = `AK_Store_Backup_${dateStr}_${timeStr}${noteSlug}.db`;

      const uploaded = await uploadDatabaseToGoogleDrive(
        dbContent,
        settings.storeName || 'AK Store',
        fileName
      );

      setCustomBackupNote('');
      showToast(
        tr(
          `تم رفع النسخة الاحتياطية (${uploaded.name}) إلى Google Drive بنجاح!`,
          `Backup (${uploaded.name}) uploaded to Google Drive successfully!`
        ),
        'success'
      );
      await fetchBackupsList();
    } catch (err: any) {
      if (err?.message === 'UNAUTHENTICATED') {
        setNeedsAuth(true);
      }
      showToast(
        tr('فشل رفع النسخة الاحتياطية إلى Google Drive', 'Failed to upload backup to Google Drive'),
        'error'
      );
    } finally {
      setIsUploading(false);
    }
  };

  // Overwrite existing file on Google Drive (MANDATORY explicit confirmation dialog)
  const handleOverwriteBackup = (file: DriveBackupFile) => {
    requestConfirm({
      title: tr('تأكيد تحديث واستبدال ملف على Google Drive', 'Confirm Overwriting File on Google Drive'),
      message: tr(
        `هل أنت متأكد من رغبتك في استبدال وتحديث محتوى ملف النسخة الاحتياطية "${file.name}" على حسابك في Google Drive بالبيانات الحالية للنظام؟ لا يمكن التراجع عن هذا التعديل.`,
        `Are you sure you want to overwrite the contents of "${file.name}" on your Google Drive with the current database? This action cannot be undone.`
      ),
      confirmText: tr('نعم، تحديث الملف على Google Drive', 'Yes, Overwrite File'),
      cancelText: tr('إلغاء', 'Cancel'),
      isDestructive: true,
      onConfirm: async () => {
        setActiveActionFileId(file.id);
        try {
          const dbContent = await getCurrentDatabaseSerialized();
          await overwriteGoogleDriveBackupFile(file.id, dbContent);
          showToast(
            tr(
              `تم تحديث ملف النسخة الاحتياطية "${file.name}" على Google Drive بنجاح!`,
              `Updated "${file.name}" on Google Drive successfully!`
            ),
            'success'
          );
          await fetchBackupsList();
        } catch (err: any) {
          if (err?.message === 'UNAUTHENTICATED') setNeedsAuth(true);
          showToast(
            tr('تعذر تحديث الملف على Google Drive', 'Failed to update file on Google Drive'),
            'error'
          );
        } finally {
          setActiveActionFileId(null);
        }
      }
    });
  };

  // Restore database from Google Drive backup
  const handleRestoreFromDrive = (file: DriveBackupFile) => {
    requestConfirm({
      title: tr('استرجاع قاعدة البيانات من Google Drive', 'Restore Database from Google Drive'),
      message: tr(
        `هل أنت متأكد من استرجاع النسخة الاحتياطية "${file.name}" من Google Drive؟ سيتم استبدال البيانات المحلية الحالية ببيانات هذه النسخة الاحتياطية.`,
        `Are you sure you want to restore "${file.name}" from Google Drive? Current local data will be replaced with this backup.`
      ),
      confirmText: tr('نعم، استرجاع البيانات الآن', 'Yes, Restore Now'),
      cancelText: tr('إلغاء', 'Cancel'),
      isDestructive: true,
      onConfirm: async () => {
        setActiveActionFileId(file.id);
        try {
          const content = await downloadGoogleDriveBackupFile(file.id);
          const success = db.importDatabaseFile(content);
          if (success) {
            refreshData();
            showToast(
              tr(
                `تم استرجاع قاعدة البيانات من "${file.name}" عبر Google Drive بنجاح!`,
                `Database restored from "${file.name}" successfully!`
              ),
              'success'
            );
          } else {
            showToast(
              tr('ملف النسخة الاحتياطية المسترجع غير صالح', 'Downloaded backup file is invalid'),
              'error'
            );
          }
        } catch (err: any) {
          if (err?.message === 'UNAUTHENTICATED') setNeedsAuth(true);
          showToast(
            tr('فشل تحميل النسخة الاحتياطية من Google Drive', 'Failed to download backup from Google Drive'),
            'error'
          );
        } finally {
          setActiveActionFileId(null);
        }
      }
    });
  };

  // Delete backup file from Google Drive (MANDATORY explicit confirmation dialog)
  const handleDeleteFromDrive = (file: DriveBackupFile) => {
    requestConfirm({
      title: tr('حذف نسخة احتياطية من Google Drive', 'Delete Backup File from Google Drive'),
      message: tr(
        `هل أنت متأكد من حذف ملف النسخة الاحتياطية "${file.name}" نهائياً من حسابك في Google Drive؟ لا يمكن التراجع عن هذا الإجراء.`,
        `Are you sure you want to permanently delete "${file.name}" from your Google Drive? This action cannot be undone.`
      ),
      confirmText: tr('نعم، حذف من Google Drive', 'Yes, Delete File'),
      cancelText: tr('إلغاء', 'Cancel'),
      isDestructive: true,
      onConfirm: async () => {
        setActiveActionFileId(file.id);
        try {
          await deleteGoogleDriveBackupFile(file.id);
          setDriveFiles((prev) => prev.filter((f) => f.id !== file.id));
          showToast(
            tr(
              `تم حذف الملف "${file.name}" من Google Drive بنجاح`,
              `Deleted "${file.name}" from Google Drive`
            ),
            'success'
          );
        } catch (err: any) {
          if (err?.message === 'UNAUTHENTICATED') setNeedsAuth(true);
          showToast(
            tr('فشل حذف الملف من Google Drive', 'Failed to delete file from Google Drive'),
            'error'
          );
        } finally {
          setActiveActionFileId(null);
        }
      }
    });
  };

  const formatFileSize = (bytesStr?: string) => {
    if (!bytesStr) return '—';
    const bytes = parseInt(bytesStr, 10);
    if (isNaN(bytes)) return '—';
    if (bytes < 1024) return `${bytes} B`;
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    return `${(kb / 1024).toFixed(2)} MB`;
  };

  return (
    <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-blue-50/70 via-white to-emerald-50/60 border border-blue-200/90 space-y-4 mt-3">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/70 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-black text-slate-800 text-xs sm:text-sm">
                {tr(
                  'النسخ الاحتياطي السحابي عبر Google Drive API (حماية البيانات ضد تعطل الجهاز)',
                  'Google Drive Cloud Backup & Restore (Hardware Failure Protection)'
                )}
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>{tr('خاص بالأدمن فقط', 'Admin Only')}</span>
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {tr(
                'ارفع نسخة احتياطية كاملة من قاعدة البيانات (الأصناف، الفواتير، العملاء، الأقساط) إلى مجلد "AK Store Backups" في حسابك على Google Drive واسترجعها في أي وقت ومن أي جهاز.',
                'Upload full database backups directly to the "AK Store Backups" folder in your Google Drive and restore them anytime.'
              )}
            </p>
          </div>
        </div>

        {/* Connected User Status or Sign In with Google Button */}
        {!needsAuth && driveUser ? (
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-2xl border border-slate-200 shadow-2xs shrink-0">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <div className="text-[11px]">
              <span className="font-bold text-slate-800 block leading-tight">
                {driveUser.displayName || tr('حساب Google متصل', 'Connected Google Account')}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">{driveUser.email}</span>
            </div>
            <button
              type="button"
              onClick={handleGoogleLogout}
              title={tr('تسجيل الخروج وفصل Google Drive', 'Disconnect Google Drive')}
              className="p-1.5 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : null}
      </div>

      {/* Authentication Prompt when not signed in or token expired */}
      {needsAuth ? (
        <div className="p-5 rounded-2xl bg-white/90 border border-slate-200/90 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-right">
            <div className="font-bold text-slate-800 text-xs sm:text-sm">
              {tr(
                'اربط حسابك في Google Drive لتفعيل النسخ الاحتياطي السحابي الفوري',
                'Sign in with Google to enable instant Google Drive cloud backups'
              )}
            </div>
            <p className="text-[11px] text-slate-500">
              {tr(
                'لا يصل النظام إلا لملفات النسخ الاحتياطي التي ينشئها التطبيق فقط داخل مجلد AK Store Backups.',
                'The app only accesses backup files it creates inside the AK Store Backups folder.'
              )}
            </p>
          </div>

          {/* Official Google Material Sign-In Button */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoggingIn}
            className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-800 font-bold text-xs border border-slate-300 shadow-sm flex items-center gap-2.5 cursor-pointer transition-all shrink-0 disabled:opacity-60"
          >
            <div className="w-4 h-4 shrink-0">
              <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                className="w-full h-full block"
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
                <path fill="none" d="M0 0h48v48H0z" />
              </svg>
            </div>
            <span>
              {isLoggingIn
                ? tr('جاري الاتصال بـ Google Drive...', 'Connecting to Google Drive...')
                : tr('Sign in with Google (ربط Google Drive)', 'Sign in with Google')}
            </span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Upload New Cloud Backup Row */}
          <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex-1">
              <input
                type="text"
                value={customBackupNote}
                onChange={(e) => setCustomBackupNote(e.target.value)}
                placeholder={tr(
                  'ملاحظة اختيارية لاسم النسخة (مثال: جرد_نهاية_الشهر)...',
                  'Optional backup label (e.g., End_of_Month)...'
                )}
                className="neu-input w-full px-3.5 py-2 rounded-xl text-xs font-semibold"
              />
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleUploadNewBackup}
                disabled={isUploading}
                className="neu-button-primary px-4 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 flex-1 sm:flex-initial"
              >
                <CloudUpload className={`w-4 h-4 ${isUploading ? 'animate-bounce' : ''}`} />
                <span>
                  {isUploading
                    ? tr('جاري الرفع إلى Google Drive...', 'Uploading to Google Drive...')
                    : tr('رفع نسخة احتياطية إلى Google Drive الآن', 'Upload Backup to Google Drive Now')}
                </span>
              </button>

              <button
                type="button"
                onClick={fetchBackupsList}
                disabled={isLoadingFiles}
                title={tr('تحديث قائمة النسخ السحابية', 'Refresh Cloud Backups List')}
                className="neu-button p-2.5 rounded-xl text-slate-700 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingFiles ? 'animate-spin text-blue-600' : ''}`} />
              </button>
            </div>
          </div>

          {/* Cloud Backups List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="font-bold text-slate-700 text-xs flex items-center gap-1.5">
                <FolderOpen className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  {tr(
                    `النسخ الاحتياطية المحفوظة في Google Drive (${driveFiles.length})`,
                    `Backups Stored in Google Drive (${driveFiles.length})`
                  )}
                </span>
              </span>
              <span className="text-[10px] text-slate-400">
                {tr('مجلد: AK Store Backups', 'Folder: AK Store Backups')}
              </span>
            </div>

            {isLoadingFiles ? (
              <div className="p-6 text-center text-xs text-slate-500 bg-white/70 rounded-2xl border border-slate-200/60">
                {tr('جاري تحميل قائمة النسخ الاحتياطية من Google Drive...', 'Loading backups from Google Drive...')}
              </div>
            ) : driveFiles.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-white/70 rounded-2xl border border-slate-200/60">
                {tr(
                  'لا توجد نسخ احتياطية مرفوعة بعد. اضغط على "رفع نسخة احتياطية إلى Google Drive الآن" لحفظ أول نسخة سحابية.',
                  'No cloud backups found yet. Click "Upload Backup to Google Drive Now" to create your first cloud backup.'
                )}
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {driveFiles.map((file) => {
                  const isBusy = activeActionFileId === file.id;
                  return (
                    <div
                      key={file.id}
                      className="p-3 rounded-2xl bg-white border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:border-blue-300 transition-all"
                    >
                      <div className="flex items-start gap-2.5 overflow-hidden">
                        <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="truncate">
                          <div className="font-bold text-slate-800 text-xs truncate">{file.name}</div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5 flex-wrap">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-slate-400" />
                              {file.modifiedTime
                                ? new Date(file.modifiedTime).toLocaleString('ar-SA')
                                : '—'}
                            </span>
                            <span>•</span>
                            <span className="font-mono">{formatFileSize(file.size)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                        {/* Restore Button */}
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleRestoreFromDrive(file)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors disabled:opacity-50"
                          title={tr('استرجاع قاعدة البيانات من هذه النسخة السحابية', 'Restore database from this cloud backup')}
                        >
                          <Download className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{tr('استرجاع للنظام', 'Restore')}</span>
                        </button>

                        {/* Overwrite / Update Button */}
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleOverwriteBackup(file)}
                          className="px-2.5 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors disabled:opacity-50"
                          title={tr('تحديث هذه النسخة بالبيانات الحالية', 'Update this backup with current database')}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>{tr('تحديث', 'Overwrite')}</span>
                        </button>

                        {/* Open in Drive Link */}
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                            title={tr('عرض في Google Drive', 'View in Google Drive')}
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* Delete Button */}
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleDeleteFromDrive(file)}
                          className="p-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 transition-colors cursor-pointer disabled:opacity-50"
                          title={tr('حذف من Google Drive', 'Delete from Google Drive')}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
