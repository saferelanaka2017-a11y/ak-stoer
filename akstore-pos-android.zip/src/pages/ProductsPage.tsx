/**
 * @file pages/ProductsPage.tsx
 * شاشة إدارة المنتجات والمخزون، إضافة وتعديل وحذف، رفع الصور، وتصدير واستيراد إكسل
 * Inventory & Product Management Page with Excel Import/Export and Stock Alerts
 */

import React, { useState, useMemo, useRef } from 'react';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  Upload,
  Download,
  AlertTriangle,
  Barcode,
  Image as ImageIcon,
  Check,
  X,
  FileSpreadsheet,
  Printer,
  Building2,
  Boxes,
  Smartphone,
  Camera
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../db/database';
import { Product } from '../types';
import {
  exportProductsToExcel,
  parseProductsFromFile,
  generateBarcodeLabelPDF,
  generateProductsCatalogPDF
} from '../utils/exportUtils';
import { MobileBarcodeScannerModal } from '../components/MobileBarcodeScannerModal';
import { NumberStepperInput } from '../components/NumberStepperInput';

const DEFAULT_PRODUCT_CATEGORIES = [
  'غذاء',
  'مشروبات',
  'ألبان وأجبان',
  'حلويات وسناكس',
  'مخبوزات ومعجنات',
  'لحوم ودواجن',
  'خضروات وفواكه',
  'منظفات وعناية منزلية',
  'عناية شخصية وتجميل',
  'إلكترونيات وإكسسوارات',
  'أجهزة منزلية وكهربائية',
  'ملابس وأحذية',
  'أدوات مكتبية وقرطاسية',
  'أدوية ومستلزمات طبية',
  'قطع غيار وعدد',
  'عام'
];

const DEFAULT_PRODUCT_UNITS = [
  'حبة',
  'قطعة',
  'علبة',
  'زجاجة',
  'كرتونة',
  'كيلو',
  'لتر',
  'كيس',
  'باكو'
];

export const ProductsPage: React.FC = () => {
  const {
    products,
    formatCurrency,
    refreshData,
    showToast,
    settings,
    t,
    tr,
    requestConfirm,
    warehouses,
    distributeProductStock,
    currencies,
    activeCurrency,
    baseCurrency,
    switchActiveCurrency
  } = useApp();
  const { canDelete, isAdmin, hasPermission } = useAuth();
  const canAddProduct = isAdmin || hasPermission('canAddProduct');
  const canEditProduct = isAdmin || hasPermission('canEditProduct');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedWarehouse, setSelectedWarehouse] = useState('all');
  const [filterLowStockOnly, setFilterLowStockOnly] = useState(false);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form Fields
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('غذاء');
  const [customCategory, setCustomCategory] = useState('');
  const [costPrice, setCostPrice] = useState(0);
  const [salePrice, setSalePrice] = useState(0);
  const [stock, setStock] = useState(10);
  const [minStockAlert, setMinStockAlert] = useState(5);
  const [unit, setUnit] = useState('حبة');
  const [description, setDescription] = useState('');
  const [imageBase64, setImageBase64] = useState<string>('');
  const [warehouseDistribution, setWarehouseDistribution] = useState<Record<string, number>>({});

  // Quick Distribute Modal State
  const [isQuickDistOpen, setIsQuickDistOpen] = useState(false);
  const [quickDistProduct, setQuickDistProduct] = useState<Product | null>(null);
  const [quickDistMap, setQuickDistMap] = useState<Record<string, number>>({});

  // Mobile Camera Barcode Scanner State
  const [isMobileScannerOpen, setIsMobileScannerOpen] = useState(false);
  const [mobileScannerTarget, setMobileScannerTarget] = useState<'search' | 'form'>('search');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const excelImportRef = useRef<HTMLInputElement>(null);

  // Categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach(p => {
      if (p.category) set.add(p.category);
    });
    return Array.from(set);
  }, [products]);

  const allProductTypeOptions = useMemo(() => {
    const set = new Set<string>(DEFAULT_PRODUCT_CATEGORIES);
    products.forEach(p => {
      if (p.category && p.category.trim()) set.add(p.category.trim());
    });
    return Array.from(set);
  }, [products]);

  // Low stock summary counts
  const lowStockStats = useMemo(() => {
    let lowCount = 0;
    let outCount = 0;
    products.forEach((p) => {
      const effectiveStock =
        selectedWarehouse === 'all' ? p.stock : p.warehouseStock?.[selectedWarehouse] || 0;
      if (effectiveStock <= p.minStockAlert) {
        lowCount += 1;
        if (effectiveStock <= 0) {
          outCount += 1;
        }
      }
    });
    return { lowCount, outCount };
  }, [products, selectedWarehouse]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return products.filter(p => {
      const matchCat = selectedCategory === 'all' || p.category === selectedCategory;
      const matchSearch = !q || p.name.toLowerCase().includes(q) || p.barcode.includes(q);
      const effectiveStock = selectedWarehouse === 'all'
        ? p.stock
        : (p.warehouseStock?.[selectedWarehouse] || 0);
      const matchStock = !filterLowStockOnly || effectiveStock <= p.minStockAlert;
      const matchWh = selectedWarehouse === 'all' || (p.warehouseStock?.[selectedWarehouse] !== undefined && (p.warehouseStock?.[selectedWarehouse] || 0) > 0);
      return matchCat && matchSearch && matchStock && (selectedWarehouse === 'all' || matchWh);
    });
  }, [products, selectedCategory, searchQuery, filterLowStockOnly, selectedWarehouse]);

  const openAddModal = () => {
    if (!canAddProduct) {
      showToast(tr('ليس لديك صلاحية إضافة منتجات جديدة', 'You do not have permission to add products'), 'error');
      return;
    }
    setEditingProduct(null);
    setBarcode(Date.now().toString().slice(-8));
    setName('');
    setCategory(selectedCategory !== 'all' ? selectedCategory : 'غذاء');
    setCustomCategory('');
    setCostPrice(0);
    setSalePrice(0);
    setStock(10);
    setMinStockAlert(5);
    setUnit('حبة');
    setDescription('');
    setImageBase64('');
    // Initial warehouse distribution: default warehouse gets the stock
    const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
    const initDist: Record<string, number> = {};
    warehouses.forEach(wh => {
      initDist[wh.id] = wh.id === defWhId ? 10 : 0;
    });
    setWarehouseDistribution(initDist);
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    if (!canEditProduct) {
      showToast(tr('ليس لديك صلاحية تعديل بيانات أو أسعار المنتجات', 'You do not have permission to edit products'), 'error');
      return;
    }
    setEditingProduct(p);
    setBarcode(p.barcode);
    setName(p.name);
    setCategory(p.category || 'عام');
    setCostPrice(p.costPrice);
    setSalePrice(p.salePrice);
    setStock(p.stock);
    setMinStockAlert(p.minStockAlert);
    setUnit(p.unit || 'حبة');
    setDescription(p.description || '');
    setImageBase64(p.image || '');
    // Existing warehouse distribution
    const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
    const dist: Record<string, number> = {};
    warehouses.forEach(wh => {
      dist[wh.id] = p.warehouseStock?.[wh.id] !== undefined
        ? p.warehouseStock[wh.id]
        : (wh.id === defWhId ? p.stock : 0);
    });
    setWarehouseDistribution(dist);
    setIsModalOpen(true);
  };

  // Quick Distribute Modal Open
  const handleOpenQuickDistribute = (p: Product) => {
    if (!canEditProduct) {
      showToast(tr('ليس لديك صلاحية تعديل كميات المستودعات', 'You do not have permission to edit warehouse quantities'), 'error');
      return;
    }
    setQuickDistProduct(p);
    const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
    const dist: Record<string, number> = {};
    warehouses.forEach(wh => {
      dist[wh.id] = p.warehouseStock?.[wh.id] !== undefined
        ? p.warehouseStock[wh.id]
        : (wh.id === defWhId ? p.stock : 0);
    });
    setQuickDistMap(dist);
    setIsQuickDistOpen(true);
  };

  const handleSaveQuickDistribute = () => {
    if (!quickDistProduct) return;
    distributeProductStock(quickDistProduct.id, quickDistMap);
    showToast(`تم تحديث توزيع مستودعات الصنف "${quickDistProduct.name}" بنجاح!`, 'success');
    setIsQuickDistOpen(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        showToast('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 2 ميغابايت', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('يرجى إدخال اسم الصنف', 'error');
      return;
    }

    // Clean distribution map
    const cleanDist: Record<string, number> = {};
    warehouses.forEach(wh => {
      cleanDist[wh.id] = Math.max(0, Number(warehouseDistribution[wh.id]) || 0);
    });
    const calculatedStock = Object.values(cleanDist).reduce((sum, v) => sum + v, 0);

    const finalCategory =
      category === '__custom__'
        ? customCategory.trim() || 'عام'
        : category || 'غذاء';

    if (editingProduct) {
      db.updateProduct(editingProduct.id, {
        barcode,
        name,
        category: finalCategory,
        costPrice,
        salePrice,
        stock: calculatedStock,
        minStockAlert,
        unit,
        description,
        image: imageBase64,
        warehouseStock: cleanDist
      });
      showToast('تم تحديث بيانات المنتج وتوزيع المستودعات بنجاح!', 'success');
    } else {
      db.addProduct({
        barcode,
        name,
        category: finalCategory,
        costPrice,
        salePrice,
        stock: calculatedStock,
        minStockAlert,
        unit,
        description,
        image: imageBase64,
        warehouseStock: cleanDist
      });
      showToast('تمت إضافة المنتج الجديد وتوزيعه على المستودعات بنجاح!', 'success');
    }

    refreshData();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, prodName: string) => {
    if (!canDelete) {
      showToast('عذراً، صلاحية حذف المنتجات مخصصة للمدير فقط!', 'error');
      return;
    }
    requestConfirm({
      title: 'تأكيد حذف المنتج',
      message: `هل أنت متأكد من رغبتك في حذف الصنف "${prodName}" نهائياً من قاعدة البيانات؟`,
      confirmText: 'نعم، حذف المنتج',
      cancelText: 'تراجع',
      isDestructive: true,
      onConfirm: () => {
        db.deleteProduct(id);
        showToast(`تم حذف الصنف "${prodName}" بنجاح`, 'success');
        refreshData();
      }
    });
  };

  // Print single product barcode label (50x30mm thermal sticker) with 100% Arabic support
  const handlePrintBarcodeLabel = async (p: Product) => {
    try {
      showToast(`جاري إنشاء ملصق الباركود للصنف: ${p.name}...`, 'info');
      await generateBarcodeLabelPDF(p, settings);
      showToast(`تم تحميل ملصق الباركود للصنف: ${p.name} بنجاح!`, 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل إنشاء ملصق الباركود', 'error');
    }
  };

  // Export to Excel
  const handleExportExcel = () => {
    exportProductsToExcel(products);
    showToast('تم تصدير ملف إكسل للمنتجات بنجاح', 'success');
  };

  // Print products catalog / price list PDF with 100% Arabic support
  const handlePrintProducts = async () => {
    try {
      showToast('جاري تصدير قائمة المنتجات والأسعار باللغة العربية...', 'info');
      await generateProductsCatalogPDF(products, settings);
      showToast('تم تصدير قائمة المنتجات والأسعار PDF بنجاح!', 'success');
    } catch (e) {
      console.error(e);
      showToast('فشل تصدير قائمة المنتجات', 'error');
    }
  };

  // Import from Excel / CSV
  const handleImportExcel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const parsed = await parseProductsFromFile(file);
      let count = 0;
      parsed.forEach(item => {
        if (item.name) {
          db.addProduct({
            barcode: item.barcode || String(Date.now().toString().slice(-8)),
            name: item.name,
            category: item.category || 'عام',
            costPrice: item.costPrice || 0,
            salePrice: item.salePrice || 0,
            stock: item.stock || 10,
            minStockAlert: item.minStockAlert || 5,
            unit: item.unit || 'حبة',
            description: item.description || ''
          });
          count++;
        }
      });
      showToast(`تم استيراد ${count} منتج بنجاح!`, 'success');
      refreshData();
    } catch (err) {
      showToast('حدث خطأ أثناء قراءة ملف الإكسل', 'error');
    }
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 neu-card p-5 rounded-3xl">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            <span>{tr('إدارة المنتجات والمخزون', 'Products & Inventory Management')}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tr('التحكم الكامل في الأصناف والأسعار وتنبيهات نواقص المخزون', 'Full control over products, pricing, multi-warehouse distribution, and low-stock alerts')}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Print Catalog button */}
          <button
            onClick={handlePrintProducts}
            className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-blue-600" />
            <span>{tr('طباعة قائمة الأصناف', 'Print Catalog PDF')}</span>
          </button>

          {/* Excel Import button */}
          <input
            ref={excelImportRef}
            type="file"
            accept=".xlsx, .xls, .csv"
            onChange={handleImportExcel}
            className="hidden"
          />
          <button
            onClick={() => excelImportRef.current?.click()}
            className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-slate-600" />
            <span>{t('importExcel')}</span>
          </button>

          {/* Excel Export button */}
          <button
            onClick={handleExportExcel}
            className="neu-button px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>{t('exportExcel')}</span>
          </button>

          {/* Add Product Button */}
          <button
            onClick={openAddModal}
            className="neu-button-primary px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{tr('إضافة صنف جديد', 'Add Product')}</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="neu-card p-4 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={tr('بحث بالاسم أو الباركود...', 'Search by name or barcode...')}
              className="neu-input w-full pl-4 pr-10 py-2 rounded-xl text-xs"
            />
            <Search className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
          </div>
          <button
            type="button"
            onClick={() => {
              setMobileScannerTarget('search');
              setIsMobileScannerOpen(true);
            }}
            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
            title={tr('بحث عن صنف في المخزون عبر مسح الباركود بكاميرا الموبايل', 'Search inventory by scanning barcode with mobile camera')}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <Camera className="w-3.5 h-3.5 hidden sm:inline" />
            <span>{tr('مسح بالموبايل', 'Scan')}</span>
          </button>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {/* Active Currency Switcher in Products Page */}
          <select
            value={activeCurrency?.code || settings.currency || 'EGP'}
            onChange={(e) => {
              const res = switchActiveCurrency(e.target.value);
              if (res.success) {
                showToast(res.message, 'success');
              }
            }}
            className="neu-input px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-700"
            title={tr('تبديل عملة عرض وتسعير الشراء والبيع', 'Switch display & pricing currency')}
          >
            {currencies.map(c => (
              <option key={c.code} value={c.code}>
                💱 {c.name} ({c.symbol}) — {tr('صرف:', 'Rate:')} {c.exchangeRate}
              </option>
            ))}
          </select>

          {/* Warehouse Filter */}
          <select
            value={selectedWarehouse}
            onChange={(e) => setSelectedWarehouse(e.target.value)}
            className="neu-input px-3 py-1.5 rounded-xl text-xs font-semibold text-indigo-700"
          >
            <option value="all">🏢 {tr(`كل المستودعات (${warehouses.length})`, `All Warehouses (${warehouses.length})`)}</option>
            {warehouses.map(w => (
              <option key={w.id} value={w.id}>
                {w.name} ({w.code}) {w.isDefault ? tr('• الافتراضي', '• Default') : ''}
              </option>
            ))}
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="neu-input px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700"
          >
            <option value="all">{tr(`كل التصنيفات (${products.length})`, `All Categories (${products.length})`)}</option>
            {categories.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <button
            onClick={() => setFilterLowStockOnly(!filterLowStockOnly)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-all flex items-center gap-1.5 ${
              filterLowStockOnly
                ? 'bg-red-600 text-white shadow-sm'
                : lowStockStats.lowCount > 0
                ? 'bg-red-50 text-red-700 border border-red-300 hover:bg-red-100'
                : 'neu-button text-slate-600'
            }`}
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${filterLowStockOnly ? 'text-white' : 'text-red-600'}`} />
            <span>
              {tr('المنخفض فقط', 'Low Stock Only')} ({lowStockStats.lowCount})
            </span>
          </button>
        </div>
      </div>

      {/* Automatic Low Stock Alert Indicator Banner */}
      {lowStockStats.lowCount > 0 && (
        <div className="p-4 rounded-2xl bg-red-50/90 border border-red-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-extrabold text-red-900 text-xs sm:text-sm">
                  {tr(
                    `تنبيه المخزون المنخفض: يوجد ${lowStockStats.lowCount} منتج وصل للحد الأدنى (مميّز باللون الأحمر في الجدول أدناه)`,
                    `Low Stock Alert: ${lowStockStats.lowCount} product(s) reached minimum threshold (highlighted in red below)`
                  )}
                </span>
                {lowStockStats.outCount > 0 && (
                  <span className="px-2 py-0.5 rounded-md bg-red-700 text-white text-[10px] font-black">
                    {lowStockStats.outCount} {tr('نفد بالكامل (0)', 'Out of Stock (0)')}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-red-700 mt-0.5">
                {tr(
                  'المنتجات ذات المؤشر الأحمر وصل رصيدها للحد الأدنى أو أقل وتحتاج إلى إعادة التوريد.',
                  'Products marked in red have reached or dropped below their minimum stock alert level.'
                )}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setFilterLowStockOnly(!filterLowStockOnly)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors shrink-0 ${
              filterLowStockOnly
                ? 'bg-slate-800 text-white hover:bg-slate-900'
                : 'bg-red-600 text-white hover:bg-red-700'
            }`}
          >
            {filterLowStockOnly
              ? tr('إظهار جميع المنتجات', 'Show All Products')
              : tr('عرض المنتجات المنخفضة فقط', 'Show Low Stock Only')}
          </button>
        </div>
      )}

      {/* Products Table */}
      <div className="neu-card p-5 rounded-3xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="pb-3 pr-2">{tr('الصورة', 'Image')}</th>
                <th className="pb-3">{t('barcode')}</th>
                <th className="pb-3">{t('productName')}</th>
                <th className="pb-3">{t('category')}</th>
                <th className="pb-3 text-center">{tr('سعر الشراء (التكلفة)', 'Cost Price')}</th>
                <th className="pb-3 text-center">{tr('سعر البيع', 'Selling Price')}</th>
                <th className="pb-3 text-center">
                  {selectedWarehouse === 'all'
                    ? tr('المخزون وتوزيعه', 'Stock & Distribution')
                    : `${tr('مخزون', 'Stock')} (${warehouses.find(w => w.id === selectedWarehouse)?.name || tr('المستودع', 'Warehouse')})`}
                </th>
                <th className="pb-3 text-left">{tr('الإجراءات', 'Actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((product) => {
                const effectiveStock = selectedWarehouse === 'all'
                  ? product.stock
                  : (product.warehouseStock?.[selectedWarehouse] || 0);
                const isLow = effectiveStock <= product.minStockAlert;
                const isOutOfStock = effectiveStock <= 0;
                return (
                  <tr
                    key={product.id}
                    className={`transition-colors ${
                      isLow
                        ? 'bg-red-50/85 hover:bg-red-100/80 border-r-4 border-r-red-600'
                        : 'hover:bg-slate-50/50'
                    }`}
                  >
                    <td className="py-2.5 pr-2">
                      <div
                        className={`relative w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center ${
                          isLow
                            ? 'bg-red-100 border-2 border-red-400 ring-2 ring-red-500/20'
                            : 'bg-slate-100 border border-slate-200'
                        }`}
                      >
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <ImageIcon className={`w-4 h-4 ${isLow ? 'text-red-500' : 'text-slate-400'}`} />
                        )}
                        {isLow && (
                          <span
                            className="absolute top-0.5 right-0.5 w-2.5 h-2.5 rounded-full bg-red-600 ring-2 ring-white animate-pulse"
                            title={tr('وصل للحد الأدنى للمخزون', 'Low Stock Alert')}
                          />
                        )}
                      </div>
                    </td>
                    <td className={`py-2.5 font-mono font-medium ${isLow ? 'text-red-700 font-bold' : 'text-slate-600'}`}>
                      {product.barcode}
                    </td>
                    <td className="py-2.5">
                      <div className="flex flex-col gap-1">
                        <span className={`font-bold ${isLow ? 'text-red-900 font-extrabold' : 'text-slate-800'}`}>
                          {product.name}
                        </span>
                        {isLow && (
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold w-fit ${
                              isOutOfStock
                                ? 'bg-red-600 text-white animate-pulse'
                                : 'bg-red-100 text-red-700 border border-red-300'
                            }`}
                          >
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>
                              {isOutOfStock
                                ? tr('نفد من المخزون (0)', 'Out of Stock (0)')
                                : tr(
                                    `وصل للحد الأدنى (${product.minStockAlert})`,
                                    `Low Stock (Min: ${product.minStockAlert})`
                                  )}
                            </span>
                          </span>
                        )}
                      </div>
                    </td>
                    <td className={`py-2.5 ${isLow ? 'text-red-700 font-semibold' : 'text-slate-600'}`}>
                      {product.category}
                    </td>
                    <td className="py-2.5 text-center font-semibold text-amber-700 tabular-nums">
                      <div>{formatCurrency(product.costPrice)}</div>
                      {activeCurrency?.code !== baseCurrency?.code && product.baseCostPrice !== undefined && (
                        <div className="text-[10px] text-slate-400 font-mono">
                          ({product.baseCostPrice.toFixed(2)} {baseCurrency?.symbol})
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 text-center font-bold text-blue-600 tabular-nums">
                      <div>{formatCurrency(product.salePrice)}</div>
                      {activeCurrency?.code !== baseCurrency?.code && product.baseSalePrice !== undefined && (
                        <div className="text-[10px] text-slate-400 font-mono font-normal">
                          ({product.baseSalePrice.toFixed(2)} {baseCurrency?.symbol})
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 text-center">
                      <div className="flex flex-col items-center gap-0.5">
                        <span
                          className={`px-2.5 py-1 rounded-full font-extrabold text-[11px] tabular-nums inline-flex items-center gap-1 ${
                            isLow
                              ? 'bg-red-600 text-white shadow-xs ring-2 ring-red-200'
                              : 'bg-emerald-100 text-emerald-700'
                          }`}
                        >
                          {isLow && <AlertTriangle className="w-3 h-3 shrink-0" />}
                          <span>
                            {effectiveStock} {product.unit}
                          </span>
                        </span>
                        {isLow && (
                          <span className="text-[10px] font-bold text-red-600 tabular-nums">
                            {tr(`الحد الأدنى: ${product.minStockAlert}`, `Min: ${product.minStockAlert}`)}
                          </span>
                        )}
                      </div>
                      {/* Mini warehouse distribution chips */}
                      <div className="flex items-center justify-center gap-1 mt-1 flex-wrap max-w-[150px] mx-auto">
                        {warehouses.map(wh => {
                          const wQty = product.warehouseStock?.[wh.id] || 0;
                          return (
                            <span
                              key={wh.id}
                              className={`text-[9px] px-1 py-0.5 rounded font-mono ${
                                selectedWarehouse === wh.id
                                  ? 'bg-indigo-600 text-white font-bold'
                                  : wQty > 0
                                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60 font-semibold'
                                  : 'bg-slate-100 text-slate-300'
                              }`}
                              title={`${wh.name}: ${wQty} ${product.unit}`}
                            >
                              {wh.code}:{wQty}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-2.5 text-left">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button
                          onClick={() => handleOpenQuickDistribute(product)}
                          title="توزيع وتعديل مخزون المستودعات لهذا الصنف"
                          className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 cursor-pointer"
                        >
                          <Boxes className="w-3.5 h-3.5 text-indigo-600" />
                        </button>
                        <button
                          onClick={() => handlePrintBarcodeLabel(product)}
                          title="طباعة ملصق الباركود"
                          className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 cursor-pointer"
                        >
                          <Barcode className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEditModal(product)}
                          title="تعديل"
                          className="neu-button p-1.5 rounded-lg text-slate-600 hover:text-blue-600 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {canDelete && (
                          <button
                            onClick={() => handleDelete(product.id, product.name)}
                            title="حذف الصنف"
                            className="neu-button p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredProducts.length === 0 && (
            <div className="py-12 text-center text-xs text-slate-400">
              لا توجد منتجات مطابقة لخيارات البحث
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
          <div className="neu-card rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/60 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-sm">
                {editingProduct ? 'تعديل بيانات المنتج' : 'إضافة منتج جديد للمخزون'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 font-bold text-xs"
              >
                إغلاق ✕
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
              {/* Image Upload Area */}
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center">
                  {imageBase64 ? (
                    <img src={imageBase64} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-8 h-8 text-slate-400" />
                  )}
                </div>
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="neu-button px-3 py-1.5 rounded-xl font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-blue-600" />
                    <span>رفع صورة المنتج</span>
                  </button>
                  <p className="text-[10px] text-slate-400 mt-1">PNG, JPG حتى 2 ميغابايت</p>
                </div>
              </div>

              {/* Form Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">اسم المنتج:</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-semibold"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">الباركود:</label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      required
                      value={barcode}
                      onChange={(e) => setBarcode(e.target.value)}
                      className="neu-input flex-1 px-3 py-2 rounded-xl font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setMobileScannerTarget('form');
                        setIsMobileScannerOpen(true);
                      }}
                      className="px-2.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                      title={tr('مسح باركود المنتج بكاميرا الموبايل', 'Scan product barcode with mobile camera')}
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{tr('مسح بالموبايل', 'Scan')}</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {tr('نوع المنتج / التصنيف (ComboBox):', 'Product Type / Category:')}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold text-slate-800 cursor-pointer"
                  >
                    {allProductTypeOptions.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                    <option value="__custom__">{tr('+ نوع آخر (كتابة نوع جديد...)', '+ Other (Type custom category...)')}</option>
                  </select>
                  {category === '__custom__' && (
                    <input
                      type="text"
                      required
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value)}
                      placeholder={tr('اكتب نوع المنتج الجديد...', 'Enter custom product type...')}
                      className="neu-input w-full px-3 py-2 rounded-xl font-bold mt-2 border border-blue-300"
                    />
                  )}
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    {tr('الوحدة:', 'Unit:')}
                  </label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="neu-input w-full px-3 py-2 rounded-xl font-bold text-slate-800 cursor-pointer"
                  >
                    {DEFAULT_PRODUCT_UNITS.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                    {!DEFAULT_PRODUCT_UNITS.includes(unit) && unit && (
                      <option value={unit}>{unit}</option>
                    )}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">سعر التكلفة (الشراء):</label>
                  <NumberStepperInput
                    min={0}
                    step={1}
                    value={costPrice}
                    onChange={(val) => setCostPrice(val)}
                    className="w-full"
                    inputClassName="font-bold text-slate-800"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">سعر البيع للجمهور:</label>
                  <NumberStepperInput
                    min={0}
                    step={1}
                    required
                    value={salePrice}
                    onChange={(val) => setSalePrice(val)}
                    className="w-full"
                    inputClassName="font-bold text-blue-600"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">الكمية الإجمالية للمنتج:</label>
                  <NumberStepperInput
                    min={0}
                    step={1}
                    value={stock}
                    onChange={(val) => {
                      const newTotal = Math.max(0, Math.round(val));
                      setStock(newTotal);
                      const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
                      setWarehouseDistribution(prev => ({
                        ...prev,
                        [defWhId]: newTotal
                      }));
                    }}
                    className="w-full"
                    inputClassName="font-bold text-slate-800"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">حد تنبيه انخفاض الكمية:</label>
                  <NumberStepperInput
                    min={1}
                    step={1}
                    fallbackOnBlur={1}
                    value={minStockAlert}
                    onChange={(val) => setMinStockAlert(Math.max(0, Math.round(val)))}
                    className="w-full"
                    inputClassName="font-bold text-amber-600"
                  />
                </div>

                {/* Multi-Warehouse Stock Distribution Section */}
                <div className="col-span-1 sm:col-span-2 neu-flat p-3.5 rounded-2xl space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                      <span>توزيع الكميات على المستودعات والمخازن:</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
                        const resetDist: Record<string, number> = {};
                        warehouses.forEach(wh => {
                          resetDist[wh.id] = wh.id === defWhId ? stock : 0;
                        });
                        setWarehouseDistribution(resetDist);
                      }}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                    >
                      وضع الكل في المستودع الافتراضي
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {warehouses.map(wh => (
                      <div key={wh.id} className="bg-white p-2.5 rounded-xl border border-slate-200/80 flex items-center justify-between gap-2 shadow-2xs">
                        <div className="truncate">
                          <span className="font-bold text-slate-700 block text-[11px] truncate">{wh.name}</span>
                          <span className="font-mono text-[9px] text-slate-400">
                            {wh.code} {wh.isDefault ? '• الافتراضي' : ''}
                          </span>
                        </div>
                        <NumberStepperInput
                          size="xs"
                          min={0}
                          step={1}
                          value={warehouseDistribution[wh.id] ?? 0}
                          onChange={(rawVal) => {
                            const val = Math.max(0, Math.round(rawVal));
                            const updated = { ...warehouseDistribution, [wh.id]: val };
                            setWarehouseDistribution(updated);
                            const newTotal = Object.values(updated).reduce((s, v) => s + (Number(v) || 0), 0);
                            setStock(newTotal);
                          }}
                          className="w-20"
                          inputClassName="text-center font-black text-indigo-700"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-200/60 font-semibold text-slate-500">
                    <span>مجموع كميات المستودعات:</span>
                    <span className="font-black text-indigo-700 tabular-nums">
                      {Object.values(warehouseDistribution).reduce((s, v) => s + (Number(v) || 0), 0)} {unit || 'حبة'}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">الوصف أو الملاحظات:</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="neu-input w-full p-2.5 rounded-xl resize-none"
                />
              </div>

              <div className="p-4 border-t border-white/60 neu-card flex justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-semibold text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold"
                >
                  حفظ البيانات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Distribute Modal */}
      {isQuickDistOpen && quickDistProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="neu-card rounded-3xl w-full max-w-md p-6 bg-white shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <Boxes className="w-4 h-4 text-indigo-600" />
                  <span>توزيع مخزون الصنف على المستودعات</span>
                </h3>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {quickDistProduct.name} ({quickDistProduct.barcode})
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsQuickDistOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-500 text-[11px]">
                حدد كمية المخزون المتوفرة في كل مستودع. سيتم تحديث إجمالي مخزون الصنف تلقائياً بمجموع هذه الكميات:
              </p>

              <div className="space-y-2">
                {warehouses.map(wh => (
                  <div key={wh.id} className="p-3 neu-flat rounded-2xl flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-bold bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded">
                          {wh.code}
                        </span>
                        <span className="font-bold text-slate-800">{wh.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5 truncate max-w-[200px]">
                        {wh.location}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <NumberStepperInput
                        size="sm"
                        min={0}
                        step={1}
                        value={quickDistMap[wh.id] !== undefined ? quickDistMap[wh.id] : 0}
                        onChange={(rawVal) => {
                          const val = Math.max(0, Math.round(rawVal));
                          setQuickDistMap(prev => ({ ...prev, [wh.id]: val }));
                        }}
                        className="w-24"
                        inputClassName="text-center font-black text-indigo-700 text-sm"
                      />
                      <span className="text-slate-500 font-semibold">{quickDistProduct.unit || 'حبة'}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total Calculation Preview */}
              <div className="p-3 neu-pressed rounded-2xl flex items-center justify-between font-bold text-xs">
                <span>إجمالي المخزون الجديد بعد التوزيع:</span>
                <span className="font-black text-indigo-700 tabular-nums text-sm">
                  {Object.values(quickDistMap).reduce((sum, v) => sum + (Number(v) || 0), 0)} {quickDistProduct.unit || 'حبة'}
                </span>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsQuickDistOpen(false)}
                  className="neu-button px-4 py-2 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleSaveQuickDistribute}
                  className="neu-button-primary px-5 py-2 rounded-xl font-bold cursor-pointer"
                >
                  حفظ التوزيع المحدث
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Camera Barcode Scanner Modal */}
      <MobileBarcodeScannerModal
        isOpen={isMobileScannerOpen}
        onClose={() => setIsMobileScannerOpen(false)}
        defaultContinuous={false}
        title={
          mobileScannerTarget === 'form'
            ? tr('مسح باركود الصنف بكاميرا الموبايل', 'Scan Product Barcode with Mobile Camera')
            : tr('البحث عن صنف بمسح الباركود بالموبايل', 'Search Inventory by Mobile Barcode Scan')
        }
        onScan={(scannedCode) => {
          const clean = scannedCode.trim();
          if (mobileScannerTarget === 'form') {
            setBarcode(clean);
            showToast(tr(`تم قراءة باركود الصنف: ${clean}`, `Product barcode scanned: ${clean}`), 'success');
          } else {
            const existing = products.find(p => p.barcode.trim().toLowerCase() === clean.toLowerCase());
            if (existing) {
              setSearchQuery(clean);
              showToast(tr(`تم العثور على الصنف: ${existing.name}`, `Found product: ${existing.name}`), 'success');
            } else if (canAddProduct) {
              setEditingProduct(null);
              setBarcode(clean);
              setName('');
              setCategory(selectedCategory !== 'all' ? selectedCategory : 'غذاء');
              setCustomCategory('');
              setCostPrice(0);
              setSalePrice(0);
              setStock(10);
              setMinStockAlert(5);
              setUnit('حبة');
              setDescription('');
              setImageBase64('');
              const defWhId = settings.defaultWarehouseId || warehouses[0]?.id || 'wh-main';
              const initDist: Record<string, number> = {};
              warehouses.forEach(wh => {
                initDist[wh.id] = wh.id === defWhId ? 10 : 0;
              });
              setWarehouseDistribution(initDist);
              setIsModalOpen(true);
              showToast(tr(`باركود جديد (${clean}) — اختر نوع المنتج وأكمل بيانات الصنف لإضافته`, `New barcode (${clean}) — select product type to add`), 'info');
            } else {
              setSearchQuery(clean);
              showToast(tr(`تم البحث عن الباركود: ${clean}`, `Searching for barcode: ${clean}`), 'info');
            }
          }
        }}
      />
    </div>
  );
};
