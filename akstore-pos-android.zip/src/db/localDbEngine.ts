/**
 * @file db/localDbEngine.ts
 * محرك التحقق من قاعدة البيانات المحلية (IndexedDB + SQLite Local Engine) وبوابة العمل أوفلاين (Offline-First Gatekeeper)
 * Verifies local IndexedDB / SQLite connection BEFORE any network request is attempted,
 * mirrors all SQLite tables into IndexedDB for permanent offline resilience, and prevents network loading hangs.
 */

export interface LocalDbHealthStatus {
  ready: boolean;
  engine: 'IndexedDB+SQLite' | 'LocalStorage+SQLite';
  latencyMs: number;
  hasLocalData: boolean;
  recordsCount: number;
  pendingOutboxCount: number;
  verifiedAt: string;
  networkReachable: boolean;
}

const IDB_NAME = 'AKStore_Local_SQLite_Engine_v1';
const IDB_VERSION = 1;
const STORE_TABLES = 'sqlite_tables';
const STORE_SNAPSHOTS = 'sqlite_snapshots';
const STORE_OUTBOX = 'sync_outbox';
const STORE_META = 'engine_meta';

const PRIMARY_LOCAL_KEY = 'soft_glass_pos_db_v1';

let cachedDbPromise: Promise<IDBDatabase | null> | null = null;
let lastHealthStatus: LocalDbHealthStatus = {
  ready: false,
  engine: 'LocalStorage+SQLite',
  latencyMs: 0,
  hasLocalData: false,
  recordsCount: 0,
  pendingOutboxCount: 0,
  verifiedAt: new Date().toISOString(),
  networkReachable: typeof navigator !== 'undefined' ? navigator.onLine !== false : false
};

const healthListeners = new Set<(status: LocalDbHealthStatus) => void>();

export function subscribeToLocalDbHealth(
  listener: (status: LocalDbHealthStatus) => void
): () => void {
  healthListeners.add(listener);
  listener(lastHealthStatus);
  return () => {
    healthListeners.delete(listener);
  };
}

export function getLocalDbHealthStatus(): LocalDbHealthStatus {
  return lastHealthStatus;
}

function notifyHealthListeners(next: Partial<LocalDbHealthStatus>) {
  lastHealthStatus = {
    ...lastHealthStatus,
    ...next,
    verifiedAt: new Date().toISOString()
  };
  healthListeners.forEach((cb) => {
    try {
      cb(lastHealthStatus);
    } catch {
      // ignore
    }
  });
}

/**
 * فتح اتصال IndexedDB المحلي مع مهلة زمنية قصيرة جداً (350ms) لمنع أي تعليق في المتصفحات المقيدة
 */
function openLocalIndexedDB(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || typeof indexedDB === 'undefined') {
    return Promise.resolve(null);
  }
  if (cachedDbPromise) {
    return cachedDbPromise;
  }

  cachedDbPromise = new Promise<IDBDatabase | null>((resolve) => {
    let settled = false;
    const finish = (dbInstance: IDBDatabase | null) => {
      if (settled) return;
      settled = true;
      if (!dbInstance) {
        cachedDbPromise = null;
      }
      resolve(dbInstance);
    };

    const timer = setTimeout(() => {
      finish(null);
    }, 400);

    try {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_TABLES)) {
          db.createObjectStore(STORE_TABLES);
        }
        if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) {
          db.createObjectStore(STORE_SNAPSHOTS);
        }
        if (!db.objectStoreNames.contains(STORE_OUTBOX)) {
          db.createObjectStore(STORE_OUTBOX);
        }
        if (!db.objectStoreNames.contains(STORE_META)) {
          db.createObjectStore(STORE_META);
        }
      };

      request.onsuccess = () => {
        clearTimeout(timer);
        const db = request.result;
        db.onversionchange = () => {
          db.close();
          cachedDbPromise = null;
        };
        finish(db);
      };

      request.onerror = () => {
        clearTimeout(timer);
        finish(null);
      };

      request.onblocked = () => {
        clearTimeout(timer);
        finish(null);
      };
    } catch {
      clearTimeout(timer);
      finish(null);
    }
  });

  return cachedDbPromise;
}

/**
 * حساب إجمالي السجلات داخل حالة قاعدة البيانات المحلية
 */
function countRecordsInState(state: any): number {
  if (!state || typeof state !== 'object') return 0;
  const tables = [
    'users',
    'products',
    'customers',
    'suppliers',
    'sales',
    'purchases',
    'returns',
    'expenses',
    'installmentPlans',
    'warehouses',
    'warehouseTransfers'
  ];
  let total = 0;
  for (const key of tables) {
    if (Array.isArray(state[key])) {
      total += state[key].length;
    }
  }
  return total;
}

/**
 * التحقق الفوري من اتصال IndexedDB و SQLite محلياً قبل أي محاولة اتصال بالشبكة
 * كما يقوم باسترجاع البيانات تلقائياً من IndexedDB إذا تم مسح localStorage، أو حفظها في IndexedDB
 */
export async function verifyAndHydrateLocalDb(
  storageKey: string = PRIMARY_LOCAL_KEY
): Promise<{
  status: LocalDbHealthStatus;
  hydratedState: any | null;
}> {
  const startMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
  let localRaw: string | null = null;
  let parsedLocal: any | null = null;

  try {
    localRaw = localStorage.getItem(storageKey) || localStorage.getItem(PRIMARY_LOCAL_KEY);
    if (localRaw) {
      parsedLocal = JSON.parse(localRaw);
    }
  } catch {
    // ignore
  }

  const db = await openLocalIndexedDB();
  const elapsed = () =>
    Math.max(
      1,
      Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - startMs)
    );

  // Fallback to synchronous LocalStorage+SQLite if IndexedDB is unavailable
  if (!db) {
    const recordsCount = countRecordsInState(parsedLocal);
    const fallbackStatus: LocalDbHealthStatus = {
      ready: true,
      engine: 'LocalStorage+SQLite',
      latencyMs: elapsed(),
      hasLocalData: Boolean(parsedLocal),
      recordsCount,
      pendingOutboxCount: 0,
      verifiedAt: new Date().toISOString(),
      networkReachable: lastHealthStatus.networkReachable
    };
    notifyHealthListeners(fallbackStatus);
    return { status: fallbackStatus, hydratedState: null };
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_SNAPSHOTS, STORE_OUTBOX, STORE_META], 'readwrite');
      const snapStore = tx.objectStore(STORE_SNAPSHOTS);
      const outboxStore = tx.objectStore(STORE_OUTBOX);
      const metaStore = tx.objectStore(STORE_META);

      const getSnapReq = snapStore.get(storageKey);
      const getDefaultSnapReq = snapStore.get(PRIMARY_LOCAL_KEY);
      const getOutboxReq = outboxStore.get('pending_sync');

      let hydratedState: any | null = null;
      let pendingOutboxCount = 0;

      tx.oncomplete = () => {
        const finalState = hydratedState || parsedLocal;
        const recordsCount = countRecordsInState(finalState);
        const nextStatus: LocalDbHealthStatus = {
          ready: true,
          engine: 'IndexedDB+SQLite',
          latencyMs: elapsed(),
          hasLocalData: Boolean(finalState),
          recordsCount,
          pendingOutboxCount,
          verifiedAt: new Date().toISOString(),
          networkReachable: lastHealthStatus.networkReachable
        };
        notifyHealthListeners(nextStatus);
        resolve({ status: nextStatus, hydratedState });
      };

      tx.onerror = () => {
        const recordsCount = countRecordsInState(parsedLocal);
        const fallbackStatus: LocalDbHealthStatus = {
          ready: true,
          engine: 'LocalStorage+SQLite',
          latencyMs: elapsed(),
          hasLocalData: Boolean(parsedLocal),
          recordsCount,
          pendingOutboxCount: 0,
          verifiedAt: new Date().toISOString(),
          networkReachable: lastHealthStatus.networkReachable
        };
        notifyHealthListeners(fallbackStatus);
        resolve({ status: fallbackStatus, hydratedState: null });
      };

      getOutboxReq.onsuccess = () => {
        if (getOutboxReq.result && getOutboxReq.result.pending) {
          pendingOutboxCount = 1;
        }
      };

      getSnapReq.onsuccess = () => {
        const idbSnap = getSnapReq.result;
        getDefaultSnapReq.onsuccess = () => {
          const bestIdbSnap = idbSnap || getDefaultSnapReq.result;

          // Case 1: localStorage is empty (or was cleared), but IndexedDB has a valid SQLite snapshot!
          if (!parsedLocal && bestIdbSnap && typeof bestIdbSnap === 'object') {
            hydratedState = bestIdbSnap;
            try {
              const serialized = JSON.stringify(bestIdbSnap);
              localStorage.setItem(storageKey, serialized);
              localStorage.setItem(PRIMARY_LOCAL_KEY, serialized);
            } catch {
              // ignore quota errors
            }
          } else if (parsedLocal) {
            // Case 2: Mirror localStorage into IndexedDB so IndexedDB is always up to date
            snapStore.put(parsedLocal, storageKey);
            if (storageKey !== PRIMARY_LOCAL_KEY) {
              snapStore.put(parsedLocal, PRIMARY_LOCAL_KEY);
            }
          }

          metaStore.put(
            {
              lastVerifiedAt: new Date().toISOString(),
              engine: 'IndexedDB+SQLite',
              storageKey
            },
            'health'
          );
        };
      };
    } catch {
      const recordsCount = countRecordsInState(parsedLocal);
      const fallbackStatus: LocalDbHealthStatus = {
        ready: true,
        engine: 'LocalStorage+SQLite',
        latencyMs: elapsed(),
        hasLocalData: Boolean(parsedLocal),
        recordsCount,
        pendingOutboxCount: 0,
        verifiedAt: new Date().toISOString(),
        networkReachable: lastHealthStatus.networkReachable
      };
      notifyHealthListeners(fallbackStatus);
      resolve({ status: fallbackStatus, hydratedState: null });
    }
  });
}

/**
 * حفظ حالة قاعدة البيانات وجداول SQLite داخل IndexedDB بشكل غير متزامن وسريع جداً
 */
export async function persistStateToLocalIndexedDB(
  state: any,
  storageKey: string = PRIMARY_LOCAL_KEY,
  deletedIds: string[] = []
): Promise<boolean> {
  const db = await openLocalIndexedDB();
  const recordsCount = countRecordsInState(state);

  if (!db) {
    notifyHealthListeners({
      ready: true,
      engine: 'LocalStorage+SQLite',
      hasLocalData: true,
      recordsCount
    });
    return false;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_SNAPSHOTS, STORE_TABLES, STORE_META], 'readwrite');
      const snapStore = tx.objectStore(STORE_SNAPSHOTS);
      const tablesStore = tx.objectStore(STORE_TABLES);
      const metaStore = tx.objectStore(STORE_META);

      snapStore.put(state, storageKey);
      snapStore.put(state, PRIMARY_LOCAL_KEY);

      // Persist individual SQLite table collections for fast modular recovery
      if (state && typeof state === 'object') {
        const tableNames = [
          'users',
          'products',
          'customers',
          'suppliers',
          'sales',
          'purchases',
          'returns',
          'expenses',
          'installmentPlans',
          'settings',
          'warehouses',
          'warehouseTransfers'
        ];
        for (const tName of tableNames) {
          if (state[tName] !== undefined) {
            tablesStore.put(state[tName], `${storageKey}::${tName}`);
          }
        }
      }

      metaStore.put(
        {
          updatedAt: new Date().toISOString(),
          recordsCount,
          deletedIdsCount: deletedIds.length
        },
        'last_write'
      );

      tx.oncomplete = () => {
        notifyHealthListeners({
          ready: true,
          engine: 'IndexedDB+SQLite',
          hasLocalData: true,
          recordsCount
        });
        resolve(true);
      };
      tx.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * تسجيل عملية مزامنة معلقة في صندوق الصادر المحلي (Outbox) عند انقطاع الشبكة
 * ليتم رفعها تلقائياً فور عودة الاتصال دون أي فقدان للبيانات
 */
export async function markOfflineOutboxPending(
  pending: boolean,
  replaceAll = false
): Promise<void> {
  const db = await openLocalIndexedDB();
  notifyHealthListeners({
    pendingOutboxCount: pending ? 1 : 0
  });
  if (!db) return;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_OUTBOX, 'readwrite');
      const store = tx.objectStore(STORE_OUTBOX);
      if (pending) {
        store.put(
          {
            pending: true,
            replaceAll,
            queuedAt: new Date().toISOString()
          },
          'pending_sync'
        );
      } else {
        store.delete('pending_sync');
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

/**
 * فحص سريع وخفيف جداً لاتصال السيرفر الفعلي (Circuit Breaker)
 * يمنع المتصفح من الانتظار الطويل أو التعليق عندما يكون الواي فاي متصلاً بدون إنترنت
 */
let lastProbeTime = 0;
let lastProbeResult = false;
let activeProbePromise: Promise<boolean> | null = null;

export async function verifyNetworkAfterLocalDbReady(
  baseUrl: string,
  forceCheck = false
): Promise<boolean> {
  // 1. Always ensure Local DB is ready first (Offline-First principle)
  if (!lastHealthStatus.ready) {
    await verifyAndHydrateLocalDb();
  }

  // 2. Instant browser offline check
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    lastProbeResult = false;
    notifyHealthListeners({ networkReachable: false });
    return false;
  }

  if (!baseUrl) {
    lastProbeResult = false;
    notifyHealthListeners({ networkReachable: false });
    return false;
  }

  const now = Date.now();
  // Reuse recent probe result within 5 seconds unless forced
  if (!forceCheck && now - lastProbeTime < 5000) {
    return lastProbeResult;
  }

  if (activeProbePromise) {
    return activeProbePromise;
  }

  activeProbePromise = (async () => {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1500);
      const res = await fetch(`${baseUrl.replace(/\/$/, '')}/api/health?t=${now}`, {
        method: 'GET',
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          Accept: 'application/json'
        }
      });
      clearTimeout(timeoutId);

      if (!res.ok) {
        lastProbeTime = Date.now();
        lastProbeResult = false;
        notifyHealthListeners({ networkReachable: false });
        return false;
      }

      const data = await res.json().catch(() => null);
      const isAlive = Boolean(data && data.status === 'ok' && !data.offline);
      lastProbeTime = Date.now();
      lastProbeResult = isAlive;
      notifyHealthListeners({ networkReachable: isAlive });
      return isAlive;
    } catch {
      lastProbeTime = Date.now();
      lastProbeResult = false;
      notifyHealthListeners({ networkReachable: false });
      return false;
    } finally {
      activeProbePromise = null;
    }
  })();

  return activeProbePromise;
}
