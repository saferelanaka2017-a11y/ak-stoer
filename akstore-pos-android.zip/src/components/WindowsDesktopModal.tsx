/**
 * @file components/WindowsDesktopModal.tsx
 * برنامج ومعالج تسطيب وتشغيل نظام AK Store على الويندوز (Windows 7 / 8 / 8.1 / 10 / 11) والتليفون (Android & iPhone)
 * Universal Windows Desktop & Mobile Phone Setup Wizard, QR Installer, Lite Mode & .EXE Packager Modal
 */

import React, { useState, useMemo, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Monitor,
  Smartphone,
  Download,
  CheckCircle2,
  X,
  Printer,
  ShieldCheck,
  Terminal,
  Laptop,
  WifiOff,
  HardDrive,
  FileCode,
  Zap,
  HelpCircle,
  Cpu,
  Gauge,
  Globe,
  RefreshCw,
  QrCode,
  Copy,
  Share2,
  Check,
  Sparkles
} from 'lucide-react';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';
import {
  resolveActiveServerUrl,
  downloadWindowsGuiSetupWizardHta,
  downloadWindows7InstallerBat,
  downloadWindowsSilentLauncherVbs,
  downloadPortableHtmlLauncher,
  downloadElectronWin7ExeBuilder,
  downloadExeAutoUpdaterScriptBat
} from '../utils/windowsDesktopBuilder';
import {
  APP_VERSION,
  applySafeOnlineUpdateAndReload,
  checkForSystemUpdate,
  syncDatabaseAndLicenseToSafeVault
} from '../utils/updateManager';
import { detectSystemCompatibility } from '../utils/win7Polyfills';
import { openSmartWhatsAppModal } from '../utils/installmentAlerts';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';

interface WindowsDesktopModalProps {
  isOpen: boolean;
  onClose: () => void;
  asPage?: boolean;
}

export const WindowsDesktopModal: React.FC<WindowsDesktopModalProps> = ({
  isOpen,
  onClose,
  asPage = false
}) => {
  const { user } = useAuth();
  const { showToast, lowSpecMode, setLowSpecMode, tr, settings } = useApp();
  const { isInstallable, isInstalled, isIOS, isAndroid, isMobile, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  const [activeTab, setActiveTab] = useState<'windows' | 'mobile' | 'thermal' | 'exe'>('windows');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [showManualInstallSteps, setShowManualInstallSteps] = useState(false);

  const sysInfo = useMemo(() => detectSystemCompatibility(), []);

  const mobileInstallUrl = useMemo(() => {
    const base = resolveActiveServerUrl();
    return `${base}/`;
  }, []);

  // Automatically select Mobile tab if opened on a phone
  useEffect(() => {
    if (isOpen && isMobile) {
      setActiveTab('mobile');
    }
  }, [isOpen, isMobile]);

  // Generate QR code for mobile installation
  useEffect(() => {
    if (!isOpen) return;
    QRCode.toDataURL(mobileInstallUrl, {
      width: 220,
      margin: 1,
      color: {
        dark: '#1e3a8a',
        light: '#ffffff'
      }
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => setQrDataUrl(''));
  }, [isOpen, mobileInstallUrl]);

  // Strictly restrict setup screen to primary @admin account only
  if (!isOpen || !user || user.username.toLowerCase() !== 'admin') return null;

  const handleDirectPWAInstall = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        showToast(
          tr(
            '✅ تم تسطيب برنامج AK Store كتطبيق مستقل بنجاح على جهازك!',
            '✅ AK Store App installed successfully on your device!'
          ),
          'success'
        );
        onClose();
      }
      return;
    }

    // If on Windows and browser prompt not fired, download the Windows GUI Setup Wizard (.HTA) + (.BAT)
    if (!isMobile) {
      downloadWindowsGuiSetupWizardHta();
      showToast(
        tr(
          'تم تحميل برنامج معالج التسطيب للويندوز (AK_Store_Windows_Setup_Wizard.hta)! افتح الملف الذي تم تحميله واضغط "تسطيب وتشغيل البرنامج الآن".',
          'Downloaded Windows Setup Wizard! Open the downloaded file to install Desktop & Start Menu shortcuts.'
        ),
        'success'
      );
      return;
    }

    // On mobile (iOS Safari or Android browser when prompt is manual), show visual 2-step guide
    setShowManualInstallSteps(true);
  };

  const handleDownloadGuiSetupHta = () => {
    downloadWindowsGuiSetupWizardHta();
    showToast(
      tr(
        '✅ تم تحميل برنامج معالج التسطيب الرسومي لويندوز (AK_Store_Windows_Setup_Wizard.hta)! شغّل الملف لإنشاء أيقونة سطح المكتب وقائمة ابدأ.',
        '✅ Windows GUI Setup Wizard downloaded!'
      ),
      'success'
    );
  };

  const handleDownloadWin7Bat = () => {
    downloadWindows7InstallerBat(false, true);
    showToast(
      tr(
        '✅ تم تحميل مثبت AK Store التلقائي لـ Windows 7 / 8 / 10 / 11 (.BAT)! شغّل الملف لإنشاء الأيقونة على سطح المكتب.',
        '✅ Windows 7-11 Auto-Installer (.BAT) downloaded!'
      ),
      'success'
    );
  };

  const handleDownloadSilentVbs = () => {
    downloadWindowsSilentLauncherVbs(true);
    showToast(
      tr(
        '✅ تم تحميل المشغل الصامت الخفيف (AK_Store_Win7_to_11_Silent_Launcher.vbs) بنجاح!',
        '✅ Silent Launcher (.VBS) downloaded!'
      ),
      'success'
    );
  };

  const handleDownloadPortableHtml = () => {
    downloadPortableHtmlLauncher();
    showToast(
      tr(
        '✅ تم تحميل ملف التشغيل والتسطيب المحمول للكمبيوتر والتليفون (AK_Store_Universal_Installer.html)!',
        '✅ Universal HTML Installer downloaded!'
      ),
      'success'
    );
  };

  const handleDownloadThermalBat = () => {
    downloadWindows7InstallerBat(true, true);
    showToast(
      tr(
        '✅ تم تحميل مثبت وضع الطباعة الحرارية التلقائية الفورية لـ Windows 7 إلى 11!',
        '✅ Thermal Silent Print Installer downloaded!'
      ),
      'success'
    );
  };

  const handleDownloadExeBuilder = () => {
    downloadElectronWin7ExeBuilder();
    showToast(
      tr(
        '✅ تم تحميل أداة بناء ملف الـ EXE المستقل (Electron 22 لدعم Windows 7/8/10/11 32/64-bit)!',
        '✅ Standalone .EXE Builder downloaded!'
      ),
      'success'
    );
  };

  const handleCopyMobileLink = async () => {
    try {
      await navigator.clipboard.writeText(mobileInstallUrl);
      setCopiedLink(true);
      showToast(
        tr(
          'تم نسخ رابط تسطيب النظام على التليفون! أرسله لهاتفك وافتحه للتثبيت الفوري.',
          'Mobile setup link copied to clipboard!'
        ),
        'success'
      );
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      showToast(mobileInstallUrl, 'info');
    }
  };

  const handleSendLinkViaWhatsApp = () => {
    const storeName = settings.storeName || 'AK Store';
    const message =
      `📲 *رابط تسطيب وتشغيل نظام ${storeName} على التليفون والكمبيوتر*\n\n` +
      `اضغط على الرابط التالي من التليفون (أندرويد أو آيفون) أو الكمبيوتر لفتح النظام وتسطيبه كتطبيق مستقل مع المزامنة اللحظية:\n` +
      `${mobileInstallUrl}\n\n` +
      `✅ خطوات التسطيب على التليفون بعد فتح الرابط:\n` +
      `• في أندرويد (Chrome): اضغط زر *"تسطيب التطبيق الآن"* أو من القائمة (⋮) اختر *"تثبيت التطبيق"*.\n` +
      `• في آيفون (Safari): اضغط زر *"مشاركة"* ثم اختر *"إضافة إلى الشاشة الرئيسية"*.`;

    openSmartWhatsAppModal({
      recipientName: tr('هاتفي المحمول / فريق العمل', 'My Mobile Phone / Team'),
      phone: settings.storePhone || '',
      message,
      title: tr('إرسال رابط تسطيب البرنامج إلى التليفون عبر واتساب', 'Send App Installer Link to Phone via WhatsApp'),
      subtitle: tr('يعمل على أندرويد وآيفون وويندوز مع مزامنة لحظية للبيانات', 'Works on Android, iPhone & Windows with real-time sync')
    });
  };

  return (
    <div
      className={
        asPage
          ? 'w-full space-y-4'
          : 'fixed inset-0 z-[95] flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto'
      }
    >
      <div
        className={
          asPage
            ? 'neu-card rounded-3xl w-full overflow-hidden shadow-lg border border-white/60'
            : 'neu-card rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl border border-white/50 my-4'
        }
      >
        {/* Header */}
        <div className="px-5 sm:px-6 py-4 bg-gradient-to-l from-blue-600/15 via-indigo-500/10 to-emerald-500/10 border-b border-white/60 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-emerald-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/20 shrink-0">
              <div className="relative flex items-center justify-center">
                <Monitor className="w-6 h-6" />
                <Smartphone className="w-3.5 h-3.5 absolute -bottom-1 -right-1 bg-emerald-600 rounded-md p-0.5 ring-1 ring-white" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-extrabold text-slate-800 text-sm sm:text-base">
                  {tr(
                    'شاشة تسطيب وتشغيل النظام على الويندوز والتليفون (خاصة بالأدمن فقط)',
                    'Windows Desktop & Mobile Phone Setup Screen (Admin Only)'
                  )}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-300">
                  {tr('خاص بالأدمن فقط (Admin Only)', 'Admin Only')}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Windows 7–11 + Android & iPhone
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {tr(
                  'سطّب النظام كبرنامج سطح مكتب على الكمبيوتر وتطبيق مستقل على التليفون مع مزامنة البيانات لحظياً بينهما',
                  'Install as a standalone Windows desktop program and mobile phone app with instant real-time data sync'
                )}
              </p>
            </div>
          </div>

          {!asPage && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl neu-button text-slate-400 hover:text-slate-700 cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Live Hardware & OS Diagnostic Bar + Instant Lite Mode Switch */}
        <div className="px-5 sm:px-6 py-2.5 bg-slate-100/90 border-b border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-blue-600" />
              <span className="text-slate-500">{tr('جهازك الحالي:', 'Current Device:')}</span>
              <span className="font-extrabold text-slate-800">
                {isIOS
                  ? 'iPhone / iPad (iOS)'
                  : isAndroid
                  ? 'Android Phone / Tablet'
                  : `${sysInfo.osName} (${sysInfo.architecture})`}
              </span>
            </div>
            <span className="text-slate-300 hidden sm:inline">|</span>
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              <span className="text-emerald-700 font-bold">
                {tr('يدعم العمل بدون إنترنت + مزامنة لحظية', 'Offline Ready + Real-Time Sync')}
              </span>
            </div>
          </div>

          {/* 1-Click Toggle for Low-Spec Mode */}
          <button
            type="button"
            onClick={() => {
              const next = !lowSpecMode;
              setLowSpecMode(next);
              showToast(
                next
                  ? '⚡ تم تفعيل وضع الأجهزة الضعيفة وويندوز 7 (سرعة قصوى واستهلاك رامات منخفض جداً)!'
                  : 'تم العودة إلى وضع المؤثرات البصرية القياسي',
                'success'
              );
            }}
            className={`px-3 py-1 rounded-xl font-extrabold text-[11px] flex items-center gap-1.5 cursor-pointer transition-all border ${
              lowSpecMode
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                : 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${lowSpecMode ? 'fill-white' : 'text-amber-600'}`} />
            <span>
              {lowSpecMode
                ? tr('وضع الأجهزة الضعيفة: مفعّل ⚡', 'Low-Spec Mode: ON ⚡')
                : tr('تسريع الأجهزة الضعيفة', 'Enable Lite Mode')}
            </span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-5 sm:px-6 pt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('windows')}
            className={`py-2.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'windows'
                ? 'bg-blue-600 text-white font-black shadow-md shadow-blue-600/20'
                : 'neu-button text-slate-700'
            }`}
          >
            <Laptop className="w-4 h-4 shrink-0" />
            <span className="truncate">{tr('تسطيب على الويندوز', 'Windows Setup')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('mobile')}
            className={`py-2.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'mobile'
                ? 'bg-emerald-600 text-white font-black shadow-md shadow-emerald-600/20'
                : 'neu-button text-slate-700'
            }`}
          >
            <Smartphone className="w-4 h-4 shrink-0" />
            <span className="truncate">{tr('تسطيب على التليفون', 'Mobile Phone Setup')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('thermal')}
            className={`py-2.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'thermal'
                ? 'bg-amber-600 text-white font-black shadow-md shadow-amber-600/20'
                : 'neu-button text-slate-700'
            }`}
          >
            <Printer className="w-4 h-4 shrink-0" />
            <span className="truncate">{tr('طباعة الكاشير والتسريع', 'Thermal & Speed')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('exe')}
            className={`py-2.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'exe'
                ? 'bg-purple-600 text-white font-black shadow-md shadow-purple-600/20'
                : 'neu-button text-slate-700'
            }`}
          >
            <FileCode className="w-4 h-4 shrink-0" />
            <span className="truncate">{tr('بناء وتحديث .EXE', 'Standalone .EXE')}</span>
          </button>
        </div>

        {/* Body Content */}
        <div
          className={`p-5 sm:p-6 space-y-4 text-xs ${
            asPage ? '' : 'max-h-[72vh] overflow-y-auto'
          }`}
        >
          {/* ================================================================= */}
          {/* TAB 1: WINDOWS DESKTOP SETUP (Windows 7 / 8 / 8.1 / 10 / 11)     */}
          {/* ================================================================= */}
          {activeTab === 'windows' && (
            <div className="space-y-4">
              {/* Direct 1-Click Install Hero Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white shadow-lg space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-900 inline-flex items-center gap-1 mb-1.5">
                      <Sparkles className="w-3 h-3" />
                      <span>{tr('معالج تسطيب الويندوز السريع', 'Express Windows Installer')}</span>
                    </span>
                    <h4 className="font-black text-sm sm:text-base">
                      {tr(
                        'تسطيب برنامج AK Store على الكمبيوتر وسطح المكتب (Windows 7 / 8 / 10 / 11)',
                        'Install AK Store on Windows Desktop (Windows 7 / 8 / 10 / 11)'
                      )}
                    </h4>
                    <p className="text-[11px] text-blue-100 mt-1 leading-relaxed">
                      {tr(
                        'ينشئ أيقونة البرنامج الرسمية على سطح المكتب (Desktop) وقائمة ابدأ (Start Menu) ويفتح النظام في نافذة برنامج مستقلة بدون شريط عنوان المتصفح، مع مزامنة الفواتير والأصناف لحظياً مع التليفون.',
                        'Creates Desktop and Start Menu shortcuts and launches the system in a standalone desktop application window.'
                      )}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {isInstallable && !isInstalled ? (
                    <button
                      type="button"
                      onClick={handleDirectPWAInstall}
                      className="py-3 px-4 rounded-xl bg-white text-blue-700 hover:bg-blue-50 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                    >
                      <Zap className="w-4 h-4 fill-blue-600" />
                      <span>{tr('تسطيب مباشر بضغطة واحدة الآن', '1-Click Direct Install Now')}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleDownloadGuiSetupHta}
                      className="py-3 px-4 rounded-xl bg-white text-blue-700 hover:bg-blue-50 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                    >
                      <Download className="w-4 h-4 text-blue-600" />
                      <span>
                        {tr(
                          'تحميل برنامج معالج التسطيب الرسومي (.HTA)',
                          'Download Windows GUI Setup Wizard (.HTA)'
                        )}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleDownloadWin7Bat}
                    className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>
                      {tr(
                        'تحميل أداة التسطيب التلقائي (.BAT) لويندوز 7–11',
                        'Download Auto-Installer (.BAT) for Win 7–11'
                      )}
                    </span>
                  </button>
                </div>
              </div>

              {/* All Windows Downloadable Launchers Grid */}
              <div className="p-4 rounded-2xl neu-flat border border-blue-200/80 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 font-black">
                    Win
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-2 flex-wrap">
                      <span>
                        {tr(
                          'جميع مشغلات ومعالجات تسطيب الويندوز (32-bit و 64-bit)',
                          'All Windows Desktop Installers & Launchers (32-bit & 64-bit)'
                        )}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                        {tr('يعمل حتى على رامات 1GB و 2GB', 'Works on 1GB-2GB RAM')}
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                      {tr(
                        'اختر طريقة التسطيب المفضلة لديك؛ جميع الملفات تقوم بإنشاء أيقونة "AK Store POS" على سطح المكتب وتشغيل النظام في نافذة مستقلة كاملة:',
                        'Choose your preferred installer below; all options create the "AK Store POS" desktop shortcut and launch the standalone app:'
                      )}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={handleDownloadGuiSetupHta}
                    className="neu-button-primary py-3 px-3 rounded-xl font-extrabold text-xs flex flex-col items-center justify-center gap-1 cursor-pointer shadow-sm text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <Download className="w-4 h-4 shrink-0" />
                      <span>معالج التسطيب (.HTA)</span>
                    </div>
                    <span className="text-[10px] opacity-85 font-normal">واجهة رسومية عربية لويندوز</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadWin7Bat}
                    className="neu-button py-3 px-3 rounded-xl font-extrabold text-blue-700 hover:bg-blue-50 text-xs flex flex-col items-center justify-center gap-1 cursor-pointer border border-blue-200 text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-blue-600 shrink-0" />
                      <span>المثبت التلقائي (.BAT)</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">ينشئ أيقونة سطح المكتب فوراً</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadSilentVbs}
                    className="neu-button py-3 px-3 rounded-xl font-bold text-slate-700 hover:text-indigo-700 text-xs flex flex-col items-center justify-center gap-1 cursor-pointer border border-slate-200/80 text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <Monitor className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>المشغل الصامت (.VBS)</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">بدون شاشة أوامر سوداء</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadPortableHtml}
                    className="neu-button py-3 px-3 rounded-xl font-bold text-emerald-700 hover:text-emerald-800 text-xs flex flex-col items-center justify-center gap-1 cursor-pointer border border-emerald-200/80 text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>ملف محمول (.HTML)</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">يعمل من الفلاشة أو الموبايل</span>
                  </button>
                </div>
              </div>

              {/* Quick Switch to Mobile Tab Banner */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/90 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-emerald-950 text-xs">
                      {tr(
                        'هل تريد تسطيب النظام على التليفون أيضاً وربطه بالكمبيوتر؟',
                        'Want to install the system on your Mobile Phone and sync with PC?'
                      )}
                    </h5>
                    <p className="text-[11px] text-emerald-800">
                      {tr(
                        'اضغط هنا لإظهار كود الباركود (QR) أو إرسال رابط التسطيب المباشر إلى تليفونك عبر واتساب.',
                        'Click here to display the QR code or send the direct installer link to your phone via WhatsApp.'
                      )}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('mobile')}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
                >
                  <QrCode className="w-4 h-4" />
                  <span>{tr('فتح معالج تسطيب التليفون', 'Open Mobile Installer')}</span>
                </button>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 2: MOBILE PHONE SETUP (Android & iPhone + QR Code + Sync)     */}
          {/* ================================================================= */}
          {activeTab === 'mobile' && (
            <div className="space-y-4">
              {/* Top Mobile Direct Install + QR Code Grid */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {/* Left/Main Column: Direct Install & Share Controls */}
                <div className="md:col-span-3 p-4 rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700 text-white shadow-lg flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-white/20 text-white inline-flex items-center gap-1">
                      <Smartphone className="w-3 h-3" />
                      <span>{tr('تطبيق الموبايل المتزامن لحظياً مع الكمبيوتر', 'Mobile App with Real-Time PC Sync')}</span>
                    </span>
                    <h4 className="font-black text-base leading-snug">
                      {tr(
                        'تسطيب نظام AK Store على التليفون (أندرويد & آيفون)',
                        'Install AK Store App on Android & iPhone'
                      )}
                    </h4>
                    <p className="text-[11px] text-emerald-50 leading-relaxed">
                      {tr(
                        'يعمل كتطبيق كامل على شاشة هاتفك الرئيسية، مع لوحة مفاتيح رقمية للمس، قارئ باركود بالكاميرا، ومزامنة تلقائية فورية لأي صنف أو فاتورة يتم إدخالها من الكمبيوتر أو الموبايل!',
                        'Runs as a full-screen app on your home screen with touch numpad, camera barcode scanner, and instant sync with your PC!'
                      )}
                    </p>
                  </div>

                  <div className="space-y-2 pt-1">
                    {/* 1-Click Install on Phone */}
                    {isInstalled ? (
                      <div className="p-2.5 rounded-xl bg-white/20 text-white font-extrabold text-xs flex items-center justify-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-amber-300" />
                        <span>{tr('التطبيق مسطّب ويعمل حالياً على هذا الجهاز', 'App is already installed on this device')}</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          if (isInstallable) {
                            handleDirectPWAInstall();
                          } else {
                            setShowManualInstallSteps(true);
                          }
                        }}
                        className="w-full py-3 px-4 rounded-xl bg-white text-emerald-800 hover:bg-emerald-50 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                      >
                        <Download className="w-4 h-4 text-emerald-600" />
                        <span>
                          {tr(
                            '📲 تسطيب التطبيق على هذا التليفون الآن',
                            '📲 Install App on This Phone Now'
                          )}
                        </span>
                      </button>
                    )}

                    {/* Send to Phone via WhatsApp & Copy Link */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={handleSendLinkViaWhatsApp}
                        className="py-2.5 px-3 rounded-xl bg-emerald-900/40 hover:bg-emerald-900/60 border border-white/25 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>{tr('إرسال للتليفون عبر واتساب', 'Send to Phone via WhatsApp')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleCopyMobileLink}
                        className="py-2.5 px-3 rounded-xl bg-emerald-900/40 hover:bg-emerald-900/60 border border-white/25 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                      >
                        {copiedLink ? <Check className="w-3.5 h-3.5 text-amber-300" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink ? tr('تم نسخ الرابط!', 'Link Copied!') : tr('نسخ رابط التسطيب', 'Copy Setup Link')}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right Column: Instant QR Code Scanner */}
                <div className="md:col-span-2 p-4 rounded-2xl bg-white border-2 border-emerald-200 flex flex-col items-center justify-center text-center space-y-2 shadow-sm">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-extrabold text-xs">
                    <QrCode className="w-4 h-4 text-emerald-600" />
                    <span>{tr('امسح الكود بكاميرا التليفون', 'Scan with Phone Camera')}</span>
                  </div>

                  {qrDataUrl ? (
                    <div className="p-2 rounded-2xl bg-white border border-slate-200 shadow-xs">
                      <img
                        src={qrDataUrl}
                        alt="Mobile App Install QR Code"
                        className="w-36 h-36 sm:w-40 sm:h-40 object-contain mx-auto"
                      />
                    </div>
                  ) : (
                    <div className="w-36 h-36 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 text-[11px]">
                      {tr('جاري توليد الباركود...', 'Generating QR...')}
                    </div>
                  )}

                  <p className="text-[10px] text-slate-500 leading-snug max-w-[200px]">
                    {tr(
                      'افتح كاميرا الموبايل ووجّهها نحو الكود ليفتح لك معالج تسطيب البرنامج على التليفون فوراً.',
                      'Point your phone camera at this QR code to open the mobile app installer.'
                    )}
                  </p>
                </div>
              </div>

              {/* Visual Step-by-Step Guide for Android & iPhone (Always visible or highlighted when clicked) */}
              <div
                className={`p-4 rounded-2xl border transition-all space-y-3 ${
                  showManualInstallSteps
                    ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400/50'
                    : 'bg-white/90 border-slate-200/80'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h5 className="font-extrabold text-slate-800 text-xs sm:text-sm flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>
                      {tr(
                        'خطوات تسطيب الأيقونة على شاشة التليفون الرئيسية (أندرويد & آيفون):',
                        'How to Add AK Store Icon to Your Phone Home Screen:'
                      )}
                    </span>
                  </h5>
                  <button
                    type="button"
                    onClick={handleDownloadPortableHtml}
                    className="text-[11px] font-bold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{tr('تحميل ملف مشغل التليفون (.HTML)', 'Download Phone Launcher (.HTML)')}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Android Guide */}
                  <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
                    <div className="font-black text-emerald-900 text-xs flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-[10px]">
                        1
                      </span>
                      <span>{tr('لهواتف أندرويد (Samsung / Xiaomi / Oppo / ...):', 'For Android Phones (Chrome):')}</span>
                    </div>
                    <ol className="list-decimal list-inside text-[11px] text-slate-700 space-y-1 leading-relaxed pr-1">
                      <li>
                        {tr(
                          'افتح الرابط في متصفح جوجل كروم (Google Chrome) على التليفون.',
                          'Open the link in Google Chrome on your Android phone.'
                        )}
                      </li>
                      <li>
                        {tr(
                          'اضغط على الثلاث نقاط (⋮) أعلى يسار أو يمين المتصفح.',
                          'Tap the three dots menu (⋮) in the top corner of Chrome.'
                        )}
                      </li>
                      <li>
                        {tr(
                          'اختر "تثبيت التطبيق" (Install App) أو "الإضافة إلى الشاشة الرئيسية"، وستظهر أيقونة AK Store فوراً مع باقي تطبيقاتك!',
                          'Tap "Install app" or "Add to Home screen" — the AK Store icon will appear on your phone!'
                        )}
                      </li>
                    </ol>
                  </div>

                  {/* iPhone / iPad Guide */}
                  <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-1.5">
                    <div className="font-black text-blue-900 text-xs flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-lg bg-blue-600 text-white flex items-center justify-center text-[10px]">
                        2
                      </span>
                      <span>{tr('لهواتف آيفون وآيباد (iPhone & iPad - Safari):', 'For iPhone & iPad (Safari):')}</span>
                    </div>
                    <ol className="list-decimal list-inside text-[11px] text-slate-700 space-y-1 leading-relaxed pr-1">
                      <li>
                        {tr(
                          'افتح الرابط في متصفح سفاري (Safari) على الآيفون.',
                          'Open the link in Safari on your iPhone or iPad.'
                        )}
                      </li>
                      <li>
                        {tr(
                          'اضغط على زر المشاركة (Share ⬆️) في الشريط السفلي.',
                          'Tap the Share button (⬆️) at the bottom toolbar.'
                        )}
                      </li>
                      <li>
                        {tr(
                          'اختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen) ثم اضغط "إضافة" (Add).',
                          'Select "Add to Home Screen" and tap "Add".'
                        )}
                      </li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 3: THERMAL SILENT PRINT & LOW-SPEC SPEED                      */}
          {/* ================================================================= */}
          {activeTab === 'thermal' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-emerald-950 text-sm">
                      مشغل الطباعة الحرارية الفورية الصامتة (Kiosk Silent Print) لـ Windows 7–11
                    </h4>
                    <p className="text-[11px] text-emerald-800 mt-1 leading-relaxed">
                      يجعل الفاتورة تخرج فوراً من طابعة الإيصالات الحرارية (80mm أو 58mm) بمجرد الضغط على <strong>"إتمام البيع (F2)"</strong> بدون ظهور نافذة معاينة الطباعة الخاصة بالويندوز، مع تفعيل وضع الأجهزة الضعيفة تلقائياً.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/90 border border-emerald-200/80 space-y-1.5 text-[11px] text-slate-700">
                  <div className="font-bold text-slate-800">خطوات التفعيل على جهاز الكاشير (Windows 7 / 8 / 10 / 11):</div>
                  <p>1. اجعل طابعة الفواتير الحرارية هي <strong>الطابعة الافتراضية (Default Printer)</strong> في لوحة تحكم ويندوز (Control Panel &rarr; Devices and Printers).</p>
                  <p>2. حمّل وشغّل ملف الإعداد أدناه؛ سيقوم بإنشاء أيقونة سطح المكتب مع تفعيل خاصية <code>--kiosk-printing</code> ووضع السرعة القصوى تلقائياً.</p>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadThermalBat}
                  className="neu-button-emerald w-full py-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل مثبت الكاشير مع الطباعة الفورية التلقائية (Win 7–11)</span>
                </button>
              </div>

              {/* Low-Spec Mode Card */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
                    <Gauge className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">
                      وضع السرعة القصوى للأجهزة الضعيفة وويندوز 7 (Ultra-Lite Mode)
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                      الأجهزة القديمة التي تعمل بـ Windows 7 أو Windows 8 أو برامات 1GB–2GB تعمل بأقصى سرعة عند تفعيل هذا الوضع حيث يتم إلغاء الضبابية والظلال الثقيلة وتخفيف استهلاك المعالج.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="p-2.5 rounded-xl bg-white border border-amber-200/80 flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-800 block">يعمل على رامات 1GB و 2GB</span>
                      <span className="text-[10px] text-slate-500">خفيف جداً على المعالج</span>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-amber-200/80 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-800 block">يدعم متصفحات Win 7</span>
                      <span className="text-[10px] text-slate-500">Chrome 109 / Edge 109</span>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-amber-200/80 flex items-center gap-2">
                    <WifiOff className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-800 block">بدون كرت شاشة خارجي</span>
                      <span className="text-[10px] text-slate-500">يمنع الشاشة السوداء</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 4: STANDALONE .EXE BUILDER & SAFE UPDATER                     */}
          {/* ================================================================= */}
          {activeTab === 'exe' && (
            <div className="space-y-4">
              {/* Instant .EXE Online & Offline Update Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50/90 to-emerald-50/90 border border-blue-200 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 text-blue-600" />
                      <span>تحديث نسخة الـ (.EXE) الفوري ومزامنة البيانات (v{APP_VERSION})</span>
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                      يقوم بتحديث ملفات نسخة الـ <strong>.EXE</strong> فوراً ومزامنة الفواتير والأصناف مع الموبايل والكمبيوتر مع الحفاظ الكامل 100% على قاعدة البيانات وتفعيل السيريل في <code>%APPDATA%\AKStorePOS_Data</code>.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={async () => {
                      showToast('جاري تأمين البيانات وتحديث نسخة الـ EXE...', 'info');
                      await syncDatabaseAndLicenseToSafeVault();
                      await checkForSystemUpdate();
                      const res = await applySafeOnlineUpdateAndReload();
                      if (res.success) {
                        showToast(res.messageAr, 'success');
                      }
                    }}
                    className="neu-button-primary py-2.5 px-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>تحديث نسخة الـ .EXE الآن (Online)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      downloadExeAutoUpdaterScriptBat();
                      showToast('تم تحميل أداة التحديث الآمن لنسخة الـ EXE (AK_Store_EXE_Updater_Tool.bat)!', 'success');
                    }}
                    className="neu-button py-2.5 px-3 rounded-xl font-bold text-emerald-800 bg-white border border-emerald-300 text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-600" />
                    <span>تحميل أداة تحديث الـ .EXE (.BAT)</span>
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-purple-950 text-sm">
                      بناء حزمة Setup.exe و Portable.exe لويندوز 7 / 8 / 10 / 11 (32-bit &amp; 64-bit)
                    </h4>
                    <p className="text-[11px] text-purple-800 mt-1 leading-relaxed">
                      تعتمد أداة البناء على <strong>Electron v22.3.27 LTS</strong> المتوافق مع <strong>Windows 7 SP1 (نواتي 32-bit و 64-bit)</strong> و Windows 8.1 و Windows 10 و Windows 11، مع حفظ البيانات في مجلد آمن دائم لا يُمسح عند التحديث.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadExeBuilder}
                  className="neu-button-primary w-full py-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل أداة البناء التلقائي لملف الـ EXE (AK_Store_Build_Win7_to_11_EXE.bat)</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3 bg-slate-100/80 border-t border-slate-200/70 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
            <HelpCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>
              {tr(
                'للويندوز: حمّل "معالج التسطيب (.HTA)" أو "المثبت التلقائي (.BAT)" · للتليفون: امسح كود QR أو اضغط "تسطيب التطبيق".',
                'For Windows: Download the .HTA Wizard or .BAT Setup · For Mobile: Scan the QR code or tap Install App.'
              )}
            </span>
          </div>
          {!asPage && (
            <button
              type="button"
              onClick={onClose}
              className="neu-button px-4 py-1.5 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
            >
              {tr('إغلاق', 'Close')}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
