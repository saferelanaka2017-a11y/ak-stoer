/**
 * @file components/ConfirmModal.tsx
 * نافذة تأكيد الإجراءات الحساسة (الحذف، إعادة التعيين) بتصميم زجاجي ناعم
 * Soft Glass Neumorphic Confirmation Dialog
 */

import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText,
  cancelText,
  isDestructive = true,
  onConfirm,
  onCancel
}) => {
  const { tr } = useApp();
  if (!isOpen) return null;

  const resolvedConfirmText = confirmText || tr('تأكيد', 'Confirm');
  const resolvedCancelText = cancelText || tr('إلغاء', 'Cancel');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="neu-card bg-[#e9eff5] w-full max-w-md p-6 rounded-3xl shadow-2xl space-y-4 border border-white/80">
        <div className="flex items-start gap-3">
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
              isDestructive ? 'bg-red-50 text-red-500 shadow-inner' : 'bg-blue-50 text-blue-600 shadow-inner'
            }`}
          >
            {isDestructive ? <Trash2 className="w-6 h-6 animate-pulse" /> : <AlertTriangle className="w-6 h-6" />}
          </div>
          <div className="flex-1">
            <h3 className="text-base font-bold text-slate-800">{title}</h3>
            <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{message}</p>
          </div>
          <button
            onClick={onCancel}
            className="neu-button p-1.5 rounded-xl text-slate-400 hover:text-slate-600 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="neu-button px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-800 cursor-pointer"
          >
            {resolvedCancelText}
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm();
              onCancel();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md flex items-center gap-1.5 cursor-pointer ${
              isDestructive
                ? 'bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'
            }`}
          >
            {isDestructive && <Trash2 className="w-3.5 h-3.5" />}
            <span>{resolvedConfirmText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
