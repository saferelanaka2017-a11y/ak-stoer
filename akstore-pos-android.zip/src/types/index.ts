/**
 * @file types/index.ts
 * تعريف كافة النماذج والأنواع المستخدمة في نظام نقاط البيع
 * Full Type Definitions for POS App
 */

export type UserRole = 'admin' | 'cashier';

export interface UserPermissions {
  // صلاحيات الوصول للشاشات والأقسام (Module / Screen Access)
  viewDashboard: boolean;
  accessPOS: boolean;
  viewSalesInvoices?: boolean;
  viewProducts: boolean;
  viewPurchases: boolean;
  viewSalesReturns: boolean;
  viewPurchaseReturns: boolean;
  viewCustomers: boolean;
  viewInstallments: boolean;
  viewExpenses: boolean;
  viewReports: boolean;
  viewSettings: boolean;
  manageUsers: boolean;

  // صلاحيات العمليات الحساسة والإجراءات (Action & Operational Permissions)
  canAddProduct: boolean;
  canEditProduct: boolean;
  canDelete: boolean;
  canDiscountPOS: boolean;
  canEditPricePOS: boolean;
  canExportData: boolean;
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  jobTitle?: string;
  phone?: string;
  isActive?: boolean;
  permissions?: UserPermissions;
  passwordHash?: string;
  avatar?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Product {
  id: string;
  barcode: string;
  sku?: string;
  name: string;
  category: string;
  costPrice: number;
  salePrice: number;
  baseCostPrice?: number; // سعر التكلفة (الشراء) بالعملة الأساسية المرجعية
  baseSalePrice?: number; // سعر البيع بالعملة الأساسية المرجعية
  stock: number;
  minStockAlert: number;
  unit: string;
  image?: string;
  description?: string;
  warehouseStock?: Record<string, number>; // توزيع الكميات حسب المستودع { [warehouseId]: quantity }
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  price: number;
  discount: number;
  tax: number;
  total: number;
}

export type PaymentMethod = 'cash' | 'card' | 'credit' | 'split';

export interface SaleInvoice {
  id: string;
  invoiceNumber: string;
  date: string;
  cashierId: string;
  cashierName: string;
  customerId?: string;
  customerName?: string;
  items: CartItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paidAmount: number;
  changeAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
  hasInstallment?: boolean;
  installmentCount?: number;
  downPayment?: number;
  remainingInstallmentAmount?: number;
  monthlyInstallmentAmount?: number;
  // Multi-Currency fields
  currency?: string; // رمز العملة (مثل USD, SAR)
  currencySymbol?: string; // رمز العرض (مثل $, ر.س)
  exchangeRate?: number; // سعر الصرف المستخدم وقت الفاتورة (مقابل العملة الأساسية)
  foreignGrandTotal?: number; // إجمالي الفاتورة بالعملة الأجنبية
  foreignPaidAmount?: number; // المدفوع بالعملة الأجنبية
  // Multi-Warehouse fields
  warehouseId?: string; // المستودع المنصرف منه
  warehouseName?: string;
}

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  date: string;
  supplierId: string;
  supplierName: string;
  items: {
    productId: string;
    productName: string;
    barcode: string;
    costPrice: number;
    quantity: number;
    total: number;
  }[];
  grandTotal: number;
  paidAmount: number;
  remainingAmount: number;
  notes?: string;
  // Multi-Currency fields
  currency?: string; // عملة الشراء
  currencySymbol?: string;
  exchangeRate?: number; // سعر الصرف
  foreignGrandTotal?: number; // إجمالي الشراء بالعملة الأجنبية
  foreignPaidAmount?: number;
  // Multi-Warehouse fields
  warehouseId?: string; // المستودع المستلم فيه
  warehouseName?: string;
}

export interface ReturnInvoice {
  id: string;
  returnNumber: string;
  type: 'sale' | 'purchase';
  originalInvoiceNumber: string;
  date: string;
  entityName: string; // Customer or Supplier name
  items: {
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    refundTotal: number;
  }[];
  totalRefund: number;
  reason: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  balance: number; // Positive = owes us money (ديون له), Negative = credit
  taxNumber?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  companyName: string;
  balance: number; // Positive = we owe them money
  taxNumber?: string;
  address?: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  title: string;
  category: string;
  amount: number;
  date: string;
  notes?: string;
  recordedBy: string;
}

export type InstallmentStatus = 'paid' | 'pending' | 'overdue';

export interface InstallmentItem {
  id: string;
  installmentNumber: number;
  dueDate: string;
  amount: number;
  status: InstallmentStatus;
  paidDate?: string;
  paidAmount?: number;
  notes?: string;
}

export interface InstallmentPlan {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  originalAmount?: number; // المبلغ الأصلي قبل الفائدة (قيمة الفاتورة)
  interestAmount?: number; // مبلغ الفائدة (مخفي عن الفاتورة)
  interestRate?: number; // نسبة الفائدة % (إن وجدت)
  totalAmount: number; // إجمالي التمويل بالتقسيط (الأصل + الفائدة)
  downPayment: number;
  remainingAmount: number;
  installmentCount: number;
  startDate: string;
  installments: InstallmentItem[];
}

export type PrinterType = 'thermal-80' | 'thermal-58' | 'a4-standard' | 'system-dialog' | 'pdf-export';

export interface CurrencyRate {
  id: string;
  code: string; // كود العملة (SAR, USD, EUR, EGP, AED, KWD...)
  name: string; // اسم العملة بالعربية
  symbol: string; // رمز العملة (ر.س, $, €, ج.م...)
  exchangeRate: number; // سعر الصرف مقابل العملة الأساسية (1 وحدة أجنبية = exchangeRate وحدة أساسية)
  isBase?: boolean; // هل هي العملة الأساسية للنظام (سعر صرفها دائماً 1.0)
  updatedAt?: string;
}

export interface Warehouse {
  id: string;
  name: string; // اسم المستودع (مثل: المستودع الرئيسي، فرع المعرض)
  code: string; // رمز المستودع (مثل: WH-01، WH-MAIN)
  location: string; // العنوان أو الموقع
  managerName?: string; // مسؤول المستودع
  phone?: string; // هاتف التواصل
  isDefault: boolean; // هل هو المستودع الافتراضي للبيع والصرف
  notes?: string;
  createdAt: string;
}

export interface WarehouseTransfer {
  id: string;
  transferNumber: string;
  date: string;
  fromWarehouseId: string;
  fromWarehouseName: string;
  toWarehouseId: string;
  toWarehouseName: string;
  productId: string;
  productName: string;
  barcode: string;
  quantity: number;
  notes?: string;
  transferredBy: string;
}

export interface ExchangeRateLog {
  id: string;
  date: string;
  currencyCode: string;
  currencyName: string;
  oldRate: number;
  newRate: number;
  affectedProductsCount: number;
  actionType: 'rate_update' | 'currency_switch' | 'base_change' | 'bulk_reprice';
  notes?: string;
}

export type AppThemeId =
  | 'ocean-blue'
  | 'emerald-mint'
  | 'royal-violet'
  | 'rose-sunset'
  | 'amber-gold'
  | 'cyber-teal'
  | 'midnight-dark';

export interface StoreSettings {
  storeName: string;
  storePhone: string;
  storeAddress: string;
  taxNumber: string;
  crNumber: string; // Commercial Registration
  vatPercentage: number;
  installmentInterestPercentage?: number; // نسبة فائدة التقسيط الافتراضية (%)
  currency: string;
  currencySymbol: string;
  // إعدادات تعدد العملات وأسعار الصرف
  enableMultiCurrency?: boolean;
  baseCurrency?: string; // كود العملة الأساسية (افتراضياً EGP)
  activeCurrency?: string; // العملة النشطة للعرض في واجهة الكاشير
  currencies?: CurrencyRate[]; // قائمة كافة العملات وأسعار صرفها
  autoUpdatePricesOnRateChange?: boolean; // تحديث أسعار البيع والشراء تلقائياً عند تعديل سعر الصرف يدوياً
  exchangeRateLogs?: ExchangeRateLog[]; // سجل تعديلات أسعار الصرف وتأثيرها على أسعار البيع والشراء
  // إعدادات تعدد المخازن والمستودعات
  enableMultiWarehouse?: boolean;
  defaultWarehouseId?: string; // معرف المستودع الافتراضي
  warehouses?: Warehouse[]; // قائمة المستودعات
  printLayout: 'thermal' | 'a4';
  logoUrl?: string;
  footerNotes: string;
  enableZatcaQR: boolean;
  language: 'ar' | 'en';
  appTheme?: AppThemeId; // لون ومظهر البرنامج العصري
  // Printer & Instant Print Configuration
  selectedPrinter?: PrinterType;
  printerCustomName?: string;
  autoPrintOnSale?: boolean;
  showPrinterDialogBeforePrint?: boolean;
  // Windows 7 / 8 / 10 / 11 Ultra-Lite Performance Mode for Low-Spec Hardware
  lowSpecMode?: boolean;
}



